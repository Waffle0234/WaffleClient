<script lang="ts" generics="T extends string">
  let {
    options,
    value,
    label,
    onchange,
  }: {
    options: { value: T; label: string }[];
    value: T;
    label: string;
    onchange: (value: T) => void;
  } = $props();

  const name = $props.id();
</script>

<div role="radiogroup" aria-label={label} class="inline-flex rounded-md border border-line bg-surface p-0.5">
  {#each options as option (option.value)}
    <label class="relative">
      <input
        type="radio"
        class="peer sr-only"
        {name}
        value={option.value}
        checked={value === option.value}
        onchange={() => onchange(option.value)}
      />
      <span
        class="block cursor-pointer rounded-sm px-3 py-1.5 text-sm text-muted transition-colors peer-checked:bg-accent peer-checked:font-medium peer-checked:text-on-accent peer-focus-visible:outline-2 peer-focus-visible:outline-offset-2 peer-focus-visible:outline-accent"
      >
        {option.label}
      </span>
    </label>
  {/each}
</div>
