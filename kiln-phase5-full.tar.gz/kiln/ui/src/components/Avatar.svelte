<script lang="ts">
  // Draws the player's head (face plus hat layer) straight from the 64x64 skin texture.
  let { skinUrl, name, size = 40 }: { skinUrl: string | null; name: string; size?: number } = $props();

  const scale = $derived(size / 8);
  let failed = $state(false);
</script>

{#if skinUrl && !failed}
  <div
    class="relative shrink-0 overflow-hidden rounded-sm bg-raised"
    style:width="{size}px"
    style:height="{size}px"
    role="img"
    aria-label="Skin of {name}"
  >
    <div
      class="pixelated absolute inset-0"
      style:background-image="url({skinUrl})"
      style:background-size="{64 * scale}px {64 * scale}px"
      style:background-position="{-8 * scale}px {-8 * scale}px"
    ></div>
    <div
      class="pixelated absolute inset-0"
      style:background-image="url({skinUrl})"
      style:background-size="{64 * scale}px {64 * scale}px"
      style:background-position="{-40 * scale}px {-8 * scale}px"
    ></div>
    <!-- Detects a texture that fails to load so we can fall back to the initial. -->
    <img class="hidden" src={skinUrl} alt="" onerror={() => (failed = true)} />
  </div>
{:else}
  <div
    class="flex shrink-0 items-center justify-center rounded-sm bg-raised font-display font-semibold text-muted"
    style:width="{size}px"
    style:height="{size}px"
    aria-hidden="true"
  >
    {name.slice(0, 1).toUpperCase()}
  </div>
{/if}
