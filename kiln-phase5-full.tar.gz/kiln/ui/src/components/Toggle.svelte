<script lang="ts">
  let {
    checked,
    label,
    onchange,
  }: { checked: boolean; label: string; onchange: (value: boolean) => void } = $props();
</script>

<button
  type="button"
  role="switch"
  aria-checked={checked}
  aria-label={label}
  class="relative h-6 w-11 shrink-0 cursor-pointer rounded-full border border-line transition-colors {checked
    ? 'bg-accent'
    : 'bg-raised'}"
  onclick={() => onchange(!checked)}
>
  <span
    class="absolute top-0.5 left-0.5 size-4.5 rounded-full transition-transform {checked
      ? 'translate-x-5 bg-on-accent'
      : 'bg-muted'}"
  ></span>
</button>
