<script lang="ts">
  let { title, body, phase }: { title: string; body: string; phase: number } = $props();
</script>

<section class="max-w-prose">
  <h1 class="font-display text-5xl font-semibold tracking-tight">{title}</h1>
  <p class="mt-4 text-lg leading-relaxed text-muted">{body}</p>
  <p class="mt-8 border-l-2 border-accent pl-4 text-sm text-muted">
    This screen is built in Phase {phase} of the roadmap.
  </p>
</section>
