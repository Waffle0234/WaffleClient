import { api, errorCode, errorMessage, type Account, type DeviceCodeInfo } from './api';

export type Flow =
  | { phase: 'idle' }
  | { phase: 'starting' }
  | { phase: 'waiting'; code: DeviceCodeInfo; expiresAt: number };

class AccountsStore {
  list = $state<Account[]>([]);
  loaded = $state(false);
  flow = $state<Flow>({ phase: 'idle' });
  error = $state<string | null>(null);

  async load(): Promise<void> {
    try {
      this.list = await api.authListAccounts();
      this.error = null;
    } catch (e) {
      this.error = errorMessage(e);
    } finally {
      this.loaded = true;
    }
  }

  /** Runs the whole device-code sign-in; resolves when it succeeds, fails or is cancelled. */
  async signIn(): Promise<void> {
    if (this.flow.phase !== 'idle') return;
    this.error = null;
    this.flow = { phase: 'starting' };
    try {
      const code = await api.authBeginDeviceFlow();
      this.flow = { phase: 'waiting', code, expiresAt: Date.now() + code.expires_in * 1000 };
      await api.authPoll();
      await this.load();
    } catch (e) {
      // Cancelling is a normal outcome, not an error worth showing.
      if (errorCode(e) !== 'auth_cancelled') this.error = errorMessage(e);
    } finally {
      this.flow = { phase: 'idle' };
    }
  }

  async cancel(): Promise<void> {
    try {
      await api.authCancel();
    } catch (e) {
      this.error = errorMessage(e);
    }
  }

  async openVerificationPage(): Promise<void> {
    try {
      await api.authOpenVerificationPage();
    } catch (e) {
      this.error = errorMessage(e);
    }
  }

  async setActive(id: string): Promise<void> {
    try {
      await api.authSetActive(id);
      await this.load();
    } catch (e) {
      this.error = errorMessage(e);
    }
  }

  async remove(id: string): Promise<void> {
    try {
      await api.authRemove(id);
      await this.load();
    } catch (e) {
      this.error = errorMessage(e);
    }
  }
}

export const accounts = new AccountsStore();
