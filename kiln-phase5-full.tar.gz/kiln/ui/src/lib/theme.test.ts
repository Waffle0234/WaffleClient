import { describe, expect, it } from 'vitest';
import { onAccent, resolveTheme } from './theme';
import { parseHash } from './routes';
import { formatBytes, formatPlaytime, loaderLabel, progressPercent } from './format';

describe('onAccent', () => {
  it('uses dark text on light accents and white on dark accents', () => {
    expect(onAccent('#5fb99a')).toBe('#10201b');
    expect(onAccent('#ffd166')).toBe('#10201b');
    expect(onAccent('#1d3557')).toBe('#ffffff');
    expect(onAccent('#000000')).toBe('#ffffff');
  });
});

describe('resolveTheme', () => {
  it('follows the OS only for the system theme', () => {
    expect(resolveTheme('system', true)).toBe('dark');
    expect(resolveTheme('system', false)).toBe('light');
    expect(resolveTheme('light', true)).toBe('light');
    expect(resolveTheme('dark', false)).toBe('dark');
  });
});

describe('parseHash', () => {
  it('maps hashes to routes and falls back to home', () => {
    expect(parseHash('#/settings')).toBe('settings');
    expect(parseHash('#instances')).toBe('instances');
    expect(parseHash('#/instances/abc')).toBe('instances');
    expect(parseHash('')).toBe('home');
    expect(parseHash('#/nope')).toBe('home');
  });
});

describe('formatBytes', () => {
  it('scales units and keeps numbers short', () => {
    expect(formatBytes(0)).toBe('0 B');
    expect(formatBytes(1536)).toBe('1.5 KB');
    expect(formatBytes(5 * 1024 * 1024)).toBe('5.0 MB');
    expect(formatBytes(250 * 1024 * 1024)).toBe('250 MB');
    expect(formatBytes(-1)).toBe('0 B');
    expect(formatBytes(Number.NaN)).toBe('0 B');
  });
});

describe('progressPercent', () => {
  const p = (done: number, total: number) => ({ bytes_done: done, bytes_total: total, files_done: 0, files_total: 0 });
  it('is null until the total is known, and never exceeds 100', () => {
    expect(progressPercent(null)).toBeNull();
    expect(progressPercent(p(5, 0))).toBeNull();
    expect(progressPercent(p(50, 200))).toBe(25);
    expect(progressPercent(p(300, 200))).toBe(100);
  });
});

describe('formatPlaytime and loaderLabel', () => {
  it('reads naturally', () => {
    expect(formatPlaytime(10)).toBe('less than a minute');
    expect(formatPlaytime(90)).toBe('1 min');
    expect(formatPlaytime(3600)).toBe('1 h');
    expect(formatPlaytime(7500)).toBe('2 h 5 min');
    expect(loaderLabel('fabric', '0.16.5')).toBe('Fabric 0.16.5');
    expect(loaderLabel('vanilla', null)).toBe('Vanilla');
  });
});
