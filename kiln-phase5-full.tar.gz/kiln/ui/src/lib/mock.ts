// Browser-only stand-in for the Rust backend, used by `npm run dev` outside Tauri.
import type {
  Account,
  AppError,
  AppInfo,
  ImportFile,
  Instance,
  InstallPlan,
  LaunchStatus,
  LoaderId,
  LogLine,
  ModEntry,
  SearchHit,
  Settings,
  TaskProgress,
  UpdateInfo,
  VersionSummary,
} from './api';

let settings: Settings = {
  theme: 'system',
  accent_color: '#5fb99a',
  animated_background: false,
  reduce_motion: false,
  max_concurrent_downloads: 8,
  default_ram_mb: null,
  check_updates_on_start: true,
  log_level: 'info',
};

let accounts: Account[] = [];
let cancelPoll: (() => void) | null = null;

const info: AppInfo = {
  name: 'Kiln',
  version: '0.1.0-dev',
  os: 'browser',
  arch: 'n/a',
  portable: false,
  data_dir: '(not available in the browser preview)',
};

type StatusListener = (s: LaunchStatus) => void;
type LogListener = (l: LogLine) => void;
const statusListeners = new Set<StatusListener>();
const logListeners = new Set<LogListener>();
let launchState: LaunchStatus = { state: 'idle' };
const launchLines: LogLine[] = [];
let mockInstances: Instance[] = [
  {
    id: 'a'.repeat(32),
    name: 'Survival',
    mc_version: '1.21.1',
    loader: 'fabric',
    loader_version: '0.16.5',
    java_id: null,
    jvm_args: null,
    ram_mb: 4096,
    created_at: 1_700_000_000,
    last_played: 1_730_000_000,
    playtime_s: 7500,
  },
];
const mockImports: ImportFile[] = [{ name: 'cool-pack.mrpack', size: 12_582_912 }];
let launchTimer: ReturnType<typeof setInterval> | null = null;

const versions: VersionSummary[] = [
  { id: '1.21.1', kind: 'release', release_time: '2024-08-08T12:24:00+00:00' },
  { id: '24w33a', kind: 'snapshot', release_time: '2024-08-14T13:00:00+00:00' },
  { id: '1.20.6', kind: 'release', release_time: '2024-04-29T10:00:00+00:00' },
];

// ---- mods (Modrinth stand-in) -------------------------------------------------------

type ProgressListener = (p: TaskProgress) => void;
const progressListeners = new Set<ProgressListener>();

export function mockListenProgress(on: ProgressListener): () => void {
  progressListeners.add(on);
  return () => progressListeners.delete(on);
}

const catalog: (SearchHit & { latest: string; requires?: string })[] = [
  { id: 'AANobbMI', slug: 'sodium', title: 'Sodium', description: 'A modern rendering engine for Minecraft.', author: 'jellysquid3', kind: 'mod', downloads: 52_400_000, follows: 90_000, icon_url: null, categories: ['optimization'], client_side: 'required', server_side: 'unsupported', license: 'LGPL-3.0-only', latest: '0.6.0' },
  { id: 'gvQqBUqZ', slug: 'lithium', title: 'Lithium', description: 'A server-side optimisation mod.', author: 'jellysquid3', kind: 'mod', downloads: 38_100_000, follows: 61_000, icon_url: null, categories: ['optimization'], client_side: 'optional', server_side: 'required', license: 'LGPL-3.0-only', latest: '0.13.0' },
  { id: 'mOgUt4GM', slug: 'modmenu', title: 'Mod Menu', description: 'Adds a screen listing your mods.', author: 'Prospector', kind: 'mod', downloads: 41_000_000, follows: 40_000, icon_url: null, categories: ['utility'], client_side: 'required', server_side: 'unsupported', license: 'MIT', latest: '11.0.0', requires: 'P7dR8mSH' },
  { id: 'P7dR8mSH', slug: 'fabric-api', title: 'Fabric API', description: 'The core library most Fabric mods need.', author: 'modmuss50', kind: 'mod', downloads: 99_000_000, follows: 120_000, icon_url: null, categories: ['library'], client_side: 'required', server_side: 'required', license: 'Apache-2.0', latest: '0.100.0' },
  { id: 'BeGpAcks', slug: 'demo-pack', title: 'Demo Adventure Pack', description: 'A small pack to try the installer.', author: 'someone', kind: 'modpack', downloads: 12_345, follows: 100, icon_url: null, categories: ['adventure'], client_side: 'required', server_side: 'optional', license: 'MIT', latest: '1.0.0' },
];

let nextModId = 100;
const modsByInstance = new Map<string, ModEntry[]>();

function modsOf(id: unknown): ModEntry[] {
  const key = String(id);
  if (!mockInstances.some((i) => i.id === key)) {
    throw { code: 'instance_not_found', message: 'That instance no longer exists.' } satisfies AppError;
  }
  if (!modsByInstance.has(key)) {
    modsByInstance.set(key, [
      mockEntry('lithium', '0.12.0', 'user'),
      { ...mockEntry('', '', 'user'), file_name: 'homebrew-tweaks.jar', source: 'unverified', project_id: null, title: null, author: null, license: null, downloads: null, version_number: null },
    ]);
  }
  return modsByInstance.get(key) ?? [];
}

function mockEntry(slug: string, version: string, installedAs: 'user' | 'dependency'): ModEntry {
  const c = catalog.find((x) => x.slug === slug);
  return {
    id: nextModId++,
    file_name: `${slug}-${version}.jar`,
    source: 'modrinth',
    project_id: c?.id ?? null,
    version_id: `v${version}`,
    version_number: version,
    pinned: false,
    enabled: true,
    size: 800_000,
    title: c?.title ?? null,
    author: c?.author ?? null,
    license: c?.license ?? null,
    downloads: c?.downloads ?? null,
    icon_url: null,
    channel: 'release',
    installed_as: installedAs,
  };
}

function pendingUpdates(list: ModEntry[]): UpdateInfo[] {
  return list.flatMap((m) => {
    const c = catalog.find((x) => x.id === m.project_id);
    if (!c || !m.enabled || m.version_number === c.latest) return [];
    return [{ mod_id: m.id, file_name: m.file_name, title: c.title, current_version: m.version_number, new_version: c.latest, new_version_id: `v${c.latest}`, channel: 'release' as const, changelog: `Changes in ${c.latest}\n- Faster\n- Fewer bugs`, pinned: m.pinned }];
  });
}

function mockPlan(list: ModEntry[], projectId: string): InstallPlan {
  const c = catalog.find((x) => x.id === projectId || x.slug === projectId);
  if (!c) throw { code: 'mod_not_found', message: "Modrinth doesn't have that project." } satisfies AppError;
  const have = new Set(list.map((m) => m.project_id));
  const wanted = [c, ...(c.requires ? [catalog.find((x) => x.id === c.requires)] : [])].filter((x): x is NonNullable<typeof x> => !!x && !have.has(x.id));
  return {
    mods: wanted.map((w, i) => ({ project_id: w.id, title: w.title, version_id: `v${w.latest}`, version_number: w.latest, channel: 'release' as const, file_name: `${w.slug}-${w.latest}.jar`, size: 900_000, reason: i === 0 ? ('requested' as const) : ('dependency' as const), icon_url: null })),
    optional: [],
    conflicts: [],
    already_installed: have.has(c.id) ? [c.title] : [],
  };
}

async function mockWork(task: TaskProgress['task']): Promise<void> {
  for (let i = 1; i <= 4; i++) {
    await new Promise((r) => setTimeout(r, 120));
    progressListeners.forEach((l) => l({ task, progress: { bytes_done: i * 250_000, bytes_total: 1_000_000, files_done: i, files_total: 4 } }));
  }
}

export function mockListen(onStatus: StatusListener, onLog: LogListener): () => void {
  statusListeners.add(onStatus);
  logListeners.add(onLog);
  return () => {
    statusListeners.delete(onStatus);
    logListeners.delete(onLog);
  };
}

function setLaunch(s: LaunchStatus) {
  launchState = s;
  statusListeners.forEach((l) => l(s));
}

function mockLine(text: string, stream: LogLine['stream'] = 'stdout') {
  const line = { stream, text };
  launchLines.push(line);
  logListeners.forEach((l) => l(line));
}

function mockStartLaunch() {
  launchLines.length = 0;
  let files = 0;
  setLaunch({ state: 'preparing', stage: 'Downloading game files', progress: null });
  launchTimer = setInterval(() => {
    files += 150;
    if (files <= 600) {
      setLaunch({
        state: 'preparing',
        stage: 'Downloading game files',
        progress: { bytes_done: files * 40_000, bytes_total: 600 * 40_000, files_done: files, files_total: 600 },
      });
      return;
    }
    if (launchState.state === 'preparing') {
      setLaunch({ state: 'running', pid: 4242 });
      mockLine('[Render thread/INFO]: Setting user: Player_1');
      mockLine('[Render thread/WARN]: This is only a browser preview', 'stderr');
      return;
    }
    mockLine(`[Server thread/INFO]: tick ${launchLines.length}`);
  }, 700);
}

function mockStopLaunch() {
  if (launchTimer) clearInterval(launchTimer);
  launchTimer = null;
  setLaunch(launchState.state === 'running' ? { state: 'exited', code: null } : { state: 'idle' });
}

export async function mockInvoke(cmd: string, args?: Record<string, unknown>): Promise<unknown> {
  switch (cmd) {
    case 'get_app_info':
      return info;
    case 'get_settings':
      return settings;
    case 'set_setting': {
      const key = String(args?.key);
      if (!(key in settings)) {
        throw { code: 'unknown_setting', message: `Kiln has no setting called "${key}".` } satisfies AppError;
      }
      settings = { ...settings, [key]: args?.value };
      return settings;
    }
    case 'auth_begin_device_flow':
      return { user_code: 'DEMO1234', verification_uri: 'https://www.microsoft.com/link', expires_in: 900 };
    case 'auth_open_verification_page':
      return undefined;
    case 'auth_poll':
      return new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
          cancelPoll = null;
          const n = accounts.length + 1;
          const account: Account = {
            id: String(n).repeat(32),
            username: `Player_${n}`,
            skin_url: null,
            skin_variant: null,
            cape_url: null,
            last_used: Date.now() / 1000,
            is_active: true,
            needs_reauth: false,
          };
          accounts = [account, ...accounts.map((a) => ({ ...a, is_active: false }))];
          resolve(account);
        }, 4000);
        cancelPoll = () => {
          clearTimeout(timer);
          reject({ code: 'auth_cancelled', message: 'Sign-in was cancelled.' } satisfies AppError);
        };
      });
    case 'auth_cancel':
      cancelPoll?.();
      cancelPoll = null;
      return undefined;
    case 'auth_list_accounts':
      return accounts;
    case 'auth_set_active':
      accounts = accounts.map((a) => ({ ...a, is_active: a.id === args?.id }));
      return accounts.find((a) => a.is_active);
    case 'auth_remove':
      accounts = accounts.filter((a) => a.id !== args?.id);
      return undefined;
    case 'picker_game_versions':
      // Loaders support fewer versions than vanilla: the real picker hides the rest.
      return args?.loader === 'vanilla' ? versions : versions.filter((v) => v.kind === 'release' && v.id !== '1.20.6');
    case 'picker_loader_versions':
      return [
        { version: '0.16.5', stable: true },
        { version: '0.17.0-beta.1', stable: false },
      ];
    case 'instance_list':
      return [...mockInstances].sort((a, b) => (b.last_played ?? b.created_at) - (a.last_played ?? a.created_at));
    case 'instance_create': {
      const name = String(args?.name ?? '').trim();
      if (!name || name.length > 64) throw { code: 'invalid_name', message: 'Instance names must be 1 to 64 characters with no control characters.' } satisfies AppError;
      const made: Instance = {
        id: Math.random().toString(16).slice(2).padEnd(32, '0'),
        name,
        mc_version: String(args?.mcVersion),
        loader: args?.loader as LoaderId,
        loader_version: (args?.loaderVersion as string | null) ?? null,
        java_id: null,
        jvm_args: null,
        ram_mb: null,
        created_at: Date.now() / 1000,
        last_played: null,
        playtime_s: 0,
      };
      mockInstances = [made, ...mockInstances];
      return made;
    }
    case 'instance_rename':
    case 'instance_update_settings': {
      const found = mockInstances.find((i) => i.id === args?.id);
      if (!found) throw { code: 'instance_not_found', message: 'That instance no longer exists.' } satisfies AppError;
      if (cmd === 'instance_rename') found.name = String(args?.name);
      else {
        const jvm = String(args?.jvmArgs ?? '').trim();
        if (/javaagent|OnError/i.test(jvm)) throw { code: 'invalid_jvm_args', message: "Those Java arguments aren't allowed: they could load code." } satisfies AppError;
        found.ram_mb = (args?.ramMb as number | null) ?? null;
        found.jvm_args = jvm || null;
      }
      return found;
    }
    case 'instance_clone': {
      const src = mockInstances.find((i) => i.id === args?.id);
      if (!src) throw { code: 'instance_not_found', message: 'That instance no longer exists.' } satisfies AppError;
      const copy = { ...src, id: Math.random().toString(16).slice(2).padEnd(32, '1'), name: String(args?.name), playtime_s: 0, last_played: null, created_at: Date.now() / 1000 };
      mockInstances = [copy, ...mockInstances];
      return copy;
    }
    case 'instance_delete':
      mockInstances = mockInstances.filter((i) => i.id !== args?.id);
      return undefined;
    case 'instance_export': {
      const mr = String(args?.format) === 'mrpack';
      return { file: mr ? 'pack.mrpack' : 'pack.kiln.zip', listed: mr ? 1 : 0, bundled_unverified: mr ? ['homebrew-tweaks.jar'] : [] };
    }
    case 'instance_list_imports':
      return mockImports;
    case 'instance_import':
      await mockWork('import');
      throw { code: 'invalid_pack', message: "Kiln can't use that pack: the browser preview can't import files." } satisfies AppError;
    case 'open_folder':
      return undefined;
    case 'launch_start':
      if (launchState.state === 'preparing' || launchState.state === 'running') {
        throw { code: 'already_running', message: 'A game is already running. Close it before starting another.' } satisfies AppError;
      }
      if (!mockInstances.some((i) => i.id === args?.instanceId)) {
        throw { code: 'instance_not_found', message: 'That instance no longer exists.' } satisfies AppError;
      }
      if (!accounts.some((a) => a.is_active)) {
        throw { code: 'no_account', message: 'Sign in with a Microsoft account on the Accounts page first.' } satisfies AppError;
      }
      mockStartLaunch();
      return undefined;
    case 'launch_stop':
      mockStopLaunch();
      return undefined;
    case 'launch_status':
      return launchState;
    case 'launch_log':
      return launchLines;
    case 'mod_search': {
      const q = (args?.query ?? {}) as { query?: string; kind?: string };
      const text = (q.query ?? '').toLowerCase();
      const hits = catalog.filter((c) => c.kind === q.kind && (text === '' || `${c.title} ${c.description}`.toLowerCase().includes(text)));
      return { hits, offset: 0, total: hits.length };
    }
    case 'mods_list':
      return modsOf(args?.instanceId).map((m) => ({ ...m }));
    case 'mod_install_plan':
      return mockPlan(modsOf(args?.instanceId), String(args?.projectId));
    case 'mod_install': {
      const list = modsOf(args?.instanceId);
      const plan = mockPlan(list, String(args?.projectId));
      await mockWork('mod-install');
      for (const p of plan.mods) {
        const c = catalog.find((x) => x.id === p.project_id);
        if (c) list.push(mockEntry(c.slug, c.latest, p.reason === 'requested' ? 'user' : 'dependency'));
      }
      return plan;
    }
    case 'mods_check_updates':
      return pendingUpdates(modsOf(args?.instanceId));
    case 'mod_update': {
      const m = modsOf(args?.instanceId).find((x) => x.id === args?.modId);
      if (!m) throw { code: 'unknown_mod', message: "That mod isn't in this instance any more." } satisfies AppError;
      if (m.pinned) throw { code: 'mod_pinned', message: 'That mod is pinned. Unpin it to update it.' } satisfies AppError;
      const c = catalog.find((x) => x.id === m.project_id);
      if (!c || m.version_number === c.latest) return false;
      await mockWork('mod-update');
      m.version_number = c.latest;
      m.file_name = `${c.slug}-${c.latest}.jar`;
      return true;
    }
    case 'mods_update_all': {
      const list = modsOf(args?.instanceId);
      const ups = pendingUpdates(list);
      await mockWork('mod-update');
      for (const u of ups.filter((x) => !x.pinned)) {
        const m = list.find((x) => x.id === u.mod_id);
        if (m) {
          m.version_number = u.new_version;
          m.file_name = `${u.title.toLowerCase()}-${u.new_version}.jar`;
        }
      }
      return { updated: ups.filter((x) => !x.pinned).map((x) => x.title), failed: [], skipped_pinned: ups.filter((x) => x.pinned).length };
    }
    case 'mod_set_pinned':
    case 'mod_set_enabled': {
      const m = modsOf(args?.instanceId).find((x) => x.id === args?.modId);
      if (!m) throw { code: 'unknown_mod', message: "That mod isn't in this instance any more." } satisfies AppError;
      if (cmd === 'mod_set_pinned') m.pinned = Boolean(args?.pinned);
      else m.enabled = Boolean(args?.enabled);
      return undefined;
    }
    case 'mod_remove': {
      const list = modsOf(args?.instanceId);
      modsByInstance.set(String(args?.instanceId), list.filter((x) => x.id !== args?.modId));
      return undefined;
    }
    case 'mods_rollback':
      modsOf(args?.instanceId);
      throw { code: 'nothing_to_roll_back', message: "There's no recent update to undo." } satisfies AppError;
    case 'modpack_install': {
      await mockWork('modpack');
      const base = mockInstances[0];
      if (!base) throw { code: 'instance_not_found', message: 'That instance no longer exists.' } satisfies AppError;
      const copy: Instance = { ...base, id: Math.random().toString(16).slice(2).padEnd(32, '2'), name: 'Demo Adventure Pack', playtime_s: 0, last_played: null, created_at: Date.now() / 1000 };
      mockInstances = [copy, ...mockInstances];
      return copy;
    }
    case 'modpack_check_update':
      return null;
    case 'modpack_update':
      return { result: 'up_to_date' };
    default:
      throw { code: 'unknown_command', message: `Unknown command ${cmd}` } satisfies AppError;
  }
}
