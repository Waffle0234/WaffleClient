import { parseHash, type RouteId } from './routes';

class Router {
  current = $state<RouteId>(parseHash(location.hash));

  go(id: RouteId): void {
    location.hash = `#/${id}`;
  }

  constructor() {
    window.addEventListener('hashchange', () => {
      this.current = parseHash(location.hash);
    });
  }
}

export const router = new Router();
