import { beforeEach, describe, expect, it, vi } from 'vitest';

vi.mock('./api', async () => {
  const actual = await vi.importActual<typeof import('./api')>('./api');
  return {
    ...actual,
    listenProgress: vi.fn(async () => () => {}),
    listenRollback: vi.fn(async () => () => {}),
    api: {
      modsList: vi.fn(),
      modInstallPlan: vi.fn(),
      modInstall: vi.fn(),
      modsCheckUpdates: vi.fn(),
      modUpdate: vi.fn(),
      modsUpdateAll: vi.fn(),
      modSetPinned: vi.fn(),
      modsRollback: vi.fn(),
      modSearch: vi.fn(),
    },
  };
});

import { api } from './api';
import { mods } from './mods.svelte';

const m = vi.mocked(api);
const plan = {
  mods: [{ project_id: 'AAAA', title: 'A', version_id: 'v1', version_number: '1', channel: 'release' as const, file_name: 'a.jar', size: 1, reason: 'requested' as const, icon_url: null }],
  optional: [],
  conflicts: [],
  already_installed: [],
};

beforeEach(async () => {
  vi.clearAllMocks();
  m.modsList.mockResolvedValue([]);
  m.modsCheckUpdates.mockResolvedValue([]);
  await mods.select('inst');
  mods.error = null;
  mods.notice = null;
});

describe('mods store', () => {
  it('reviews a plan, installs it and refreshes the list', async () => {
    m.modInstallPlan.mockResolvedValue(plan);
    m.modInstall.mockResolvedValue(plan);
    await mods.review({ id: 'AAAA', title: 'A' });
    expect(mods.plan).toEqual(plan);
    await mods.confirmInstall(['OPT']);
    expect(m.modInstall).toHaveBeenCalledWith('inst', 'AAAA', ['OPT']);
    expect(mods.notice).toBe('Installed A.');
    expect(mods.plan).toBeNull();
    expect(m.modsList).toHaveBeenCalledTimes(2);
  });

  it('shows the backend message and keeps the plan when an install fails', async () => {
    m.modInstallPlan.mockResolvedValue(plan);
    m.modInstall.mockRejectedValue({ code: 'hash_mismatch', message: 'A downloaded file didn’t match.' });
    await mods.review({ id: 'AAAA', title: 'A' });
    await mods.confirmInstall([]);
    expect(mods.error).toBe('A downloaded file didn’t match.');
    expect(mods.plan).not.toBeNull();
    expect(mods.busy).toBeNull();
  });

  it('reports pinned mods left alone by update all', async () => {
    m.modsUpdateAll.mockResolvedValue({ updated: ['B'], failed: [{ title: 'C', message: 'x' }], skipped_pinned: 2 });
    await mods.updateAll();
    expect(mods.notice).toBe('Updated 1. 2 pinned, left alone. 1 failed: C.');
  });

  it('does nothing without an instance and ignores a stale list', async () => {
    await mods.select(null);
    await mods.updateAll();
    expect(m.modsUpdateAll).not.toHaveBeenCalled();
  });

  it('says so when a rollback has nothing to undo', async () => {
    m.modsRollback.mockRejectedValue({ code: 'nothing_to_roll_back', message: "There's no recent update to undo." });
    await mods.rollback();
    expect(mods.error).toBe("There's no recent update to undo.");
  });
});
