export const routes = [
  { id: 'home', label: 'Home', icon: 'home' },
  { id: 'instances', label: 'Instances', icon: 'grid' },
  { id: 'mods', label: 'Mods', icon: 'box' },
  { id: 'accounts', label: 'Accounts', icon: 'user' },
  { id: 'console', label: 'Console', icon: 'terminal' },
  { id: 'settings', label: 'Settings', icon: 'sliders' },
] as const;

export type RouteId = (typeof routes)[number]['id'];

/** `#/settings` -> `settings`. Unknown or empty hashes fall back to Home. */
export function parseHash(hash: string): RouteId {
  const id = hash.replace(/^#\/?/, '').split('/')[0];
  return routes.find((r) => r.id === id)?.id ?? 'home';
}
