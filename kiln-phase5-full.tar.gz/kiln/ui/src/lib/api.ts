// Typed IPC layer. Every call to the Rust backend goes through here.
import { invoke } from '@tauri-apps/api/core';
import { listen } from '@tauri-apps/api/event';

export type Theme = 'system' | 'dark' | 'light';

export interface Settings {
  theme: Theme;
  accent_color: string;
  animated_background: boolean;
  reduce_motion: boolean;
  max_concurrent_downloads: number;
  default_ram_mb: number | null;
  check_updates_on_start: boolean;
  log_level: 'error' | 'warn' | 'info' | 'debug' | 'trace';
}

export interface AppInfo {
  name: string;
  version: string;
  os: string;
  arch: string;
  portable: boolean;
  data_dir: string;
}

export interface AppError {
  code: string;
  message: string;
}

export interface Account {
  id: string;
  username: string;
  skin_url: string | null;
  skin_variant: 'classic' | 'slim' | null;
  cape_url: string | null;
  last_used: number | null;
  is_active: boolean;
  /** The Microsoft sign-in expired or was revoked: sign in again. */
  needs_reauth: boolean;
}

export interface DeviceCodeInfo {
  user_code: string;
  verification_uri: string;
  expires_in: number;
}

export type LoaderId = 'vanilla' | 'fabric' | 'quilt' | 'neoforge' | 'forge';

export interface Instance {
  id: string;
  name: string;
  mc_version: string;
  loader: LoaderId;
  loader_version: string | null;
  java_id: string | null;
  jvm_args: string | null;
  ram_mb: number | null;
  created_at: number;
  last_played: number | null;
  playtime_s: number;
}

export interface LoaderVersion {
  version: string;
  stable: boolean;
}

export interface ImportFile {
  name: string;
  size: number;
}

export interface VersionSummary {
  id: string;
  kind: string;
  release_time: string;
}

export interface Progress {
  bytes_done: number;
  bytes_total: number;
  files_done: number;
  files_total: number;
}

export type LaunchStatus =
  | { state: 'idle' }
  | { state: 'preparing'; stage: string; progress: Progress | null }
  | { state: 'running'; pid: number }
  | { state: 'exited'; code: number | null }
  | { state: 'failed'; code: string; message: string };

export interface LogLine {
  stream: 'stdout' | 'stderr';
  text: string;
}

export type ProjectKind = 'mod' | 'modpack';
export type SortOrder = 'relevance' | 'downloads' | 'follows' | 'newest' | 'updated';

export interface SearchQuery {
  query: string;
  kind: ProjectKind;
  mc_version?: string | null;
  loader?: LoaderId | null;
  categories?: string[];
  sort?: SortOrder;
  offset?: number;
  limit?: number;
}

export interface SearchHit {
  id: string;
  slug: string;
  title: string;
  description: string;
  author: string;
  kind: ProjectKind;
  downloads: number;
  follows: number;
  icon_url: string | null;
  categories: string[];
  client_side: string;
  server_side: string;
  license: string | null;
}

export interface SearchPage {
  hits: SearchHit[];
  offset: number;
  total: number;
}

/** A jar Kiln tracks. `source` is `modrinth` or `unverified` (Modrinth doesn't know the file). */
export interface ModEntry {
  id: number;
  file_name: string;
  source: 'modrinth' | 'unverified';
  project_id: string | null;
  version_id: string | null;
  version_number: string | null;
  pinned: boolean;
  enabled: boolean;
  size: number | null;
  title: string | null;
  author: string | null;
  license: string | null;
  downloads: number | null;
  icon_url: string | null;
  channel: string | null;
  installed_as: 'user' | 'dependency';
}

export interface PlannedMod {
  project_id: string;
  title: string;
  version_id: string;
  version_number: string;
  channel: 'release' | 'beta' | 'alpha';
  file_name: string;
  size: number;
  reason: 'requested' | 'dependency';
  icon_url: string | null;
}

export interface InstallPlan {
  mods: PlannedMod[];
  optional: { project_id: string; title: string }[];
  conflicts: { title: string; conflicts_with: string }[];
  already_installed: string[];
}

export interface UpdateInfo {
  mod_id: number;
  file_name: string;
  title: string;
  current_version: string | null;
  new_version: string;
  new_version_id: string;
  channel: 'release' | 'beta' | 'alpha';
  changelog: string | null;
  pinned: boolean;
}

export interface UpdateAllReport {
  updated: string[];
  failed: { title: string; message: string }[];
  skipped_pinned: number;
}

export interface RollbackReport {
  instance_id: string;
  restored: string[];
  removed: string[];
  failed: string[];
}

export interface PackUpdateInfo {
  version_id: string;
  version_number: string;
  changelog: string | null;
}

export type PackUpdateOutcome = { result: 'up_to_date' } | { result: 'updated'; version_number: string };

export interface ExportResult {
  file: string;
  /** Mods listed by Modrinth hash instead of being copied into the pack. */
  listed: number;
  /** Jars Modrinth doesn't know; they are bundled, so check you may share them. */
  bundled_unverified: string[];
}

export interface TaskProgress {
  task: 'import' | 'mod-install' | 'mod-update' | 'modpack';
  progress: Progress;
}

const inTauri = typeof window !== 'undefined' && '__TAURI_INTERNALS__' in window;

async function call<T>(cmd: string, args?: Record<string, unknown>): Promise<T> {
  if (inTauri) return invoke<T>(cmd, args);
  if (import.meta.env.DEV) {
    // Plain `vite dev` in a browser: use the in-memory stand-in. Stripped from production builds.
    const { mockInvoke } = await import('./mock');
    return mockInvoke(cmd, args) as Promise<T>;
  }
  throw { code: 'no_backend', message: 'Kiln must be opened through its desktop app.' } satisfies AppError;
}

/** Plain-English text for any error thrown by an IPC call. */
export function errorMessage(e: unknown): string {
  if (typeof e === 'object' && e !== null && 'message' in e && typeof e.message === 'string') {
    return e.message;
  }
  return 'Something went wrong. Try again, and check the logs if it keeps happening.';
}

export function errorCode(e: unknown): string | null {
  return typeof e === 'object' && e !== null && 'code' in e && typeof e.code === 'string' ? e.code : null;
}

export const api = {
  getAppInfo: () => call<AppInfo>('get_app_info'),
  getSettings: () => call<Settings>('get_settings'),
  setSetting: <K extends keyof Settings>(key: K, value: Settings[K]) =>
    call<Settings>('set_setting', { key, value }),

  // Accounts. No call here ever returns a token.
  authBeginDeviceFlow: () => call<DeviceCodeInfo>('auth_begin_device_flow'),
  /** Resolves when the user finishes signing in; rejects with code `auth_cancelled` if cancelled. */
  authPoll: () => call<Account>('auth_poll'),
  authCancel: () => call<void>('auth_cancel'),
  authOpenVerificationPage: () => call<void>('auth_open_verification_page'),
  authListAccounts: () => call<Account[]>('auth_list_accounts'),
  authSetActive: (id: string) => call<Account>('auth_set_active', { id }),
  authRemove: (id: string) => call<void>('auth_remove', { id }),

  // Launching. Progress and output arrive through `listenLaunch`; none of it holds a token.
  launchStart: (instanceId: string) => call<void>('launch_start', { instanceId }),
  launchStop: () => call<void>('launch_stop'),
  launchStatus: () => call<LaunchStatus>('launch_status'),
  launchLog: () => call<LogLine[]>('launch_log'),

  // Instances and the version picker. Imports name a file in Kiln's imports folder: the UI
  // never supplies a path.
  pickerGameVersions: (loader: LoaderId) => call<VersionSummary[]>('picker_game_versions', { loader }),
  pickerLoaderVersions: (loader: LoaderId, mcVersion: string) =>
    call<LoaderVersion[]>('picker_loader_versions', { loader, mcVersion }),
  instanceList: () => call<Instance[]>('instance_list'),
  instanceCreate: (name: string, mcVersion: string, loader: LoaderId, loaderVersion: string | null) =>
    call<Instance>('instance_create', { name, mcVersion, loader, loaderVersion }),
  instanceRename: (id: string, name: string) => call<Instance>('instance_rename', { id, name }),
  instanceClone: (id: string, name: string) => call<Instance>('instance_clone', { id, name }),
  instanceDelete: (id: string) => call<void>('instance_delete', { id }),
  instanceUpdateSettings: (id: string, ramMb: number | null, jvmArgs: string | null) =>
    call<Instance>('instance_update_settings', { id, ramMb, jvmArgs }),
  /** Writes into the exports folder. */
  instanceExport: (id: string, format: 'kiln' | 'mrpack') => call<ExportResult>('instance_export', { id, format }),
  instanceListImports: () => call<ImportFile[]>('instance_list_imports'),
  instanceImport: (fileName: string) => call<Instance>('instance_import', { fileName }),
  openFolder: (which: 'imports' | 'exports' | 'instance', id?: string) =>
    call<void>('open_folder', { which, id: id ?? null }),

  // Mods and modpacks (Modrinth). The UI names projects, instances and mod rows, never paths or URLs.
  modSearch: (query: SearchQuery) => call<SearchPage>('mod_search', { query }),
  modsList: (instanceId: string) => call<ModEntry[]>('mods_list', { instanceId }),
  modInstallPlan: (instanceId: string, projectId: string) =>
    call<InstallPlan>('mod_install_plan', { instanceId, projectId }),
  modInstall: (instanceId: string, projectId: string, optional: string[]) =>
    call<InstallPlan>('mod_install', { instanceId, projectId, optional }),
  modsCheckUpdates: (instanceId: string) => call<UpdateInfo[]>('mods_check_updates', { instanceId }),
  /** Resolves to false when the mod was already up to date. */
  modUpdate: (instanceId: string, modId: number) => call<boolean>('mod_update', { instanceId, modId }),
  modsUpdateAll: (instanceId: string) => call<UpdateAllReport>('mods_update_all', { instanceId }),
  modSetPinned: (instanceId: string, modId: number, pinned: boolean) =>
    call<void>('mod_set_pinned', { instanceId, modId, pinned }),
  modSetEnabled: (instanceId: string, modId: number, enabled: boolean) =>
    call<void>('mod_set_enabled', { instanceId, modId, enabled }),
  modRemove: (instanceId: string, modId: number) => call<void>('mod_remove', { instanceId, modId }),
  modsRollback: (instanceId: string) => call<RollbackReport>('mods_rollback', { instanceId }),
  modpackInstall: (projectId: string) => call<Instance>('modpack_install', { projectId }),
  modpackCheckUpdate: (instanceId: string) =>
    call<PackUpdateInfo | null>('modpack_check_update', { instanceId }),
  modpackUpdate: (instanceId: string) => call<PackUpdateOutcome>('modpack_update', { instanceId }),
};

/** Progress of imports, installs and updates. Returns a function that unsubscribes. */
export async function listenProgress(onProgress: (p: TaskProgress) => void): Promise<() => void> {
  if (inTauri) return listen<TaskProgress>('task-progress', (e) => onProgress(e.payload));
  if (import.meta.env.DEV) {
    const { mockListenProgress } = await import('./mock');
    return mockListenProgress(onProgress);
  }
  return () => {};
}

/** Told when Kiln undid mod updates because the game failed to start after them. */
export async function listenRollback(onRollback: (r: RollbackReport) => void): Promise<() => void> {
  if (inTauri) return listen<RollbackReport>('mods-rolled-back', (e) => onRollback(e.payload));
  return () => {};
}

/** Subscribe to launch progress and game output. Returns a function that unsubscribes. */
export async function listenLaunch(
  onStatus: (s: LaunchStatus) => void,
  onLog: (l: LogLine) => void,
): Promise<() => void> {
  if (inTauri) {
    const offStatus = await listen<LaunchStatus>('launch-status', (e) => onStatus(e.payload));
    const offLog = await listen<LogLine>('game-log', (e) => onLog(e.payload));
    return () => {
      offStatus();
      offLog();
    };
  }
  if (import.meta.env.DEV) {
    const { mockListen } = await import('./mock');
    return mockListen(onStatus, onLog);
  }
  return () => {};
}
