import { api, errorMessage, listenLaunch, type LaunchStatus, type LogLine } from './api';

/** Console lines kept in memory; the backend keeps the same number for late openers. */
const MAX_LINES = 2000;

class LaunchStore {
  status = $state<LaunchStatus>({ state: 'idle' });
  lines = $state<LogLine[]>([]);
  error = $state<string | null>(null);
  /** Set when live progress and output can't be received; separate so it isn't overwritten. */
  eventsError = $state<string | null>(null);
  private started = false;

  readonly active = $derived(this.status.state === 'preparing' || this.status.state === 'running');

  /** Subscribe to backend events once, then catch up on anything already happened. */
  async init(): Promise<void> {
    if (this.started) return;
    this.started = true;
    try {
      await listenLaunch(
        (s) => (this.status = s),
        (l) => this.push(l),
      );
      this.status = await api.launchStatus();
      this.lines = await api.launchLog();
    } catch (e) {
      this.started = false;
      this.eventsError = errorMessage(e);
    }
  }

  private push(line: LogLine) {
    this.lines.push(line);
    if (this.lines.length > MAX_LINES) this.lines.splice(0, this.lines.length - MAX_LINES);
  }

  async start(instanceId: string): Promise<void> {
    if (this.active) return;
    this.error = null;
    try {
      await api.launchStart(instanceId);
    } catch (e) {
      this.error = errorMessage(e);
    }
  }

  async stop(): Promise<void> {
    try {
      await api.launchStop();
    } catch (e) {
      this.error = errorMessage(e);
    }
  }
}

export const launch = new LaunchStore();
