import { api, errorMessage, listenProgress, type ImportFile, type Instance, type Progress } from './api';

class InstancesStore {
  list = $state<Instance[]>([]);
  imports = $state<ImportFile[]>([]);
  loaded = $state(false);
  error = $state<string | null>(null);
  /** A short confirmation, e.g. where an export was written. */
  notice = $state<string | null>(null);
  /** What is in progress: an instance id, or `import`. */
  busy = $state<string | null>(null);
  /** Download progress of an import in flight. */
  progress = $state<Progress | null>(null);
  private listening = false;

  /** Follow import progress. Safe to call more than once. */
  async listen(): Promise<void> {
    if (this.listening) return;
    this.listening = true;
    try {
      await listenProgress((p) => {
        if (p.task === 'import' && this.busy === 'import') this.progress = p.progress;
      });
    } catch {
      this.listening = false;
    }
  }

  private async run<T>(busy: string | null, work: () => Promise<T>): Promise<T | undefined> {
    this.error = null;
    this.notice = null;
    this.busy = busy;
    this.progress = null;
    try {
      return await work();
    } catch (e) {
      this.error = errorMessage(e);
      return undefined;
    } finally {
      this.busy = null;
      this.progress = null;
    }
  }

  async load(): Promise<void> {
    try {
      this.list = await api.instanceList();
      this.error = null;
    } catch (e) {
      this.error = errorMessage(e);
    } finally {
      this.loaded = true;
    }
  }

  async loadImports(): Promise<void> {
    try {
      this.imports = await api.instanceListImports();
    } catch (e) {
      this.error = errorMessage(e);
    }
  }

  async create(name: string, mc: string, loader: Instance['loader'], loaderVersion: string | null): Promise<boolean> {
    const made = await this.run(null, () => api.instanceCreate(name, mc, loader, loaderVersion));
    if (made) await this.load();
    return made !== undefined;
  }

  async rename(id: string, name: string): Promise<boolean> {
    const ok = await this.run(id, () => api.instanceRename(id, name));
    if (ok) await this.load();
    return ok !== undefined;
  }

  async duplicate(id: string, name: string): Promise<void> {
    if ((await this.run(id, () => api.instanceClone(id, name))) !== undefined) await this.load();
  }

  async remove(id: string): Promise<void> {
    const done = await this.run(id, async () => {
      await api.instanceDelete(id);
      return true;
    });
    if (done) await this.load();
  }

  async saveSettings(id: string, ramMb: number | null, jvmArgs: string | null): Promise<boolean> {
    const ok = await this.run(id, () => api.instanceUpdateSettings(id, ramMb, jvmArgs));
    if (ok) await this.load();
    return ok !== undefined;
  }

  async export(id: string, format: 'kiln' | 'mrpack'): Promise<void> {
    const out = await this.run(id, () => api.instanceExport(id, format));
    if (!out) return;
    let notice = `Saved ${out.file} in Kiln's exports folder.`;
    if (out.listed > 0) notice += ` ${out.listed} mods are listed by their Modrinth hash instead of being copied in.`;
    if (out.bundled_unverified.length > 0) {
      const names = out.bundled_unverified.slice(0, 5).join(', ');
      const more = out.bundled_unverified.length > 5 ? ` and ${out.bundled_unverified.length - 5} more` : '';
      notice += ` Modrinth doesn't know ${names}${more}, so they were bundled into the pack. Check you're allowed to share them.`;
    }
    this.notice = notice;
  }

  async importFile(name: string): Promise<void> {
    const made = await this.run('import', () => api.instanceImport(name));
    if (made) {
      this.notice = `Added ${made.name} to your instances.`;
      await Promise.all([this.load(), this.loadImports()]);
    }
  }

  async openFolder(which: 'imports' | 'exports' | 'instance', id?: string): Promise<void> {
    await this.run(null, () => api.openFolder(which, id));
  }
}

export const instances = new InstancesStore();
