import { describe, expect, it } from 'vitest';
import type { InstallPlan, ModEntry, UpdateInfo } from './api';
import { formatCount, planSummary, rollbackSummary, sourceLine, updateLabel } from './mods-format';

const entry = (over: Partial<ModEntry> = {}): ModEntry => ({
  id: 1,
  file_name: 'a.jar',
  source: 'modrinth',
  project_id: 'AAAA',
  version_id: 'v1',
  version_number: '1.0',
  pinned: false,
  enabled: true,
  size: 10,
  title: 'A',
  author: 'alice',
  license: 'MIT License',
  downloads: 1234,
  icon_url: null,
  channel: 'release',
  installed_as: 'user',
  ...over,
});

describe('formatCount', () => {
  it('abbreviates large numbers', () => {
    expect(formatCount(950)).toBe('950');
    expect(formatCount(1234)).toBe('1.2K');
    expect(formatCount(1000)).toBe('1K');
    expect(formatCount(52_400_000)).toBe('52.4M');
    expect(formatCount(120_000)).toBe('120K');
    expect(formatCount(3_100_000_000)).toBe('3.1B');
  });
  it('shows a dash for unknown values', () => {
    expect(formatCount(null)).toBe('–');
    expect(formatCount(undefined)).toBe('–');
    expect(formatCount(-1)).toBe('–');
    expect(formatCount(Number.NaN)).toBe('–');
  });
});

describe('sourceLine', () => {
  it('shows author, downloads and licence for Modrinth mods', () => {
    expect(sourceLine(entry())).toBe('by alice · 1.2K downloads · MIT License');
  });
  it('says plainly that other jars are unverified and shows no invented details', () => {
    const line = sourceLine(entry({ source: 'unverified', author: 'mallory', downloads: 999_999, license: 'WTFPL' }));
    expect(line).toMatch(/Not from Modrinth/);
    expect(line).not.toMatch(/mallory|WTFPL|999/);
  });
  it('copes with missing details', () => {
    expect(sourceLine(entry({ author: null, downloads: null, license: null }))).toBe('From Modrinth');
  });
});

describe('planSummary', () => {
  const plan = (reasons: ('requested' | 'dependency')[]): InstallPlan => ({
    mods: reasons.map((reason, i) => ({
      project_id: `P${i}`, title: `M${i}`, version_id: `v${i}`, version_number: '1', channel: 'release',
      file_name: `m${i}.jar`, size: 1, reason, icon_url: null,
    })),
    optional: [],
    conflicts: [],
    already_installed: [],
  });
  it('counts the mod and its dependencies', () => {
    expect(planSummary(plan(['requested']))).toBe('Installs 1 mod.');
    expect(planSummary(plan(['requested', 'dependency']))).toBe('Installs 1 mod and 1 dependency.');
    expect(planSummary(plan(['requested', 'dependency', 'dependency']))).toBe('Installs 1 mod and 2 dependencies.');
    expect(planSummary(plan([]))).toBe('Everything needed is already installed.');
  });
});

describe('updateLabel and rollbackSummary', () => {
  const u: UpdateInfo = {
    mod_id: 1, file_name: 'a.jar', title: 'A', current_version: '1.0', new_version: '2.0',
    new_version_id: 'v2', channel: 'beta', changelog: null, pinned: false,
  };
  it('marks pre-releases', () => {
    expect(updateLabel(u)).toBe('1.0 → 2.0 (beta)');
    expect(updateLabel({ ...u, current_version: null, channel: 'release' })).toBe('2.0');
  });
  it('describes what was undone and what could not be', () => {
    expect(rollbackSummary({ instance_id: 'x', restored: ['a.jar'], removed: ['e.jar'], failed: [] })).toBe(
      'Kiln put back a.jar and removed e.jar.',
    );
    expect(rollbackSummary({ instance_id: 'x', restored: [], removed: [], failed: ['b.jar'] })).toBe(
      'Nothing could be undone. Couldn’t restore: b.jar.',
    );
  });
});
