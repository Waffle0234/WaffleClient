import type { InstallPlan, ModEntry, RollbackReport, UpdateInfo } from './api';

/** `1234` -> `1.2K`, `2500000` -> `2.5M`. */
export function formatCount(n: number | null | undefined): string {
  if (n === null || n === undefined || !Number.isFinite(n) || n < 0) return '–';
  if (n < 1000) return String(Math.round(n));
  const units: [number, string][] = [
    [1e9, 'B'],
    [1e6, 'M'],
    [1e3, 'K'],
  ];
  for (const [size, suffix] of units) {
    if (n >= size) {
      const v = n / size;
      return `${v >= 100 ? Math.round(v) : v.toFixed(1).replace(/\.0$/, '')}${suffix}`;
    }
  }
  return String(n);
}

/** One line about where a mod came from. Unverified jars get no author, downloads or licence. */
export function sourceLine(m: ModEntry): string {
  if (m.source !== 'modrinth') {
    return 'Not from Modrinth: Kiln can’t verify who made this file or check it for updates.';
  }
  const parts = [m.author ? `by ${m.author}` : null, m.downloads !== null ? `${formatCount(m.downloads)} downloads` : null, m.license]
    .filter((p): p is string => !!p);
  return parts.join(' · ') || 'From Modrinth';
}

/** What an install will do, in one sentence, for the confirmation panel. */
export function planSummary(plan: InstallPlan): string {
  const wanted = plan.mods.filter((m) => m.reason === 'requested').length;
  const deps = plan.mods.length - wanted;
  if (plan.mods.length === 0) return 'Everything needed is already installed.';
  const base = wanted === 1 ? 'Installs 1 mod' : `Installs ${wanted} mods`;
  return deps > 0 ? `${base} and ${deps} ${deps === 1 ? 'dependency' : 'dependencies'}.` : `${base}.`;
}

export function updateLabel(u: UpdateInfo): string {
  const from = u.current_version ? `${u.current_version} → ` : '';
  return `${from}${u.new_version}${u.channel === 'release' ? '' : ` (${u.channel})`}`;
}

export function rollbackSummary(r: RollbackReport): string {
  const parts: string[] = [];
  if (r.restored.length > 0) parts.push(`put back ${r.restored.length === 1 ? r.restored[0] : `${r.restored.length} mods`}`);
  if (r.removed.length > 0) parts.push(`removed ${r.removed.length === 1 ? r.removed[0] : `${r.removed.length} added mods`}`);
  const done = parts.length > 0 ? `Kiln ${parts.join(' and ')}.` : 'Nothing could be undone.';
  return r.failed.length > 0 ? `${done} Couldn’t restore: ${r.failed.join(', ')}.` : done;
}
