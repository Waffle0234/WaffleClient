import {
  api,
  errorMessage,
  listenProgress,
  listenRollback,
  type InstallPlan,
  type Instance,
  type ModEntry,
  type ProjectKind,
  type Progress,
  type SearchHit,
  type SortOrder,
  type UpdateInfo,
} from './api';
import { rollbackSummary } from './mods-format';

/** Mods, modpacks and their updates for one instance at a time. */
class ModsStore {
  instanceId = $state<string | null>(null);
  installed = $state<ModEntry[]>([]);
  updates = $state<UpdateInfo[]>([]);
  checkedUpdates = $state(false);
  loading = $state(false);

  hits = $state<SearchHit[]>([]);
  total = $state(0);
  searched = $state(false);
  searching = $state(false);

  /** The install plan being reviewed, for `planFor`. */
  plan = $state<InstallPlan | null>(null);
  planFor = $state<{ id: string; title: string } | null>(null);

  /** The operation in flight: `plan`, `install`, `update:<id>`, `update-all`, `rollback`, `modpack`... */
  busy = $state<string | null>(null);
  progress = $state<Progress | null>(null);
  error = $state<string | null>(null);
  notice = $state<string | null>(null);
  private started = false;

  /** Listen for progress and automatic rollbacks, once. */
  async init(): Promise<void> {
    if (this.started) return;
    this.started = true;
    try {
      await listenProgress((p) => {
        if (this.busy !== null) this.progress = p.progress;
      });
      await listenRollback((r) => {
        this.notice = `The game didn’t start after a mod update. ${rollbackSummary(r)}`;
        if (r.instance_id === this.instanceId) void this.load();
      });
    } catch (e) {
      this.started = false;
      this.error = errorMessage(e);
    }
  }

  private async run<T>(busy: string, work: () => Promise<T>): Promise<T | undefined> {
    this.error = null;
    this.notice = null;
    this.busy = busy;
    this.progress = null;
    try {
      return await work();
    } catch (e) {
      this.error = errorMessage(e);
      return undefined;
    } finally {
      this.busy = null;
      this.progress = null;
    }
  }

  async select(instanceId: string | null): Promise<void> {
    this.instanceId = instanceId;
    this.installed = [];
    this.updates = [];
    this.checkedUpdates = false;
    this.plan = null;
    this.planFor = null;
    this.error = null;
    this.notice = null;
    if (instanceId) await this.load();
  }

  async load(): Promise<void> {
    const id = this.instanceId;
    if (!id) return;
    this.loading = true;
    try {
      const list = await api.modsList(id);
      if (this.instanceId === id) this.installed = list;
    } catch (e) {
      this.error = errorMessage(e);
    } finally {
      this.loading = false;
    }
  }

  async search(query: string, kind: ProjectKind, sort: SortOrder, mc: string | null, loader: Instance['loader'] | null): Promise<void> {
    this.searching = true;
    this.error = null;
    try {
      const page = await api.modSearch({
        query,
        kind,
        sort,
        mc_version: mc,
        loader: kind === 'mod' ? loader : null,
      });
      this.hits = page.hits;
      this.total = page.total;
      this.searched = true;
    } catch (e) {
      this.error = errorMessage(e);
    } finally {
      this.searching = false;
    }
  }

  async review(project: { id: string; title: string }): Promise<void> {
    if (!this.instanceId) return;
    const id = this.instanceId;
    const plan = await this.run('plan', () => api.modInstallPlan(id, project.id));
    if (plan) {
      this.plan = plan;
      this.planFor = project;
    }
  }

  cancelReview(): void {
    this.plan = null;
    this.planFor = null;
  }

  async confirmInstall(optional: string[]): Promise<void> {
    const id = this.instanceId;
    const target = this.planFor;
    if (!id || !target) return;
    const done = await this.run('install', () => api.modInstall(id, target.id, optional));
    if (done) {
      this.notice = `Installed ${target.title}${done.mods.length > 1 ? ` and ${done.mods.length - 1} more` : ''}.`;
      this.cancelReview();
      this.updates = [];
      this.checkedUpdates = false;
      await this.load();
    }
  }

  async checkUpdates(): Promise<void> {
    const id = this.instanceId;
    if (!id) return;
    const found = await this.run('check', () => api.modsCheckUpdates(id));
    if (found) {
      this.updates = found;
      this.checkedUpdates = true;
      await this.load();
    }
  }

  updateFor(modId: number): UpdateInfo | undefined {
    return this.updates.find((u) => u.mod_id === modId);
  }

  async update(modId: number): Promise<void> {
    const id = this.instanceId;
    if (!id) return;
    const ok = await this.run(`update:${modId}`, () => api.modUpdate(id, modId));
    if (ok !== undefined) {
      this.notice = ok ? 'Updated. If the game doesn’t start afterwards, Kiln will undo the update.' : 'Already up to date.';
      await this.afterChange();
    }
  }

  async updateAll(): Promise<void> {
    const id = this.instanceId;
    if (!id) return;
    const report = await this.run('update-all', () => api.modsUpdateAll(id));
    if (report) {
      const bits = [`Updated ${report.updated.length}.`];
      if (report.skipped_pinned > 0) bits.push(`${report.skipped_pinned} pinned, left alone.`);
      if (report.failed.length > 0) bits.push(`${report.failed.length} failed: ${report.failed.map((f) => f.title).join(', ')}.`);
      this.notice = bits.join(' ');
      await this.afterChange();
    }
  }

  private async afterChange(): Promise<void> {
    await this.load();
    const id = this.instanceId;
    if (!id) return;
    try {
      this.updates = await api.modsCheckUpdates(id);
    } catch {
      this.updates = [];
    }
  }

  async setPinned(modId: number, pinned: boolean): Promise<void> {
    const id = this.instanceId;
    if (!id) return;
    if ((await this.run(`pin:${modId}`, async () => (await api.modSetPinned(id, modId, pinned), true))) !== undefined) {
      this.updates = this.updates.map((u) => (u.mod_id === modId ? { ...u, pinned } : u));
      await this.load();
    }
  }

  async setEnabled(modId: number, enabled: boolean): Promise<void> {
    const id = this.instanceId;
    if (!id) return;
    if ((await this.run(`toggle:${modId}`, async () => (await api.modSetEnabled(id, modId, enabled), true))) !== undefined) await this.load();
  }

  async remove(modId: number): Promise<void> {
    const id = this.instanceId;
    if (!id) return;
    if ((await this.run(`remove:${modId}`, async () => (await api.modRemove(id, modId), true))) !== undefined) {
      this.updates = this.updates.filter((u) => u.mod_id !== modId);
      await this.load();
    }
  }

  async rollback(): Promise<void> {
    const id = this.instanceId;
    if (!id) return;
    const report = await this.run('rollback', () => api.modsRollback(id));
    if (report) {
      this.notice = rollbackSummary(report);
      await this.afterChange();
    }
  }

  async installModpack(projectId: string, title: string): Promise<Instance | undefined> {
    const made = await this.run('modpack', () => api.modpackInstall(projectId));
    if (made) this.notice = `Added ${made.name} to your instances (from ${title}).`;
    return made;
  }
}

export const mods = new ModsStore();
