import { api, errorMessage, type AppInfo, type Settings } from './api';
import { applyTheme } from './theme';

class SettingsStore {
  value = $state<Settings | null>(null);
  info = $state<AppInfo | null>(null);
  error = $state<string | null>(null);

  async init(): Promise<void> {
    try {
      const [settings, info] = await Promise.all([api.getSettings(), api.getAppInfo()]);
      this.value = settings;
      this.info = info;
      this.error = null;
      applyTheme(settings);
      // Follow the OS while the theme is "system".
      window
        .matchMedia('(prefers-color-scheme: dark)')
        .addEventListener('change', () => this.value && applyTheme(this.value));
    } catch (e) {
      this.error = errorMessage(e);
    }
  }

  async set<K extends keyof Settings>(key: K, value: Settings[K]): Promise<void> {
    try {
      this.value = await api.setSetting(key, value);
      this.error = null;
      applyTheme(this.value);
    } catch (e) {
      this.error = errorMessage(e);
    }
  }
}

export const settings = new SettingsStore();
