import type { Progress } from './api';

/** `1536` -> `1.5 KB`. */
export function formatBytes(n: number): string {
  if (!Number.isFinite(n) || n < 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let value = n;
  let i = 0;
  while (value >= 1024 && i < units.length - 1) {
    value /= 1024;
    i++;
  }
  return `${i === 0 || value >= 100 ? Math.round(value) : value.toFixed(1)} ${units[i]}`;
}

/** Whole-number percentage of bytes done, or `null` when the total isn't known yet. */
export function progressPercent(p: Progress | null): number | null {
  if (!p || p.bytes_total <= 0) return null;
  return Math.min(100, Math.floor((p.bytes_done / p.bytes_total) * 100));
}

/** `7500` -> `2 h 5 min`; under a minute -> `less than a minute`. */
export function formatPlaytime(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 60) return 'less than a minute';
  const minutes = Math.floor(seconds / 60);
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return h === 0 ? `${m} min` : m === 0 ? `${h} h` : `${h} h ${m} min`;
}

const LOADER_NAMES: Record<string, string> = {
  vanilla: 'Vanilla',
  fabric: 'Fabric',
  quilt: 'Quilt',
  neoforge: 'NeoForge',
  forge: 'Forge',
};

/** `fabric`, `0.16.5` -> `Fabric 0.16.5`. */
export function loaderLabel(loader: string, version: string | null): string {
  const name = LOADER_NAMES[loader] ?? loader;
  return version ? `${name} ${version}` : name;
}
