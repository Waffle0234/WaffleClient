import type { Settings } from './api';

function channel(v: number): number {
  const c = v / 255;
  return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
}

/** WCAG relative luminance of a `#rrggbb` color. */
export function luminance(hex: string): number {
  const n = Number.parseInt(hex.slice(1), 16);
  return 0.2126 * channel((n >> 16) & 255) + 0.7152 * channel((n >> 8) & 255) + 0.0722 * channel(n & 255);
}

/** Text color that stays readable on top of an accent-colored fill. */
export function onAccent(hex: string): string {
  return luminance(hex) > 0.3 ? '#10201b' : '#ffffff';
}

export function resolveTheme(theme: Settings['theme'], prefersDark: boolean): 'dark' | 'light' {
  return theme === 'system' ? (prefersDark ? 'dark' : 'light') : theme;
}

export function applyTheme(s: Settings): void {
  const root = document.documentElement;
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  root.dataset.theme = resolveTheme(s.theme, prefersDark);
  root.style.setProperty('--accent', s.accent_color);
  root.style.setProperty('--on-accent', onAccent(s.accent_color));
  root.dataset.motion = s.reduce_motion ? 'reduced' : 'full';
  root.dataset.bg = s.animated_background ? 'animated' : 'plain';
}
