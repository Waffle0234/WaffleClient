<script lang="ts">
  import Segmented from '../components/Segmented.svelte';
  import Toggle from '../components/Toggle.svelte';
  import type { Settings } from '../lib/api';
  import { settings } from '../lib/settings.svelte';

  const glazes = [
    { name: 'Celadon', hex: '#5fb99a' },
    { name: 'Cobalt', hex: '#5b84e6' },
    { name: 'Copper', hex: '#d98a56' },
    { name: 'Plum', hex: '#b07cc6' },
    { name: 'Ash', hex: '#9aa5a0' },
  ];

  const s = $derived(settings.value);

  function readNumber(event: Event): number {
    return Number((event.currentTarget as HTMLInputElement).valueAsNumber);
  }
</script>

<section class="max-w-3xl">
  <h1 class="font-display text-5xl font-semibold tracking-tight">Settings</h1>

  {#if settings.error}
    <p role="alert" class="mt-6 rounded-md border border-danger px-4 py-3 text-danger">
      {settings.error}
    </p>
  {/if}

  {#if s}
    <h2 class="mt-10 font-display text-xl font-semibold">Appearance</h2>

    <div class="mt-2 divide-y divide-line border-y border-line">
      <div class="flex items-center justify-between gap-8 py-4">
        <div>
          <div class="font-medium">Theme</div>
          <div class="text-sm text-muted">System follows your operating system.</div>
        </div>
        <Segmented
          label="Theme"
          value={s.theme}
          options={[
            { value: 'system', label: 'System' },
            { value: 'dark', label: 'Dark' },
            { value: 'light', label: 'Light' },
          ]}
          onchange={(v) => settings.set('theme', v)}
        />
      </div>

      <div class="flex items-center justify-between gap-8 py-4">
        <div>
          <div class="font-medium">Accent color</div>
          <div class="text-sm text-muted">Used for buttons, focus rings and progress.</div>
        </div>
        <div class="flex items-center gap-2">
          {#each glazes as g (g.hex)}
            <button
              type="button"
              class="size-7 cursor-pointer rounded-full border-2 {s.accent_color === g.hex
                ? 'border-ink'
                : 'border-transparent'}"
              style:background-color={g.hex}
              aria-label="{g.name} accent"
              aria-pressed={s.accent_color === g.hex}
              onclick={() => settings.set('accent_color', g.hex)}
            ></button>
          {/each}
          <input
            type="color"
            aria-label="Custom accent color"
            class="size-7 cursor-pointer rounded-sm border border-line bg-transparent p-0"
            value={s.accent_color}
            onchange={(e) => settings.set('accent_color', e.currentTarget.value)}
          />
        </div>
      </div>

      <div class="flex items-center justify-between gap-8 py-4">
        <div>
          <div class="font-medium">Animated background</div>
          <div class="text-sm text-muted">Two slow glows behind the interface.</div>
        </div>
        <Toggle
          label="Animated background"
          checked={s.animated_background}
          onchange={(v) => settings.set('animated_background', v)}
        />
      </div>

      <div class="flex items-center justify-between gap-8 py-4">
        <div>
          <div class="font-medium">Reduce motion</div>
          <div class="text-sm text-muted">Turns off all animation. Kiln also honors your system setting.</div>
        </div>
        <Toggle
          label="Reduce motion"
          checked={s.reduce_motion}
          onchange={(v) => settings.set('reduce_motion', v)}
        />
      </div>
    </div>

    <h2 class="mt-10 font-display text-xl font-semibold">Downloads and memory</h2>

    <div class="mt-2 divide-y divide-line border-y border-line">
      <div class="flex items-center justify-between gap-8 py-4">
        <div>
          <label class="font-medium" for="downloads">Parallel downloads</label>
          <div class="text-sm text-muted">From 1 to 16. Lower this on slow or metered connections.</div>
        </div>
        <input
          id="downloads"
          type="number"
          min="1"
          max="16"
          class="w-20 rounded-md border border-line bg-surface px-3 py-1.5 text-right"
          value={s.max_concurrent_downloads}
          onchange={(e) => settings.set('max_concurrent_downloads', readNumber(e))}
        />
      </div>

      <div class="flex items-center justify-between gap-8 py-4">
        <div>
          <div class="font-medium">Choose memory automatically</div>
          <div class="text-sm text-muted">
            Kiln picks RAM for each instance from its mods and your system.
          </div>
        </div>
        <Toggle
          label="Choose memory automatically"
          checked={s.default_ram_mb === null}
          onchange={(auto) => settings.set('default_ram_mb', auto ? null : 4096)}
        />
      </div>

      {#if s.default_ram_mb !== null}
        <div class="flex items-center justify-between gap-8 py-4">
          <div>
            <label class="font-medium" for="ram">Default memory (MB)</label>
            <div class="text-sm text-muted">Instances can override this.</div>
          </div>
          <input
            id="ram"
            type="number"
            min="512"
            step="256"
            class="w-28 rounded-md border border-line bg-surface px-3 py-1.5 text-right"
            value={s.default_ram_mb}
            onchange={(e) => settings.set('default_ram_mb', readNumber(e))}
          />
        </div>
      {/if}
    </div>

    <h2 class="mt-10 font-display text-xl font-semibold">Updates and diagnostics</h2>

    <div class="mt-2 divide-y divide-line border-y border-line">
      <div class="flex items-center justify-between gap-8 py-4">
        <div>
          <div class="font-medium">Check for updates on start</div>
          <div class="text-sm text-muted">Updates are signed and verified before they install.</div>
        </div>
        <Toggle
          label="Check for updates on start"
          checked={s.check_updates_on_start}
          onchange={(v) => settings.set('check_updates_on_start', v)}
        />
      </div>

      <div class="flex items-center justify-between gap-8 py-4">
        <div>
          <label class="font-medium" for="log-level">Log detail</label>
          <div class="text-sm text-muted">
            Logs stay on this computer and have tokens and account names removed.
          </div>
        </div>
        <select
          id="log-level"
          class="rounded-md border border-line bg-surface px-3 py-1.5"
          value={s.log_level}
          onchange={(e) => settings.set('log_level', e.currentTarget.value as Settings['log_level'])}
        >
          {#each ['error', 'warn', 'info', 'debug', 'trace'] as level (level)}
            <option value={level}>{level}</option>
          {/each}
        </select>
      </div>
    </div>

    {#if settings.info}
      <h2 class="mt-10 font-display text-xl font-semibold">About</h2>
      <dl class="mt-2 grid grid-cols-[10rem_1fr] gap-y-2 border-y border-line py-4 text-sm">
        <dt class="text-muted">Version</dt>
        <dd>{settings.info.version}</dd>
        <dt class="text-muted">Platform</dt>
        <dd>{settings.info.os} ({settings.info.arch})</dd>
        <dt class="text-muted">Data folder</dt>
        <dd class="break-all">{settings.info.data_dir}</dd>
        <dt class="text-muted">Portable mode</dt>
        <dd>{settings.info.portable ? 'On' : 'Off'}</dd>
      </dl>
      <p class="mt-4 max-w-prose text-sm text-muted">
        Kiln is not affiliated with Mojang or Microsoft. Minecraft is a trademark of Mojang AB.
      </p>
    {/if}
  {/if}
</section>
