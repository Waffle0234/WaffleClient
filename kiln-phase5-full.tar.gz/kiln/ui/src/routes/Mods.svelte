<script lang="ts">
  import { onMount } from 'svelte';
  import Segmented from '../components/Segmented.svelte';
  import type { ProjectKind, SortOrder } from '../lib/api';
  import { formatBytes, progressPercent } from '../lib/format';
  import { instances } from '../lib/instances.svelte';
  import { formatCount, planSummary, sourceLine, updateLabel } from '../lib/mods-format';
  import { mods } from '../lib/mods.svelte';
  import { router } from '../lib/router.svelte';

  const button =
    'cursor-pointer rounded-md px-4 py-2 font-medium transition-colors disabled:cursor-not-allowed disabled:opacity-50';
  const link =
    'cursor-pointer text-muted underline-offset-2 hover:text-ink hover:underline disabled:opacity-50 disabled:no-underline';
  const field = 'rounded-md border border-line bg-surface px-3 py-2';

  onMount(() => {
    void instances.load();
    void mods.init();
  });

  const moddable = $derived(instances.list.filter((i) => i.loader !== 'vanilla'));
  const current = $derived(instances.list.find((i) => i.id === mods.instanceId) ?? null);

  // Pick the first instance that can have mods once the list has loaded.
  $effect(() => {
    const first = moddable[0];
    if (!mods.instanceId && first) void mods.select(first.id);
  });

  type Tab = 'installed' | 'browse';
  let tab = $state<Tab>('installed');
  let kind = $state<ProjectKind>('mod');
  let query = $state('');
  let sort = $state<SortOrder>('relevance');
  let fitInstance = $state(true);

  let confirmRemove = $state<number | null>(null);
  let showLog = $state<number | null>(null);
  let confirmPack = $state<string | null>(null);
  let chosenOptional = $state<string[]>([]);

  const percent = $derived(progressPercent(mods.progress));
  const updatableCount = $derived(mods.updates.filter((u) => !u.pinned).length);

  function runSearch() {
    void mods.search(
      query.trim(),
      kind,
      sort,
      fitInstance && current ? current.mc_version : null,
      fitInstance && current ? current.loader : null,
    );
  }

  function openBrowse() {
    tab = 'browse';
    if (!mods.searched) runSearch();
  }

  async function review(hit: { id: string; title: string }) {
    chosenOptional = [];
    await mods.review(hit);
  }

  function toggleOptional(id: string, on: boolean) {
    chosenOptional = on ? [...chosenOptional, id] : chosenOptional.filter((x) => x !== id);
  }

  async function installPack(id: string, title: string) {
    confirmPack = null;
    const made = await mods.installModpack(id, title);
    if (made) {
      await instances.load();
      router.go('instances');
    }
  }

  const installedProjects = $derived(new Set(mods.installed.map((m) => m.project_id).filter((p): p is string => !!p)));
</script>

<section class="max-w-4xl">
  <div class="flex flex-wrap items-end justify-between gap-6">
    <h1 class="font-display text-5xl font-semibold tracking-tight">Mods</h1>
    {#if instances.list.length > 0}
      <div>
        <label class="block text-sm text-muted" for="mods-instance">Instance</label>
        <select
          id="mods-instance"
          class="{field} mt-1 min-w-56"
          value={mods.instanceId ?? ''}
          onchange={(e) => void mods.select(e.currentTarget.value || null)}
        >
          {#each instances.list as inst (inst.id)}
            <option value={inst.id} disabled={inst.loader === 'vanilla'}>
              {inst.name} ({inst.loader === 'vanilla' ? 'vanilla: no mods' : `${inst.mc_version} ${inst.loader}`})
            </option>
          {/each}
        </select>
      </div>
    {/if}
  </div>

  {#if mods.error}
    <p role="alert" class="mt-6 rounded-md border border-danger px-4 py-3 text-danger">{mods.error}</p>
  {/if}
  {#if mods.notice}
    <p role="status" class="mt-6 border-l-2 border-accent pl-4 text-muted">{mods.notice}</p>
  {/if}

  {#if mods.busy && mods.busy !== 'plan' && mods.busy !== 'check'}
    <div class="mt-6 max-w-xl" role="status">
      <p>
        Working…
        {#if mods.progress && mods.progress.bytes_total > 0}
          <span class="text-muted">
            {formatBytes(mods.progress.bytes_done)} of {formatBytes(mods.progress.bytes_total)}
          </span>
        {/if}
      </p>
      {#if percent !== null}
        <div
          class="mt-2 h-1.5 overflow-hidden rounded-full bg-raised"
          role="progressbar"
          aria-label="Download progress"
          aria-valuemin="0"
          aria-valuemax="100"
          aria-valuenow={percent}
        >
          <div class="h-full bg-accent transition-[width]" style:width="{percent}%"></div>
        </div>
      {/if}
    </div>
  {/if}

  {#if instances.loaded && instances.list.length === 0}
    <p class="mt-10 max-w-prose text-lg leading-relaxed">Create an instance first, then come back to add mods to it.</p>
  {:else if instances.loaded && moddable.length === 0}
    <p class="mt-10 max-w-prose text-lg leading-relaxed">
      Mods need a mod loader. Make a Fabric, Quilt, Forge or NeoForge instance on the Instances page.
    </p>
  {:else if current}
    <div class="mt-8 flex flex-wrap items-center gap-4">
      <Segmented
        label="Mods view"
        value={tab}
        options={[
          { value: 'installed', label: `Installed (${mods.installed.length})` },
          { value: 'browse', label: 'Browse Modrinth' },
        ]}
        onchange={(v) => (v === 'browse' ? openBrowse() : (tab = v))}
      />
    </div>

    {#if tab === 'installed'}
      <div class="mt-6 flex flex-wrap items-center gap-3">
        <button
          type="button"
          class="{button} border border-line hover:bg-raised"
          disabled={mods.busy !== null}
          onclick={() => mods.checkUpdates()}>{mods.busy === 'check' ? 'Checking…' : 'Check for updates'}</button
        >
        {#if updatableCount > 0}
          <button
            type="button"
            class="{button} bg-accent text-on-accent hover:brightness-110"
            disabled={mods.busy !== null}
            onclick={() => mods.updateAll()}>Update all ({updatableCount})</button
          >
        {/if}
        <button type="button" class={link} disabled={mods.busy !== null} onclick={() => mods.rollback()}
          >Undo last update</button
        >
        <button type="button" class={link} onclick={() => instances.openFolder('instance', current.id)}
          >Open instance folder</button
        >
      </div>
      {#if mods.checkedUpdates && mods.updates.length === 0}
        <p class="mt-4 text-muted">Everything from Modrinth is up to date.</p>
      {/if}

      {#if mods.installed.length === 0 && !mods.loading}
        <p class="mt-8 max-w-prose text-muted">
          No mods in this instance yet. Use “Browse Modrinth” to add some. Jars you drop into the mods folder
          yourself show up here too.
        </p>
      {:else}
        <ul class="mt-6 divide-y divide-line border-y border-line">
          {#each mods.installed as m (m.id)}
            {@const update = mods.updateFor(m.id)}
            <li class="py-4">
              <div class="flex items-start gap-4">
                {#if m.icon_url}
                  <img src={m.icon_url} alt="" class="size-10 shrink-0 rounded-sm bg-raised" loading="lazy" />
                {:else}
                  <div class="size-10 shrink-0 rounded-sm border border-line bg-raised" aria-hidden="true"></div>
                {/if}
                <div class="min-w-0 flex-1">
                  <div class="flex flex-wrap items-baseline gap-x-3">
                    <span class="truncate text-lg font-medium">{m.title ?? m.file_name}</span>
                    {#if m.version_number}<span class="text-sm text-muted">{m.version_number}</span>{/if}
                    {#if m.source !== 'modrinth'}
                      <span class="rounded-sm border border-danger px-1.5 text-xs text-danger">Unverified</span>
                    {/if}
                    {#if m.pinned}<span class="rounded-sm border border-line px-1.5 text-xs text-muted">Pinned</span>{/if}
                    {#if !m.enabled}<span class="rounded-sm border border-line px-1.5 text-xs text-muted">Off</span>{/if}
                    {#if m.installed_as === 'dependency'}
                      <span class="rounded-sm border border-line px-1.5 text-xs text-muted">Dependency</span>
                    {/if}
                  </div>
                  <div class="text-sm text-muted">{sourceLine(m)}</div>
                  <div class="truncate text-xs text-muted">{m.file_name}</div>
                  {#if update}
                    <p class="mt-1 text-sm text-accent">
                      Update available: {updateLabel(update)}{update.pinned ? ' (pinned: won’t be updated)' : ''}
                    </p>
                  {/if}
                </div>
              </div>
              <div class="mt-2 flex flex-wrap gap-x-4 gap-y-1 pl-14 text-sm">
                {#if update && !update.pinned}
                  <button type="button" class="cursor-pointer font-medium text-accent hover:underline" disabled={mods.busy !== null} onclick={() => mods.update(m.id)}
                    >Update</button
                  >
                {/if}
                {#if update?.changelog}
                  <button type="button" class={link} onclick={() => (showLog = showLog === m.id ? null : m.id)}
                    >{showLog === m.id ? 'Hide changes' : 'What’s new'}</button
                  >
                {/if}
                {#if m.source === 'modrinth'}
                  <button type="button" class={link} disabled={mods.busy !== null} onclick={() => mods.setPinned(m.id, !m.pinned)}
                    >{m.pinned ? 'Unpin' : 'Pin version'}</button
                  >
                {/if}
                <button type="button" class={link} disabled={mods.busy !== null} onclick={() => mods.setEnabled(m.id, !m.enabled)}
                  >{m.enabled ? 'Turn off' : 'Turn on'}</button
                >
                {#if confirmRemove === m.id}
                  <span class="text-danger">Remove this mod?</span>
                  <button
                    type="button"
                    class="cursor-pointer text-danger underline"
                    onclick={async () => {
                      confirmRemove = null;
                      await mods.remove(m.id);
                    }}>Remove</button
                  >
                  <button type="button" class="cursor-pointer text-muted underline" onclick={() => (confirmRemove = null)}>Keep</button>
                {:else}
                  <button type="button" class="{link} hover:text-danger" disabled={mods.busy !== null} onclick={() => (confirmRemove = m.id)}
                    >Remove</button
                  >
                {/if}
              </div>
              {#if update?.changelog && showLog === m.id}
                <pre class="mt-3 ml-14 max-h-56 overflow-auto rounded-md border border-line bg-surface p-3 text-sm whitespace-pre-wrap">{update.changelog}</pre>
              {/if}
            </li>
          {/each}
        </ul>
      {/if}
    {:else}
      <form
        class="mt-6 flex flex-wrap items-end gap-3"
        onsubmit={(e) => {
          e.preventDefault();
          runSearch();
        }}
      >
        <div>
          <label class="block text-sm text-muted" for="mods-kind">Looking for</label>
          <select id="mods-kind" class="{field} mt-1" bind:value={kind} onchange={runSearch}>
            <option value="mod">Mods</option>
            <option value="modpack">Modpacks</option>
          </select>
        </div>
        <div class="min-w-48 flex-1">
          <label class="block text-sm text-muted" for="mods-q">Search</label>
          <input id="mods-q" class="{field} mt-1 w-full" maxlength="100" placeholder="sodium, minimap, …" bind:value={query} />
        </div>
        <div>
          <label class="block text-sm text-muted" for="mods-sort">Sort by</label>
          <select id="mods-sort" class="{field} mt-1" bind:value={sort} onchange={runSearch}>
            <option value="relevance">Relevance</option>
            <option value="downloads">Downloads</option>
            <option value="follows">Follows</option>
            <option value="newest">Newest</option>
            <option value="updated">Recently updated</option>
          </select>
        </div>
        <button type="submit" class="{button} bg-accent text-on-accent hover:brightness-110" disabled={mods.searching}
          >{mods.searching ? 'Searching…' : 'Search'}</button
        >
      </form>
      <label class="mt-3 flex items-center gap-2 text-sm text-muted">
        <input type="checkbox" bind:checked={fitInstance} onchange={runSearch} />
        Only show projects for Minecraft {current.mc_version}{kind === 'mod' ? ` on ${current.loader}` : ''}
      </label>

      {#if mods.plan && mods.planFor}
        <div class="mt-8 border-y border-line py-6" role="region" aria-label="Install {mods.planFor.title}">
          <h2 class="font-display text-xl font-semibold">Install {mods.planFor.title}</h2>
          <p class="mt-2 text-muted">{planSummary(mods.plan)}</p>
          {#if mods.plan.conflicts.length > 0}
            <ul class="mt-3 text-danger">
              {#each mods.plan.conflicts as c (c.title + c.conflicts_with)}
                <li>{c.title} can’t be used together with {c.conflicts_with}.</li>
              {/each}
            </ul>
          {/if}
          <ul class="mt-4 divide-y divide-line">
            {#each mods.plan.mods as p (p.project_id)}
              <li class="flex items-baseline gap-3 py-2">
                <span class="font-medium">{p.title}</span>
                <span class="text-sm text-muted">{p.version_number}{p.channel === 'release' ? '' : ` (${p.channel})`}</span>
                <span class="text-sm text-muted">{formatBytes(p.size)}</span>
                {#if p.reason === 'dependency'}<span class="rounded-sm border border-line px-1.5 text-xs text-muted">Needed</span>{/if}
              </li>
            {/each}
          </ul>
          {#if mods.plan.already_installed.length > 0}
            <p class="mt-3 text-sm text-muted">Already installed: {mods.plan.already_installed.join(', ')}.</p>
          {/if}
          {#if mods.plan.optional.length > 0}
            <fieldset class="mt-4">
              <legend class="text-sm text-muted">Works better with (optional)</legend>
              {#each mods.plan.optional as o (o.project_id)}
                <label class="mt-1 flex items-center gap-2">
                  <input type="checkbox" onchange={(e) => toggleOptional(o.project_id, e.currentTarget.checked)} />
                  {o.title}
                </label>
              {/each}
            </fieldset>
          {/if}
          <div class="mt-5 flex gap-3">
            <button
              type="button"
              class="{button} bg-accent text-on-accent hover:brightness-110"
              disabled={mods.busy !== null || mods.plan.conflicts.length > 0 || mods.plan.mods.length === 0}
              onclick={() => mods.confirmInstall(chosenOptional)}>{mods.busy === 'install' ? 'Installing…' : 'Install'}</button
            >
            <button type="button" class="{button} text-muted hover:text-ink" onclick={() => mods.cancelReview()}>Cancel</button>
          </div>
        </div>
      {/if}

      {#if mods.searched && mods.hits.length === 0}
        <p class="mt-8 text-muted">Nothing found. Try a different word, or untick the filter above.</p>
      {/if}
      <ul class="mt-6 divide-y divide-line border-y border-line">
        {#each mods.hits as hit (hit.id)}
          <li class="flex items-start gap-4 py-4">
            {#if hit.icon_url}
              <img src={hit.icon_url} alt="" class="size-12 shrink-0 rounded-sm bg-raised" loading="lazy" />
            {:else}
              <div class="size-12 shrink-0 rounded-sm border border-line bg-raised" aria-hidden="true"></div>
            {/if}
            <div class="min-w-0 flex-1">
              <div class="flex flex-wrap items-baseline gap-x-3">
                <span class="text-lg font-medium">{hit.title}</span>
                <span class="text-sm text-muted">by {hit.author}</span>
              </div>
              <p class="mt-0.5 text-muted">{hit.description}</p>
              <p class="mt-1 text-sm text-muted">
                {formatCount(hit.downloads)} downloads{hit.license ? ` · ${hit.license}` : ''}{hit.categories.length > 0
                  ? ` · ${hit.categories.slice(0, 3).join(', ')}`
                  : ''}
              </p>
            </div>
            {#if hit.kind === 'modpack'}
              {#if confirmPack === hit.id}
                <div class="flex flex-col items-end gap-1 text-sm">
                  <span class="text-muted">Creates a new instance.</span>
                  <span class="flex gap-3">
                    <button type="button" class="cursor-pointer font-medium text-accent hover:underline" onclick={() => installPack(hit.id, hit.title)}>Install</button>
                    <button type="button" class="cursor-pointer text-muted underline" onclick={() => (confirmPack = null)}>Cancel</button>
                  </span>
                </div>
              {:else}
                <button
                  type="button"
                  class="{button} border border-line hover:bg-raised"
                  disabled={mods.busy !== null}
                  onclick={() => (confirmPack = hit.id)}>{mods.busy === 'modpack' ? 'Installing…' : 'Install pack'}</button
                >
              {/if}
            {:else if installedProjects.has(hit.id)}
              <span class="self-center text-sm text-muted">Installed</span>
            {:else}
              <button
                type="button"
                class="{button} border border-line hover:bg-raised"
                disabled={mods.busy !== null}
                onclick={() => review(hit)}>Install</button
              >
            {/if}
          </li>
        {/each}
      </ul>
      {#if mods.total > mods.hits.length}
        <p class="mt-3 text-sm text-muted">Showing {mods.hits.length} of {formatCount(mods.total)}. Narrow the search to see others.</p>
      {/if}
    {/if}
  {/if}
</section>
