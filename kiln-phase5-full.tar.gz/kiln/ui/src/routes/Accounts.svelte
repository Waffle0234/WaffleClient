<script lang="ts">
  import { onMount } from 'svelte';
  import Avatar from '../components/Avatar.svelte';
  import { accounts } from '../lib/accounts.svelte';

  let now = $state(Date.now());
  let confirmingId = $state<string | null>(null);
  let copied = $state(false);

  onMount(() => {
    void accounts.load();
  });

  // The countdown ticks only while a sign-in code is on screen.
  $effect(() => {
    if (accounts.flow.phase !== 'waiting') return;
    now = Date.now();
    const timer = setInterval(() => (now = Date.now()), 1000);
    return () => clearInterval(timer);
  });

  const remaining = $derived.by(() => {
    const flow = accounts.flow;
    if (flow.phase !== 'waiting') return '';
    const s = Math.max(0, Math.round((flow.expiresAt - now) / 1000));
    return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
  });

  async function copyCode(code: string) {
    try {
      await navigator.clipboard.writeText(code);
      copied = true;
      setTimeout(() => (copied = false), 2000);
    } catch {
      copied = false;
    }
  }

  const busy = $derived(accounts.flow.phase !== 'idle');
  const button =
    'cursor-pointer rounded-md px-4 py-2 font-medium transition-colors disabled:cursor-not-allowed disabled:opacity-50';
</script>

<section class="max-w-3xl">
  <div class="flex items-end justify-between gap-6">
    <h1 class="font-display text-5xl font-semibold tracking-tight">Accounts</h1>
    {#if accounts.list.length > 0}
      <button
        type="button"
        class="{button} bg-accent text-on-accent hover:brightness-110"
        disabled={busy}
        onclick={() => accounts.signIn()}>Add account</button
      >
    {/if}
  </div>

  {#if accounts.error}
    <p role="alert" class="mt-6 rounded-md border border-danger px-4 py-3 text-danger">
      {accounts.error}
    </p>
  {/if}

  {#if accounts.flow.phase === 'starting'}
    <p class="mt-8 text-muted" role="status">Contacting Microsoft…</p>
  {:else if accounts.flow.phase === 'waiting'}
    {@const code = accounts.flow.code}
    <div class="mt-8 border-y border-line py-8" role="status" aria-live="polite">
      <p class="text-lg">Finish signing in on Microsoft's page with this code:</p>
      <p class="mt-4 font-display text-6xl font-semibold tracking-[0.18em] select-all">{code.user_code}</p>
      <ol class="mt-6 max-w-md list-decimal space-y-1 pl-5 text-muted">
        <li>Open the sign-in page.</li>
        <li>Enter the code above and sign in with the Microsoft account that owns Minecraft.</li>
        <li>Come back here. Kiln continues on its own.</li>
      </ol>
      <div class="mt-6 flex flex-wrap items-center gap-3">
        <button
          type="button"
          class="{button} bg-accent text-on-accent hover:brightness-110"
          onclick={() => accounts.openVerificationPage()}>Open sign-in page</button
        >
        <button
          type="button"
          class="{button} border border-line hover:bg-raised"
          onclick={() => copyCode(code.user_code)}>{copied ? 'Copied' : 'Copy code'}</button
        >
        <button type="button" class="{button} text-muted hover:text-ink" onclick={() => accounts.cancel()}
          >Cancel</button
        >
        <span class="ml-auto text-sm text-muted">Code expires in {remaining}</span>
      </div>
      <p class="mt-4 text-sm text-muted">
        Or go to {code.verification_uri} on any device.
      </p>
    </div>
  {/if}

  {#if accounts.loaded && accounts.list.length === 0 && !busy}
    <div class="mt-10 max-w-prose">
      <p class="text-lg leading-relaxed">
        Add the Microsoft account that owns Minecraft: Java Edition to play online.
      </p>
      <p class="mt-3 text-muted">
        Kiln never sees your password. Your sign-in is stored in your system's keychain, not in a file.
      </p>
      <button
        type="button"
        class="{button} mt-6 bg-accent text-on-accent hover:brightness-110"
        onclick={() => accounts.signIn()}>Sign in with Microsoft</button
      >
    </div>
  {:else if accounts.list.length > 0}
    <ul class="mt-8 divide-y divide-line border-y border-line">
      {#each accounts.list as account (account.id)}
        <li class="flex items-center gap-4 py-4">
          <Avatar skinUrl={account.skin_url} name={account.username} size={44} />
          <div class="min-w-0 flex-1">
            <div class="truncate font-medium">{account.username}</div>
            <div class="text-sm {account.needs_reauth ? 'text-danger' : 'text-muted'}">
              {#if account.needs_reauth}
                Sign-in expired. Sign in again to keep using this account.
              {:else if account.is_active}
                In use
              {:else}
                Signed in
              {/if}
            </div>
          </div>

          {#if confirmingId === account.id}
            <span class="text-sm text-muted">Remove this account from Kiln?</span>
            <button
              type="button"
              class="{button} border border-danger text-danger hover:bg-raised"
              onclick={async () => {
                confirmingId = null;
                await accounts.remove(account.id);
              }}>Remove</button
            >
            <button type="button" class="{button} text-muted hover:text-ink" onclick={() => (confirmingId = null)}
              >Keep</button
            >
          {:else}
            {#if account.needs_reauth}
              <button
                type="button"
                class="{button} bg-accent text-on-accent hover:brightness-110"
                disabled={busy}
                onclick={() => accounts.signIn()}>Sign in again</button
              >
            {:else if !account.is_active}
              <button
                type="button"
                class="{button} border border-line hover:bg-raised"
                onclick={() => accounts.setActive(account.id)}>Use this account</button
              >
            {/if}
            <button
              type="button"
              class="{button} text-muted hover:text-ink"
              aria-label="Remove {account.username}"
              onclick={() => (confirmingId = account.id)}>Remove</button
            >
          {/if}
        </li>
      {/each}
    </ul>
  {/if}
</section>
