<script lang="ts">
  import { onMount } from 'svelte';
  import { api, errorMessage, type LoaderId, type LoaderVersion, type VersionSummary } from '../lib/api';
  import { formatBytes, formatPlaytime, loaderLabel, progressPercent } from '../lib/format';
  import { instances } from '../lib/instances.svelte';
  import { launch } from '../lib/launch.svelte';
  import { router } from '../lib/router.svelte';

  const loaders: { id: LoaderId; label: string }[] = [
    { id: 'vanilla', label: 'Vanilla' },
    { id: 'fabric', label: 'Fabric' },
    { id: 'quilt', label: 'Quilt' },
    { id: 'neoforge', label: 'NeoForge' },
    { id: 'forge', label: 'Forge' },
  ];

  const button =
    'cursor-pointer rounded-md px-4 py-2 font-medium transition-colors disabled:cursor-not-allowed disabled:opacity-50';
  const field = 'rounded-md border border-line bg-surface px-3 py-2';

  onMount(() => {
    void instances.load();
    void instances.loadImports();
    void instances.listen();
  });

  // ---- new instance form -------------------------------------------------
  let creating = $state(false);
  let name = $state('');
  let loader = $state<LoaderId>('vanilla');
  let games = $state<VersionSummary[]>([]);
  let mc = $state('');
  let loaderVersions = $state<LoaderVersion[]>([]);
  let loaderVersion = $state('');
  let showSnapshots = $state(false);
  let pickerError = $state<string | null>(null);
  let pickerBusy = $state(false);

  const visibleGames = $derived(games.filter((v) => showSnapshots || v.kind === 'release'));
  const canCreate = $derived(
    name.trim().length > 0 && mc !== '' && (loader === 'vanilla' || loaderVersion !== '') && !pickerBusy,
  );

  /** Only versions the chosen loader supports are listed, so every choice can be launched. */
  async function loadGames() {
    pickerBusy = true;
    pickerError = null;
    games = [];
    mc = '';
    loaderVersions = [];
    loaderVersion = '';
    try {
      games = await api.pickerGameVersions(loader);
      mc = visibleGames[0]?.id ?? '';
      await loadLoaderVersions();
    } catch (e) {
      pickerError = errorMessage(e);
    } finally {
      pickerBusy = false;
    }
  }

  async function loadLoaderVersions() {
    loaderVersions = [];
    loaderVersion = '';
    if (loader === 'vanilla' || !mc) return;
    try {
      loaderVersions = await api.pickerLoaderVersions(loader, mc);
      loaderVersion = (loaderVersions.find((v) => v.stable) ?? loaderVersions[0])?.version ?? '';
    } catch (e) {
      pickerError = errorMessage(e);
    }
  }

  function openForm() {
    creating = true;
    void loadGames();
  }

  function onSnapshotsChange() {
    if (!visibleGames.some((v) => v.id === mc)) mc = visibleGames[0]?.id ?? '';
    void loadLoaderVersions();
  }

  async function create() {
    if (!canCreate) return;
    const ok = await instances.create(name.trim(), mc, loader, loader === 'vanilla' ? null : loaderVersion);
    if (ok) {
      creating = false;
      name = '';
    }
  }

  // ---- per-instance actions ----------------------------------------------
  let renaming = $state<string | null>(null);
  let renameText = $state('');
  let editing = $state<string | null>(null);
  let ramText = $state('');
  let jvmText = $state('');
  let confirmDelete = $state<string | null>(null);

  function startRename(id: string, current: string) {
    renaming = id;
    renameText = current;
  }

  async function saveRename() {
    if (renaming && (await instances.rename(renaming, renameText))) renaming = null;
  }

  function startEdit(id: string, ram: number | null, jvm: string | null) {
    editing = id;
    ramText = ram === null ? '' : String(ram);
    jvmText = jvm ?? '';
  }

  async function saveSettings() {
    if (!editing) return;
    const trimmed = ramText.trim();
    const ram = trimmed === '' ? null : Number(trimmed);
    if (ram !== null && !Number.isFinite(ram)) return;
    if (await instances.saveSettings(editing, ram, jvmText.trim() || null)) editing = null;
  }

  async function play(id: string) {
    await launch.start(id);
    if (!launch.error) router.go('console');
  }

  const noInstances = $derived(instances.loaded && instances.list.length === 0 && !creating);
</script>

<section class="max-w-4xl">
  <div class="flex items-end justify-between gap-6">
    <h1 class="font-display text-5xl font-semibold tracking-tight">Instances</h1>
    {#if !creating}
      <button type="button" class="{button} bg-accent text-on-accent hover:brightness-110" onclick={openForm}
        >New instance</button
      >
    {/if}
  </div>

  {#if instances.error}
    <p role="alert" class="mt-6 rounded-md border border-danger px-4 py-3 text-danger">{instances.error}</p>
  {/if}
  {#if launch.error}
    <p role="alert" class="mt-6 rounded-md border border-danger px-4 py-3 text-danger">{launch.error}</p>
  {/if}
  {#if instances.notice}
    <p role="status" class="mt-6 border-l-2 border-accent pl-4 text-muted">{instances.notice}</p>
  {/if}

  {#if creating}
    <form
      class="mt-8 border-y border-line py-6"
      onsubmit={(e) => {
        e.preventDefault();
        void create();
      }}
    >
      <h2 class="font-display text-xl font-semibold">New instance</h2>
      <div class="mt-4 grid grid-cols-2 gap-x-6 gap-y-4 max-w-2xl">
        <div class="col-span-2">
          <label class="block text-sm text-muted" for="new-name">Name</label>
          <input id="new-name" class="{field} mt-1 w-full" maxlength="64" bind:value={name} />
        </div>
        <div>
          <label class="block text-sm text-muted" for="new-loader">Mod loader</label>
          <select id="new-loader" class="{field} mt-1 w-full" bind:value={loader} onchange={loadGames}>
            {#each loaders as l (l.id)}
              <option value={l.id}>{l.label}</option>
            {/each}
          </select>
        </div>
        <div>
          <label class="block text-sm text-muted" for="new-mc">Minecraft version</label>
          <select
            id="new-mc"
            class="{field} mt-1 w-full"
            bind:value={mc}
            onchange={loadLoaderVersions}
            disabled={pickerBusy || visibleGames.length === 0}
          >
            {#each visibleGames as v (v.id)}
              <option value={v.id}>{v.id}</option>
            {/each}
          </select>
        </div>
        {#if loader !== 'vanilla'}
          <div>
            <label class="block text-sm text-muted" for="new-lv">{loaderLabel(loader, null)} version</label>
            <select id="new-lv" class="{field} mt-1 w-full" bind:value={loaderVersion} disabled={loaderVersions.length === 0}>
              {#each loaderVersions as v (v.version)}
                <option value={v.version}>{v.version}{v.stable ? '' : ' (beta)'}</option>
              {/each}
            </select>
          </div>
        {/if}
        <label class="flex items-center gap-2 self-end pb-2 text-sm text-muted">
          <input type="checkbox" bind:checked={showSnapshots} onchange={onSnapshotsChange} />
          Show snapshots
        </label>
      </div>
      {#if loader !== 'vanilla'}
        <p class="mt-3 max-w-2xl text-sm text-muted">
          Only Minecraft versions that {loaderLabel(loader, null)} supports are listed.
          {#if loader === 'forge' || loader === 'neoforge'}
            The first launch runs the official installer, which can take a few minutes.
          {/if}
        </p>
      {/if}
      {#if pickerError}
        <p role="alert" class="mt-4 text-danger">{pickerError}</p>
      {/if}
      <div class="mt-6 flex gap-3">
        <button type="submit" class="{button} bg-accent text-on-accent hover:brightness-110" disabled={!canCreate}
          >Create</button
        >
        <button type="button" class="{button} text-muted hover:text-ink" onclick={() => (creating = false)}>Cancel</button>
      </div>
    </form>
  {/if}

  {#if noInstances}
    <div class="mt-10 max-w-prose">
      <p class="text-lg leading-relaxed">No instances yet.</p>
      <p class="mt-3 text-muted">
        An instance is a separate game folder with its own version, mod loader, mods, worlds and settings.
      </p>
    </div>
  {:else if instances.list.length > 0}
    <ul class="mt-8 divide-y divide-line border-y border-line">
      {#each instances.list as inst (inst.id)}
        <li class="py-4">
          <div class="flex items-center gap-4">
            <div class="min-w-0 flex-1">
              {#if renaming === inst.id}
                <form
                  class="flex gap-2"
                  onsubmit={(e) => {
                    e.preventDefault();
                    void saveRename();
                  }}
                >
                  <input class="{field} w-64" aria-label="New name" maxlength="64" bind:value={renameText} />
                  <button type="submit" class="{button} bg-accent text-on-accent">Save</button>
                  <button type="button" class="{button} text-muted" onclick={() => (renaming = null)}>Cancel</button>
                </form>
              {:else}
                <div class="truncate text-lg font-medium">{inst.name}</div>
                <div class="text-sm text-muted">
                  Minecraft {inst.mc_version} · {loaderLabel(inst.loader, inst.loader_version)} · played {formatPlaytime(inst.playtime_s)}
                </div>
              {/if}
            </div>
            {#if launch.active}
              <button type="button" class="{button} border border-line" disabled>Game running</button>
            {:else}
              <button
                type="button"
                class="{button} bg-accent text-on-accent hover:brightness-110"
                disabled={instances.busy !== null}
                onclick={() => play(inst.id)}>Play</button
              >
            {/if}
          </div>

          <div class="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-sm">
            {#each [
              { label: 'Rename', run: () => startRename(inst.id, inst.name) },
              { label: 'Settings', run: () => startEdit(inst.id, inst.ram_mb, inst.jvm_args) },
              { label: 'Duplicate', run: () => instances.duplicate(inst.id, `${inst.name} copy`.slice(0, 64)) },
              { label: 'Export as Kiln file', run: () => instances.export(inst.id, 'kiln') },
              { label: 'Export as Modrinth pack', run: () => instances.export(inst.id, 'mrpack') },
              { label: 'Open folder', run: () => instances.openFolder('instance', inst.id) },
            ] as action (action.label)}
              <button
                type="button"
                class="cursor-pointer text-muted underline-offset-2 hover:text-ink hover:underline disabled:opacity-50"
                disabled={instances.busy === inst.id}
                onclick={action.run}>{action.label}</button
              >
            {/each}
            {#if confirmDelete === inst.id}
              <span class="text-danger">Delete this instance and its worlds?</span>
              <button
                type="button"
                class="cursor-pointer text-danger underline"
                onclick={async () => {
                  confirmDelete = null;
                  await instances.remove(inst.id);
                }}>Delete</button
              >
              <button type="button" class="cursor-pointer text-muted underline" onclick={() => (confirmDelete = null)}>Keep</button>
            {:else}
              <button
                type="button"
                class="cursor-pointer text-muted underline-offset-2 hover:text-danger hover:underline"
                onclick={() => (confirmDelete = inst.id)}>Delete</button
              >
            {/if}
          </div>

          {#if editing === inst.id}
            <form
              class="mt-4 grid max-w-2xl grid-cols-[10rem_1fr] items-center gap-x-4 gap-y-3"
              onsubmit={(e) => {
                e.preventDefault();
                void saveSettings();
              }}
            >
              <label class="text-sm text-muted" for="ram-{inst.id}">Memory (MB)</label>
              <input id="ram-{inst.id}" class="{field} w-40" placeholder="automatic" inputmode="numeric" bind:value={ramText} />
              <label class="text-sm text-muted" for="jvm-{inst.id}">Java arguments</label>
              <input id="jvm-{inst.id}" class="{field}" placeholder="-XX:+UseG1GC" bind:value={jvmText} />
              <div class="col-start-2 flex gap-3">
                <button type="submit" class="{button} bg-accent text-on-accent hover:brightness-110">Save</button>
                <button type="button" class="{button} text-muted" onclick={() => (editing = null)}>Cancel</button>
              </div>
              <p class="col-start-2 text-sm text-muted">
                Only memory and plain JVM options are accepted. Anything that loads code or changes Java's own paths is refused.
              </p>
            </form>
          {/if}
        </li>
      {/each}
    </ul>
  {/if}

  <h2 class="mt-12 font-display text-xl font-semibold">Import</h2>
  <p class="mt-2 max-w-prose text-sm text-muted">
    Put a Kiln export (.kiln.zip) or a Modrinth pack (.mrpack) in Kiln's imports folder, then pick it here.
  </p>
  <div class="mt-3 flex gap-3">
    <button type="button" class="{button} border border-line hover:bg-raised" onclick={() => instances.openFolder('imports')}
      >Open imports folder</button
    >
    <button type="button" class="{button} border border-line hover:bg-raised" onclick={() => instances.loadImports()}
      >Refresh</button
    >
    <button type="button" class="{button} border border-line hover:bg-raised" onclick={() => instances.openFolder('exports')}
      >Open exports folder</button
    >
  </div>
  {#if instances.imports.length > 0}
    <ul class="mt-4 divide-y divide-line border-y border-line">
      {#each instances.imports as file (file.name)}
        <li class="flex items-center gap-4 py-3">
          <div class="min-w-0 flex-1 truncate">{file.name} <span class="text-sm text-muted">{formatBytes(file.size)}</span></div>
          <button
            type="button"
            class="{button} border border-line hover:bg-raised"
            disabled={instances.busy !== null}
            onclick={() => instances.importFile(file.name)}
            >{instances.busy === 'import' ? 'Importing…' : 'Import'}</button
          >
        </li>
      {/each}
    </ul>
  {:else}
    <p class="mt-4 text-muted">Nothing waiting to import.</p>
  {/if}
  {#if instances.busy === 'import'}
    {@const percent = progressPercent(instances.progress)}
    <div class="mt-4 max-w-xl" role="status">
      <p>
        Importing…
        {#if instances.progress && instances.progress.bytes_total > 0}
          <span class="text-muted">
            {formatBytes(instances.progress.bytes_done)} of {formatBytes(instances.progress.bytes_total)}
            ({instances.progress.files_done} of {instances.progress.files_total} files)
          </span>
        {/if}
      </p>
      {#if percent !== null}
        <div
          class="mt-2 h-1.5 overflow-hidden rounded-full bg-raised"
          role="progressbar"
          aria-label="Import progress"
          aria-valuemin="0"
          aria-valuemax="100"
          aria-valuenow={percent}
        >
          <div class="h-full bg-accent transition-[width]" style:width="{percent}%"></div>
        </div>
      {/if}
    </div>
  {/if}
</section>
