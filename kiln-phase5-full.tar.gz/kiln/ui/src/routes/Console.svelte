<script lang="ts">
  import { tick } from 'svelte';
  import { formatBytes, progressPercent } from '../lib/format';
  import { launch } from '../lib/launch.svelte';

  let logEl: HTMLElement | undefined = $state();
  let pinned = true;

  // Follow new output, unless the reader has scrolled up to look at something.
  $effect(() => {
    void launch.lines.length;
    if (!logEl || !pinned) return;
    void tick().then(() => logEl && (logEl.scrollTop = logEl.scrollHeight));
  });

  function onScroll() {
    if (!logEl) return;
    pinned = logEl.scrollHeight - logEl.scrollTop - logEl.clientHeight < 24;
  }

  const status = $derived(launch.status);
  const percent = $derived(status.state === 'preparing' ? progressPercent(status.progress) : null);
  const button =
    'cursor-pointer rounded-md px-4 py-2 font-medium transition-colors disabled:cursor-not-allowed disabled:opacity-50';
</script>

<section class="flex h-full max-w-5xl flex-col">
  <div class="flex items-end justify-between gap-6">
    <h1 class="font-display text-5xl font-semibold tracking-tight">Console</h1>
    {#if launch.active}
      <button type="button" class="{button} border border-danger text-danger hover:bg-raised" onclick={() => launch.stop()}
        >{status.state === 'running' ? 'Stop game' : 'Cancel'}</button
      >
    {/if}
  </div>

  {#if launch.eventsError}
    <p role="alert" class="mt-6 rounded-md border border-danger px-4 py-3 text-danger">
      Live progress and game output are unavailable: {launch.eventsError}
    </p>
  {/if}

  {#if launch.error}
    <p role="alert" class="mt-6 rounded-md border border-danger px-4 py-3 text-danger">{launch.error}</p>
  {/if}

  <div class="mt-6 min-h-12" role="status" aria-live="polite">
    {#if status.state === 'preparing'}
      <p>
        {status.stage}…
        {#if status.progress && status.progress.bytes_total > 0}
          <span class="text-muted">
            {formatBytes(status.progress.bytes_done)} of {formatBytes(status.progress.bytes_total)}
            ({status.progress.files_done} of {status.progress.files_total} files)
          </span>
        {/if}
      </p>
      {#if percent !== null}
        <div
          class="mt-2 h-1.5 overflow-hidden rounded-full bg-raised"
          role="progressbar"
          aria-label="Download progress"
          aria-valuemin="0"
          aria-valuemax="100"
          aria-valuenow={percent}
        >
          <div class="h-full bg-accent transition-[width]" style:width="{percent}%"></div>
        </div>
      {/if}
    {:else if status.state === 'running'}
      <p>Game running.</p>
    {:else if status.state === 'exited'}
      <p class="text-muted">
        {status.code === null || status.code === 0 ? 'The game closed.' : `The game closed with exit code ${status.code}.`}
      </p>
    {:else if status.state === 'failed'}
      <p class="text-danger">{status.message}</p>
    {:else}
      <p class="text-muted">Start a game from the Instances page. Its output appears here.</p>
    {/if}
  </div>

  <!-- A scrollable region must be focusable so keyboard users can scroll it. -->
  <!-- svelte-ignore a11y_no_noninteractive_tabindex -->
  <div
    bind:this={logEl}
    onscroll={onScroll}
    tabindex="0"
    role="log"
    aria-label="Game output"
    class="mt-2 min-h-48 flex-1 overflow-auto rounded-md border border-line bg-surface p-4 font-mono text-sm leading-relaxed"
  >
    {#if launch.lines.length === 0}
      <p class="text-muted">Game output will appear here once a game starts.</p>
    {:else}
      {#each launch.lines as line, i (i)}
        <div class="break-all whitespace-pre-wrap {line.stream === 'stderr' ? 'text-danger' : ''}">{line.text}</div>
      {/each}
    {/if}
  </div>
</section>
