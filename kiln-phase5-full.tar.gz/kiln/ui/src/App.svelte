<script lang="ts">
  import { onMount } from 'svelte';
  import Icon from './components/Icon.svelte';
  import Placeholder from './components/Placeholder.svelte';
  import { router } from './lib/router.svelte';
  import { routes } from './lib/routes';
  import { settings } from './lib/settings.svelte';
  import { launch } from './lib/launch.svelte';
  import Accounts from './routes/Accounts.svelte';
  import Console from './routes/Console.svelte';
  import Instances from './routes/Instances.svelte';
  import Mods from './routes/Mods.svelte';
  import Settings from './routes/Settings.svelte';

  let main: HTMLElement | undefined = $state();
  let firstRoute = true;

  onMount(() => {
    void settings.init();
    void launch.init();
  });

  // Move focus to the content on navigation so keyboard and screen-reader users land there.
  $effect(() => {
    void router.current;
    if (firstRoute) {
      firstRoute = false;
      return;
    }
    main?.focus({ preventScroll: true });
  });
</script>

<a
  href="#main"
  class="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:left-2 focus:z-50 focus:rounded-md focus:bg-accent focus:px-3 focus:py-2 focus:text-on-accent"
  onclick={(e) => {
    e.preventDefault();
    main?.focus();
  }}>Skip to content</a
>

<div class="flex h-screen">
  <nav aria-label="Main" class="flex w-56 shrink-0 flex-col border-r border-line bg-surface py-6">
    <div class="px-6 font-display text-3xl font-semibold tracking-tight">Kiln</div>
    <ul class="mt-8 flex flex-col gap-0.5">
      {#each routes as r (r.id)}
        {@const active = router.current === r.id}
        <li>
          <a
            href="#/{r.id}"
            aria-current={active ? 'page' : undefined}
            class="flex items-center gap-3 border-l-[3px] py-2 pr-4 pl-5 transition-colors {active
              ? 'border-accent bg-raised font-medium text-ink'
              : 'border-transparent text-muted hover:bg-raised hover:text-ink'}"
          >
            <Icon name={r.icon} />
            {r.label}
          </a>
        </li>
      {/each}
    </ul>
  </nav>

  <main id="main" tabindex="-1" bind:this={main} class="min-w-0 flex-1 overflow-y-auto px-12 py-10 outline-none">
    {#if router.current === 'settings'}
      <Settings />
    {:else if settings.error && !settings.value}
      <section class="max-w-prose">
        <h1 class="font-display text-3xl font-semibold">Kiln couldn't start properly</h1>
        <p role="alert" class="mt-3 text-danger">{settings.error}</p>
        <button
          type="button"
          class="mt-6 cursor-pointer rounded-md bg-accent px-4 py-2 font-medium text-on-accent"
          onclick={() => settings.init()}>Try again</button
        >
      </section>
    {:else if router.current === 'home'}
      <Placeholder
        title="Home"
        body="Your most recently played instances and launcher news will appear here."
        phase={7}
      />
    {:else if router.current === 'instances'}
      <Instances />
    {:else if router.current === 'mods'}
      <Mods />
    {:else if router.current === 'accounts'}
      <Accounts />
    {:else if router.current === 'console'}
      <Console />
    {/if}
  </main>
</div>
