import { defineConfig } from 'vite';
import { svelte } from '@sveltejs/vite-plugin-svelte';
import tailwindcss from '@tailwindcss/vite';

export default defineConfig({
  plugins: [tailwindcss(), svelte()],
  clearScreen: false,
  server: { port: 5173, strictPort: true },
  build: {
    target: ['es2021', 'chrome105', 'safari15'],
    // Never inline assets as data: URIs, so the CSP can stay `font-src 'self'`.
    assetsInlineLimit: 0,
  },
});
