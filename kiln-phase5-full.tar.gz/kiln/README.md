# Kiln

A fast, secure, cross-platform Minecraft Java Edition launcher (Windows, macOS, Linux).
"Kiln" is a working codename: the display name lives in `kiln_core::APP_NAME` and
`src-tauri/tauri.conf.json`.

> Kiln is not affiliated with Mojang or Microsoft. Minecraft is a trademark of Mojang AB.
> A legitimately owned Minecraft account is required for online play.

**Status:** Phase 5 of 8 done (scaffold, settings, SQLite, logging, CI, Microsoft sign-in with OS keychain, version manifests, Java manager, verified downloader, launching, instances, Fabric/Quilt/NeoForge/Forge loaders, `.kiln.zip` and `.mrpack` import/export, Modrinth browsing, installs with dependencies, updates with automatic rollback, modpack install and update). Real sign-in needs an approved client ID: see [docs/AUTH.md](docs/AUTH.md). Real downloads, loader installs, launches and Modrinth traffic have only been tested against mock servers. See
[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for the roadmap.

## Layout

| Path | Purpose |
|---|---|
| `crates/kiln-core` | All launcher logic. No GUI dependency, fully unit-tested. |
| `src-tauri` | Tauri 2 shell: validates IPC input, calls core, maps errors. |
| `ui` | Svelte 5 + TypeScript + Tailwind 4 frontend. |

## Build and test

Requirements: Rust 1.85+, Node 22+. On Linux, Tauri's system libraries
(`libwebkit2gtk-4.1-dev`, `libgtk-3-dev`, `libayatana-appindicator3-dev`, `librsvg2-dev`,
`libsoup-3.0-dev`) plus `libdbus-1-dev` for the keychain.

```sh
# Core logic only (no WebView libraries needed)
cargo test

# Whole workspace, as CI runs it
(cd ui && npm ci && npm run build)
cargo fmt --all --check
cargo clippy --workspace --all-targets -- -D warnings
cargo test --workspace

# UI checks
(cd ui && npm run check && npm test)

# Run the desktop app
cargo install tauri-cli --version "^2" --locked
cargo tauri dev
```

`npm run dev` inside `ui/` also works in a plain browser using an in-memory stand-in for
the backend, which is handy for styling work. Set `KILN_LOG=debug` (any `tracing` filter)
to override the log level.

## Data and portable mode

Data lives in the platform data directory under `Kiln`. Create a file or folder named
`kiln-portable` next to the executable to keep everything in `kiln-data/` beside the app.

## Security model (summary)

Full document arrives in Phase 8. What already holds:

- Only the `allow-*` permissions in `src-tauri/capabilities` are granted to the webview;
  there are no `fs`, `shell` or `http` plugins.
- Strict CSP: no inline or remote scripts, no `eval`, fonts and styles from the app only.
- Every log line passes through a redactor that masks tokens, launch credentials,
  e-mail addresses and OS account names before it is written.
- `SafePath` is the only way to turn untrusted relative paths into file operations: it
  rejects `..`, absolute paths, Windows device names and symlink escapes.
- Sign-in tokens: refresh tokens exist only in the OS keychain, access tokens only in memory, and
  none ever reaches the webview or a log.
- All network traffic goes through one client that is HTTPS-only, allowlisted by host and
  never follows redirects.
- Hashes are verified with SHA-1/256/512 before any downloaded file is kept (files are written to `.part` and renamed only after verification).
- Archives are extracted through `SafePath` (zip-slip safe), with hard links refused, symlinks confined to the target folder and a size cap.
- Game output shown in the Console passes through the log redactor first.
- Per-instance Java arguments are vetted (no agents, no `-XX:OnError`, no overriding Java's own paths); imported packs never bring JVM arguments, and nothing in a pack is executed.
- The webview never supplies a file path: imports name a file in Kiln's `imports/` folder, exports go to `exports/`.
- Forge and NeoForge installers run their processors with the user's privileges, after the installer's published checksum is verified: see `docs/NEXT_STEPS.md` for the trust note.
- Mods: ids are validated before they reach a URL, a file is installed only if its name is a plain `.jar`, its URL is on `cdn.modrinth.com` and it carries a hash that matches after download. Jars Modrinth doesn't know are labelled "Unverified" and never show an author, download count or licence. An update keeps the old jar; if the game then fails to start within two minutes, Kiln checks the backup against its recorded hash and puts it back. Modrinth's rate limit is honoured and API responses are cached by ETag. Modpack updates never overwrite or remove files you added.
- No telemetry.

## Licensing

Kiln is released under **GPL-3.0-only** (see `LICENSE`). Bundled or auto-installed mods
keep their own licenses; Kiln only downloads them from their official source and never
redistributes them itself. A Modrinth `.mrpack` export lists mods Modrinth hosts by hash and URL
instead of copying them; jars Modrinth doesn't know are bundled, and Kiln lists them so you can
check you may share them.
