//! End-to-end: initialise the real subscriber (once per process, hence a separate test
//! binary), log secrets, and confirm none reach the log file on disk.

use kiln_core::logging;

#[test]
fn log_file_never_contains_secrets() {
    let dir = tempfile::tempdir().unwrap();
    {
        let guard = logging::init(dir.path(), "info", false).unwrap();
        tracing::info!("signed in alex@example.com with refresh_token=M.R3_BAY.TOPSECRET");
        tracing::debug!("this debug line is below the level and must not appear");
        guard.set_level("debug").unwrap();
        tracing::debug!("now visible, still no --accessToken hunter2");
        assert!(guard.set_level("nonsense").is_err());
        // Dropping the guard flushes the background writer.
    }

    let mut combined = String::new();
    for entry in std::fs::read_dir(dir.path()).unwrap() {
        combined.push_str(&std::fs::read_to_string(entry.unwrap().path()).unwrap());
    }

    assert!(combined.contains("signed in"), "{combined}");
    assert!(combined.contains("now visible"), "{combined}");
    assert!(!combined.contains("must not appear"), "{combined}");
    for leaked in ["alex@example.com", "TOPSECRET", "hunter2"] {
        assert!(!combined.contains(leaked), "leaked {leaked}: {combined}");
    }
}
