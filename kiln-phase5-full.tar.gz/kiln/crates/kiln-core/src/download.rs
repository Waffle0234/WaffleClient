//! Parallel, resumable, verified downloads.
//!
//! Every file is written to `<dest>.part`, hashed while it is written, checked against its
//! expected digest, and only then renamed over `<dest>`, so a file at its final path has
//! always passed verification. Interrupted downloads resume with a `Range` request.
//! Destinations are [`SafePath`]s: callers can't hand this module a raw path.

use std::collections::HashSet;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicU64, AtomicUsize, Ordering};
use std::sync::Arc;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

use serde::Serialize;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::sync::{watch, Semaphore};
use tokio::task::JoinSet;

use crate::hash::{ExpectedHash, StreamHasher};
use crate::net::HttpClient;
use crate::paths::SafePath;
use crate::{Error, Result};

/// One file to fetch.
#[derive(Debug, Clone)]
pub struct DownloadTask {
    pub url: String,
    pub dest: SafePath,
    /// Verified before the file is kept. Strongly preferred.
    pub hash: Option<ExpectedHash>,
    /// Expected size in bytes. Used for progress, for cheap "already have it" checks and to
    /// reject over-long responses.
    pub size: Option<u64>,
}

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize)]
pub struct Progress {
    pub bytes_done: u64,
    pub bytes_total: u64,
    pub files_done: usize,
    pub files_total: usize,
}

#[derive(Debug, Clone)]
pub struct RetryPolicy {
    pub attempts: u32,
    pub base_delay: Duration,
}

impl Default for RetryPolicy {
    fn default() -> Self {
        Self {
            attempts: 4,
            base_delay: Duration::from_millis(500),
        }
    }
}

impl RetryPolicy {
    /// Exponential backoff with up to 50% jitter, capped at 30 s.
    fn delay(&self, attempt: u32) -> Duration {
        let exp = self
            .base_delay
            .saturating_mul(2u32.saturating_pow(attempt))
            .min(Duration::from_secs(30));
        let nanos = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map_or(0, |d| u64::from(d.subsec_nanos()));
        // Cheap jitter: no need for a random-number crate to desynchronize retries.
        let jitter = exp.as_nanos() as u64 / 2;
        let extra = if jitter == 0 { 0 } else { nanos % jitter };
        exp + Duration::from_nanos(extra)
    }
}

/// Why one attempt failed, and whether trying again makes sense.
enum Failure {
    Retry(Error),
    Fatal(Error),
}

struct Tracker {
    bytes_done: AtomicU64,
    bytes_total: u64,
    files_done: AtomicUsize,
    files_total: usize,
    tx: Option<watch::Sender<Progress>>,
}

impl Tracker {
    fn publish(&self) {
        if let Some(tx) = &self.tx {
            tx.send_replace(Progress {
                bytes_done: self.bytes_done.load(Ordering::Relaxed),
                bytes_total: self.bytes_total,
                files_done: self.files_done.load(Ordering::Relaxed),
                files_total: self.files_total,
            });
        }
    }

    fn add(&self, n: u64) {
        self.bytes_done.fetch_add(n, Ordering::Relaxed);
        self.publish();
    }

    fn sub(&self, n: u64) {
        let _ = self
            .bytes_done
            .fetch_update(Ordering::Relaxed, Ordering::Relaxed, |v| {
                Some(v.saturating_sub(n))
            });
        self.publish();
    }

    fn file_done(&self) {
        self.files_done.fetch_add(1, Ordering::Relaxed);
        self.publish();
    }
}

#[derive(Debug, Clone)]
pub struct Downloader {
    http: HttpClient,
    max_concurrent: usize,
    retry: RetryPolicy,
}

fn part_path(dest: &SafePath) -> PathBuf {
    let mut name = dest.as_path().as_os_str().to_owned();
    name.push(".part");
    PathBuf::from(name)
}

fn io_err(e: std::io::Error) -> Error {
    Error::Io(e)
}

impl Downloader {
    /// `max_concurrent` is the `max_concurrent_downloads` setting (clamped to 1..=16).
    pub fn new(http: HttpClient, max_concurrent: u8) -> Self {
        Self {
            http,
            max_concurrent: usize::from(max_concurrent).clamp(1, 16),
            retry: RetryPolicy::default(),
        }
    }

    pub fn with_retry(mut self, retry: RetryPolicy) -> Self {
        self.retry = retry;
        self
    }

    /// Download every task, at most `max_concurrent` at a time. Stops at the first failure.
    /// Tasks with the same destination are fetched once.
    pub async fn download_all(
        &self,
        tasks: Vec<DownloadTask>,
        progress: Option<watch::Sender<Progress>>,
    ) -> Result<()> {
        let mut seen = HashSet::new();
        let tasks: Vec<DownloadTask> = tasks
            .into_iter()
            .filter(|t| seen.insert(t.dest.as_path().to_path_buf()))
            .collect();
        let tracker = Arc::new(Tracker {
            bytes_done: AtomicU64::new(0),
            bytes_total: tasks.iter().filter_map(|t| t.size).sum(),
            files_done: AtomicUsize::new(0),
            files_total: tasks.len(),
            tx: progress,
        });
        tracker.publish();

        let this = Arc::new(self.clone());
        let limit = Arc::new(Semaphore::new(self.max_concurrent));
        let mut set = JoinSet::new();
        for task in tasks {
            let (this, limit, tracker) = (this.clone(), limit.clone(), tracker.clone());
            set.spawn(async move {
                let _permit = limit
                    .acquire_owned()
                    .await
                    .map_err(|e| Error::Io(std::io::Error::other(e)))?;
                this.download_one(&task, &tracker).await
            });
        }
        while let Some(joined) = set.join_next().await {
            let outcome = joined.map_err(|e| Error::Io(std::io::Error::other(e)));
            if let Err(e) | Ok(Err(e)) = outcome {
                set.abort_all();
                return Err(e);
            }
        }
        Ok(())
    }

    /// Download a single file with no progress reporting.
    pub async fn download(&self, task: DownloadTask) -> Result<()> {
        self.download_all(vec![task], None).await
    }

    async fn download_one(&self, task: &DownloadTask, tracker: &Tracker) -> Result<()> {
        if let Some(parent) = task.dest.as_path().parent() {
            tokio::fs::create_dir_all(parent).await.map_err(io_err)?;
        }
        if is_already_present(task).await {
            if let Some(size) = task.size {
                tracker.add(size);
            }
            tracker.file_done();
            return Ok(());
        }
        let mut counted = 0u64;
        for attempt in 0..self.retry.attempts.max(1) {
            match self.attempt(task, tracker, &mut counted).await {
                Ok(()) => {
                    tracker.file_done();
                    return Ok(());
                }
                Err(Failure::Fatal(e)) => return Err(e),
                Err(Failure::Retry(e)) => {
                    if attempt + 1 >= self.retry.attempts.max(1) {
                        return Err(e);
                    }
                    tracing::debug!(attempt, "download attempt failed; retrying");
                    tokio::time::sleep(self.retry.delay(attempt)).await;
                }
            }
        }
        Err(Error::Http("download failed".into()))
    }

    async fn attempt(
        &self,
        task: &DownloadTask,
        tracker: &Tracker,
        counted: &mut u64,
    ) -> std::result::Result<(), Failure> {
        let part = part_path(&task.dest);
        let mut existing = match tokio::fs::metadata(&part).await {
            Ok(m) if m.is_file() => m.len(),
            _ => 0,
        };
        // A leftover longer than the file can't be a prefix of it.
        if task.size.is_some_and(|s| existing > s) {
            discard(&part, tracker, counted).await;
            existing = 0;
        }
        // Bytes counted by a failed earlier attempt are re-counted from the file.
        tracker.sub(*counted);
        *counted = 0;

        let mut hasher = task.hash.as_ref().map(|h| StreamHasher::new(h.algo()));
        let mut written = 0u64;

        let complete_already = task.size == Some(existing) && existing > 0;
        if complete_already {
            written = prefix_into(&part, &mut hasher, tracker, counted).await?;
        } else {
            let mut stream = self
                .http
                .get_stream(&task.url, (existing > 0).then_some(existing))
                .await
                .map_err(Failure::Retry)?;
            let resuming = match stream.status {
                206 if stream.content_range_start == Some(existing) && existing > 0 => true,
                200 => false,
                416 => {
                    discard(&part, tracker, counted).await;
                    return Err(Failure::Retry(Error::Http(
                        "the server rejected a resumed download".into(),
                    )));
                }
                206 => {
                    discard(&part, tracker, counted).await;
                    return Err(Failure::Retry(Error::Http(
                        "the server resumed at the wrong position".into(),
                    )));
                }
                429 | 500..=599 => {
                    return Err(Failure::Retry(Error::Http(format!(
                        "the server is busy (HTTP {})",
                        stream.status
                    ))));
                }
                status => {
                    return Err(Failure::Fatal(Error::Http(format!(
                        "the server refused the download (HTTP {status})"
                    ))));
                }
            };

            let mut file = if resuming {
                written = prefix_into(&part, &mut hasher, tracker, counted).await?;
                tokio::fs::OpenOptions::new()
                    .append(true)
                    .open(&part)
                    .await
                    .map_err(|e| Failure::Retry(io_err(e)))?
            } else {
                tokio::fs::File::create(&part)
                    .await
                    .map_err(|e| Failure::Retry(io_err(e)))?
            };

            while let Some(chunk) = stream.next_chunk().await.map_err(Failure::Retry)? {
                written += chunk.len() as u64;
                if task.size.is_some_and(|s| written > s) {
                    drop(file);
                    discard(&part, tracker, counted).await;
                    return Err(Failure::Retry(Error::Http(
                        "the server sent more data than expected".into(),
                    )));
                }
                if let Some(h) = hasher.as_mut() {
                    h.update(&chunk);
                }
                file.write_all(&chunk)
                    .await
                    .map_err(|e| Failure::Fatal(io_err(e)))?;
                tracker.add(chunk.len() as u64);
                *counted += chunk.len() as u64;
            }
            file.flush().await.map_err(|e| Failure::Fatal(io_err(e)))?;
        }

        // A short body keeps its .part so the next attempt can resume.
        if task.size.is_some_and(|s| written != s) {
            return Err(Failure::Retry(Error::Http(
                "the download ended early".into(),
            )));
        }
        if let (Some(hasher), Some(expected)) = (hasher, &task.hash) {
            let actual = hasher.finalize_hex();
            if actual != expected.hex() {
                discard(&part, tracker, counted).await;
                return Err(Failure::Retry(Error::HashMismatch {
                    expected: expected.hex().to_owned(),
                    actual,
                }));
            }
        }
        tokio::fs::rename(&part, task.dest.as_path())
            .await
            .map_err(|e| Failure::Fatal(io_err(e)))?;
        Ok(())
    }
}

async fn is_already_present(task: &DownloadTask) -> bool {
    let Ok(meta) = tokio::fs::metadata(task.dest.as_path()).await else {
        return false;
    };
    if !meta.is_file() {
        return false;
    }
    // Files only reach their final path after verification, so a size match is enough
    // to skip them cheaply (this runs for thousands of assets on every launch).
    if let Some(size) = task.size {
        return meta.len() == size;
    }
    match &task.hash {
        Some(h) => crate::hash::verify_file(task.dest.as_path(), h)
            .await
            .is_ok(),
        None => false,
    }
}

async fn discard(part: &Path, tracker: &Tracker, counted: &mut u64) {
    let _ = tokio::fs::remove_file(part).await;
    tracker.sub(*counted);
    *counted = 0;
}

/// Feed the bytes already on disk into the hasher and count them as done.
async fn prefix_into(
    part: &Path,
    hasher: &mut Option<StreamHasher>,
    tracker: &Tracker,
    counted: &mut u64,
) -> std::result::Result<u64, Failure> {
    let mut file = tokio::fs::File::open(part)
        .await
        .map_err(|e| Failure::Retry(io_err(e)))?;
    let mut buf = vec![0u8; 64 * 1024];
    let mut total = 0u64;
    loop {
        let n = file
            .read(&mut buf)
            .await
            .map_err(|e| Failure::Retry(io_err(e)))?;
        if n == 0 {
            break;
        }
        if let Some(h) = hasher.as_mut() {
            h.update(&buf[..n]);
        }
        total += n as u64;
    }
    tracker.add(total);
    *counted += total;
    Ok(total)
}

/// Put `src` at `dst` as a hard link, falling back to a copy when the two are on different
/// filesystems (or the filesystem has no hard links). Used to share cached files between
/// instances without duplicating them.
pub fn link_or_copy(src: &Path, dst: &SafePath) -> Result<()> {
    if let Some(parent) = dst.as_path().parent() {
        std::fs::create_dir_all(parent)?;
    }
    match std::fs::remove_file(dst.as_path()) {
        Ok(()) => {}
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => {}
        Err(e) => return Err(e.into()),
    }
    if std::fs::hard_link(src, dst.as_path()).is_err() {
        std::fs::copy(src, dst.as_path())?;
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use wiremock::matchers::{header, path};
    use wiremock::{Mock, MockServer, ResponseTemplate};

    use super::*;
    use crate::hash::{hash_bytes, HashAlgo};
    use crate::net::HostPolicy;

    fn downloader() -> Downloader {
        let http =
            HttpClient::new_for_downloads("Kiln-test/0", HostPolicy::new(&[]).with_loopback_http())
                .unwrap();
        Downloader::new(http, 4).with_retry(RetryPolicy {
            attempts: 3,
            base_delay: Duration::from_millis(1),
        })
    }

    fn data(n: usize) -> Vec<u8> {
        (0..n).map(|i| (i % 251) as u8).collect()
    }

    fn task(server: &MockServer, root: &Path, name: &str, body: &[u8]) -> DownloadTask {
        DownloadTask {
            url: format!("{}/{name}", server.uri()),
            dest: SafePath::new(root, name).unwrap(),
            hash: Some(
                ExpectedHash::new(HashAlgo::Sha1, &hash_bytes(HashAlgo::Sha1, body)).unwrap(),
            ),
            size: Some(body.len() as u64),
        }
    }

    async fn requests(server: &MockServer) -> usize {
        server.received_requests().await.unwrap().len()
    }

    #[tokio::test]
    async fn downloads_verifies_and_leaves_no_part_file() {
        let server = MockServer::start().await;
        let dir = tempfile::tempdir().unwrap();
        let body = data(100_000);
        Mock::given(path("/a/f.bin"))
            .respond_with(ResponseTemplate::new(200).set_body_bytes(body.clone()))
            .mount(&server)
            .await;
        let t = task(&server, dir.path(), "a/f.bin", &body);

        let (tx, rx) = watch::channel(Progress::default());
        downloader()
            .download_all(vec![t.clone()], Some(tx))
            .await
            .unwrap();

        assert_eq!(std::fs::read(t.dest.as_path()).unwrap(), body);
        assert!(!part_path(&t.dest).exists());
        let p = *rx.borrow();
        assert_eq!(p.bytes_done, 100_000);
        assert_eq!(p.bytes_total, 100_000);
        assert_eq!((p.files_done, p.files_total), (1, 1));
    }

    #[tokio::test]
    async fn a_hash_mismatch_discards_the_file_and_reports_it() {
        let server = MockServer::start().await;
        let dir = tempfile::tempdir().unwrap();
        let good = data(5000);
        let mut evil = good.clone();
        evil[10] ^= 0xff;
        Mock::given(path("/f.bin"))
            .respond_with(ResponseTemplate::new(200).set_body_bytes(evil))
            .mount(&server)
            .await;
        let t = task(&server, dir.path(), "f.bin", &good);

        let err = downloader().download(t.clone()).await.unwrap_err();
        assert!(matches!(err, Error::HashMismatch { .. }), "{err:?}");
        assert!(
            !t.dest.as_path().exists(),
            "unverified data must not be kept"
        );
        assert!(!part_path(&t.dest).exists());
    }

    #[tokio::test]
    async fn an_interrupted_download_resumes_from_the_part_file() {
        let server = MockServer::start().await;
        let dir = tempfile::tempdir().unwrap();
        let body = data(80_000);
        Mock::given(path("/f.bin"))
            .and(header("range", "bytes=30000-"))
            .respond_with(
                ResponseTemplate::new(206)
                    .insert_header("content-range", "bytes 30000-79999/80000")
                    .set_body_bytes(body[30_000..].to_vec()),
            )
            .mount(&server)
            .await;
        let t = task(&server, dir.path(), "f.bin", &body);
        std::fs::write(part_path(&t.dest), &body[..30_000]).unwrap();

        let (tx, rx) = watch::channel(Progress::default());
        downloader()
            .download_all(vec![t.clone()], Some(tx))
            .await
            .unwrap();

        assert_eq!(std::fs::read(t.dest.as_path()).unwrap(), body);
        assert_eq!(requests(&server).await, 1);
        assert_eq!(rx.borrow().bytes_done, 80_000, "resumed bytes count once");
    }

    #[tokio::test]
    async fn a_corrupt_part_file_is_caught_by_the_hash_and_redone_from_scratch() {
        let server = MockServer::start().await;
        let dir = tempfile::tempdir().unwrap();
        let body = data(20_000);
        Mock::given(path("/f.bin"))
            .and(header("range", "bytes=5000-"))
            .respond_with(
                ResponseTemplate::new(206)
                    .insert_header("content-range", "bytes 5000-19999/20000")
                    .set_body_bytes(body[5000..].to_vec()),
            )
            .with_priority(1)
            .mount(&server)
            .await;
        Mock::given(path("/f.bin"))
            .respond_with(ResponseTemplate::new(200).set_body_bytes(body.clone()))
            .with_priority(2)
            .mount(&server)
            .await;
        let t = task(&server, dir.path(), "f.bin", &body);
        std::fs::write(part_path(&t.dest), vec![0u8; 5000]).unwrap(); // wrong prefix

        downloader().download(t.clone()).await.unwrap();
        assert_eq!(std::fs::read(t.dest.as_path()).unwrap(), body);
    }

    #[tokio::test]
    async fn a_server_that_ignores_range_restarts_cleanly() {
        let server = MockServer::start().await;
        let dir = tempfile::tempdir().unwrap();
        let body = data(40_000);
        Mock::given(path("/f.bin"))
            .respond_with(ResponseTemplate::new(200).set_body_bytes(body.clone()))
            .mount(&server)
            .await;
        let t = task(&server, dir.path(), "f.bin", &body);
        std::fs::write(part_path(&t.dest), &body[..10_000]).unwrap();

        downloader().download(t.clone()).await.unwrap();
        assert_eq!(std::fs::read(t.dest.as_path()).unwrap(), body);
    }

    #[tokio::test]
    async fn transient_server_errors_are_retried() {
        let server = MockServer::start().await;
        let dir = tempfile::tempdir().unwrap();
        let body = data(1000);
        Mock::given(path("/f.bin"))
            .respond_with(ResponseTemplate::new(503))
            .up_to_n_times(2)
            .with_priority(1)
            .mount(&server)
            .await;
        Mock::given(path("/f.bin"))
            .respond_with(ResponseTemplate::new(200).set_body_bytes(body.clone()))
            .with_priority(2)
            .mount(&server)
            .await;
        let t = task(&server, dir.path(), "f.bin", &body);
        downloader().download(t.clone()).await.unwrap();
        assert_eq!(requests(&server).await, 3);
    }

    #[tokio::test]
    async fn client_errors_are_not_retried() {
        let server = MockServer::start().await;
        let dir = tempfile::tempdir().unwrap();
        Mock::given(path("/f.bin"))
            .respond_with(ResponseTemplate::new(404))
            .mount(&server)
            .await;
        let t = task(&server, dir.path(), "f.bin", b"x");
        assert!(downloader().download(t).await.is_err());
        assert_eq!(requests(&server).await, 1);
    }

    #[tokio::test]
    async fn existing_files_of_the_right_size_are_not_downloaded_again() {
        let server = MockServer::start().await;
        let dir = tempfile::tempdir().unwrap();
        let body = data(777);
        let t = task(&server, dir.path(), "have.bin", &body);
        std::fs::write(t.dest.as_path(), &body).unwrap();
        downloader().download(t).await.unwrap();
        assert_eq!(requests(&server).await, 0);
    }

    #[tokio::test]
    async fn over_long_responses_are_rejected() {
        let server = MockServer::start().await;
        let dir = tempfile::tempdir().unwrap();
        Mock::given(path("/f.bin"))
            .respond_with(ResponseTemplate::new(200).set_body_bytes(data(2000)))
            .mount(&server)
            .await;
        let t = task(&server, dir.path(), "f.bin", &data(1000));
        assert!(downloader().download(t.clone()).await.is_err());
        assert!(!t.dest.as_path().exists());
    }

    #[tokio::test]
    async fn many_files_download_in_parallel_and_duplicates_are_fetched_once() {
        let server = MockServer::start().await;
        let dir = tempfile::tempdir().unwrap();
        let mut tasks = Vec::new();
        for i in 0..20 {
            let body = data(500 + i);
            let name = format!("d/{i}.bin");
            Mock::given(path(format!("/{name}")))
                .respond_with(ResponseTemplate::new(200).set_body_bytes(body.clone()))
                .mount(&server)
                .await;
            tasks.push(task(&server, dir.path(), &name, &body));
        }
        tasks.push(tasks[0].clone());
        downloader().download_all(tasks, None).await.unwrap();
        assert_eq!(requests(&server).await, 20);
    }

    #[test]
    fn link_or_copy_replaces_the_destination() {
        let dir = tempfile::tempdir().unwrap();
        let src = dir.path().join("src.bin");
        std::fs::write(&src, b"one").unwrap();
        let dst = SafePath::new(dir.path(), "inst/lib/dst.bin").unwrap();
        link_or_copy(&src, &dst).unwrap();
        std::fs::write(&src, b"two").unwrap_or_default();
        let dst2 = SafePath::new(dir.path(), "inst/lib/dst.bin").unwrap();
        link_or_copy(&src, &dst2).unwrap();
        assert_eq!(std::fs::read(dst2.as_path()).unwrap(), b"two");
    }

    #[test]
    fn backoff_grows_and_is_capped() {
        let p = RetryPolicy {
            attempts: 10,
            base_delay: Duration::from_millis(100),
        };
        assert!(p.delay(0) >= Duration::from_millis(100));
        assert!(p.delay(3) >= Duration::from_millis(800));
        assert!(p.delay(20) <= Duration::from_secs(45));
    }
}
