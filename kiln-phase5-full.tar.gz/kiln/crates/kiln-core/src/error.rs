//! Error types. [`Error`] carries technical detail (logged, redacted);
//! [`AppError`] is what crosses the IPC boundary: a stable code and a plain-English message.

use serde::Serialize;

use crate::auth::AuthError;
use crate::launch::LaunchError;
use crate::mods::ModsError;

pub type Result<T> = std::result::Result<T, Error>;

#[derive(Debug, thiserror::Error)]
pub enum Error {
    #[error("path rejected: {0}")]
    InvalidPath(String),
    #[error("hash mismatch: expected {expected}, got {actual}")]
    HashMismatch { expected: String, actual: String },
    #[error("invalid hash: {0}")]
    InvalidHash(String),
    #[error("unknown setting: {0}")]
    UnknownSetting(String),
    #[error("invalid value for setting {key}: {reason}")]
    InvalidSetting { key: String, reason: String },
    #[error("database error: {0}")]
    Database(#[from] sqlx::Error),
    #[error("database migration failed: {0}")]
    Migration(#[from] sqlx::migrate::MigrateError),
    #[error("I/O error: {0}")]
    Io(#[from] std::io::Error),
    #[error("JSON error: {0}")]
    Json(#[from] serde_json::Error),
    #[error("logging setup failed: {0}")]
    Logging(String),
    #[error("network error: {0}")]
    Http(String),
    #[error("connection blocked by host policy: {0}")]
    HostNotAllowed(String),
    #[error("keychain error: {0}")]
    Keychain(String),
    #[error("archive error: {0}")]
    Archive(String),
    #[error(transparent)]
    Auth(#[from] AuthError),
    #[error(transparent)]
    Launch(#[from] LaunchError),
    #[error(transparent)]
    Mods(#[from] ModsError),
}

impl Error {
    /// Stable machine-readable code for the UI.
    pub fn code(&self) -> &'static str {
        match self {
            Self::InvalidPath(_) => "invalid_path",
            Self::HashMismatch { .. } => "hash_mismatch",
            Self::InvalidHash(_) => "invalid_hash",
            Self::UnknownSetting(_) => "unknown_setting",
            Self::InvalidSetting { .. } => "invalid_setting",
            Self::Database(_) => "database",
            Self::Migration(_) => "migration",
            Self::Io(_) => "io",
            Self::Json(_) => "json",
            Self::Logging(_) => "logging",
            Self::Http(_) => "network",
            Self::HostNotAllowed(_) => "host_not_allowed",
            Self::Keychain(_) => "keychain",
            Self::Archive(_) => "archive",
            Self::Auth(e) => e.code(),
            Self::Launch(e) => e.code(),
            Self::Mods(e) => e.code(),
        }
    }

    /// Plain-English message for the user. Never includes file paths, which can contain
    /// the person's account name.
    pub fn user_message(&self) -> String {
        match self {
            Self::InvalidPath(_) => {
                "That file path isn't allowed because it points outside Kiln's folders.".into()
            }
            Self::HashMismatch { .. } => "A downloaded file didn't match its expected checksum, \
                so Kiln discarded it. Try again. If it keeps happening, check your network \
                connection and antivirus."
                .into(),
            Self::InvalidHash(_) => "Kiln was given a checksum it couldn't understand.".into(),
            Self::UnknownSetting(key) => format!("Kiln has no setting called \"{key}\"."),
            Self::InvalidSetting { key, reason } => {
                format!("\"{key}\" can't be set to that value: {reason}.")
            }
            Self::Database(_) => "Kiln couldn't read or write its database. Make sure its data \
                folder is writable and the disk isn't full, then restart Kiln."
                .into(),
            Self::Migration(_) => "Kiln couldn't upgrade its database. Restart Kiln. If this \
                repeats, restore the data folder from a backup."
                .into(),
            Self::Io(_) => {
                "Kiln couldn't access a file or folder. Check permissions and free disk space."
                    .into()
            }
            Self::Json(_) => "Kiln found data it couldn't understand.".into(),
            Self::Logging(_) => "Kiln couldn't set up its log files.".into(),
            Self::Http(_) => "Kiln couldn't reach the server. Check your internet connection \
                and try again."
                .into(),
            Self::HostNotAllowed(_) => {
                "Kiln refused to connect to an address it doesn't trust.".into()
            }
            Self::Keychain(_) => {
                if cfg!(target_os = "linux") {
                    "Kiln couldn't use your system keychain to store your sign-in. Install and \
                     unlock a Secret Service provider such as GNOME Keyring or KWallet, then try \
                     again."
                        .into()
                } else {
                    "Kiln couldn't use your system keychain to store your sign-in. Make sure it \
                     is unlocked and available, then try again."
                        .into()
                }
            }
            Self::Archive(_) => "Kiln couldn't unpack a downloaded archive. It may be damaged: \
                try again."
                .into(),
            Self::Auth(e) => e.user_message(),
            Self::Launch(e) => e.user_message(),
            Self::Mods(e) => e.user_message(),
        }
    }
}

/// Serializable error returned from every IPC command.
#[derive(Debug, Clone, Serialize, PartialEq, Eq)]
pub struct AppError {
    pub code: &'static str,
    pub message: String,
}

impl From<Error> for AppError {
    fn from(e: Error) -> Self {
        // Technical detail goes to the (redacting) log, not to the UI.
        tracing::error!(error = %e, code = e.code(), "command failed");
        Self {
            code: e.code(),
            message: e.user_message(),
        }
    }
}
