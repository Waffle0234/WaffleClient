//! Archive extraction (zip and tar.gz) that treats every entry name as hostile.
//!
//! Each entry's destination is built with [`SafePath`], which rejects `..`, absolute paths,
//! Windows device names and anything that resolves outside the target folder through a
//! symlink. Hard links are refused; symlinks are only created when their target stays
//! inside the folder. A total-size cap stops decompression bombs.

use std::collections::HashSet;
use std::fs::File;
use std::io::{self, Read};
use std::path::Path;

use crate::paths::{validate_relative, SafePath};
use crate::{Error, Result};

/// Default cap on the total unpacked size: more than any JDK or natives bundle we handle.
pub const DEFAULT_MAX_UNPACKED: u64 = 2 * 1024 * 1024 * 1024;

pub struct ExtractOptions<'a> {
    /// Leading path components to drop from every entry (`1` removes a JDK's top folder).
    pub strip_components: usize,
    pub max_total_bytes: u64,
    /// Return `false` to skip an entry. Receives the entry's original name.
    pub filter: Option<&'a dyn Fn(&str) -> bool>,
}

impl Default for ExtractOptions<'_> {
    fn default() -> Self {
        Self {
            strip_components: 0,
            max_total_bytes: DEFAULT_MAX_UNPACKED,
            filter: None,
        }
    }
}

fn bad(msg: impl Into<String>) -> Error {
    Error::Archive(msg.into())
}

impl From<zip::result::ZipError> for Error {
    fn from(e: zip::result::ZipError) -> Self {
        Self::Archive(e.to_string())
    }
}

/// Where an entry goes, or `None` if it is the stripped-away top folder itself.
fn destination(root: &Path, name: &str, strip: usize) -> Result<Option<SafePath>> {
    // Validate the whole original name first so a `..` hidden in a stripped component
    // is still caught.
    let parts = validate_relative(name)?;
    if parts.len() <= strip {
        return Ok(None);
    }
    Ok(Some(SafePath::new(root, &parts[strip..].join("/"))?))
}

#[cfg(unix)]
fn set_mode(path: &Path, executable: bool) -> Result<()> {
    use std::os::unix::fs::PermissionsExt;
    let mode = if executable { 0o755 } else { 0o644 };
    std::fs::set_permissions(path, std::fs::Permissions::from_mode(mode))?;
    Ok(())
}

#[cfg(not(unix))]
fn set_mode(_path: &Path, _executable: bool) -> Result<()> {
    Ok(())
}

/// Copy at most the remaining budget from `reader`, failing if the entry is larger.
fn copy_limited(reader: &mut impl Read, dest: &Path, total: &mut u64, max: u64) -> Result<()> {
    let mut out = File::create(dest)?;
    let remaining = max.saturating_sub(*total);
    let copied = io::copy(&mut reader.take(remaining.saturating_add(1)), &mut out)?;
    *total += copied;
    if *total > max {
        drop(out);
        let _ = std::fs::remove_file(dest);
        return Err(bad("the archive is larger than allowed"));
    }
    Ok(())
}

/// Read one named entry of a zip fully into memory, refusing entries over `max_bytes`.
pub fn read_zip_entry(archive: &Path, name: &str, max_bytes: u64) -> Result<Vec<u8>> {
    let mut zip = zip::ZipArchive::new(File::open(archive)?)?;
    let entry = zip.by_name(name)?;
    let mut out = Vec::new();
    entry
        .take(max_bytes.saturating_add(1))
        .read_to_end(&mut out)?;
    if out.len() as u64 > max_bytes {
        return Err(bad("an entry in the archive is larger than allowed"));
    }
    Ok(out)
}

/// Extract a zip into `root` (created if needed). Returns the number of files written.
pub fn extract_zip(archive: &Path, root: &Path, opts: &ExtractOptions<'_>) -> Result<usize> {
    std::fs::create_dir_all(root)?;
    let mut zip = zip::ZipArchive::new(File::open(archive)?)?;
    let (mut files, mut total) = (0usize, 0u64);
    for i in 0..zip.len() {
        let mut entry = zip.by_index(i)?;
        let name = entry.name().to_owned();
        if opts.filter.is_some_and(|f| !f(&name)) {
            continue;
        }
        let mode = entry.unix_mode();
        if mode.is_some_and(|m| m & 0o170_000 == 0o120_000) {
            return Err(bad("the archive contains a symbolic link"));
        }
        let Some(dest) = destination(root, &name, opts.strip_components)? else {
            continue;
        };
        if entry.is_dir() {
            std::fs::create_dir_all(dest.as_path())?;
            continue;
        }
        if let Some(parent) = dest.as_path().parent() {
            std::fs::create_dir_all(parent)?;
        }
        copy_limited(&mut entry, dest.as_path(), &mut total, opts.max_total_bytes)?;
        set_mode(dest.as_path(), mode.is_some_and(|m| m & 0o111 != 0))?;
        files += 1;
    }
    Ok(files)
}

/// Zip up `src_dir` into `dest`, naming entries `prefix` + relative path. Top-level names in
/// `skip_top` are left out, symlinks are never followed, and `first` entries (name, bytes)
/// are written before the folder contents. The archive appears at `dest` only when complete.
pub fn write_zip(
    dest: &Path,
    prefix: &str,
    src_dir: &Path,
    skip_top: &[&str],
    first: &[(String, Vec<u8>)],
) -> Result<()> {
    write_zip_excluding(dest, prefix, src_dir, skip_top, first, &HashSet::new())
}

/// Like [`write_zip`], and also leaves out files whose path relative to `src_dir` (with `/`
/// separators) is in `exclude`.
pub fn write_zip_excluding(
    dest: &Path,
    prefix: &str,
    src_dir: &Path,
    skip_top: &[&str],
    first: &[(String, Vec<u8>)],
    exclude: &HashSet<String>,
) -> Result<()> {
    use zip::write::SimpleFileOptions;
    fn walk(
        w: &mut zip::ZipWriter<File>,
        dir: &Path,
        rel: &str,
        top: bool,
        prefix: &str,
        skip: &[&str],
        exclude: &HashSet<String>,
    ) -> Result<()> {
        let mut entries: Vec<_> = std::fs::read_dir(dir)?.collect::<std::io::Result<_>>()?;
        entries.sort_by_key(std::fs::DirEntry::file_name);
        for e in entries {
            let name = e.file_name().to_string_lossy().into_owned();
            if top && skip.contains(&name.as_str()) {
                continue;
            }
            let rel_name = if rel.is_empty() {
                name
            } else {
                format!("{rel}/{name}")
            };
            let kind = e.file_type()?;
            if kind.is_dir() {
                walk(w, &e.path(), &rel_name, false, prefix, skip, exclude)?;
            } else if kind.is_file() && !exclude.contains(&rel_name) {
                let big = e.metadata()?.len() > 3 * 1024 * 1024 * 1024;
                let opts = SimpleFileOptions::default()
                    .compression_method(zip::CompressionMethod::Deflated)
                    .large_file(big);
                w.start_file(format!("{prefix}{rel_name}"), opts)?;
                io::copy(&mut File::open(e.path())?, w)?;
            }
        }
        Ok(())
    }
    let tmp = dest.with_extension("partial");
    let result = (|| -> Result<()> {
        let mut w = zip::ZipWriter::new(File::create(&tmp)?);
        let opts =
            SimpleFileOptions::default().compression_method(zip::CompressionMethod::Deflated);
        for (name, data) in first {
            w.start_file(name.as_str(), opts)?;
            io::Write::write_all(&mut w, data)?;
        }
        walk(&mut w, src_dir, "", true, prefix, skip_top, exclude)?;
        w.finish()?;
        Ok(())
    })();
    match result {
        Ok(()) => Ok(std::fs::rename(&tmp, dest)?),
        Err(e) => {
            let _ = std::fs::remove_file(&tmp);
            Err(e)
        }
    }
}

/// Lexically check that a symlink at `link_rel` pointing at `target` stays inside the root.
fn symlink_stays_inside(link_rel: &[&str], target: &str) -> bool {
    if target.is_empty()
        || target.starts_with('/')
        || target.starts_with('\\')
        || target.contains(':')
    {
        return false;
    }
    let mut stack: Vec<&str> = link_rel[..link_rel.len().saturating_sub(1)].to_vec();
    for part in target.split(['/', '\\']) {
        match part {
            "" | "." => {}
            ".." => {
                if stack.pop().is_none() {
                    return false;
                }
            }
            p => stack.push(p),
        }
    }
    true
}

/// Extract a `.tar.gz` into `root` (created if needed). Returns the number of files written.
pub fn extract_tar_gz(archive: &Path, root: &Path, opts: &ExtractOptions<'_>) -> Result<usize> {
    std::fs::create_dir_all(root)?;
    let gz = flate2::read::GzDecoder::new(File::open(archive)?);
    let mut tar = tar::Archive::new(gz);
    let (mut files, mut total) = (0usize, 0u64);
    for entry in tar.entries()? {
        let mut entry = entry?;
        let name = entry.path()?.to_string_lossy().into_owned();
        let kind = entry.header().entry_type();
        if kind.is_hard_link() {
            return Err(bad("the archive contains a hard link"));
        }
        if !(kind.is_file() || kind.is_dir() || kind.is_symlink()) {
            continue; // pax headers, devices and the like carry no files we want
        }
        if opts.filter.is_some_and(|f| !f(&name)) {
            continue;
        }
        let Some(dest) = destination(root, &name, opts.strip_components)? else {
            continue;
        };
        if kind.is_dir() {
            std::fs::create_dir_all(dest.as_path())?;
            continue;
        }
        if let Some(parent) = dest.as_path().parent() {
            std::fs::create_dir_all(parent)?;
        }
        if kind.is_symlink() {
            let target = entry
                .link_name()?
                .map(|t| t.to_string_lossy().into_owned())
                .unwrap_or_default();
            let rel = dest.relative().to_string_lossy().replace('\\', "/");
            let rel_parts: Vec<&str> = rel.split('/').collect();
            if !symlink_stays_inside(&rel_parts, &target) {
                return Err(bad(
                    "the archive contains a link that points outside its folder",
                ));
            }
            #[cfg(unix)]
            {
                let _ = std::fs::remove_file(dest.as_path());
                std::os::unix::fs::symlink(&target, dest.as_path())?;
            }
            continue;
        }
        let executable = entry.header().mode().is_ok_and(|m| m & 0o111 != 0);
        copy_limited(&mut entry, dest.as_path(), &mut total, opts.max_total_bytes)?;
        set_mode(dest.as_path(), executable)?;
        files += 1;
    }
    Ok(files)
}

#[cfg(test)]
mod tests {
    use std::io::Write;

    use super::*;

    fn make_zip(path: &Path, entries: &[(&str, &[u8])]) {
        let mut w = zip::ZipWriter::new(File::create(path).unwrap());
        let opts = zip::write::SimpleFileOptions::default();
        for (name, data) in entries {
            w.start_file(*name, opts).unwrap();
            w.write_all(data).unwrap();
        }
        w.finish().unwrap();
    }

    fn make_tar_gz(
        path: &Path,
        build: impl FnOnce(&mut tar::Builder<flate2::write::GzEncoder<File>>),
    ) {
        let gz =
            flate2::write::GzEncoder::new(File::create(path).unwrap(), flate2::Compression::fast());
        let mut b = tar::Builder::new(gz);
        build(&mut b);
        b.into_inner().unwrap().finish().unwrap();
    }

    /// Append an entry with a raw, unvalidated name (the builder refuses `..` itself).
    fn append_raw(b: &mut tar::Builder<flate2::write::GzEncoder<File>>, name: &str, data: &[u8]) {
        let mut h = tar::Header::new_gnu();
        h.as_gnu_mut().unwrap().name[..name.len()].copy_from_slice(name.as_bytes());
        h.set_size(data.len() as u64);
        h.set_mode(0o644);
        h.set_entry_type(tar::EntryType::Regular);
        h.set_cksum();
        b.append(&h, data).unwrap();
    }

    fn dirs() -> (tempfile::TempDir, std::path::PathBuf, std::path::PathBuf) {
        let base = tempfile::tempdir().unwrap();
        let out = base.path().join("out");
        let zip = base.path().join("a.archive");
        (base, out, zip)
    }

    #[test]
    fn zip_extracts_nested_files_and_strips_components() {
        let (_b, out, z) = dirs();
        make_zip(&z, &[("top/bin/java.exe", b"J"), ("top/readme.txt", b"R")]);
        let n = extract_zip(
            &z,
            &out,
            &ExtractOptions {
                strip_components: 1,
                ..Default::default()
            },
        )
        .unwrap();
        assert_eq!(n, 2);
        assert_eq!(std::fs::read(out.join("bin/java.exe")).unwrap(), b"J");
        assert!(!out.join("top").exists());
    }

    #[test]
    fn zip_slip_entries_are_rejected_and_nothing_escapes() {
        for evil in [
            "../evil.txt",
            "a/../../evil.txt",
            "..\\evil.txt",
            "/abs/evil.txt",
            "C:\\evil.txt",
        ] {
            let (b, out, z) = dirs();
            make_zip(&z, &[(evil, b"pwned")]);
            let err = extract_zip(&z, &out, &ExtractOptions::default()).unwrap_err();
            assert!(matches!(err, Error::InvalidPath(_)), "{evil}: {err:?}");
            assert!(!b.path().join("evil.txt").exists(), "{evil} escaped");
            assert!(!out.join("evil.txt").exists());
        }
    }

    #[test]
    fn zip_dotdot_hidden_in_a_stripped_component_is_still_rejected() {
        let (_b, out, z) = dirs();
        make_zip(&z, &[("../x/file.txt", b"p")]);
        let opts = ExtractOptions {
            strip_components: 2,
            ..Default::default()
        };
        assert!(extract_zip(&z, &out, &opts).is_err());
    }

    #[cfg(unix)]
    #[test]
    fn zip_symlinks_are_refused() {
        let (_b, out, z) = dirs();
        let mut w = zip::ZipWriter::new(File::create(&z).unwrap());
        w.add_symlink(
            "link",
            "/etc/passwd",
            zip::write::SimpleFileOptions::default(),
        )
        .unwrap();
        w.finish().unwrap();
        assert!(extract_zip(&z, &out, &ExtractOptions::default()).is_err());
    }

    #[test]
    fn filter_skips_entries() {
        let (_b, out, z) = dirs();
        make_zip(
            &z,
            &[
                ("lib.so", b"1"),
                ("META-INF/MANIFEST.MF", b"2"),
                ("x.txt", b"3"),
            ],
        );
        let only_so = |n: &str| n.ends_with(".so");
        let opts = ExtractOptions {
            filter: Some(&only_so),
            ..Default::default()
        };
        assert_eq!(extract_zip(&z, &out, &opts).unwrap(), 1);
        assert!(out.join("lib.so").exists() && !out.join("META-INF").exists());
    }

    #[test]
    fn unpacked_size_is_capped() {
        let (_b, out, z) = dirs();
        make_zip(&z, &[("big.bin", &vec![0u8; 10_000])]);
        let opts = ExtractOptions {
            max_total_bytes: 1000,
            ..Default::default()
        };
        assert!(matches!(
            extract_zip(&z, &out, &opts),
            Err(Error::Archive(_))
        ));
        assert!(
            !out.join("big.bin").exists(),
            "an over-limit file must not be left behind"
        );
    }

    #[test]
    fn tar_gz_extracts_with_strip_and_keeps_exec_bit() {
        let (_b, out, t) = dirs();
        make_tar_gz(&t, |b| {
            let mut h = tar::Header::new_gnu();
            h.set_size(2);
            h.set_mode(0o755);
            h.set_cksum();
            b.append_data(&mut h, "jdk-17/bin/java", &b"ok"[..])
                .unwrap();
        });
        let n = extract_tar_gz(
            &t,
            &out,
            &ExtractOptions {
                strip_components: 1,
                ..Default::default()
            },
        )
        .unwrap();
        assert_eq!(n, 1);
        assert_eq!(std::fs::read(out.join("bin/java")).unwrap(), b"ok");
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            assert_ne!(
                std::fs::metadata(out.join("bin/java"))
                    .unwrap()
                    .permissions()
                    .mode()
                    & 0o111,
                0
            );
        }
    }

    #[test]
    fn tar_slip_entries_are_rejected() {
        for evil in ["../evil.txt", "a/../../evil.txt", "/tmp/evil.txt"] {
            let (b, out, t) = dirs();
            make_tar_gz(&t, |bld| append_raw(bld, evil, b"pwned"));
            let err = extract_tar_gz(&t, &out, &ExtractOptions::default()).unwrap_err();
            assert!(matches!(err, Error::InvalidPath(_)), "{evil}: {err:?}");
            assert!(!b.path().join("evil.txt").exists());
        }
    }

    #[cfg(unix)]
    #[test]
    fn tar_links_inside_are_kept_and_links_outside_or_hard_links_are_refused() {
        let link = |b: &mut tar::Builder<flate2::write::GzEncoder<File>>,
                    name: &str,
                    target: &str,
                    kind| {
            let mut h = tar::Header::new_gnu();
            h.set_entry_type(kind);
            h.set_size(0);
            h.set_cksum();
            b.append_link(&mut h, name, target).unwrap();
        };

        let (_b, out, t) = dirs();
        make_tar_gz(&t, |b| {
            let mut h = tar::Header::new_gnu();
            h.set_size(1);
            h.set_cksum();
            b.append_data(&mut h, "top/real.txt", &b"x"[..]).unwrap();
            link(b, "top/legal/alias", "../real.txt", tar::EntryType::Symlink);
        });
        extract_tar_gz(
            &t,
            &out,
            &ExtractOptions {
                strip_components: 1,
                ..Default::default()
            },
        )
        .unwrap();
        assert_eq!(std::fs::read(out.join("legal/alias")).unwrap(), b"x");

        for (target, kind) in [
            ("../../etc/passwd", tar::EntryType::Symlink),
            ("/etc/passwd", tar::EntryType::Symlink),
            ("real.txt", tar::EntryType::Link),
        ] {
            let (_b, out, t) = dirs();
            make_tar_gz(&t, |b| link(b, "x/evil", target, kind));
            assert!(
                extract_tar_gz(&t, &out, &ExtractOptions::default()).is_err(),
                "{target}"
            );
        }
    }

    #[test]
    fn symlink_target_rules() {
        assert!(symlink_stays_inside(&["a", "b", "l"], "../c"));
        assert!(!symlink_stays_inside(&["a", "l"], "../../c"));
        assert!(!symlink_stays_inside(&["l"], "/etc"));
        assert!(!symlink_stays_inside(&["l"], "C:foo"));
    }
}
