//! The only HTTP client in Kiln. It speaks HTTPS only, refuses any host that isn't on an
//! explicit allowlist, never follows redirects on its own, caps response sizes, and never
//! logs URLs beyond host and path or any request or response body.

use std::sync::Once;
use std::time::Duration;

use reqwest::{Method, Url};
use serde::de::DeserializeOwned;

use crate::{Error, Result};

/// Largest response body accepted by [`HttpClient::execute`].
pub const MAX_RESPONSE_BYTES: usize = 2 * 1024 * 1024;

/// Which hosts a client may talk to. Entries are exact host names, or start with `.` to
/// also allow subdomains (`.example.com` matches `example.com` and `a.example.com`, but
/// not `badexample.com` or `example.com.evil.net`).
#[derive(Debug, Clone)]
pub struct HostPolicy {
    allowed: Vec<String>,
    #[cfg(test)]
    loopback_http: bool,
}

fn host_matches(host: &str, entry: &str) -> bool {
    match entry.strip_prefix('.') {
        Some(bare) => host == bare || host.ends_with(entry),
        None => host == entry,
    }
}

impl HostPolicy {
    pub fn new(allowed: &[&str]) -> Self {
        Self {
            allowed: allowed.iter().map(|h| h.to_ascii_lowercase()).collect(),
            #[cfg(test)]
            loopback_http: false,
        }
    }

    /// Test-only: also allow plain HTTP to a loopback mock server.
    #[cfg(test)]
    pub fn with_loopback_http(mut self) -> Self {
        self.loopback_http = true;
        self
    }

    fn loopback_http_enabled(&self) -> bool {
        #[cfg(test)]
        {
            self.loopback_http
        }
        #[cfg(not(test))]
        {
            false
        }
    }

    pub fn check(&self, url: &Url) -> Result<()> {
        let deny =
            |why: &str| Error::HostNotAllowed(format!("{} ({why})", url.host_str().unwrap_or("?")));
        let host = url.host_str().ok_or_else(|| deny("no host"))?;

        if self.loopback_http_enabled()
            && url.scheme() == "http"
            && matches!(host, "127.0.0.1" | "localhost")
        {
            return Ok(());
        }
        if url.scheme() != "https" {
            return Err(deny("not HTTPS"));
        }
        if !url.username().is_empty() || url.password().is_some() {
            return Err(deny("credentials in URL"));
        }
        if url.port().is_some_and(|p| p != 443) {
            return Err(deny("unexpected port"));
        }
        if self.allowed.iter().any(|entry| host_matches(host, entry)) {
            Ok(())
        } else {
            Err(deny("host not on the allowlist"))
        }
    }
}

pub enum Body<'a> {
    Empty,
    Form(&'a [(&'a str, &'a str)]),
    Json(&'a serde_json::Value),
}

/// Status and (size-capped) body. `Debug` deliberately hides the body: it may hold tokens.
pub struct HttpResponse {
    pub status: u16,
    body: Vec<u8>,
    /// Only the few headers callers have a use for (see [`KEPT_HEADERS`]), lower-case names.
    headers: Vec<(String, String)>,
}

/// Response headers that are kept. Cookies and anything else are dropped on purpose.
const KEPT_HEADERS: &[&str] = &[
    "etag",
    "retry-after",
    "x-ratelimit-limit",
    "x-ratelimit-remaining",
    "x-ratelimit-reset",
];

impl std::fmt::Debug for HttpResponse {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(
            f,
            "HttpResponse {{ status: {}, body: {} bytes }}",
            self.status,
            self.body.len()
        )
    }
}

impl HttpResponse {
    pub fn is_success(&self) -> bool {
        (200..300).contains(&self.status)
    }

    /// A kept response header (`name` in lower case), if the server sent it.
    pub fn header(&self, name: &str) -> Option<&str> {
        self.headers
            .iter()
            .find(|(k, _)| k == name)
            .map(|(_, v)| v.as_str())
    }

    /// The raw body (size-capped by `execute`).
    pub fn bytes(&self) -> &[u8] {
        &self.body
    }

    pub fn json<T: DeserializeOwned>(&self) -> Result<T> {
        serde_json::from_slice(&self.body)
            .map_err(|_| Error::Http("the server sent a response in an unexpected format".into()))
    }
}

fn http_err(e: reqwest::Error) -> Error {
    // Strip the URL: it could carry query parameters.
    Error::Http(e.without_url().to_string())
}

fn install_crypto_provider() {
    static ONCE: Once = Once::new();
    ONCE.call_once(|| {
        // Err means another provider is already installed, which is fine.
        let _ = rustls::crypto::ring::default_provider().install_default();
    });
}

#[derive(Debug, Clone)]
pub struct HttpClient {
    inner: reqwest::Client,
    policy: HostPolicy,
}

impl HttpClient {
    /// Client for small API calls: 30 s overall timeout.
    pub fn new(user_agent: &str, policy: HostPolicy) -> Result<Self> {
        Self::build(user_agent, policy, false)
    }

    /// Client for large downloads: no overall timeout (a big file may legitimately take
    /// minutes) but a stalled connection still fails after 30 s without data.
    pub fn new_for_downloads(user_agent: &str, policy: HostPolicy) -> Result<Self> {
        Self::build(user_agent, policy, true)
    }

    fn build(user_agent: &str, policy: HostPolicy, downloads: bool) -> Result<Self> {
        install_crypto_provider();
        let mut builder = reqwest::Client::builder()
            .user_agent(user_agent)
            .https_only(!policy.loopback_http_enabled())
            .redirect(reqwest::redirect::Policy::none())
            .connect_timeout(Duration::from_secs(10));
        builder = if downloads {
            builder.read_timeout(Duration::from_secs(30))
        } else {
            builder.timeout(Duration::from_secs(30))
        };
        if policy.loopback_http_enabled() {
            // A system proxy must never intercept calls to a local mock server.
            builder = builder.no_proxy();
        }
        Ok(Self {
            inner: builder.build().map_err(http_err)?,
            policy,
        })
    }

    pub async fn execute(
        &self,
        method: Method,
        url: &str,
        body: Body<'_>,
        bearer: Option<&str>,
    ) -> Result<HttpResponse> {
        self.execute_with(method, url, body, bearer, &[]).await
    }

    /// Like [`execute`](Self::execute), with extra request headers (for example
    /// `If-None-Match`). Never use it for credentials: those go through `bearer`.
    pub async fn execute_with(
        &self,
        method: Method,
        url: &str,
        body: Body<'_>,
        bearer: Option<&str>,
        extra_headers: &[(&str, &str)],
    ) -> Result<HttpResponse> {
        let url = Url::parse(url).map_err(|_| Error::HostNotAllowed("invalid URL".into()))?;
        self.policy.check(&url)?;

        let mut request = self.inner.request(method.clone(), url.clone());
        request = match body {
            Body::Empty => request,
            Body::Form(fields) => request.form(fields),
            Body::Json(value) => request.json(value),
        };
        if let Some(token) = bearer {
            request = request.bearer_auth(token);
        }
        for (name, value) in extra_headers {
            request = request.header(*name, *value);
        }

        let mut response = request.send().await.map_err(http_err)?;
        let status = response.status().as_u16();
        let headers: Vec<(String, String)> = KEPT_HEADERS
            .iter()
            .filter_map(|name| {
                let value = response.headers().get(*name)?.to_str().ok()?;
                Some(((*name).to_owned(), value.to_owned()))
            })
            .collect();
        tracing::debug!(
            %method,
            host = url.host_str().unwrap_or(""),
            path = url.path(),
            status,
            "http response"
        );

        let mut body = Vec::new();
        while let Some(chunk) = response.chunk().await.map_err(http_err)? {
            if body.len() + chunk.len() > MAX_RESPONSE_BYTES {
                return Err(Error::Http("the server's response was too large".into()));
            }
            body.extend_from_slice(&chunk);
        }
        Ok(HttpResponse {
            status,
            body,
            headers,
        })
    }
}

/// A response whose body is read in chunks instead of being buffered. Used for downloads.
pub struct ByteStream {
    pub status: u16,
    /// Length of the body that will follow (not the whole file when the status is 206).
    pub content_length: Option<u64>,
    /// For 206 responses: the first byte offset the server is actually sending.
    pub content_range_start: Option<u64>,
    response: reqwest::Response,
}

impl std::fmt::Debug for ByteStream {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "ByteStream {{ status: {} }}", self.status)
    }
}

impl ByteStream {
    pub async fn next_chunk(&mut self) -> Result<Option<Vec<u8>>> {
        Ok(self
            .response
            .chunk()
            .await
            .map_err(http_err)?
            .map(|b| b.to_vec()))
    }
}

/// Redirects followed per request. Every hop is checked against the host policy.
const MAX_REDIRECTS: usize = 5;

fn content_range_start(value: &str) -> Option<u64> {
    // "bytes 100-999/1000"
    value
        .strip_prefix("bytes ")?
        .split(['-', '/'])
        .next()?
        .trim()
        .parse()
        .ok()
}

impl HttpClient {
    /// GET that streams the body, optionally from byte `range_from`. Redirects are
    /// followed by hand, up to [`MAX_REDIRECTS`], and each target is checked against the
    /// host policy before any connection is made, so an allowed host can't bounce us to
    /// one that isn't.
    pub async fn get_stream(&self, url: &str, range_from: Option<u64>) -> Result<ByteStream> {
        let mut url = Url::parse(url).map_err(|_| Error::HostNotAllowed("invalid URL".into()))?;
        for _ in 0..=MAX_REDIRECTS {
            self.policy.check(&url)?;
            let mut request = self.inner.get(url.clone());
            if let Some(from) = range_from.filter(|f| *f > 0) {
                request = request.header(reqwest::header::RANGE, format!("bytes={from}-"));
            }
            let response = request.send().await.map_err(http_err)?;
            let status = response.status();
            tracing::debug!(
                host = url.host_str().unwrap_or(""),
                path = url.path(),
                status = status.as_u16(),
                "http stream response"
            );
            if status.is_redirection() {
                let location = response
                    .headers()
                    .get(reqwest::header::LOCATION)
                    .and_then(|v| v.to_str().ok())
                    .ok_or_else(|| Error::Http("a redirect had no destination".into()))?;
                url = url
                    .join(location)
                    .map_err(|_| Error::HostNotAllowed("invalid redirect target".into()))?;
                continue;
            }
            let content_range_start = response
                .headers()
                .get(reqwest::header::CONTENT_RANGE)
                .and_then(|v| v.to_str().ok())
                .and_then(content_range_start);
            return Ok(ByteStream {
                status: status.as_u16(),
                content_length: response.content_length(),
                content_range_start,
                response,
            });
        }
        Err(Error::Http("too many redirects".into()))
    }
}

#[cfg(test)]
mod tests {
    use wiremock::matchers::{header, method, path};
    use wiremock::{Mock, MockServer, ResponseTemplate};

    use super::*;

    fn policy() -> HostPolicy {
        HostPolicy::new(&["login.example.com", ".xboxlive.com"])
    }

    fn check(url: &str) -> Result<()> {
        policy().check(&Url::parse(url).unwrap())
    }

    #[test]
    fn allows_listed_hosts_and_subdomains_over_https() {
        check("https://login.example.com/token").unwrap();
        check("https://user.auth.xboxlive.com/x").unwrap();
        check("https://xboxlive.com/").unwrap();
        check("https://login.example.com:443/").unwrap();
    }

    #[test]
    fn rejects_everything_else() {
        for bad in [
            "http://login.example.com/",
            "https://other.example.com/",
            "https://evilxboxlive.com/",
            "https://user.auth.xboxlive.com.evil.net/",
            "https://login.example.com:8443/",
            "https://user:pass@login.example.com/",
            "https://login.example.com@evil.net/",
            "ftp://login.example.com/",
            "http://127.0.0.1:1234/",
            "https://127.0.0.1/",
        ] {
            assert!(check(bad).is_err(), "allowed {bad}");
        }
    }

    fn client() -> HttpClient {
        HttpClient::new("Kiln-test/0", HostPolicy::new(&[]).with_loopback_http()).unwrap()
    }

    #[tokio::test]
    async fn sends_form_and_bearer_and_reads_json() {
        let server = MockServer::start().await;
        Mock::given(method("POST"))
            .and(path("/echo"))
            .and(header("authorization", "Bearer tok-123"))
            .and(header("user-agent", "Kiln-test/0"))
            .and(wiremock::matchers::body_string("a=1&b=two+words"))
            .respond_with(ResponseTemplate::new(200).set_body_json(serde_json::json!({"ok": true})))
            .mount(&server)
            .await;

        let url = format!("{}/echo", server.uri());
        let resp = client()
            .execute(
                Method::POST,
                &url,
                Body::Form(&[("a", "1"), ("b", "two words")]),
                Some("tok-123"),
            )
            .await
            .unwrap();
        assert!(resp.is_success());
        assert_eq!(resp.json::<serde_json::Value>().unwrap()["ok"], true);
        assert!(
            !format!("{resp:?}").contains("ok"),
            "Debug must not show the body"
        );
    }

    #[tokio::test]
    async fn does_not_follow_redirects() {
        let server = MockServer::start().await;
        Mock::given(path("/r"))
            .respond_with(
                ResponseTemplate::new(302).insert_header("location", "https://evil.example/"),
            )
            .mount(&server)
            .await;
        let resp = client()
            .execute(
                Method::GET,
                &format!("{}/r", server.uri()),
                Body::Empty,
                None,
            )
            .await
            .unwrap();
        assert_eq!(resp.status, 302);
    }

    #[tokio::test]
    async fn rejects_oversized_responses() {
        let server = MockServer::start().await;
        Mock::given(path("/big"))
            .respond_with(
                ResponseTemplate::new(200).set_body_bytes(vec![b'x'; MAX_RESPONSE_BYTES + 1]),
            )
            .mount(&server)
            .await;
        let err = client()
            .execute(
                Method::GET,
                &format!("{}/big", server.uri()),
                Body::Empty,
                None,
            )
            .await
            .unwrap_err();
        assert!(matches!(err, Error::Http(_)), "{err:?}");
    }

    #[tokio::test]
    async fn policy_is_enforced_before_any_connection() {
        let strict = HttpClient::new("Kiln-test/0", policy()).unwrap();
        let err = strict
            .execute(Method::GET, "http://login.example.com/", Body::Empty, None)
            .await
            .unwrap_err();
        assert!(matches!(err, Error::HostNotAllowed(_)));
    }

    #[tokio::test]
    async fn stream_follows_redirects_and_supports_ranges() {
        let server = MockServer::start().await;
        Mock::given(path("/start"))
            .respond_with(ResponseTemplate::new(302).insert_header("location", "/final"))
            .mount(&server)
            .await;
        Mock::given(path("/final"))
            .and(header("range", "bytes=3-"))
            .respond_with(
                ResponseTemplate::new(206)
                    .insert_header("content-range", "bytes 3-5/6")
                    .set_body_bytes(b"def".to_vec()),
            )
            .mount(&server)
            .await;
        let mut s = client()
            .get_stream(&format!("{}/start", server.uri()), Some(3))
            .await
            .unwrap();
        assert_eq!((s.status, s.content_range_start), (206, Some(3)));
        assert_eq!(s.next_chunk().await.unwrap().unwrap(), b"def");
        assert!(s.next_chunk().await.unwrap().is_none());
    }

    #[tokio::test]
    async fn stream_rechecks_the_policy_on_every_redirect_hop() {
        let server = MockServer::start().await;
        Mock::given(path("/r"))
            .respond_with(
                ResponseTemplate::new(302).insert_header("location", "https://evil.example/x"),
            )
            .mount(&server)
            .await;
        let err = client()
            .get_stream(&format!("{}/r", server.uri()), None)
            .await
            .unwrap_err();
        assert!(matches!(err, Error::HostNotAllowed(_)), "{err:?}");
    }

    #[tokio::test]
    async fn redirect_loops_are_cut_off() {
        let server = MockServer::start().await;
        Mock::given(path("/loop"))
            .respond_with(ResponseTemplate::new(302).insert_header("location", "/loop"))
            .mount(&server)
            .await;
        let err = client()
            .get_stream(&format!("{}/loop", server.uri()), None)
            .await
            .unwrap_err();
        assert!(matches!(err, Error::Http(_)), "{err:?}");
    }

    #[test]
    fn content_range_parsing() {
        assert_eq!(content_range_start("bytes 100-999/1000"), Some(100));
        assert_eq!(content_range_start("bytes */1000"), None);
        assert_eq!(content_range_start("junk"), None);
    }

    #[tokio::test]
    async fn only_a_few_response_headers_are_kept_and_extra_request_headers_are_sent() {
        let server = MockServer::start().await;
        Mock::given(method("GET"))
            .and(path("/h"))
            .and(header("if-none-match", "\"v1\""))
            .respond_with(
                ResponseTemplate::new(200)
                    .insert_header("etag", "\"v2\"")
                    .insert_header("x-ratelimit-remaining", "7")
                    .insert_header("set-cookie", "session=secret")
                    .insert_header("x-other", "nope"),
            )
            .mount(&server)
            .await;
        let client =
            HttpClient::new("kiln-test", HostPolicy::new(&[]).with_loopback_http()).unwrap();
        let resp = client
            .execute_with(
                Method::GET,
                &format!("{}/h", server.uri()),
                Body::Empty,
                None,
                &[("If-None-Match", "\"v1\"")],
            )
            .await
            .unwrap();
        assert_eq!(resp.header("etag"), Some("\"v2\""));
        assert_eq!(resp.header("x-ratelimit-remaining"), Some("7"));
        assert_eq!(resp.header("set-cookie"), None);
        assert_eq!(resp.header("x-other"), None);
    }
}
