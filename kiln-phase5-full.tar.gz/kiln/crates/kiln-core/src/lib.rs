//! Kiln core: all launcher logic, with no GUI dependencies so it can be unit-tested
//! on its own. The Tauri shell (`src-tauri`) only validates input and calls into here.

pub mod archive;
pub mod auth;
pub mod db;
pub mod download;
pub mod error;
pub mod hash;
pub mod instance;
pub mod java;
pub mod launch;
pub mod loader;
pub mod logging;
pub mod mods;
pub mod mojang;
pub mod net;
pub mod paths;
pub mod redact;
pub mod settings;

pub use error::{AppError, Error, Result};

/// Display name. Kept in one place so the codename is easy to change.
pub const APP_NAME: &str = "Kiln";
/// Version of the core crate (the workspace version).
pub const APP_VERSION: &str = env!("CARGO_PKG_VERSION");
