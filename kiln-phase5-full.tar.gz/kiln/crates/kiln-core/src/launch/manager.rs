use std::collections::VecDeque;
use std::path::PathBuf;
use std::sync::{Arc, Mutex, MutexGuard};
use std::time::Duration;

use serde::Serialize;
use tokio::io::{AsyncBufReadExt, AsyncRead, AsyncReadExt, BufReader};
use tokio::sync::{watch, Notify};

use super::args::{build_args, join_classpath, ArgContext};
use super::LaunchError;
use crate::archive::{extract_zip, ExtractOptions};
use crate::auth::LaunchSession;
use crate::download::Progress;
use crate::instance::InstanceStore;
use crate::java::JavaManager;
use crate::loader::{InstallContext, LoaderClient, LoaderKind};
use crate::mods::store::{ModStore, RollbackReport};
use crate::mojang::rules::Environment;
use crate::mojang::{is_valid_version_id, MojangClient};
use crate::paths::{DataDirs, SafePath};
use crate::{redact, AppError, Result, APP_NAME, APP_VERSION};

/// Game output lines kept for a console opened after the game started.
const LOG_BUFFER_LINES: usize = 2000;
/// Longest piece of output forwarded as a single line.
const MAX_LINE_BYTES: u64 = 64 * 1024;
const MAX_LINE_CHARS: usize = 8 * 1024;
/// Natives are a few MB; anything bigger is not a natives bundle.
const MAX_NATIVES_BYTES: u64 = 256 * 1024 * 1024;

#[derive(Debug, Clone, Copy, Serialize, PartialEq, Eq)]
#[serde(rename_all = "lowercase")]
pub enum LogStream {
    Stdout,
    Stderr,
}

#[derive(Debug, Clone, Serialize, PartialEq, Eq)]
pub struct LogLine {
    pub stream: LogStream,
    pub text: String,
}

#[derive(Debug, Clone, Default, Serialize, PartialEq)]
#[serde(tag = "state", rename_all = "snake_case")]
pub enum LaunchStatus {
    #[default]
    Idle,
    Preparing {
        stage: String,
        progress: Option<Progress>,
    },
    Running {
        pid: u32,
    },
    Exited {
        code: Option<i32>,
    },
    Failed {
        code: String,
        message: String,
    },
}

impl LaunchStatus {
    fn preparing(stage: &str) -> Self {
        Self::Preparing {
            stage: stage.into(),
            progress: None,
        }
    }

    fn is_active(&self) -> bool {
        matches!(self, Self::Preparing { .. } | Self::Running { .. })
    }
}

/// Where status changes and game output go. The Tauri shell turns these into UI events.
pub trait LaunchEvents: Send + Sync + 'static {
    fn status(&self, status: &LaunchStatus);
    fn log(&self, line: &LogLine);
    /// Mod updates were undone because the game failed to start after them.
    fn rolled_back(&self, _report: &RollbackReport) {}
}

pub struct LaunchRequest {
    pub mc_version: String,
    pub loader: LoaderKind,
    pub loader_version: Option<String>,
    /// The game's folder inside `instances/`.
    pub game_dir: SafePath,
    /// Set when launching a stored instance, so play time can be recorded.
    pub instance_id: Option<String>,
    pub ram_mb: Option<u32>,
    /// Extra JVM flags. Must already have passed `instance::parse_jvm_args`.
    pub jvm_args: Vec<String>,
    /// Use this `java` instead of finding or downloading one.
    pub java_path: Option<PathBuf>,
}

pub struct LaunchDeps {
    pub dirs: DataDirs,
    pub mojang: MojangClient,
    pub java: JavaManager,
    pub loaders: LoaderClient,
    pub instances: Option<InstanceStore>,
    /// When set, a mod update that stops the game from starting is undone automatically.
    pub mods: Option<ModStore>,
}

/// Everything needed to start the process. `Debug` hides the arguments: they hold the
/// access token.
pub struct Prepared {
    pub java: PathBuf,
    pub args: Vec<String>,
    pub game_dir: PathBuf,
}

impl std::fmt::Debug for Prepared {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("Prepared { .. }")
    }
}

/// Turns download progress into throttled status events until dropped.
struct Forwarder {
    tx: watch::Sender<Progress>,
    task: tokio::task::JoinHandle<()>,
}

impl Drop for Forwarder {
    fn drop(&mut self) {
        self.task.abort();
    }
}

fn forwarder(events: &Arc<dyn LaunchEvents>, stage: &'static str) -> Forwarder {
    let (tx, mut rx) = watch::channel(Progress::default());
    let events = Arc::clone(events);
    let task = tokio::spawn(async move {
        while rx.changed().await.is_ok() {
            let progress = *rx.borrow_and_update();
            events.status(&LaunchStatus::Preparing {
                stage: stage.into(),
                progress: Some(progress),
            });
            // Updates arriving meanwhile coalesce into the latest one.
            tokio::time::sleep(Duration::from_millis(120)).await;
        }
    });
    Forwarder { tx, task }
}

fn path_str(p: &std::path::Path) -> String {
    p.to_string_lossy().into_owned()
}

/// Download everything the version needs, install Java, unpack natives and build the command.
pub async fn prepare(
    deps: &LaunchDeps,
    req: &LaunchRequest,
    session: &LaunchSession,
    events: &Arc<dyn LaunchEvents>,
) -> Result<Prepared> {
    let id = req.mc_version.as_str();
    if !is_valid_version_id(id) {
        return Err(LaunchError::InvalidVersionId.into());
    }
    events.status(&LaunchStatus::preparing("Fetching version information"));
    let parent = deps.mojang.version_json(id).await?;
    if parent.inherits_from.is_some() {
        return Err(LaunchError::UnsupportedLibrary(format!("{id} (loader profile)")).into());
    }
    let env = Environment::current();
    let parent_libs = parent.resolve_libraries(&env)?;
    let index = deps.mojang.asset_index(&parent).await?;

    // Step 1: everything vanilla needs.
    let client_task = deps.mojang.client_jar_task(&parent)?;
    let client_jar = client_task.dest.as_path().to_path_buf();
    let mut tasks = vec![client_task];
    for lib in parent_libs
        .classpath
        .iter()
        .chain(parent_libs.natives.iter().map(|(l, _)| l))
    {
        tasks.push(deps.mojang.library_task(lib)?);
    }
    tasks.extend(deps.mojang.asset_tasks(&index)?);
    events.status(&LaunchStatus::preparing("Downloading game files"));
    {
        let fwd = forwarder(events, "Downloading game files");
        deps.mojang
            .downloader()
            .download_all(tasks, Some(fwd.tx.clone()))
            .await?;
    }

    // Step 2: Java (the Forge installer needs it too).
    let java = match &req.java_path {
        Some(p) => p.clone(),
        None => {
            events.status(&LaunchStatus::preparing("Preparing Java"));
            let fwd = forwarder(events, "Downloading Java");
            deps.java
                .ensure(parent.java_major(), Some(fwd.tx.clone()))
                .await?
        }
    };

    // Step 3: the mod loader, merged onto the vanilla version.
    let (version, libs) = if req.loader == LoaderKind::Vanilla {
        (parent, parent_libs)
    } else {
        let lv = req
            .loader_version
            .as_deref()
            .ok_or(LaunchError::InvalidVersionId)?;
        events.status(&LaunchStatus::preparing(&format!(
            "Installing {} (the first time can take a few minutes)",
            req.loader.display_name()
        )));
        let profile = deps
            .loaders
            .ensure_installed(
                req.loader,
                id,
                lv,
                &InstallContext {
                    java: &java,
                    client_jar: &client_jar,
                },
            )
            .await?;
        let merged = profile.merged_onto(&parent);
        let libs = merged.resolve_libraries(&env)?;
        let already: std::collections::HashSet<&str> = parent_libs
            .classpath
            .iter()
            .chain(parent_libs.natives.iter().map(|(l, _)| l))
            .map(|l| l.path.as_str())
            .collect();
        let mut tasks = Vec::new();
        for lib in libs
            .classpath
            .iter()
            .chain(libs.natives.iter().map(|(l, _)| l))
        {
            if already.contains(lib.path.as_str()) {
                continue;
            }
            if lib.url.is_empty() {
                // Produced by the loader's installer: it must exist already.
                if !deps.mojang.library_path(lib)?.as_path().is_file() {
                    return Err(LaunchError::UnsupportedLibrary(lib.path.clone()).into());
                }
            } else {
                tasks.push(deps.mojang.library_task(lib)?);
            }
        }
        events.status(&LaunchStatus::preparing("Downloading loader files"));
        let fwd = forwarder(events, "Downloading loader files");
        deps.loaders
            .downloader()
            .download_all(tasks, Some(fwd.tx.clone()))
            .await?;
        (merged, libs)
    };

    events.status(&LaunchStatus::preparing("Starting the game"));
    let game_root = req.game_dir.clone();
    std::fs::create_dir_all(game_root.as_path())?;
    let natives = SafePath::new(game_root.as_path(), ".kiln-natives")?;
    let natives_dir = natives.as_path().to_path_buf();
    let native_jars: Vec<(PathBuf, Vec<String>)> = libs
        .natives
        .iter()
        .map(|(l, exclude)| {
            Ok((
                deps.mojang.library_path(l)?.as_path().to_path_buf(),
                exclude.clone(),
            ))
        })
        .collect::<Result<_>>()?;
    {
        let natives_dir = natives_dir.clone();
        tokio::task::spawn_blocking(move || -> Result<()> {
            let _ = std::fs::remove_dir_all(&natives_dir);
            std::fs::create_dir_all(&natives_dir)?;
            for (jar, exclude) in native_jars {
                let keep = |name: &str| {
                    !name.starts_with("META-INF/")
                        && !exclude.iter().any(|e| name.starts_with(e.as_str()))
                };
                let opts = ExtractOptions {
                    max_total_bytes: MAX_NATIVES_BYTES,
                    filter: Some(&keep),
                    ..Default::default()
                };
                extract_zip(&jar, &natives_dir, &opts)?;
            }
            Ok(())
        })
        .await
        .map_err(|e| crate::Error::Io(std::io::Error::other(e)))??;
    }

    let mut classpath = Vec::new();
    for lib in &libs.classpath {
        classpath.push(path_str(deps.mojang.library_path(lib)?.as_path()));
    }
    classpath.push(path_str(&client_jar));
    let classpath = join_classpath(classpath.iter().map(String::as_str));
    let assets_root = path_str(&deps.mojang.assets_root()?);
    let library_dir = path_str(&deps.mojang.cache_dir("libraries")?);
    let ctx = ArgContext {
        player_name: &session.username,
        uuid: &session.account_id,
        access_token: session.access_token.expose(),
        version_name: &version.id,
        version_type: &version.kind,
        game_dir: &path_str(game_root.as_path()),
        assets_root: &assets_root,
        assets_index: &version.asset_index_ref()?.id,
        natives_dir: &path_str(&natives_dir),
        classpath: &classpath,
        library_dir: &library_dir,
        launcher_name: APP_NAME,
        launcher_version: APP_VERSION,
    };
    let args = build_args(&version, &env, &ctx, req.ram_mb, &req.jvm_args);
    Ok(Prepared {
        java,
        args,
        game_dir: game_root.as_path().to_path_buf(),
    })
}

/// Forward a child's output line by line, with secrets masked. Invalid UTF-8 is replaced
/// rather than ending the stream, and overlong lines are split.
async fn pump(reader: impl AsyncRead + Unpin, stream: LogStream, events: &dyn LaunchEvents) {
    let mut reader = BufReader::new(reader);
    let mut buf = Vec::new();
    loop {
        buf.clear();
        match (&mut reader)
            .take(MAX_LINE_BYTES)
            .read_until(b'\n', &mut buf)
            .await
        {
            Ok(0) | Err(_) => break,
            Ok(_) => {
                let text = String::from_utf8_lossy(&buf);
                let text: String = text
                    .trim_end_matches(['\n', '\r'])
                    .chars()
                    .take(MAX_LINE_CHARS)
                    .collect();
                events.log(&LogLine {
                    stream,
                    text: redact::global().redact(&text).into_owned(),
                });
            }
        }
    }
}

/// Run the game and wait for it to exit. Dropping this future kills the process.
pub async fn spawn_and_stream(
    prepared: Prepared,
    events: &Arc<dyn LaunchEvents>,
) -> Result<Option<i32>> {
    let mut cmd = tokio::process::Command::new(&prepared.java);
    cmd.args(&prepared.args)
        .current_dir(&prepared.game_dir)
        .stdin(std::process::Stdio::null())
        .stdout(std::process::Stdio::piped())
        .stderr(std::process::Stdio::piped())
        .kill_on_drop(true);
    super::hide_console_window(&mut cmd);
    let mut child = cmd
        .spawn()
        .map_err(|e| LaunchError::SpawnFailed(e.kind().to_string()))?;
    let (Some(stdout), Some(stderr)) = (child.stdout.take(), child.stderr.take()) else {
        return Err(LaunchError::SpawnFailed("no output pipes".into()).into());
    };
    events.status(&LaunchStatus::Running {
        pid: child.id().unwrap_or(0),
    });
    let (_, _, exit) = tokio::join!(
        pump(stdout, LogStream::Stdout, events.as_ref()),
        pump(stderr, LogStream::Stderr, events.as_ref()),
        child.wait()
    );
    Ok(exit?.code())
}

#[derive(Default)]
struct Shared {
    status: LaunchStatus,
    log: VecDeque<LogLine>,
    stop: Option<Arc<Notify>>,
    instance: Option<String>,
    run_started: Option<std::time::Instant>,
}

fn lock(m: &Mutex<Shared>) -> MutexGuard<'_, Shared> {
    m.lock().unwrap_or_else(|e| e.into_inner())
}

/// Remembers the latest status and recent output, then passes events on.
struct Tee {
    shared: Arc<Mutex<Shared>>,
    out: Arc<dyn LaunchEvents>,
}

impl LaunchEvents for Tee {
    fn status(&self, status: &LaunchStatus) {
        {
            let mut s = lock(&self.shared);
            if matches!(status, LaunchStatus::Running { .. }) {
                s.run_started = Some(std::time::Instant::now());
            }
            s.status = status.clone();
        }
        self.out.status(status);
    }

    fn log(&self, line: &LogLine) {
        {
            let mut s = lock(&self.shared);
            if s.log.len() >= LOG_BUFFER_LINES {
                s.log.pop_front();
            }
            s.log.push_back(line.clone());
        }
        self.out.log(line);
    }

    fn rolled_back(&self, report: &RollbackReport) {
        self.out.rolled_back(report);
    }
}

/// After the game exits: a crash soon after starting undoes the mod updates made since the
/// last good run; a clean exit, or a long enough run, keeps them.
async fn settle_mod_updates(
    mods: &ModStore,
    instance_id: &str,
    code: Option<i32>,
    ran_secs: u64,
    events: &Arc<dyn LaunchEvents>,
) {
    let failed_early = code != Some(0) && Duration::from_secs(ran_secs) < mods.startup_window();
    if failed_early {
        match mods.rollback_pending(instance_id).await {
            Ok(report) if !report.is_empty() => events.rolled_back(&report),
            Ok(_) => {}
            Err(e) => tracing::warn!(error = %e, "could not roll back mod updates"),
        }
    } else if let Err(e) = mods.confirm_pending(instance_id).await {
        tracing::warn!(error = %e, "could not confirm mod updates");
    }
}

/// Runs at most one game at a time.
#[derive(Clone, Default)]
pub struct LaunchManager {
    shared: Arc<Mutex<Shared>>,
}

impl std::fmt::Debug for LaunchManager {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("LaunchManager { .. }")
    }
}

impl LaunchManager {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn status(&self) -> LaunchStatus {
        lock(&self.shared).status.clone()
    }

    pub fn log_tail(&self) -> Vec<LogLine> {
        lock(&self.shared).log.iter().cloned().collect()
    }

    /// The instance the game is currently starting or running from, if any.
    pub fn running_instance(&self) -> Option<String> {
        let s = lock(&self.shared);
        s.status.is_active().then(|| s.instance.clone()).flatten()
    }

    pub fn is_active(&self) -> bool {
        lock(&self.shared).status.is_active()
    }

    /// Begin preparing and launching in the background. Progress, output and the final
    /// outcome arrive through `events`. Must be called inside a tokio runtime.
    pub fn start(
        &self,
        deps: LaunchDeps,
        req: LaunchRequest,
        session: LaunchSession,
        events: Arc<dyn LaunchEvents>,
    ) -> Result<()> {
        let stop = Arc::new(Notify::new());
        {
            let mut s = lock(&self.shared);
            if s.status.is_active() {
                return Err(LaunchError::AlreadyRunning.into());
            }
            s.status = LaunchStatus::preparing("Starting");
            s.log.clear();
            s.stop = Some(Arc::clone(&stop));
            s.instance = req.instance_id.clone();
            s.run_started = None;
        }
        let tee: Arc<dyn LaunchEvents> = Arc::new(Tee {
            shared: Arc::clone(&self.shared),
            out: events,
        });
        tee.status(&LaunchStatus::preparing("Starting"));
        let shared = Arc::clone(&self.shared);
        tokio::spawn(async move {
            let work = async {
                let prepared = prepare(&deps, &req, &session, &tee).await?;
                spawn_and_stream(prepared, &tee).await
            };
            tokio::pin!(work);
            let outcome = tokio::select! {
                result = &mut work => Some(result),
                () = stop.notified() => None,
            };
            let was_running = matches!(lock(&shared).status, LaunchStatus::Running { .. });
            // `Some(code)` only when the game exited by itself (not when the user stopped it).
            let exit_code = match &outcome {
                Some(Ok(code)) => Some(*code),
                _ => None,
            };
            let final_status = match outcome {
                None if was_running => LaunchStatus::Exited { code: None },
                None => LaunchStatus::Idle,
                Some(Ok(code)) => LaunchStatus::Exited { code },
                Some(Err(e)) => {
                    let app = AppError::from(e);
                    LaunchStatus::Failed {
                        code: app.code.into(),
                        message: app.message,
                    }
                }
            };
            let played = lock(&shared).run_started.map(|t| t.elapsed().as_secs());
            lock(&shared).stop = None;
            if let (Some(secs), Some(id), Some(store)) = (played, &req.instance_id, &deps.instances)
            {
                let secs = i64::try_from(secs).unwrap_or(i64::MAX);
                let started = std::time::SystemTime::now()
                    .duration_since(std::time::UNIX_EPOCH)
                    .map_or(0, |d| i64::try_from(d.as_secs()).unwrap_or(0))
                    - secs;
                if let Err(e) = store.record_play(id, started, secs).await {
                    tracing::warn!(error = %e, "could not record play time");
                }
            }
            if let (Some(code), Some(id), Some(mods)) = (exit_code, &req.instance_id, &deps.mods) {
                settle_mod_updates(mods, id, code, played.unwrap_or(0), &tee).await;
            }
            tee.status(&final_status);
        });
        Ok(())
    }

    /// Cancel preparation or kill the running game.
    pub fn stop(&self) -> Result<()> {
        let s = lock(&self.shared);
        match (&s.stop, s.status.is_active()) {
            (Some(stop), true) => {
                stop.notify_one();
                Ok(())
            }
            _ => Err(LaunchError::NotRunning.into()),
        }
    }
}

#[cfg(test)]
mod tests {
    use std::time::Instant;

    use serde_json::json;
    use wiremock::matchers::path;
    use wiremock::{Mock, MockServer, ResponseTemplate};

    use super::*;
    use crate::auth::SecretString;
    use crate::db;
    use crate::download::{Downloader, RetryPolicy};
    use crate::hash::{hash_bytes, HashAlgo};
    use crate::net::{HostPolicy, HttpClient};
    use crate::Error;

    const TOKEN: &str = "TEST-ACCESS-TOKEN-1234567890";

    #[derive(Default)]
    struct Recorder {
        statuses: Mutex<Vec<LaunchStatus>>,
        lines: Mutex<Vec<LogLine>>,
        rollbacks: Mutex<Vec<RollbackReport>>,
    }

    impl LaunchEvents for Recorder {
        fn rolled_back(&self, r: &RollbackReport) {
            self.rollbacks.lock().unwrap().push(r.clone());
        }

        fn status(&self, s: &LaunchStatus) {
            self.statuses.lock().unwrap().push(s.clone());
        }
        fn log(&self, l: &LogLine) {
            self.lines.lock().unwrap().push(l.clone());
        }
    }

    fn sha1(b: &[u8]) -> String {
        hash_bytes(HashAlgo::Sha1, b)
    }

    fn natives_zip() -> Vec<u8> {
        use std::io::Write;
        let mut w = zip::ZipWriter::new(std::io::Cursor::new(Vec::new()));
        let o = zip::write::SimpleFileOptions::default();
        w.start_file("libfoo.so", o).unwrap();
        w.write_all(b"native").unwrap();
        w.start_file("META-INF/MANIFEST.MF", o).unwrap();
        w.write_all(b"junk").unwrap();
        w.finish().unwrap().into_inner()
    }

    struct World {
        server: MockServer,
        dir: tempfile::TempDir,
        deps: LaunchDeps,
        client_jar: Vec<u8>,
    }

    async fn mount(server: &MockServer, p: &str, body: Vec<u8>) {
        Mock::given(path(p.to_owned()))
            .respond_with(ResponseTemplate::new(200).set_body_bytes(body))
            .mount(server)
            .await;
    }

    /// A fake Mojang: manifest, version JSON, asset index, client jar, a library, natives.
    async fn world(serve_client_jar: Option<Vec<u8>>) -> World {
        let server = MockServer::start().await;
        let s = server.uri();
        let client_jar = b"CLIENT-JAR".to_vec();
        let lib = b"LIB-JAR".to_vec();
        let nat = natives_zip();
        let (a1, a2) = (b"ASSET-ONE".to_vec(), b"ASSET-TWO".to_vec());
        let index = json!({"objects": {
            "icons/a.png": {"hash": sha1(&a1), "size": a1.len()},
            "sounds/b.ogg": {"hash": sha1(&a2), "size": a2.len()},
        }})
        .to_string()
        .into_bytes();
        let file = |p: &str, url: &str, body: &[u8]| json!({"path": p, "url": format!("{s}{url}"), "sha1": sha1(body), "size": body.len()});
        let version = json!({
            "id": "test-1.0", "type": "release", "mainClass": "net.test.Main",
            "assetIndex": {"id": "t1", "sha1": sha1(&index), "size": index.len(), "url": format!("{s}/assets-index.json")},
            "downloads": {"client": file("", "/client.jar", &client_jar)},
            "libraries": [
                {"name": "a:lib:1", "downloads": {"artifact": file("a/lib/1/lib-1.jar", "/lib.jar", &lib)}},
                {"name": "a:nat:1", "natives": {"linux": "n", "windows": "n", "osx": "n"},
                 "extract": {"exclude": ["META-INF/"]},
                 "downloads": {"classifiers": {"n": file("a/nat/1/nat-1-n.jar", "/nat.jar", &nat)}}}
            ],
            "arguments": {
                "jvm": ["-Djava.library.path=${natives_directory}", "-cp", "${classpath}"],
                "game": ["--username", "${auth_player_name}", "--accessToken", "${auth_access_token}",
                         "--version", "${version_name}", "--clientId", "${clientid}"]
            }
        })
        .to_string()
        .into_bytes();
        let manifest = json!({
            "latest": {"release": "test-1.0", "snapshot": "test-1.0"},
            "versions": [{"id": "test-1.0", "type": "release", "url": format!("{s}/version.json"),
                          "sha1": sha1(&version), "releaseTime": "2024-01-01T00:00:00+00:00"}]
        })
        .to_string()
        .into_bytes();

        mount(&server, "/manifest.json", manifest).await;
        mount(&server, "/version.json", version).await;
        mount(&server, "/assets-index.json", index).await;
        mount(
            &server,
            "/client.jar",
            serve_client_jar.unwrap_or_else(|| client_jar.clone()),
        )
        .await;
        mount(&server, "/lib.jar", lib).await;
        mount(&server, "/nat.jar", nat).await;
        for a in [&a1, &a2] {
            let h = sha1(a);
            mount(&server, &format!("/assets/{}/{h}", &h[..2]), a.clone()).await;
        }

        let dir = tempfile::tempdir().unwrap();
        let dirs = DataDirs::from_root(dir.path().join("data"), false);
        dirs.ensure_created().unwrap();
        let policy = || HostPolicy::new(&[]).with_loopback_http();
        let downloader = || {
            Downloader::new(HttpClient::new_for_downloads("t/0", policy()).unwrap(), 4).with_retry(
                RetryPolicy {
                    attempts: 2,
                    base_delay: Duration::from_millis(1),
                },
            )
        };
        let mojang = MojangClient::with_clients(
            HttpClient::new("t/0", policy()).unwrap(),
            downloader(),
            &dirs.cache,
            format!("{s}/manifest.json"),
            format!("{s}/assets/"),
        );
        let db = db::open_in_memory().await.unwrap();
        let loaders = LoaderClient::with_clients(
            HttpClient::new("t/0", policy()).unwrap(),
            downloader(),
            mojang.clone(),
            crate::loader::Endpoints {
                fabric_meta: s.clone(),
                quilt_meta: format!("{s}/quilt"),
                neoforge_maven: format!("{s}/neo"),
                forge_maven: format!("{s}/forge"),
            },
        );
        let java = JavaManager::with_clients(
            db,
            &dirs.java,
            HttpClient::new("t/0", policy()).unwrap(),
            downloader(),
            s,
        );
        World {
            server,
            dir,
            deps: LaunchDeps {
                dirs,
                mojang,
                java,
                loaders,
                instances: None,
                mods: None,
            },
            client_jar,
        }
    }

    fn session() -> LaunchSession {
        LaunchSession {
            account_id: "069a79f44e9d4e9cb12bd4a2bb7d6fd4".into(),
            username: "Steve_Test".into(),
            access_token: SecretString::new(TOKEN),
        }
    }

    fn req_for(w: &World, mc: &str, java: Option<PathBuf>) -> LaunchRequest {
        LaunchRequest {
            mc_version: mc.into(),
            loader: LoaderKind::Vanilla,
            loader_version: None,
            game_dir: SafePath::new(&w.deps.dirs.instances, "vanilla-test").unwrap(),
            instance_id: None,
            ram_mb: Some(1024),
            jvm_args: vec!["-Xss1M".into()],
            java_path: java,
        }
    }

    fn request(w: &World, java: Option<PathBuf>) -> LaunchRequest {
        req_for(w, "test-1.0", java)
    }

    fn recorder() -> (Arc<Recorder>, Arc<dyn LaunchEvents>) {
        let r = Arc::new(Recorder::default());
        (r.clone(), r)
    }

    async fn request_count(w: &World) -> usize {
        w.server.received_requests().await.unwrap().len()
    }

    #[tokio::test]
    async fn prepare_downloads_everything_and_builds_the_command() {
        let w = world(None).await;
        let (rec, events) = recorder();
        let p = prepare(
            &w.deps,
            &request(&w, Some("/bin/true".into())),
            &session(),
            &events,
        )
        .await
        .unwrap();

        // Files landed in the content-addressed cache.
        let cache = &w.deps.dirs.cache;
        assert_eq!(
            std::fs::read(cache.join("jars/test-1.0/test-1.0.jar")).unwrap(),
            w.client_jar
        );
        assert!(cache.join("libraries/a/lib/1/lib-1.jar").is_file());
        let h = sha1(b"ASSET-ONE");
        assert!(cache
            .join(format!("assets/objects/{}/{h}", &h[..2]))
            .is_file());
        assert!(cache.join("assets/indexes/t1.json").is_file());

        // Natives were unpacked flat, minus the excluded entries.
        let natives = p.game_dir.join(".kiln-natives");
        assert_eq!(std::fs::read(natives.join("libfoo.so")).unwrap(), b"native");
        assert!(!natives.join("META-INF").exists());

        // The command line.
        let a = &p.args;
        assert_eq!(
            &a[..2],
            ["-Xmx1024M", "-Xss1M"],
            "RAM and vetted extra JVM flags come first"
        );
        assert!(a.contains(&format!("-Djava.library.path={}", natives.display())));
        let cp = &a[a.iter().position(|x| x == "-cp").unwrap() + 1];
        assert!(
            cp.contains("lib-1.jar") && cp.ends_with("test-1.0.jar"),
            "{cp}"
        );
        let main = a.iter().position(|x| x == "net.test.Main").unwrap();
        assert_eq!(&a[main + 1..main + 3], ["--username", "Steve_Test"]);
        assert!(a.windows(2).any(|w| w == ["--accessToken", TOKEN]));
        assert!(
            !a.contains(&"--clientId".to_string()),
            "valueless flags are dropped"
        );
        assert!(
            !format!("{p:?}").contains(TOKEN),
            "Debug must hide the token"
        );

        // Progress and stage changes were reported.
        let statuses = rec.statuses.lock().unwrap();
        assert!(statuses.iter().any(|s| matches!(s, LaunchStatus::Preparing { stage, .. } if stage == "Downloading game files")));
    }

    #[tokio::test]
    async fn a_second_prepare_reuses_the_cache() {
        let w = world(None).await;
        let (_r, events) = recorder();
        prepare(
            &w.deps,
            &request(&w, Some("/bin/true".into())),
            &session(),
            &events,
        )
        .await
        .unwrap();
        let before = request_count(&w).await;
        prepare(
            &w.deps,
            &request(&w, Some("/bin/true".into())),
            &session(),
            &events,
        )
        .await
        .unwrap();
        // Only the version list is fetched again; every file is already cached.
        assert_eq!(request_count(&w).await, before + 1);
    }

    #[tokio::test]
    async fn a_tampered_client_jar_is_rejected_before_anything_runs() {
        let w = world(Some(b"EVIL--JAR!".to_vec())).await;
        let (_r, events) = recorder();
        let err = prepare(
            &w.deps,
            &request(&w, Some("/bin/true".into())),
            &session(),
            &events,
        )
        .await
        .unwrap_err();
        assert!(matches!(err, Error::HashMismatch { .. }), "{err:?}");
        assert!(!w
            .deps
            .dirs
            .cache
            .join("jars/test-1.0/test-1.0.jar")
            .exists());
    }

    #[tokio::test]
    async fn bad_version_ids_never_touch_the_network_or_disk() {
        let w = world(None).await;
        let (_r, events) = recorder();
        for bad in ["../evil", "a/b", ""] {
            let req = req_for(&w, bad, None);
            let err = prepare(&w.deps, &req, &session(), &events)
                .await
                .unwrap_err();
            assert!(
                matches!(err, Error::Launch(LaunchError::InvalidVersionId)),
                "{bad}: {err:?}"
            );
        }
        assert_eq!(request_count(&w).await, 0);
    }

    #[tokio::test]
    async fn unknown_versions_are_reported() {
        let w = world(None).await;
        let (_r, events) = recorder();
        let req = req_for(&w, "9.9.9", None);
        let err = prepare(&w.deps, &req, &session(), &events)
            .await
            .unwrap_err();
        assert!(
            matches!(err, Error::Launch(LaunchError::UnknownVersion(_))),
            "{err:?}"
        );
    }

    #[tokio::test]
    async fn saved_data_lets_an_installed_version_prepare_offline() {
        let w = world(None).await;
        let (_r, events) = recorder();
        prepare(
            &w.deps,
            &request(&w, Some("/bin/true".into())),
            &session(),
            &events,
        )
        .await
        .unwrap();
        // Unreachable server from now on: stop answering by dropping the mounts.
        w.server.reset().await;
        prepare(
            &w.deps,
            &request(&w, Some("/bin/true".into())),
            &session(),
            &events,
        )
        .await
        .expect("cached files should be enough offline");
    }

    #[cfg(unix)]
    fn fake_java(dir: &std::path::Path, body: &str) -> PathBuf {
        use std::os::unix::fs::PermissionsExt;
        let p = dir.join("fake-java.sh");
        std::fs::write(&p, format!("#!/bin/sh\n{body}\n")).unwrap();
        std::fs::set_permissions(&p, std::fs::Permissions::from_mode(0o755)).unwrap();
        p
    }

    #[cfg(unix)]
    #[tokio::test]
    async fn output_is_streamed_with_the_token_masked_and_the_exit_code_reported() {
        let w = world(None).await;
        let java = fake_java(
            w.dir.path(),
            "for a in \"$@\"; do echo \"ARG:$a\"; done\necho oops-on-stderr >&2\nprintf 'bad\\377bytes\\n'\nexit 3",
        );
        let (rec, events) = recorder();
        let prepared = prepare(&w.deps, &request(&w, Some(java)), &session(), &events)
            .await
            .unwrap();
        let code = spawn_and_stream(prepared, &events).await.unwrap();
        assert_eq!(code, Some(3));

        let lines = rec.lines.lock().unwrap();
        assert!(lines
            .iter()
            .any(|l| l.stream == LogStream::Stdout && l.text == "ARG:net.test.Main"));
        assert!(lines
            .iter()
            .any(|l| l.stream == LogStream::Stderr && l.text == "oops-on-stderr"));
        assert!(
            lines.iter().any(|l| l.text.starts_with("bad")),
            "invalid UTF-8 must not end the stream"
        );
        // The fake game printed its own arguments, token included: none may get through.
        assert!(lines.iter().all(|l| !l.text.contains(TOKEN)), "{lines:?}");
        assert!(lines.iter().any(|l| l.text.contains("[REDACTED]")));
        assert!(rec
            .statuses
            .lock()
            .unwrap()
            .iter()
            .any(|s| matches!(s, LaunchStatus::Running { .. })));
    }

    #[cfg(unix)]
    async fn wait_for(m: &LaunchManager, pred: impl Fn(&LaunchStatus) -> bool) -> LaunchStatus {
        let start = Instant::now();
        loop {
            let s = m.status();
            if pred(&s) {
                return s;
            }
            assert!(
                start.elapsed() < Duration::from_secs(20),
                "timed out in {s:?}"
            );
            tokio::time::sleep(Duration::from_millis(20)).await;
        }
    }

    #[cfg(unix)]
    #[tokio::test]
    async fn the_manager_runs_one_game_stops_it_and_keeps_a_log() {
        let w = world(None).await;
        let java = fake_java(w.dir.path(), "echo started\nsleep 30");
        let manager = LaunchManager::new();
        let (rec, events) = recorder();
        assert_eq!(manager.status(), LaunchStatus::Idle);
        assert!(matches!(
            manager.stop(),
            Err(Error::Launch(LaunchError::NotRunning))
        ));

        manager
            .start(
                clone_deps(&w),
                request(&w, Some(java.clone())),
                session(),
                events.clone(),
            )
            .unwrap();
        wait_for(&manager, |s| matches!(s, LaunchStatus::Running { .. })).await;

        let second = manager.start(clone_deps(&w), request(&w, Some(java)), session(), events);
        assert!(matches!(
            second,
            Err(Error::Launch(LaunchError::AlreadyRunning))
        ));

        // The output so far is available to a console opened late.
        let start = Instant::now();
        while manager.log_tail().is_empty() && start.elapsed() < Duration::from_secs(10) {
            tokio::time::sleep(Duration::from_millis(20)).await;
        }
        assert_eq!(manager.log_tail()[0].text, "started");

        manager.stop().unwrap();
        let s = wait_for(&manager, |s| matches!(s, LaunchStatus::Exited { .. })).await;
        assert_eq!(s, LaunchStatus::Exited { code: None });
        assert!(!manager.is_active());
        assert!(rec
            .statuses
            .lock()
            .unwrap()
            .last()
            .is_some_and(|s| matches!(s, LaunchStatus::Exited { .. })));
    }

    #[tokio::test]
    async fn failures_become_a_failed_status_with_a_plain_message() {
        let w = world(None).await;
        let manager = LaunchManager::new();
        let (_r, events) = recorder();
        let req = req_for(&w, "9.9.9", None);
        manager.start(w.deps, req, session(), events).unwrap();
        let start = Instant::now();
        let status = loop {
            let s = manager.status();
            if matches!(s, LaunchStatus::Failed { .. }) {
                break s;
            }
            assert!(start.elapsed() < Duration::from_secs(20), "{s:?}");
            tokio::time::sleep(Duration::from_millis(20)).await;
        };
        let LaunchStatus::Failed { code, message } = status else {
            unreachable!()
        };
        assert_eq!(code, "unknown_version");
        assert!(message.contains("9.9.9"));
        // And a new launch is allowed afterwards.
        assert!(!manager.is_active());
    }

    #[tokio::test]
    async fn a_fabric_instance_merges_the_loader_profile_onto_vanilla() {
        let w = world(None).await;
        let s = w.server.uri();
        let loader_jar = b"FABRIC-LOADER-JAR".to_vec();
        mount(
            &w.server,
            "/maven/net/fabricmc/fabric-loader/0.16.5/fabric-loader-0.16.5.jar",
            loader_jar.clone(),
        )
        .await;
        mount(
            &w.server,
            "/maven/net/fabricmc/fabric-loader/0.16.5/fabric-loader-0.16.5.jar.sha1",
            sha1(&loader_jar).into_bytes(),
        )
        .await;
        mount(&w.server, "/v2/versions/loader/test-1.0/0.16.5/profile/json", json!({
            "id": "fabric-loader-0.16.5-test-1.0", "inheritsFrom": "test-1.0", "type": "release",
            "mainClass": "net.fabricmc.loader.impl.launch.knot.KnotClient",
            "arguments": {"game": [], "jvm": ["-DFabricMcEmu= net.minecraft.client.main.Main "]},
            "libraries": [{"name": "net.fabricmc:fabric-loader:0.16.5", "url": format!("{s}/maven/")}]
        }).to_string().into_bytes()).await;

        let mut req = request(&w, Some("/bin/true".into()));
        req.loader = LoaderKind::Fabric;
        req.loader_version = Some("0.16.5".into());
        let (_r, events) = recorder();
        let p = prepare(&w.deps, &req, &session(), &events).await.unwrap();

        let a = &p.args;
        assert!(a.contains(&"net.fabricmc.loader.impl.launch.knot.KnotClient".to_string()));
        assert!(
            !a.contains(&"net.test.Main".to_string()),
            "the loader's main class replaces vanilla's"
        );
        assert!(
            a.contains(&"-DFabricMcEmu= net.minecraft.client.main.Main ".to_string()),
            "a JVM argument containing spaces stays one argument"
        );
        let cp = &a[a.iter().position(|x| x == "-cp").unwrap() + 1];
        let (fabric_at, lib_at) = (
            cp.find("fabric-loader-0.16.5.jar").unwrap(),
            cp.find("lib-1.jar").unwrap(),
        );
        assert!(fabric_at < lib_at, "loader libraries come first: {cp}");
        assert_eq!(
            std::fs::read(
                w.deps
                    .dirs
                    .cache
                    .join("libraries/net/fabricmc/fabric-loader/0.16.5/fabric-loader-0.16.5.jar")
            )
            .unwrap(),
            loader_jar
        );
        assert!(
            a.windows(2)
                .any(|x| x == ["--version", "fabric-loader-0.16.5-test-1.0"]),
            "version_name is the profile id"
        );
    }

    #[tokio::test]
    async fn a_tampered_loader_library_is_rejected() {
        let w = world(None).await;
        let s = w.server.uri();
        mount(&w.server, "/maven/x/y/1/y-1.jar", b"EVIL".to_vec()).await;
        mount(
            &w.server,
            "/maven/x/y/1/y-1.jar.sha1",
            sha1(b"GOOD").into_bytes(),
        )
        .await;
        mount(
            &w.server,
            "/v2/versions/loader/test-1.0/1/profile/json",
            json!({
                "id": "p", "inheritsFrom": "test-1.0", "type": "release", "mainClass": "M",
                "libraries": [{"name": "x:y:1", "url": format!("{s}/maven/")}]
            })
            .to_string()
            .into_bytes(),
        )
        .await;
        let mut req = request(&w, Some("/bin/true".into()));
        req.loader = LoaderKind::Fabric;
        req.loader_version = Some("1".into());
        let (_r, events) = recorder();
        let err = prepare(&w.deps, &req, &session(), &events)
            .await
            .unwrap_err();
        assert!(matches!(err, Error::HashMismatch { .. }), "{err:?}");
        assert!(!w.deps.dirs.cache.join("libraries/x/y/1/y-1.jar").exists());
    }

    #[cfg(unix)]
    #[tokio::test]
    async fn play_time_is_recorded_for_stored_instances() {
        let w = world(None).await;
        let store = InstanceStore::new(db::open_in_memory().await.unwrap(), &w.deps.dirs.instances);
        let inst = store
            .create(crate::instance::NewInstance {
                name: "T".into(),
                mc_version: "test-1.0".into(),
                loader: LoaderKind::Vanilla,
                loader_version: None,
            })
            .await
            .unwrap();
        let java = fake_java(w.dir.path(), "sleep 1");
        let mut req = request(&w, Some(java));
        req.game_dir = store.game_dir(&inst.id).await.unwrap();
        req.instance_id = Some(inst.id.clone());
        let manager = LaunchManager::new();
        let (_r, events) = recorder();
        manager
            .start(
                LaunchDeps {
                    instances: Some(store.clone()),
                    ..clone_deps(&w)
                },
                req,
                session(),
                events,
            )
            .unwrap();
        assert_eq!(
            manager.running_instance().as_deref(),
            Some(inst.id.as_str())
        );
        wait_for(&manager, |s| matches!(s, LaunchStatus::Exited { .. })).await;
        let played = store.get(&inst.id).await.unwrap();
        assert!(
            played.playtime_s >= 1 && played.last_played.is_some(),
            "{played:?}"
        );
        assert_eq!(manager.running_instance(), None);
    }

    fn clone_deps(w: &World) -> LaunchDeps {
        LaunchDeps {
            dirs: w.deps.dirs.clone(),
            mojang: w.deps.mojang.clone(),
            java: w.deps.java.clone(),
            loaders: w.deps.loaders.clone(),
            instances: None,
            mods: None,
        }
    }

    /// An instance whose mods folder holds `a-2.jar`, installed by an update that replaced
    /// `a-1.jar` and hasn't been proven yet.
    #[cfg(unix)]
    async fn instance_with_pending_update(
        w: &World,
        window: Duration,
    ) -> (InstanceStore, crate::mods::store::ModStore, String) {
        let db = db::open_in_memory().await.unwrap();
        let store = InstanceStore::new(db.clone(), &w.deps.dirs.instances);
        let inst = store
            .create(crate::instance::NewInstance {
                name: "T".into(),
                mc_version: "test-1.0".into(),
                loader: LoaderKind::Vanilla,
                loader_version: None,
            })
            .await
            .unwrap();
        let mods = crate::mods::store::ModStore::new(db, store.clone(), &w.deps.dirs.backups)
            .with_startup_window(window);
        let dir = mods.mods_dir(&inst.id).await.unwrap();
        std::fs::create_dir_all(dir.as_path()).unwrap();
        std::fs::write(dir.as_path().join("a-1.jar"), b"OLD").unwrap();
        mods.sync(&inst.id).await.unwrap();
        let old = mods.list(&inst.id).await.unwrap().remove(0);
        mods.backup_for_update(&inst.id, &old, "a-2.jar")
            .await
            .unwrap();
        std::fs::remove_file(dir.as_path().join("a-1.jar")).unwrap();
        std::fs::write(dir.as_path().join("a-2.jar"), b"NEW").unwrap();
        mods.sync(&inst.id).await.unwrap();
        assert_eq!(mods.pending_updates(&inst.id).await.unwrap(), 1);
        (store, mods, inst.id)
    }

    #[cfg(unix)]
    async fn play(
        w: &World,
        store: &InstanceStore,
        mods: &crate::mods::store::ModStore,
        id: &str,
        java_body: &str,
    ) -> (LaunchManager, Arc<Recorder>) {
        let java = fake_java(w.dir.path(), java_body);
        let mut req = request(w, Some(java));
        req.game_dir = store.game_dir(id).await.unwrap();
        req.instance_id = Some(id.to_owned());
        let manager = LaunchManager::new();
        let (rec, events) = recorder();
        manager
            .start(
                LaunchDeps {
                    instances: Some(store.clone()),
                    mods: Some(mods.clone()),
                    ..clone_deps(w)
                },
                req,
                session(),
                events,
            )
            .unwrap();
        (manager, rec)
    }

    #[cfg(unix)]
    #[tokio::test]
    async fn a_crash_right_after_a_mod_update_rolls_the_update_back() {
        let w = world(None).await;
        let (store, mods, id) = instance_with_pending_update(&w, Duration::from_secs(60)).await;
        let (manager, rec) = play(&w, &store, &mods, &id, "exit 1").await;
        wait_for(&manager, |s| matches!(s, LaunchStatus::Exited { .. })).await;

        let dir = mods.mods_dir(&id).await.unwrap().as_path().to_path_buf();
        assert_eq!(std::fs::read(dir.join("a-1.jar")).unwrap(), b"OLD");
        assert!(!dir.join("a-2.jar").exists());
        assert_eq!(mods.pending_updates(&id).await.unwrap(), 0);
        let reports = rec.rollbacks.lock().unwrap();
        assert_eq!(reports.len(), 1);
        assert_eq!(reports[0].restored, ["a-1.jar"]);
        assert_eq!(reports[0].instance_id, id);
    }

    #[cfg(unix)]
    #[tokio::test]
    async fn a_clean_exit_keeps_the_update() {
        let w = world(None).await;
        let (store, mods, id) = instance_with_pending_update(&w, Duration::from_secs(60)).await;
        let (manager, rec) = play(&w, &store, &mods, &id, "exit 0").await;
        wait_for(&manager, |s| matches!(s, LaunchStatus::Exited { .. })).await;
        let dir = mods.mods_dir(&id).await.unwrap().as_path().to_path_buf();
        assert!(dir.join("a-2.jar").exists() && !dir.join("a-1.jar").exists());
        assert_eq!(
            mods.pending_updates(&id).await.unwrap(),
            0,
            "confirmed, not pending"
        );
        assert!(rec.rollbacks.lock().unwrap().is_empty());
    }

    #[cfg(unix)]
    #[tokio::test]
    async fn a_crash_after_the_game_ran_a_while_is_not_blamed_on_the_update() {
        let w = world(None).await;
        // A zero-length window: every run counts as having started fine.
        let (store, mods, id) = instance_with_pending_update(&w, Duration::ZERO).await;
        let (manager, rec) = play(&w, &store, &mods, &id, "exit 1").await;
        wait_for(&manager, |s| matches!(s, LaunchStatus::Exited { .. })).await;
        let dir = mods.mods_dir(&id).await.unwrap().as_path().to_path_buf();
        assert!(dir.join("a-2.jar").exists());
        assert!(rec.rollbacks.lock().unwrap().is_empty());
        assert_eq!(mods.pending_updates(&id).await.unwrap(), 0);
    }

    #[cfg(unix)]
    #[tokio::test]
    async fn stopping_the_game_yourself_decides_nothing_about_the_update() {
        let w = world(None).await;
        let (store, mods, id) = instance_with_pending_update(&w, Duration::from_secs(60)).await;
        let (manager, rec) = play(&w, &store, &mods, &id, "sleep 30").await;
        wait_for(&manager, |s| matches!(s, LaunchStatus::Running { .. })).await;
        manager.stop().unwrap();
        wait_for(&manager, |s| {
            matches!(s, LaunchStatus::Exited { .. } | LaunchStatus::Idle)
        })
        .await;
        tokio::time::sleep(Duration::from_millis(200)).await;
        let dir = mods.mods_dir(&id).await.unwrap().as_path().to_path_buf();
        assert!(dir.join("a-2.jar").exists());
        assert_eq!(mods.pending_updates(&id).await.unwrap(), 1);
        assert!(rec.rollbacks.lock().unwrap().is_empty());
    }
}
