//! Errors from resolving versions, installing Java and starting the game.

#[derive(Debug, thiserror::Error)]
pub enum LaunchError {
    #[error("invalid version id")]
    InvalidVersionId,
    #[error("unknown Minecraft version {0}")]
    UnknownVersion(String),
    #[error("library {0} has no download information")]
    UnsupportedLibrary(String),
    #[error("version {0} uses the legacy asset layout")]
    LegacyAssets(String),
    #[error("no Java {0} build is available for this computer")]
    NoJavaBuild(u32),
    #[error("the Java runtime is not usable: {0}")]
    BadJava(String),
    #[error("a game is already running")]
    AlreadyRunning,
    #[error("no game is running")]
    NotRunning,
    #[error("no account is signed in")]
    NoAccount,
    #[error("the game could not be started: {0}")]
    SpawnFailed(String),
    #[error("no such instance")]
    InstanceNotFound,
    #[error("invalid instance name")]
    InvalidName,
    #[error("the instance is in use")]
    InstanceBusy,
    #[error("invalid JVM arguments: {0}")]
    InvalidJvmArgs(String),
    #[error("not a usable pack: {0}")]
    InvalidPack(String),
    #[error("installing the mod loader failed: {0}")]
    LoaderInstall(String),
    #[error("{0} is not compatible with Minecraft {1}")]
    IncompatibleLoader(String, String),
}

impl LaunchError {
    pub fn code(&self) -> &'static str {
        match self {
            Self::InvalidVersionId => "invalid_version",
            Self::UnknownVersion(_) => "unknown_version",
            Self::UnsupportedLibrary(_) => "unsupported_library",
            Self::LegacyAssets(_) => "legacy_assets",
            Self::NoJavaBuild(_) => "no_java_build",
            Self::BadJava(_) => "bad_java",
            Self::AlreadyRunning => "already_running",
            Self::NotRunning => "not_running",
            Self::NoAccount => "no_account",
            Self::SpawnFailed(_) => "spawn_failed",
            Self::InstanceNotFound => "instance_not_found",
            Self::InvalidName => "invalid_name",
            Self::InstanceBusy => "instance_busy",
            Self::InvalidJvmArgs(_) => "invalid_jvm_args",
            Self::InvalidPack(_) => "invalid_pack",
            Self::LoaderInstall(_) => "loader_install_failed",
            Self::IncompatibleLoader(..) => "incompatible_loader",
        }
    }

    pub fn user_message(&self) -> String {
        match self {
            Self::InvalidVersionId => "That isn't a valid Minecraft version.".into(),
            Self::UnknownVersion(v) => format!("Mojang has no Minecraft version called \"{v}\"."),
            Self::UnsupportedLibrary(_) => {
                "This version needs a library Kiln can't download yet.".into()
            }
            Self::LegacyAssets(_) => {
                "This is a very old version that stores its assets in a legacy \
                layout, which Kiln doesn't support yet."
                    .into()
            }
            Self::NoJavaBuild(n) => format!(
                "Kiln couldn't find a Java {n} runtime to download for this computer. Install \
                 Java {n} yourself and Kiln will use it."
            ),
            Self::BadJava(_) => "The Java runtime Kiln found doesn't work. Reinstall Java, or \
                delete Kiln's java folder so it downloads a fresh copy."
                .into(),
            Self::AlreadyRunning => {
                "A game is already running. Close it before starting another.".into()
            }
            Self::NotRunning => "No game is running.".into(),
            Self::NoAccount => {
                "Sign in with a Microsoft account on the Accounts page first.".into()
            }
            Self::InstanceNotFound => "That instance no longer exists.".into(),
            Self::InvalidName => {
                "Instance names must be 1 to 64 characters with no control characters.".into()
            }
            Self::InstanceBusy => "That instance is running. Close the game first.".into(),
            Self::InvalidJvmArgs(why) => format!("Those Java arguments aren't allowed: {why}."),
            Self::InvalidPack(why) => format!("Kiln can't use that pack: {why}."),
            Self::LoaderInstall(_) => {
                "Kiln couldn't install the mod loader. Check your connection \
                and try again; if it keeps failing, the log has details."
                    .into()
            }
            Self::IncompatibleLoader(loader, mc) => {
                format!("{loader} isn't available for Minecraft {mc}.")
            }
            Self::SpawnFailed(_) => "Kiln couldn't start the game process. Check that Java is \
                installed correctly and that your antivirus isn't blocking it."
                .into(),
        }
    }
}
