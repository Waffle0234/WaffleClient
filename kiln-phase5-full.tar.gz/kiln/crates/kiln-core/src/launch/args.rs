//! Builds the JVM and game command line from a version's argument templates.

use crate::mojang::rules::Environment;
use crate::mojang::VersionJson;

/// Values substituted into `${placeholders}`.
pub struct ArgContext<'a> {
    pub player_name: &'a str,
    /// 32 hex characters, no dashes.
    pub uuid: &'a str,
    pub access_token: &'a str,
    pub version_name: &'a str,
    pub version_type: &'a str,
    pub game_dir: &'a str,
    pub assets_root: &'a str,
    pub assets_index: &'a str,
    pub natives_dir: &'a str,
    pub classpath: &'a str,
    pub library_dir: &'a str,
    pub launcher_name: &'a str,
    pub launcher_version: &'a str,
}

fn classpath_separator() -> &'static str {
    if cfg!(windows) {
        ";"
    } else {
        ":"
    }
}

pub fn join_classpath<'a>(entries: impl IntoIterator<Item = &'a str>) -> String {
    entries
        .into_iter()
        .collect::<Vec<_>>()
        .join(classpath_separator())
}

/// `None` means "we have no value": the argument is dropped instead of passed empty.
fn lookup(key: &str, c: &ArgContext<'_>) -> Option<String> {
    Some(match key {
        "auth_player_name" => c.player_name.into(),
        "auth_uuid" => c.uuid.into(),
        "auth_access_token" => c.access_token.into(),
        "auth_session" => format!("token:{}:{}", c.access_token, c.uuid),
        "user_type" => "msa".into(),
        "user_properties" => "{}".into(),
        "version_name" => c.version_name.into(),
        "version_type" => c.version_type.into(),
        "game_directory" => c.game_dir.into(),
        "assets_root" | "game_assets" => c.assets_root.into(),
        "assets_index_name" => c.assets_index.into(),
        "natives_directory" => c.natives_dir.into(),
        "classpath" => c.classpath.into(),
        "library_directory" => c.library_dir.into(),
        "classpath_separator" => classpath_separator().into(),
        "launcher_name" => c.launcher_name.into(),
        "launcher_version" => c.launcher_version.into(),
        // `clientid`, `auth_xuid` (telemetry ids), resolution, quick play: not provided.
        _ => return None,
    })
}

fn expand(token: &str, c: &ArgContext<'_>) -> Option<String> {
    let mut out = String::new();
    let mut rest = token;
    while let Some(start) = rest.find("${") {
        out.push_str(&rest[..start]);
        let after = &rest[start + 2..];
        let Some(end) = after.find('}') else {
            out.push_str(&rest[start..]);
            return Some(out);
        };
        out.push_str(&lookup(&after[..end], c)?);
        rest = &after[end + 1..];
    }
    out.push_str(rest);
    Some(out)
}

fn expand_all<'a>(tokens: impl IntoIterator<Item = &'a str>, c: &ArgContext<'_>) -> Vec<String> {
    let mut out: Vec<String> = Vec::new();
    for token in tokens {
        match expand(token, c) {
            Some(value) => out.push(value),
            // A flag whose value we can't provide goes too: `--xuid ${auth_xuid}`.
            None => {
                if out.last().is_some_and(|l| l.starts_with("--")) {
                    out.pop();
                }
            }
        }
    }
    out
}

/// The complete argument list for `java`: JVM flags, main class, then game flags.
pub fn build_args(
    version: &VersionJson,
    env: &Environment,
    ctx: &ArgContext<'_>,
    ram_mb: Option<u32>,
    extra_jvm: &[String],
) -> Vec<String> {
    let (jvm, game): (Vec<&str>, Vec<&str>) =
        match (&version.arguments, &version.minecraft_arguments) {
            (Some(a), _) => (
                a.jvm.iter().flat_map(|x| x.values(env)).collect(),
                a.game.iter().flat_map(|x| x.values(env)).collect(),
            ),
            // Before 1.13 the JSON has no JVM arguments at all.
            (None, Some(legacy)) => (
                vec![
                    "-Djava.library.path=${natives_directory}",
                    "-cp",
                    "${classpath}",
                ],
                legacy.split_whitespace().collect(),
            ),
            (None, None) => (Vec::new(), Vec::new()),
        };
    let mut args = Vec::new();
    if let Some(mb) = ram_mb {
        args.push(format!("-Xmx{mb}M"));
    }
    args.extend(extra_jvm.iter().cloned());
    args.extend(expand_all(jvm, ctx));
    args.push(version.main_class.clone());
    args.extend(expand_all(game, ctx));
    args
}

#[cfg(test)]
mod tests {
    use serde_json::json;

    use super::*;

    fn ctx() -> ArgContext<'static> {
        ArgContext {
            player_name: "Steve",
            uuid: "069a79f44e9d4e9cb12bd4a2bb7d6fd4",
            access_token: "TOKEN",
            version_name: "1.21.1",
            version_type: "release",
            game_dir: "/g",
            assets_root: "/a",
            assets_index: "17",
            natives_dir: "/n",
            classpath: "/c.jar",
            library_dir: "/l",
            launcher_name: "Kiln",
            launcher_version: "0.1",
        }
    }

    fn version(extra: serde_json::Value) -> VersionJson {
        let mut v = json!({
            "id": "1.21.1", "type": "release", "mainClass": "net.minecraft.client.main.Main",
            "assetIndex": {"id": "17", "sha1": "a".repeat(40), "size": 1, "url": "https://x/i"},
        });
        v.as_object_mut()
            .unwrap()
            .extend(extra.as_object().unwrap().clone());
        serde_json::from_value(v).unwrap()
    }

    #[test]
    fn modern_arguments_expand_and_optional_flags_are_dropped() {
        let v = version(json!({"arguments": {
            "jvm": ["-Djava.library.path=${natives_directory}", "-cp", "${classpath}"],
            "game": ["--username", "${auth_player_name}", "--clientId", "${clientid}",
                     "--xuid", "${auth_xuid}", "--accessToken", "${auth_access_token}",
                     "--gameDir", "${game_directory}"]
        }}));
        let env = Environment::current();
        let args = build_args(&v, &env, &ctx(), Some(3072), &["-Xss1M".to_string()]);
        assert_eq!(
            args,
            [
                "-Xmx3072M",
                "-Xss1M",
                "-Djava.library.path=/n",
                "-cp",
                "/c.jar",
                "net.minecraft.client.main.Main",
                "--username",
                "Steve",
                "--accessToken",
                "TOKEN",
                "--gameDir",
                "/g",
            ]
        );
    }

    #[test]
    fn legacy_argument_strings_get_default_jvm_flags() {
        let v = version(json!({
            "minecraftArguments": "--username ${auth_player_name} --session ${auth_session} --userProperties ${user_properties} --assetsDir ${game_assets}"
        }));
        let args = build_args(&v, &Environment::current(), &ctx(), None, &[]);
        assert_eq!(&args[..3], ["-Djava.library.path=/n", "-cp", "/c.jar"]);
        assert!(args.contains(&"token:TOKEN:069a79f44e9d4e9cb12bd4a2bb7d6fd4".to_string()));
        assert!(args.contains(&"{}".to_string()));
        assert!(args.contains(&"/a".to_string()));
    }

    #[test]
    fn unknown_placeholders_never_reach_the_command_line_verbatim() {
        let v = version(
            json!({"arguments": {"jvm": [], "game": ["--mystery", "${nope}", "--keep", "yes"]}}),
        );
        let args = build_args(&v, &Environment::current(), &ctx(), None, &[]);
        assert!(!args.iter().any(|a| a.contains("${")), "{args:?}");
        assert!(args.windows(2).any(|w| w == ["--keep", "yes"]));
        assert!(!args.contains(&"--mystery".to_string()));
    }

    #[test]
    fn placeholders_embedded_in_a_token_and_unterminated_ones() {
        let c = ctx();
        assert_eq!(
            expand("-Dx=${version_name}-${version_type}", &c).as_deref(),
            Some("-Dx=1.21.1-release")
        );
        assert_eq!(
            expand("odd${unterminated", &c).as_deref(),
            Some("odd${unterminated")
        );
        assert_eq!(expand("a${nope}b", &c), None);
    }

    #[test]
    fn classpath_joins_with_the_platform_separator() {
        let sep = if cfg!(windows) { ";" } else { ":" };
        assert_eq!(join_classpath(["a", "b"]), format!("a{sep}b"));
    }
}
