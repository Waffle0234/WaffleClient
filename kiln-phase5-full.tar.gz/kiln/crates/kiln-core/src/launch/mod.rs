//! Launching the game: prepare files, build the command line, run Java, stream its output.

mod args;
mod error;
mod manager;

pub use args::{build_args, ArgContext};
pub use error::LaunchError;
pub use manager::{
    prepare, spawn_and_stream, LaunchDeps, LaunchEvents, LaunchManager, LaunchRequest,
    LaunchStatus, LogLine, LogStream, Prepared,
};

/// Stop Windows from flashing a console window for every child process.
pub(crate) fn hide_console_window(cmd: &mut tokio::process::Command) {
    #[cfg(windows)]
    {
        const CREATE_NO_WINDOW: u32 = 0x0800_0000;
        cmd.creation_flags(CREATE_NO_WINDOW);
    }
    #[cfg(not(windows))]
    {
        let _ = cmd;
    }
}
