//! Minecraft services: exchange the XSTS token for a game token, then read the profile.
//! A missing profile (404) means the account doesn't own Minecraft: Java Edition.

use std::time::Duration;

use reqwest::{Method, Url};
use serde::Deserialize;
use serde_json::json;

use super::accounts::{is_valid_account_id, SkinVariant};
use super::endpoints::Endpoints;
use super::error::{unexpected, AuthError};
use super::secret::SecretString;
use super::xbox::XboxToken;
use crate::net::{Body, HttpClient};
use crate::Result;

pub struct McLogin {
    pub access_token: SecretString,
    pub expires_in: Duration,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Profile {
    /// 32 lowercase hex characters (the player UUID without dashes).
    pub id: String,
    pub name: String,
    pub skin_hash: Option<String>,
    pub skin_variant: Option<SkinVariant>,
    pub cape_hash: Option<String>,
}

#[derive(Deserialize)]
struct LoginResponse {
    access_token: String,
    expires_in: u64,
}

#[derive(Deserialize)]
struct RawProfile {
    id: String,
    name: String,
    #[serde(default)]
    skins: Vec<RawTexture>,
    #[serde(default)]
    capes: Vec<RawTexture>,
}

#[derive(Deserialize)]
struct RawTexture {
    state: Option<String>,
    url: String,
    variant: Option<String>,
}

/// Extract the texture hash from a Mojang texture URL. Mojang serves these over plain
/// `http://`; only the host and a hex hash are trusted, and the UI rebuilds an HTTPS URL.
pub fn texture_hash(url: &str) -> Option<String> {
    let url = Url::parse(url).ok()?;
    if url.host_str() != Some("textures.minecraft.net") {
        return None;
    }
    let hash = url.path().strip_prefix("/texture/")?;
    let ok = (8..=64).contains(&hash.len())
        && hash.bytes().all(|b| matches!(b, b'0'..=b'9' | b'a'..=b'f'));
    ok.then(|| hash.to_owned())
}

fn is_active(t: &RawTexture) -> bool {
    t.state
        .as_deref()
        .is_some_and(|s| s.eq_ignore_ascii_case("ACTIVE"))
}

fn valid_name(name: &str) -> bool {
    (1..=16).contains(&name.len()) && name.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'_')
}

fn parse_profile(raw: RawProfile) -> Result<Profile> {
    let id = raw.id.to_ascii_lowercase().replace('-', "");
    if !is_valid_account_id(&id) || !valid_name(&raw.name) {
        return Err(unexpected(
            "Minecraft",
            "profile id or name failed validation",
        ));
    }
    let skin = raw
        .skins
        .iter()
        .find(|t| is_active(t))
        .or(raw.skins.first());
    let cape = raw.capes.iter().find(|t| is_active(t));
    Ok(Profile {
        id,
        name: raw.name,
        skin_hash: skin.and_then(|t| texture_hash(&t.url)),
        skin_variant: skin
            .and_then(|t| t.variant.as_deref())
            .and_then(SkinVariant::parse),
        cape_hash: cape.and_then(|t| texture_hash(&t.url)),
    })
}

pub async fn login_with_xbox(
    http: &HttpClient,
    ep: &Endpoints,
    xsts: &XboxToken,
) -> Result<McLogin> {
    let body = json!({ "identityToken": format!("XBL3.0 x={};{}", xsts.uhs, xsts.token.expose()) });
    let resp = http
        .execute(Method::POST, &ep.minecraft_login, Body::Json(&body), None)
        .await?;
    match resp.status {
        // Mojang answers 403 "Invalid app registration" for client ids it hasn't approved.
        403 => Err(AuthError::AppNotApproved.into()),
        s if !(200..300).contains(&s) => {
            Err(unexpected("Minecraft", format!("HTTP {s} from login")))
        }
        _ => {
            let body: LoginResponse = resp.json()?;
            Ok(McLogin {
                access_token: SecretString::new(body.access_token),
                expires_in: Duration::from_secs(body.expires_in.clamp(60, 172_800)),
            })
        }
    }
}

pub async fn fetch_profile(
    http: &HttpClient,
    ep: &Endpoints,
    token: &SecretString,
) -> Result<Profile> {
    let resp = http
        .execute(
            Method::GET,
            &ep.minecraft_profile,
            Body::Empty,
            Some(token.expose()),
        )
        .await?;
    match resp.status {
        404 => Err(AuthError::NoGameOwnership.into()),
        s if !(200..300).contains(&s) => Err(unexpected(
            "Minecraft",
            format!("HTTP {s} reading the profile"),
        )),
        _ => parse_profile(resp.json()?),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const HASH: &str = "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef";

    #[test]
    fn texture_hash_accepts_only_mojang_texture_urls() {
        let good = format!("http://textures.minecraft.net/texture/{HASH}");
        assert_eq!(texture_hash(&good).as_deref(), Some(HASH));
        assert!(texture_hash(&good.replace("http:", "https:")).is_some());
        for bad in [
            "http://evil.example/texture/0123456789abcdef",
            "http://textures.minecraft.net.evil.net/texture/0123456789abcdef",
            "http://textures.minecraft.net/other/0123456789abcdef",
            "http://textures.minecraft.net/texture/../../x",
            "http://textures.minecraft.net/texture/NOTHEX!!NOTHEX!!",
            "http://textures.minecraft.net/texture/abc",
            "garbage",
        ] {
            assert!(texture_hash(bad).is_none(), "accepted {bad}");
        }
    }

    fn raw(json: serde_json::Value) -> RawProfile {
        serde_json::from_value(json).unwrap()
    }

    #[test]
    fn profile_parsing_normalizes_and_picks_active_textures() {
        let p = parse_profile(raw(serde_json::json!({
            "id": "069A79F4-4E9D-4E9C-B12B-D4A2BB7D6FD4",
            "name": "Steve_1",
            "skins": [
                {"state": "INACTIVE", "url": format!("http://textures.minecraft.net/texture/{}", "a".repeat(64)), "variant": "CLASSIC"},
                {"state": "ACTIVE", "url": format!("http://textures.minecraft.net/texture/{HASH}"), "variant": "slim"}
            ],
            "capes": [{"state": "ACTIVE", "url": format!("http://textures.minecraft.net/texture/{}", "b".repeat(64))}]
        })))
        .unwrap();
        assert_eq!(p.id, "069a79f44e9d4e9cb12bd4a2bb7d6fd4");
        assert_eq!(p.skin_hash.as_deref(), Some(HASH));
        assert_eq!(p.skin_variant, Some(SkinVariant::Slim));
        assert_eq!(p.cape_hash, Some("b".repeat(64)));
    }

    #[test]
    fn profile_without_textures_is_fine_and_bad_identity_is_rejected() {
        let p = parse_profile(raw(
            serde_json::json!({"id": "a".repeat(32), "name": "Alex"}),
        ))
        .unwrap();
        assert!(p.skin_hash.is_none() && p.cape_hash.is_none());

        for (id, name) in [
            ("short", "Alex"),
            (&"a".repeat(32), "bad name!"),
            (&"a".repeat(32), ""),
        ] {
            assert!(parse_profile(raw(serde_json::json!({"id": id, "name": name}))).is_err());
        }
    }
}
