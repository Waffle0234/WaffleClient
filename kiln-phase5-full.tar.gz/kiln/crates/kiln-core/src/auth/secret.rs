use zeroize::{Zeroize, ZeroizeOnDrop};

use crate::redact;

/// A token that can't be printed by accident: `Debug` hides it, it is wiped from memory
/// when dropped (best effort: copies made by HTTP buffers are outside our control), and it
/// is registered with the log redactor the moment it exists.
#[derive(Clone, Zeroize, ZeroizeOnDrop)]
pub struct SecretString(String);

impl SecretString {
    pub fn new(value: impl Into<String>) -> Self {
        let value = value.into();
        redact::global().register_secret(&value);
        Self(value)
    }

    /// The raw value. Use only to build a request or a launch argument.
    pub fn expose(&self) -> &str {
        &self.0
    }
}

impl std::fmt::Debug for SecretString {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("SecretString([REDACTED])")
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn debug_never_shows_the_value() {
        let s = SecretString::new("super-secret-token-value");
        assert!(!format!("{s:?}").contains("super-secret"));
        assert_eq!(s.expose(), "super-secret-token-value");
    }
}
