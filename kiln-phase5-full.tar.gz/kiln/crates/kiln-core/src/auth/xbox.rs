//! Xbox Live user token and XSTS authorization for the Minecraft relying party.

use reqwest::Method;
use serde::Deserialize;
use serde_json::json;

use super::endpoints::Endpoints;
use super::error::{unexpected, AuthError};
use super::secret::SecretString;
use crate::net::{Body, HttpClient};
use crate::Result;

pub struct XboxToken {
    pub token: SecretString,
    /// "User hash": identifies the Xbox user inside the Minecraft identity token.
    pub uhs: String,
}

#[derive(Deserialize)]
struct XboxResponse {
    #[serde(rename = "Token")]
    token: String,
    #[serde(rename = "DisplayClaims")]
    claims: Claims,
}

#[derive(Deserialize)]
struct Claims {
    xui: Vec<Xui>,
}

#[derive(Deserialize)]
struct Xui {
    uhs: String,
}

#[derive(Deserialize)]
struct XstsError {
    #[serde(rename = "XErr")]
    code: Option<u64>,
}

fn parse(resp: &crate::net::HttpResponse, what: &str) -> Result<XboxToken> {
    let body: XboxResponse = resp.json()?;
    let uhs = body
        .claims
        .xui
        .into_iter()
        .next()
        .map(|x| x.uhs)
        .filter(|u| (1..=64).contains(&u.len()) && u.bytes().all(|b| b.is_ascii_alphanumeric()))
        .ok_or_else(|| unexpected("Xbox", format!("{what} response had no valid user hash")))?;
    Ok(XboxToken {
        token: SecretString::new(body.token),
        uhs,
    })
}

pub async fn authenticate(
    http: &HttpClient,
    ep: &Endpoints,
    ms_access: &SecretString,
) -> Result<XboxToken> {
    let body = json!({
        "Properties": {
            "AuthMethod": "RPS",
            "SiteName": "user.auth.xboxlive.com",
            "RpsTicket": format!("d={}", ms_access.expose()),
        },
        "RelyingParty": "http://auth.xboxlive.com",
        "TokenType": "JWT",
    });
    let resp = http
        .execute(Method::POST, &ep.xbox_user_auth, Body::Json(&body), None)
        .await?;
    if !resp.is_success() {
        return Err(unexpected(
            "Xbox",
            format!("HTTP {} from user authentication", resp.status),
        ));
    }
    parse(&resp, "user authentication")
}

pub async fn authorize_xsts(
    http: &HttpClient,
    ep: &Endpoints,
    user: &XboxToken,
) -> Result<XboxToken> {
    let body = json!({
        "Properties": {
            "SandboxId": "RETAIL",
            "UserTokens": [user.token.expose()],
        },
        "RelyingParty": "rp://api.minecraftservices.com/",
        "TokenType": "JWT",
    });
    let resp = http
        .execute(Method::POST, &ep.xsts, Body::Json(&body), None)
        .await?;
    if resp.status == 401 {
        let code = resp.json::<XstsError>().ok().and_then(|e| e.code);
        return Err(map_xsts_error(code).into());
    }
    if !resp.is_success() {
        return Err(unexpected(
            "Xbox",
            format!("HTTP {} from XSTS", resp.status),
        ));
    }
    parse(&resp, "XSTS")
}

/// <https://wiki.vg/Microsoft_Authentication_Scheme> documents these `XErr` codes.
fn map_xsts_error(code: Option<u64>) -> AuthError {
    match code {
        Some(2_148_916_233) => AuthError::XboxNoAccount,
        Some(2_148_916_235) => AuthError::XboxRegionBlocked,
        Some(2_148_916_236 | 2_148_916_237) => AuthError::XboxAdultVerification,
        Some(2_148_916_238) => AuthError::XboxChildAccount,
        Some(other) => AuthError::XboxOther(other),
        None => AuthError::XboxOther(0),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn xsts_codes_map_to_specific_errors() {
        assert!(matches!(
            map_xsts_error(Some(2_148_916_233)),
            AuthError::XboxNoAccount
        ));
        assert!(matches!(
            map_xsts_error(Some(2_148_916_235)),
            AuthError::XboxRegionBlocked
        ));
        assert!(matches!(
            map_xsts_error(Some(2_148_916_236)),
            AuthError::XboxAdultVerification
        ));
        assert!(matches!(
            map_xsts_error(Some(2_148_916_237)),
            AuthError::XboxAdultVerification
        ));
        assert!(matches!(
            map_xsts_error(Some(2_148_916_238)),
            AuthError::XboxChildAccount
        ));
        assert!(matches!(map_xsts_error(Some(42)), AuthError::XboxOther(42)));
        assert!(matches!(map_xsts_error(None), AuthError::XboxOther(0)));
    }
}
