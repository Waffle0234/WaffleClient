use crate::Error;

#[derive(Debug, thiserror::Error)]
pub enum AuthError {
    #[error("Microsoft sign-in is not configured (no valid client id)")]
    NotConfigured,
    #[error("no sign-in is in progress")]
    NoPendingFlow,
    #[error("the sign-in code expired")]
    FlowExpired,
    #[error("sign-in was declined on the Microsoft page")]
    FlowDeclined,
    #[error("sign-in was cancelled")]
    FlowCancelled,
    #[error("the refresh token was rejected; the user must sign in again")]
    ReauthRequired,
    #[error("the Microsoft account has no Xbox profile")]
    XboxNoAccount,
    #[error("Xbox is not available in this account's region")]
    XboxRegionBlocked,
    #[error("the account needs adult verification")]
    XboxAdultVerification,
    #[error("the account is a child account that needs a family group")]
    XboxChildAccount,
    #[error("Xbox returned error {0}")]
    XboxOther(u64),
    #[error("Mojang rejected this app registration")]
    AppNotApproved,
    #[error("the account does not own Minecraft: Java Edition")]
    NoGameOwnership,
    #[error("no such account")]
    AccountNotFound,
    #[error("invalid account id")]
    InvalidAccountId,
    #[error("unexpected response from {service}: {detail}")]
    Unexpected {
        service: &'static str,
        detail: String,
    },
}

/// Build an "unexpected response" error. `detail` must never contain a token or body.
pub(crate) fn unexpected(service: &'static str, detail: impl Into<String>) -> Error {
    AuthError::Unexpected {
        service,
        detail: detail.into(),
    }
    .into()
}

impl AuthError {
    pub fn code(&self) -> &'static str {
        match self {
            Self::NotConfigured => "auth_not_configured",
            Self::NoPendingFlow => "auth_no_flow",
            Self::FlowExpired => "auth_expired",
            Self::FlowDeclined => "auth_declined",
            Self::FlowCancelled => "auth_cancelled",
            Self::ReauthRequired => "auth_reauth",
            Self::XboxNoAccount => "xbox_no_account",
            Self::XboxRegionBlocked => "xbox_region",
            Self::XboxAdultVerification => "xbox_adult",
            Self::XboxChildAccount => "xbox_child",
            Self::XboxOther(_) => "xbox_other",
            Self::AppNotApproved => "app_not_approved",
            Self::NoGameOwnership => "no_game",
            Self::AccountNotFound => "account_not_found",
            Self::InvalidAccountId => "invalid_account_id",
            Self::Unexpected { .. } => "auth_unexpected",
        }
    }

    pub fn user_message(&self) -> String {
        match self {
            Self::NotConfigured => "Microsoft sign-in isn't set up in this build of Kiln.".into(),
            Self::NoPendingFlow => "There's no sign-in in progress. Start again.".into(),
            Self::FlowExpired => {
                "The sign-in code expired before it was used. Start again to get a new one.".into()
            }
            Self::FlowDeclined => "Sign-in was cancelled on the Microsoft page.".into(),
            Self::FlowCancelled => "Sign-in was cancelled.".into(),
            Self::ReauthRequired => "Your Microsoft sign-in for this account has expired or was \
                revoked. Sign in again to keep using it."
                .into(),
            Self::XboxNoAccount => "This Microsoft account doesn't have an Xbox profile yet. \
                Sign in once at xbox.com to create one, then try again."
                .into(),
            Self::XboxRegionBlocked => "Xbox services aren't available in the country or region \
                this Microsoft account is set to."
                .into(),
            Self::XboxAdultVerification => "This account needs adult verification on the Xbox \
                site before it can be used for Minecraft."
                .into(),
            Self::XboxChildAccount => "This is a child account. An adult has to add it to a \
                Microsoft family group before it can sign in to Minecraft."
                .into(),
            Self::XboxOther(code) => {
                format!("Xbox refused the sign-in (error {code}). Try again later.")
            }
            Self::AppNotApproved => "Mojang hasn't approved this build's Microsoft app \
                registration, so Minecraft sign-in is refused."
                .into(),
            Self::NoGameOwnership => "This Microsoft account doesn't own Minecraft: Java \
                Edition. Kiln needs a legitimately owned copy for online play."
                .into(),
            Self::AccountNotFound => "That account no longer exists.".into(),
            Self::InvalidAccountId => "That isn't a valid account.".into(),
            Self::Unexpected { .. } => "Microsoft or Mojang sent a response Kiln didn't expect. \
                Try again later."
                .into(),
        }
    }
}
