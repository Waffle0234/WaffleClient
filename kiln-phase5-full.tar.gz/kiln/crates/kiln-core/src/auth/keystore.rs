//! Where refresh tokens live: the operating system's keychain, and nowhere else.
//! (Windows Credential Manager, macOS Keychain, Secret Service on Linux.)
//!
//! Secrets are stored as raw bytes. The string API on Windows stores UTF-16, which would
//! double a ~1.5 KB Microsoft refresh token and risk exceeding Credential Manager's
//! 2,560-byte limit.

use crate::{Error, Result};

pub trait SecretStore: Send + Sync {
    fn set(&self, account_id: &str, secret: &[u8]) -> Result<()>;
    fn get(&self, account_id: &str) -> Result<Option<Vec<u8>>>;
    /// Deleting something that doesn't exist is not an error.
    fn delete(&self, account_id: &str) -> Result<()>;
}

#[derive(Debug, Clone)]
pub struct KeyringStore {
    service: String,
}

impl KeyringStore {
    pub fn new(service: impl Into<String>) -> Self {
        Self {
            service: service.into(),
        }
    }

    fn entry(&self, account_id: &str) -> Result<keyring::Entry> {
        keyring::Entry::new(&self.service, &format!("msa-refresh-token:{account_id}"))
            .map_err(keychain_err)
    }
}

fn keychain_err(e: keyring::Error) -> Error {
    Error::Keychain(e.to_string())
}

impl SecretStore for KeyringStore {
    fn set(&self, account_id: &str, secret: &[u8]) -> Result<()> {
        self.entry(account_id)?
            .set_secret(secret)
            .map_err(keychain_err)
    }

    fn get(&self, account_id: &str) -> Result<Option<Vec<u8>>> {
        match self.entry(account_id)?.get_secret() {
            Ok(v) => Ok(Some(v)),
            Err(keyring::Error::NoEntry) => Ok(None),
            Err(e) => Err(keychain_err(e)),
        }
    }

    fn delete(&self, account_id: &str) -> Result<()> {
        match self.entry(account_id)?.delete_credential() {
            Ok(()) | Err(keyring::Error::NoEntry) => Ok(()),
            Err(e) => Err(keychain_err(e)),
        }
    }
}

/// In-memory store for tests. Deliberately not available outside `cfg(test)`, so a
/// production build can't accidentally keep tokens in an unprotected place.
#[cfg(test)]
#[derive(Default)]
pub struct MemoryStore(std::sync::Mutex<std::collections::HashMap<String, Vec<u8>>>);

#[cfg(test)]
impl MemoryStore {
    pub fn snapshot(&self) -> std::collections::HashMap<String, Vec<u8>> {
        self.0.lock().unwrap().clone()
    }
}

#[cfg(test)]
impl SecretStore for MemoryStore {
    fn set(&self, id: &str, secret: &[u8]) -> Result<()> {
        self.0.lock().unwrap().insert(id.into(), secret.to_vec());
        Ok(())
    }
    fn get(&self, id: &str) -> Result<Option<Vec<u8>>> {
        Ok(self.0.lock().unwrap().get(id).cloned())
    }
    fn delete(&self, id: &str) -> Result<()> {
        self.0.lock().unwrap().remove(id);
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn memory_store_semantics() {
        let s = MemoryStore::default();
        assert_eq!(s.get("a").unwrap(), None);
        s.set("a", b"one").unwrap();
        s.set("a", b"two").unwrap();
        assert_eq!(s.get("a").unwrap().as_deref(), Some(&b"two"[..]));
        s.delete("a").unwrap();
        s.delete("a").unwrap(); // idempotent
        assert_eq!(s.get("a").unwrap(), None);
    }

    /// Round trip against the real OS keychain. Ignored by default because CI runners and
    /// containers often have no unlocked keychain (on Linux it needs a running Secret
    /// Service such as gnome-keyring). Run with `cargo test -- --ignored keyring`.
    #[test]
    #[ignore = "needs an unlocked OS keychain"]
    fn keyring_round_trip_with_a_realistic_token_size() {
        let store = KeyringStore::new(format!("kiln-test-{}", std::process::id()));
        let id = "11111111111111112222222222222222";
        // About the size of a real Microsoft refresh token, and above the 1,280 characters
        // a UTF-16 encoding would allow on Windows.
        let token = "M.C507_BAY.0.U.".to_string() + &"x".repeat(1900);

        store.set(id, token.as_bytes()).unwrap();
        assert_eq!(store.get(id).unwrap().as_deref(), Some(token.as_bytes()));
        store.delete(id).unwrap();
        assert_eq!(store.get(id).unwrap(), None);
        store.delete(id).unwrap();
    }
}
