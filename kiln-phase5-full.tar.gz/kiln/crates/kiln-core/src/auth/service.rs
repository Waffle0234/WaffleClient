use std::collections::HashMap;
use std::sync::{Arc, Mutex, MutexGuard};
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

use serde::Serialize;
use tokio::sync::Notify;

use super::accounts::{self, validate_account_id, Account};
use super::endpoints::{host_policy, Endpoints};
use super::error::{unexpected, AuthError};
use super::keystore::SecretStore;
use super::minecraft::{self, McLogin, Profile};
use super::ms::{self, MsTokens, PollOutcome};
use super::secret::SecretString;
use super::xbox;
use crate::db::Db;
use crate::net::HttpClient;
use crate::{redact, Error, Result, APP_NAME, APP_VERSION};

/// Refresh a cached Minecraft token this long before it expires.
const REFRESH_MARGIN: Duration = Duration::from_secs(300);

/// What the UI needs to show while the user signs in on Microsoft's page. The device code
/// itself stays inside the backend.
#[derive(Debug, Clone, Serialize, PartialEq, Eq)]
pub struct DeviceCodeInfo {
    pub user_code: String,
    pub verification_uri: String,
    pub expires_in: u64,
}

/// Everything the launch pipeline needs to start the game as this player. Deliberately not
/// `Serialize` and never sent over IPC.
#[derive(Clone)]
pub struct LaunchSession {
    pub account_id: String,
    pub username: String,
    pub access_token: SecretString,
}

impl std::fmt::Debug for LaunchSession {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("LaunchSession { .. }")
    }
}

/// Polling pace. Production uses the server's interval and adds [`Timing::slow_down_step`]
/// whenever Microsoft asks us to slow down; tests shrink both.
#[derive(Debug, Clone)]
pub struct Timing {
    pub interval_override: Option<Duration>,
    pub slow_down_step: Duration,
}

impl Default for Timing {
    fn default() -> Self {
        Self {
            interval_override: None,
            slow_down_step: Duration::from_secs(5),
        }
    }
}

struct PendingFlow {
    id: u64,
    device_code: SecretString,
    verification_uri: String,
    expires_at: Instant,
    interval: Duration,
    cancel: Arc<Notify>,
}

#[derive(Default)]
struct Flows {
    next_id: u64,
    current: Option<PendingFlow>,
}

struct CachedSession {
    access_token: SecretString,
    username: String,
    expires_at: Instant,
}

fn lock<T>(m: &Mutex<T>) -> MutexGuard<'_, T> {
    m.lock().unwrap_or_else(|e| e.into_inner())
}

fn now_unix() -> i64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_or(0, |d| i64::try_from(d.as_secs()).unwrap_or(i64::MAX))
}

/// A Microsoft application (client) id is a GUID. Anything else is treated as "not set".
fn valid_client_id(id: &str) -> bool {
    id.len() == 36
        && id.bytes().enumerate().all(|(i, b)| match i {
            8 | 13 | 18 | 23 => b == b'-',
            _ => b.is_ascii_hexdigit(),
        })
}

/// The client id comes from `KILN_MS_CLIENT_ID` at runtime, or was baked in at build time.
pub fn client_id_from_env() -> Option<String> {
    std::env::var("KILN_MS_CLIENT_ID")
        .ok()
        .or_else(|| option_env!("KILN_MS_CLIENT_ID").map(str::to_owned))
        .map(|s| s.trim().to_owned())
        .filter(|s| valid_client_id(s))
}

pub struct AuthService {
    db: Db,
    http: HttpClient,
    keys: Arc<dyn SecretStore>,
    endpoints: Endpoints,
    client_id: Option<String>,
    timing: Timing,
    flows: Mutex<Flows>,
    sessions: Mutex<HashMap<String, CachedSession>>,
    /// Serializes refreshes so two launches can't race a rotating refresh token.
    refresh_lock: tokio::sync::Mutex<()>,
}

impl std::fmt::Debug for AuthService {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("AuthService { .. }")
    }
}

impl AuthService {
    pub fn new(db: Db, keys: Arc<dyn SecretStore>, client_id: Option<String>) -> Result<Self> {
        let http = HttpClient::new(&format!("{APP_NAME}/{APP_VERSION}"), host_policy())?;
        Ok(Self::build(
            db,
            http,
            keys,
            Endpoints::default(),
            client_id,
            Timing::default(),
        ))
    }

    fn build(
        db: Db,
        http: HttpClient,
        keys: Arc<dyn SecretStore>,
        endpoints: Endpoints,
        client_id: Option<String>,
        timing: Timing,
    ) -> Self {
        Self {
            db,
            http,
            keys,
            endpoints,
            client_id: client_id.filter(|id| valid_client_id(id)),
            timing,
            flows: Mutex::new(Flows::default()),
            sessions: Mutex::new(HashMap::new()),
            refresh_lock: tokio::sync::Mutex::new(()),
        }
    }

    /// Register known usernames with the log redactor. Call once at startup.
    pub async fn init(&self) -> Result<()> {
        for account in accounts::list(&self.db).await? {
            redact::global().register_secret(&account.username);
        }
        Ok(())
    }

    fn client_id(&self) -> Result<&str> {
        self.client_id
            .as_deref()
            .ok_or_else(|| AuthError::NotConfigured.into())
    }

    // ---- keychain access (blocking OS calls run off the async runtime) ----

    async fn keys_get(&self, id: &str) -> Result<Option<Vec<u8>>> {
        let (keys, id) = (Arc::clone(&self.keys), id.to_owned());
        tokio::task::spawn_blocking(move || keys.get(&id))
            .await
            .map_err(|e| Error::Keychain(e.to_string()))?
    }

    async fn keys_set(&self, id: &str, secret: &[u8]) -> Result<()> {
        let (keys, id, secret) = (Arc::clone(&self.keys), id.to_owned(), secret.to_vec());
        tokio::task::spawn_blocking(move || keys.set(&id, &secret))
            .await
            .map_err(|e| Error::Keychain(e.to_string()))?
    }

    async fn keys_delete(&self, id: &str) -> Result<()> {
        let (keys, id) = (Arc::clone(&self.keys), id.to_owned());
        tokio::task::spawn_blocking(move || keys.delete(&id))
            .await
            .map_err(|e| Error::Keychain(e.to_string()))?
    }

    // ---- sign-in (device code flow) ----

    /// Ask Microsoft for a code the user enters on their own device or browser.
    pub async fn begin_device_flow(&self) -> Result<DeviceCodeInfo> {
        let client_id = self.client_id()?;
        let code = ms::request_device_code(&self.http, &self.endpoints, client_id).await?;
        let info = DeviceCodeInfo {
            user_code: code.user_code,
            verification_uri: code.verification_uri.clone(),
            expires_in: code.expires_in.as_secs(),
        };

        let mut flows = lock(&self.flows);
        if let Some(old) = flows.current.take() {
            old.cancel.notify_one();
        }
        flows.next_id += 1;
        let id = flows.next_id;
        flows.current = Some(PendingFlow {
            id,
            device_code: code.device_code,
            verification_uri: code.verification_uri,
            expires_at: Instant::now() + code.expires_in,
            interval: code.interval,
            cancel: Arc::new(Notify::new()),
        });
        Ok(info)
    }

    /// The (validated) page where the user enters the code, for the "open in browser" button.
    pub fn pending_verification_uri(&self) -> Option<String> {
        lock(&self.flows)
            .current
            .as_ref()
            .map(|f| f.verification_uri.clone())
    }

    /// Wait for the user to finish signing in, then complete the Xbox and Minecraft steps.
    /// Returns when the flow succeeds, is declined, expires, or is cancelled.
    pub async fn poll(&self) -> Result<Account> {
        let (flow_id, device_code, expires_at, interval, cancel) = {
            let flows = lock(&self.flows);
            let f = flows.current.as_ref().ok_or(AuthError::NoPendingFlow)?;
            (
                f.id,
                f.device_code.clone(),
                f.expires_at,
                f.interval,
                Arc::clone(&f.cancel),
            )
        };
        let result = self
            .poll_loop(&device_code, expires_at, interval, &cancel)
            .await;

        let mut flows = lock(&self.flows);
        if flows.current.as_ref().is_some_and(|f| f.id == flow_id) {
            flows.current = None;
        }
        result
    }

    async fn poll_loop(
        &self,
        device_code: &SecretString,
        expires_at: Instant,
        interval: Duration,
        cancel: &Notify,
    ) -> Result<Account> {
        let client_id = self.client_id()?;
        let mut extra = Duration::ZERO;
        loop {
            let wait = self.timing.interval_override.unwrap_or(interval) + extra;
            tokio::select! {
                () = cancel.notified() => return Err(AuthError::FlowCancelled.into()),
                () = tokio::time::sleep(wait) => {}
            }
            if Instant::now() >= expires_at {
                return Err(AuthError::FlowExpired.into());
            }
            match ms::poll_token(&self.http, &self.endpoints, client_id, device_code).await? {
                PollOutcome::Tokens(tokens) => return self.finish_sign_in(tokens).await,
                PollOutcome::Pending => {}
                PollOutcome::SlowDown => extra += self.timing.slow_down_step,
            }
        }
    }

    /// Abandon the sign-in in progress, if any.
    pub fn cancel_flow(&self) {
        if let Some(flow) = lock(&self.flows).current.take() {
            flow.cancel.notify_one();
        }
    }

    async fn minecraft_login(&self, ms_access: &SecretString) -> Result<(McLogin, Profile)> {
        let xbl = xbox::authenticate(&self.http, &self.endpoints, ms_access).await?;
        let xsts = xbox::authorize_xsts(&self.http, &self.endpoints, &xbl).await?;
        let login = minecraft::login_with_xbox(&self.http, &self.endpoints, &xsts).await?;
        let profile =
            minecraft::fetch_profile(&self.http, &self.endpoints, &login.access_token).await?;
        Ok((login, profile))
    }

    fn cache_session(&self, profile: &Profile, login: &McLogin) {
        redact::global().register_secret(&profile.name);
        lock(&self.sessions).insert(
            profile.id.clone(),
            CachedSession {
                access_token: login.access_token.clone(),
                username: profile.name.clone(),
                expires_at: Instant::now() + login.expires_in,
            },
        );
    }

    async fn finish_sign_in(&self, tokens: MsTokens) -> Result<Account> {
        let refresh = tokens
            .refresh_token
            .ok_or_else(|| unexpected("Microsoft", "no refresh token was issued"))?;
        // Ownership is checked here: a missing profile aborts before anything is stored.
        let (login, profile) = self.minecraft_login(&tokens.access_token).await?;

        // Keychain first: if it fails, no account row is created.
        self.keys_set(&profile.id, refresh.expose().as_bytes())
            .await?;
        let account = accounts::upsert_signed_in(&self.db, &profile, now_unix()).await?;
        self.cache_session(&profile, &login);
        tracing::info!("signed in to a Minecraft account");
        Ok(account)
    }

    // ---- sessions for launching ----

    fn cached(&self, id: &str) -> Option<LaunchSession> {
        let sessions = lock(&self.sessions);
        let s = sessions.get(id)?;
        (s.expires_at > Instant::now() + REFRESH_MARGIN).then(|| LaunchSession {
            account_id: id.to_owned(),
            username: s.username.clone(),
            access_token: s.access_token.clone(),
        })
    }

    /// A valid Minecraft session for this account, refreshing through Microsoft if the
    /// cached one is missing or about to expire. Only the launch pipeline calls this.
    pub async fn session_for_launch(&self, account_id: &str) -> Result<LaunchSession> {
        validate_account_id(account_id)?;
        if let Some(session) = self.cached(account_id) {
            return Ok(session);
        }
        let _guard = self.refresh_lock.lock().await;
        // Another task may have refreshed while we waited.
        if let Some(session) = self.cached(account_id) {
            return Ok(session);
        }
        self.refresh_account(account_id).await
    }

    async fn refresh_account(&self, id: &str) -> Result<LaunchSession> {
        let client_id = self.client_id()?;
        if accounts::get(&self.db, id).await?.is_none() {
            return Err(AuthError::AccountNotFound.into());
        }
        let stored = self
            .keys_get(id)
            .await?
            .and_then(|raw| String::from_utf8(raw).ok());
        let Some(stored) = stored else {
            accounts::mark_needs_reauth(&self.db, id).await?;
            return Err(AuthError::ReauthRequired.into());
        };

        let tokens = match ms::refresh(
            &self.http,
            &self.endpoints,
            client_id,
            &SecretString::new(stored),
        )
        .await
        {
            Ok(tokens) => tokens,
            Err(e @ Error::Auth(AuthError::ReauthRequired)) => {
                accounts::mark_needs_reauth(&self.db, id).await?;
                return Err(e);
            }
            Err(e) => return Err(e),
        };
        if let Some(rotated) = &tokens.refresh_token {
            self.keys_set(id, rotated.expose().as_bytes()).await?;
        }

        let (login, profile) = self.minecraft_login(&tokens.access_token).await?;
        if profile.id != id {
            return Err(unexpected(
                "Minecraft",
                "the refreshed profile belongs to a different account",
            ));
        }
        accounts::update_profile(&self.db, &profile).await?;
        self.cache_session(&profile, &login);
        Ok(LaunchSession {
            account_id: id.to_owned(),
            username: profile.name,
            access_token: login.access_token,
        })
    }

    // ---- account management ----

    pub async fn list_accounts(&self) -> Result<Vec<Account>> {
        accounts::list(&self.db).await
    }

    pub async fn set_active(&self, id: &str) -> Result<Account> {
        validate_account_id(id)?;
        accounts::set_active(&self.db, id, now_unix()).await
    }

    /// Remove an account and its stored sign-in. The keychain entry goes first: if that
    /// fails the account stays listed so the user can retry, instead of leaving an
    /// orphaned secret behind.
    pub async fn remove_account(&self, id: &str) -> Result<()> {
        validate_account_id(id)?;
        if accounts::get(&self.db, id).await?.is_none() {
            return Err(AuthError::AccountNotFound.into());
        }
        self.keys_delete(id).await?;
        accounts::remove(&self.db, id).await?;
        lock(&self.sessions).remove(id);
        Ok(())
    }
}

#[cfg(test)]
impl AuthService {
    fn for_tests(
        db: Db,
        keys: Arc<dyn SecretStore>,
        base_url: &str,
        client_id: Option<&str>,
    ) -> Self {
        use crate::net::HostPolicy;
        let http =
            HttpClient::new("Kiln-test/0", HostPolicy::new(&[]).with_loopback_http()).unwrap();
        Self::build(
            db,
            http,
            keys,
            Endpoints::with_base(base_url),
            client_id.map(str::to_owned),
            Timing {
                interval_override: Some(Duration::from_millis(5)),
                slow_down_step: Duration::from_millis(10),
            },
        )
    }
}

#[cfg(test)]
mod tests {
    use std::io::Write;

    use serde_json::json;
    use tracing_subscriber::fmt::MakeWriter;
    use wiremock::matchers::{body_string_contains, header, method, path};
    use wiremock::{Mock, MockServer, ResponseTemplate};

    use super::*;
    use crate::auth::keystore::MemoryStore;
    use crate::db;

    const CLIENT_ID: &str = "00000000-1111-2222-3333-444444444444";
    const DEVICE_CODE: &str = "DEVICECODE-SECRET-123456";
    const MS_ACCESS: &str = "MS-ACCESS-TOKEN-SECRET";
    const REFRESH_1: &str = "REFRESH-TOKEN-SECRET-1";
    const REFRESH_2: &str = "REFRESH-TOKEN-SECRET-2";
    const XBL: &str = "XBL-TOKEN-SECRET-abcdef";
    const XSTS: &str = "XSTS-TOKEN-SECRET-abcdef";
    const MC: &str = "MC-ACCESS-TOKEN-SECRET-xyz";
    const PLAYER_ID: &str = "069a79f44e9d4e9cb12bd4a2bb7d6fd4";
    const PLAYER_NAME: &str = "Steve_Test";
    const SECRETS: [&str; 7] = [DEVICE_CODE, MS_ACCESS, REFRESH_1, REFRESH_2, XBL, XSTS, MC];

    fn skin_hash() -> String {
        "0123456789abcdef".repeat(4)
    }

    struct Harness {
        svc: Arc<AuthService>,
        server: MockServer,
        keys: Arc<MemoryStore>,
        db: Db,
    }

    impl Harness {
        async fn new() -> Self {
            Self::with_db(db::open_in_memory().await.unwrap()).await
        }

        async fn with_db(db: Db) -> Self {
            let server = MockServer::start().await;
            let keys = Arc::new(MemoryStore::default());
            let svc = Arc::new(AuthService::for_tests(
                db.clone(),
                keys.clone(),
                &server.uri(),
                Some(CLIENT_ID),
            ));
            Self {
                svc,
                server,
                keys,
                db,
            }
        }

        async fn mount_device_start(&self, verification_uri: &str) {
            Mock::given(method("POST"))
                .and(path("/devicecode"))
                .and(body_string_contains(CLIENT_ID))
                .respond_with(ResponseTemplate::new(200).set_body_json(json!({
                    "device_code": DEVICE_CODE,
                    "user_code": "ABCD1234",
                    "verification_uri": verification_uri,
                    "expires_in": 900,
                    "interval": 5,
                })))
                .mount(&self.server)
                .await;
        }

        async fn mount_device_token_error(&self, error: &str, times: Option<u64>, priority: u8) {
            let mock = Mock::given(method("POST"))
                .and(path("/token"))
                .and(body_string_contains(format!("device_code={DEVICE_CODE}")))
                .respond_with(ResponseTemplate::new(400).set_body_json(json!({ "error": error })))
                .with_priority(priority);
            match times {
                Some(n) => mock.up_to_n_times(n).mount(&self.server).await,
                None => mock.mount(&self.server).await,
            }
        }

        async fn mount_device_token_success(&self, priority: u8) {
            Mock::given(method("POST"))
                .and(path("/token"))
                .and(body_string_contains(format!("device_code={DEVICE_CODE}")))
                .respond_with(ResponseTemplate::new(200).set_body_json(json!({
                    "access_token": MS_ACCESS, "refresh_token": REFRESH_1, "expires_in": 3600,
                })))
                .with_priority(priority)
                .mount(&self.server)
                .await;
        }

        async fn mount_chain(&self) {
            Mock::given(method("POST"))
                .and(path("/xbl"))
                .and(body_string_contains(format!("d={MS_ACCESS}")))
                .respond_with(ResponseTemplate::new(200).set_body_json(
                    json!({"Token": XBL, "DisplayClaims": {"xui": [{"uhs": "1234567890"}]}}),
                ))
                .mount(&self.server)
                .await;
            self.mount_xsts_ok().await;
            Mock::given(method("POST"))
                .and(path("/mclogin"))
                .and(body_string_contains(format!("XBL3.0 x=1234567890;{XSTS}")))
                .respond_with(ResponseTemplate::new(200).set_body_json(
                    json!({"access_token": MC, "expires_in": 86400, "token_type": "Bearer"}),
                ))
                .mount(&self.server)
                .await;
            self.mount_profile(PLAYER_NAME).await;
        }

        async fn mount_xsts_ok(&self) {
            Mock::given(method("POST"))
                .and(path("/xsts"))
                .and(body_string_contains(XBL))
                .respond_with(ResponseTemplate::new(200).set_body_json(
                    json!({"Token": XSTS, "DisplayClaims": {"xui": [{"uhs": "1234567890"}]}}),
                ))
                .mount(&self.server)
                .await;
        }

        async fn mount_profile(&self, name: &str) {
            Mock::given(method("GET"))
                .and(path("/profile"))
                .and(header("authorization", format!("Bearer {MC}").as_str()))
                .respond_with(ResponseTemplate::new(200).set_body_json(json!({
                    "id": PLAYER_ID,
                    "name": name,
                    "skins": [{"state": "ACTIVE", "variant": "SLIM",
                               "url": format!("http://textures.minecraft.net/texture/{}", skin_hash())}],
                    "capes": [],
                })))
                .mount(&self.server)
                .await;
        }

        async fn mount_happy_path(&self) {
            self.mount_device_start("https://www.microsoft.com/link")
                .await;
            self.mount_device_token_error("authorization_pending", Some(2), 1)
                .await;
            self.mount_device_token_success(2).await;
            self.mount_chain().await;
        }

        async fn sign_in(&self) -> Result<Account> {
            self.svc.begin_device_flow().await?;
            self.svc.poll().await
        }

        async fn count(&self, p: &str, needle: &str) -> usize {
            self.server
                .received_requests()
                .await
                .unwrap()
                .iter()
                .filter(|r| r.url.path() == p && String::from_utf8_lossy(&r.body).contains(needle))
                .count()
        }
    }

    #[derive(Clone, Default)]
    struct LogBuf(Arc<Mutex<Vec<u8>>>);

    impl Write for LogBuf {
        fn write(&mut self, data: &[u8]) -> std::io::Result<usize> {
            self.0.lock().unwrap().extend_from_slice(data);
            Ok(data.len())
        }
        fn flush(&mut self) -> std::io::Result<()> {
            Ok(())
        }
    }

    impl<'a> MakeWriter<'a> for LogBuf {
        type Writer = LogBuf;
        fn make_writer(&'a self) -> LogBuf {
            self.clone()
        }
    }

    /// Capture every event from every crate at TRACE, with NO redaction, so tests prove the
    /// code never emits a secret rather than relying on the redactor to hide it.
    fn capture_logs() -> (tracing::subscriber::DefaultGuard, LogBuf) {
        let buf = LogBuf::default();
        let subscriber = tracing_subscriber::fmt()
            .with_ansi(false)
            .with_max_level(tracing::Level::TRACE)
            .with_writer(buf.clone())
            .finish();
        (tracing::subscriber::set_default(subscriber), buf)
    }

    fn contains(haystack: &[u8], needle: &[u8]) -> bool {
        haystack.windows(needle.len()).any(|w| w == needle)
    }

    #[tokio::test]
    async fn sign_in_stores_the_refresh_token_only_in_the_keychain_and_never_logs_secrets() {
        let (_guard, logs) = capture_logs();
        let dir = tempfile::tempdir().unwrap();
        let db = db::open(&dir.path().join("kiln.sqlite")).await.unwrap();
        let h = Harness::with_db(db).await;
        h.mount_happy_path().await;

        let account = h.sign_in().await.unwrap();
        assert_eq!(account.id, PLAYER_ID);
        assert_eq!(account.username, PLAYER_NAME);
        assert!(account.is_active && !account.needs_reauth);
        assert_eq!(
            account.skin_url.as_deref(),
            Some(format!("https://textures.minecraft.net/texture/{}", skin_hash()).as_str())
        );

        // The refresh token is in the keychain, byte for byte.
        let stored = h.keys.snapshot();
        assert_eq!(
            stored.get(PLAYER_ID).map(Vec::as_slice),
            Some(REFRESH_1.as_bytes())
        );
        assert_eq!(stored.len(), 1);

        // No token appears anywhere in the database files.
        h.db.close().await;
        let mut db_bytes = Vec::new();
        for entry in std::fs::read_dir(dir.path()).unwrap() {
            db_bytes.extend(std::fs::read(entry.unwrap().path()).unwrap());
        }
        for secret in SECRETS {
            assert!(
                !contains(&db_bytes, secret.as_bytes()),
                "{secret} found in database files"
            );
        }

        // No token (and no username) appears in raw, unredacted logs.
        let logs = String::from_utf8(logs.0.lock().unwrap().clone()).unwrap();
        assert!(
            logs.contains("signed in"),
            "log capture is not working: {logs}"
        );
        for secret in SECRETS.iter().copied().chain([PLAYER_NAME]) {
            assert!(!logs.contains(secret), "{secret} found in logs:\n{logs}");
        }
    }

    #[tokio::test]
    async fn polling_survives_pending_and_slow_down() {
        let h = Harness::new().await;
        h.mount_device_start("https://www.microsoft.com/link").await;
        h.mount_device_token_error("slow_down", Some(1), 1).await;
        h.mount_device_token_error("authorization_pending", Some(1), 2)
            .await;
        h.mount_device_token_success(3).await;
        h.mount_chain().await;

        h.sign_in().await.unwrap();
        assert_eq!(h.count("/token", "device_code=").await, 3);
    }

    #[tokio::test]
    async fn declined_and_expired_codes_report_specific_errors() {
        for (server_error, expect_declined) in
            [("authorization_declined", true), ("expired_token", false)]
        {
            let h = Harness::new().await;
            h.mount_device_start("https://www.microsoft.com/link").await;
            h.mount_device_token_error(server_error, None, 1).await;
            let err = h.sign_in().await.unwrap_err();
            if expect_declined {
                assert!(
                    matches!(err, Error::Auth(AuthError::FlowDeclined)),
                    "{err:?}"
                );
            } else {
                assert!(
                    matches!(err, Error::Auth(AuthError::FlowExpired)),
                    "{err:?}"
                );
            }
            assert!(h.svc.list_accounts().await.unwrap().is_empty());
        }
    }

    #[tokio::test]
    async fn cancelling_stops_the_poll_and_clears_the_flow() {
        let h = Harness::new().await;
        h.mount_device_start("https://www.microsoft.com/link").await;
        h.mount_device_token_error("authorization_pending", None, 1)
            .await;
        h.svc.begin_device_flow().await.unwrap();
        assert_eq!(
            h.svc.pending_verification_uri().as_deref(),
            Some("https://www.microsoft.com/link")
        );

        let poller = tokio::spawn({
            let svc = Arc::clone(&h.svc);
            async move { svc.poll().await }
        });
        tokio::time::sleep(Duration::from_millis(30)).await;
        h.svc.cancel_flow();

        let result = tokio::time::timeout(Duration::from_secs(5), poller)
            .await
            .unwrap()
            .unwrap();
        assert!(matches!(result, Err(Error::Auth(AuthError::FlowCancelled))));
        assert!(h.svc.pending_verification_uri().is_none());
        assert!(matches!(
            h.svc.poll().await,
            Err(Error::Auth(AuthError::NoPendingFlow))
        ));
    }

    #[tokio::test]
    async fn starting_a_new_flow_cancels_the_old_one() {
        let h = Harness::new().await;
        h.mount_device_start("https://www.microsoft.com/link").await;
        h.mount_device_token_error("authorization_pending", None, 1)
            .await;
        h.svc.begin_device_flow().await.unwrap();
        let first = tokio::spawn({
            let svc = Arc::clone(&h.svc);
            async move { svc.poll().await }
        });
        tokio::time::sleep(Duration::from_millis(20)).await;
        h.svc.begin_device_flow().await.unwrap();

        let result = tokio::time::timeout(Duration::from_secs(5), first)
            .await
            .unwrap()
            .unwrap();
        assert!(matches!(result, Err(Error::Auth(AuthError::FlowCancelled))));
        // The newer flow is still pending.
        assert!(h.svc.pending_verification_uri().is_some());
    }

    #[tokio::test]
    async fn unconfigured_builds_say_so() {
        let server = MockServer::start().await;
        let db = db::open_in_memory().await.unwrap();
        for id in [None, Some("not-a-guid"), Some("")] {
            let svc = AuthService::for_tests(
                db.clone(),
                Arc::new(MemoryStore::default()),
                &server.uri(),
                id,
            );
            let err = svc.begin_device_flow().await.unwrap_err();
            assert!(
                matches!(err, Error::Auth(AuthError::NotConfigured)),
                "{id:?}: {err:?}"
            );
        }
        assert!(server.received_requests().await.unwrap().is_empty());
    }

    #[test]
    fn client_id_must_be_a_guid() {
        assert!(valid_client_id(CLIENT_ID));
        assert!(valid_client_id("AAAAAAAA-BBBB-CCCC-DDDD-EEEEEEEEEEEE"));
        for bad in [
            "",
            "abc",
            "00000000111122223333444444444444",
            "0000000g-1111-2222-3333-444444444444",
            "00000000-1111-2222-3333-4444444444444",
        ] {
            assert!(!valid_client_id(bad), "accepted {bad:?}");
        }
    }

    #[tokio::test]
    async fn a_verification_address_outside_microsoft_is_refused() {
        let h = Harness::new().await;
        h.mount_device_start("https://evil.example/login").await;
        let err = h.svc.begin_device_flow().await.unwrap_err();
        assert!(
            matches!(err, Error::Auth(AuthError::Unexpected { .. })),
            "{err:?}"
        );
        assert!(h.svc.pending_verification_uri().is_none());
    }

    #[tokio::test]
    async fn xsts_failures_map_to_plain_explanations() {
        type Check = fn(&AuthError) -> bool;
        let cases: [(u64, Check); 4] = [
            (2_148_916_233, |e| matches!(e, AuthError::XboxNoAccount)),
            (2_148_916_235, |e| matches!(e, AuthError::XboxRegionBlocked)),
            (2_148_916_236, |e| {
                matches!(e, AuthError::XboxAdultVerification)
            }),
            (2_148_916_238, |e| matches!(e, AuthError::XboxChildAccount)),
        ];
        for (code, is_expected) in cases {
            let h = Harness::new().await;
            h.mount_device_start("https://www.microsoft.com/link").await;
            h.mount_device_token_success(1).await;
            Mock::given(method("POST"))
                .and(path("/xbl"))
                .respond_with(ResponseTemplate::new(200).set_body_json(
                    json!({"Token": XBL, "DisplayClaims": {"xui": [{"uhs": "1234567890"}]}}),
                ))
                .mount(&h.server)
                .await;
            Mock::given(method("POST"))
                .and(path("/xsts"))
                .respond_with(
                    ResponseTemplate::new(401).set_body_json(json!({"XErr": code, "Message": ""})),
                )
                .mount(&h.server)
                .await;

            match h.sign_in().await.unwrap_err() {
                Error::Auth(e) => assert!(is_expected(&e), "{code}: {e:?}"),
                other => panic!("{code}: {other:?}"),
            }
            assert!(h.keys.snapshot().is_empty());
        }
    }

    #[tokio::test]
    async fn accounts_without_minecraft_are_rejected_and_nothing_is_stored() {
        let h = Harness::new().await;
        h.mount_device_start("https://www.microsoft.com/link").await;
        h.mount_device_token_success(1).await;
        h.mount_chain().await;
        // Replace the profile with a 404 ("no game"): wiremock matches the newest mock first.
        Mock::given(method("GET"))
            .and(path("/profile"))
            .respond_with(ResponseTemplate::new(404).set_body_json(json!({"error": "NOT_FOUND"})))
            .with_priority(1)
            .mount(&h.server)
            .await;

        let err = h.sign_in().await.unwrap_err();
        assert!(
            matches!(err, Error::Auth(AuthError::NoGameOwnership)),
            "{err:?}"
        );
        assert!(h.svc.list_accounts().await.unwrap().is_empty());
        assert!(
            h.keys.snapshot().is_empty(),
            "nothing may reach the keychain without ownership"
        );
    }

    #[tokio::test]
    async fn an_unapproved_app_registration_is_reported_clearly() {
        let h = Harness::new().await;
        h.mount_device_start("https://www.microsoft.com/link").await;
        h.mount_device_token_success(1).await;
        h.mount_chain().await;
        Mock::given(method("POST"))
            .and(path("/mclogin"))
            .respond_with(ResponseTemplate::new(403).set_body_json(json!({
                "errorMessage": "Invalid app registration, see https://aka.ms/AppRegInfo"
            })))
            .with_priority(1)
            .mount(&h.server)
            .await;

        let err = h.sign_in().await.unwrap_err();
        assert!(
            matches!(err, Error::Auth(AuthError::AppNotApproved)),
            "{err:?}"
        );
    }

    #[tokio::test]
    async fn launch_sessions_are_cached_then_refreshed_and_the_rotated_token_is_stored() {
        let h = Harness::new().await;
        h.mount_happy_path().await;
        h.sign_in().await.unwrap();

        // Fresh cache: no refresh call is made.
        let s = h.svc.session_for_launch(PLAYER_ID).await.unwrap();
        assert_eq!(s.access_token.expose(), MC);
        assert_eq!(s.username, PLAYER_NAME);
        assert_eq!(h.count("/token", "grant_type=refresh_token").await, 0);
        assert!(!format!("{s:?}").contains(MC));

        // Expire the cache; Microsoft rotates the refresh token and the player renamed.
        lock(&h.svc.sessions).clear();
        Mock::given(method("POST"))
            .and(path("/token"))
            .and(body_string_contains(format!("refresh_token={REFRESH_1}")))
            .respond_with(ResponseTemplate::new(200).set_body_json(json!({
                "access_token": MS_ACCESS, "refresh_token": REFRESH_2, "expires_in": 3600,
            })))
            .mount(&h.server)
            .await;
        h.mount_profile("Steve_Renamed").await;
        Mock::given(method("GET"))
            .and(path("/profile"))
            .respond_with(ResponseTemplate::new(200).set_body_json(json!({
                "id": PLAYER_ID, "name": "Steve_Renamed", "skins": [], "capes": [],
            })))
            .with_priority(1)
            .mount(&h.server)
            .await;

        let s = h.svc.session_for_launch(PLAYER_ID).await.unwrap();
        assert_eq!(s.username, "Steve_Renamed");
        assert_eq!(h.count("/token", "grant_type=refresh_token").await, 1);
        assert_eq!(
            h.keys.snapshot().get(PLAYER_ID).map(Vec::as_slice),
            Some(REFRESH_2.as_bytes())
        );
        assert_eq!(
            h.svc.list_accounts().await.unwrap()[0].username,
            "Steve_Renamed"
        );
    }

    #[tokio::test]
    async fn a_revoked_refresh_token_flags_the_account_but_keeps_it() {
        let h = Harness::new().await;
        h.mount_happy_path().await;
        h.sign_in().await.unwrap();
        lock(&h.svc.sessions).clear();
        Mock::given(method("POST"))
            .and(path("/token"))
            .and(body_string_contains("grant_type=refresh_token"))
            .respond_with(
                ResponseTemplate::new(400).set_body_json(json!({"error": "invalid_grant"})),
            )
            .mount(&h.server)
            .await;

        let err = h.svc.session_for_launch(PLAYER_ID).await.unwrap_err();
        assert!(
            matches!(err, Error::Auth(AuthError::ReauthRequired)),
            "{err:?}"
        );
        let accounts = h.svc.list_accounts().await.unwrap();
        assert_eq!(accounts.len(), 1);
        assert!(accounts[0].needs_reauth);
    }

    #[tokio::test]
    async fn a_missing_keychain_entry_requires_signing_in_again() {
        let h = Harness::new().await;
        h.mount_happy_path().await;
        h.sign_in().await.unwrap();
        lock(&h.svc.sessions).clear();
        h.keys.delete(PLAYER_ID).unwrap(); // e.g. the user wiped their keychain

        let err = h.svc.session_for_launch(PLAYER_ID).await.unwrap_err();
        assert!(
            matches!(err, Error::Auth(AuthError::ReauthRequired)),
            "{err:?}"
        );
        assert!(h.svc.list_accounts().await.unwrap()[0].needs_reauth);
        assert_eq!(
            h.count("/token", "grant_type=refresh_token").await,
            0,
            "no network call without a token"
        );
    }

    struct BrokenKeychain;

    impl SecretStore for BrokenKeychain {
        fn set(&self, _: &str, _: &[u8]) -> Result<()> {
            Err(Error::Keychain("locked".into()))
        }
        fn get(&self, _: &str) -> Result<Option<Vec<u8>>> {
            Err(Error::Keychain("locked".into()))
        }
        fn delete(&self, _: &str) -> Result<()> {
            Err(Error::Keychain("locked".into()))
        }
    }

    #[tokio::test]
    async fn if_the_keychain_fails_no_account_is_created() {
        let server = MockServer::start().await;
        let db = db::open_in_memory().await.unwrap();
        let svc =
            AuthService::for_tests(db, Arc::new(BrokenKeychain), &server.uri(), Some(CLIENT_ID));
        let h = Harness {
            svc: Arc::new(svc),
            server,
            keys: Arc::new(MemoryStore::default()),
            db: db::open_in_memory().await.unwrap(),
        };
        h.mount_happy_path().await;

        let err = h.sign_in().await.unwrap_err();
        assert!(matches!(err, Error::Keychain(_)), "{err:?}");
        assert!(h.svc.list_accounts().await.unwrap().is_empty());
    }

    #[tokio::test]
    async fn removing_an_account_deletes_its_keychain_entry_and_promotes_another() {
        let h = Harness::new().await;
        let (a, b) = ("a".repeat(32), "b".repeat(32));
        for (id, name, t) in [(&a, "Alex", 100), (&b, "Bea", 200)] {
            let profile = Profile {
                id: id.clone(),
                name: name.into(),
                skin_hash: None,
                skin_variant: None,
                cape_hash: None,
            };
            accounts::upsert_signed_in(&h.db, &profile, t)
                .await
                .unwrap();
            h.keys.set(id, b"token").unwrap();
        }

        h.svc.remove_account(&b).await.unwrap();
        assert!(!h.keys.snapshot().contains_key(&b));
        assert!(h.keys.snapshot().contains_key(&a));
        let remaining = h.svc.list_accounts().await.unwrap();
        assert_eq!(remaining.len(), 1);
        assert!(remaining[0].is_active, "the remaining account is promoted");

        assert!(matches!(
            h.svc.remove_account(&b).await,
            Err(Error::Auth(AuthError::AccountNotFound))
        ));
        assert!(matches!(
            h.svc.remove_account("../etc").await,
            Err(Error::Auth(AuthError::InvalidAccountId))
        ));
        assert!(matches!(
            h.svc.set_active("nope").await,
            Err(Error::Auth(AuthError::InvalidAccountId))
        ));
        assert!(matches!(
            h.svc.session_for_launch("nope").await,
            Err(Error::Auth(AuthError::InvalidAccountId))
        ));
    }

    #[tokio::test]
    async fn if_the_keychain_cannot_delete_the_account_stays_listed() {
        let server = MockServer::start().await;
        let db = db::open_in_memory().await.unwrap();
        let id = "c".repeat(32);
        let profile = Profile {
            id: id.clone(),
            name: "Cy".into(),
            skin_hash: None,
            skin_variant: None,
            cape_hash: None,
        };
        accounts::upsert_signed_in(&db, &profile, 1).await.unwrap();
        let svc =
            AuthService::for_tests(db, Arc::new(BrokenKeychain), &server.uri(), Some(CLIENT_ID));

        assert!(matches!(
            svc.remove_account(&id).await,
            Err(Error::Keychain(_))
        ));
        assert_eq!(svc.list_accounts().await.unwrap().len(), 1);
    }
}
