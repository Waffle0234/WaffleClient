//! Non-secret account metadata in SQLite. Tokens never touch this table.

use serde::Serialize;
use sqlx::FromRow;

use super::error::AuthError;
use super::minecraft::Profile;
use crate::db::Db;
use crate::Result;

pub const TEXTURE_BASE: &str = "https://textures.minecraft.net/texture/";

pub fn texture_url(hash: &str) -> String {
    format!("{TEXTURE_BASE}{hash}")
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all = "lowercase")]
pub enum SkinVariant {
    Classic,
    Slim,
}

impl SkinVariant {
    pub fn parse(s: &str) -> Option<Self> {
        match s.to_ascii_lowercase().as_str() {
            "classic" => Some(Self::Classic),
            "slim" => Some(Self::Slim),
            _ => None,
        }
    }

    fn as_str(self) -> &'static str {
        match self {
            Self::Classic => "classic",
            Self::Slim => "slim",
        }
    }
}

/// Accounts are identified by the Minecraft player UUID: 32 lowercase hex characters.
pub fn is_valid_account_id(id: &str) -> bool {
    id.len() == 32 && id.bytes().all(|b| matches!(b, b'0'..=b'9' | b'a'..=b'f'))
}

pub fn validate_account_id(id: &str) -> Result<()> {
    if is_valid_account_id(id) {
        Ok(())
    } else {
        Err(AuthError::InvalidAccountId.into())
    }
}

#[derive(Debug, Clone, Serialize, PartialEq, Eq)]
pub struct Account {
    pub id: String,
    pub username: String,
    pub skin_url: Option<String>,
    pub skin_variant: Option<SkinVariant>,
    pub cape_url: Option<String>,
    pub last_used: Option<i64>,
    pub is_active: bool,
    /// The Microsoft sign-in was revoked or expired: the account must be signed in again.
    pub needs_reauth: bool,
}

#[derive(FromRow)]
struct Row {
    id: String,
    username: String,
    skin_hash: Option<String>,
    skin_variant: Option<String>,
    cape_hash: Option<String>,
    last_used: Option<i64>,
    is_active: i64,
    needs_reauth: i64,
}

impl From<Row> for Account {
    fn from(r: Row) -> Self {
        Self {
            id: r.id,
            username: r.username,
            skin_url: r.skin_hash.as_deref().map(texture_url),
            skin_variant: r.skin_variant.as_deref().and_then(SkinVariant::parse),
            cape_url: r.cape_hash.as_deref().map(texture_url),
            last_used: r.last_used,
            is_active: r.is_active != 0,
            needs_reauth: r.needs_reauth != 0,
        }
    }
}

const COLUMNS: &str =
    "id, username, skin_hash, skin_variant, cape_hash, last_used, is_active, needs_reauth";

pub async fn list(db: &Db) -> Result<Vec<Account>> {
    let rows: Vec<Row> = sqlx::query_as(&format!(
        "SELECT {COLUMNS} FROM accounts ORDER BY is_active DESC, last_used DESC, username COLLATE NOCASE"
    ))
    .fetch_all(db)
    .await?;
    Ok(rows.into_iter().map(Account::from).collect())
}

pub async fn get(db: &Db, id: &str) -> Result<Option<Account>> {
    let row: Option<Row> = sqlx::query_as(&format!("SELECT {COLUMNS} FROM accounts WHERE id = ?1"))
        .bind(id)
        .fetch_optional(db)
        .await?;
    Ok(row.map(Account::from))
}

/// Insert or update a freshly signed-in account and make it the active one.
pub async fn upsert_signed_in(db: &Db, p: &Profile, now: i64) -> Result<Account> {
    let mut tx = db.begin().await?;
    sqlx::query("UPDATE accounts SET is_active = 0 WHERE is_active = 1")
        .execute(&mut *tx)
        .await?;
    sqlx::query(
        "INSERT INTO accounts (id, username, skin_hash, skin_variant, cape_hash, last_used, is_active, needs_reauth) \
         VALUES (?1, ?2, ?3, ?4, ?5, ?6, 1, 0) \
         ON CONFLICT (id) DO UPDATE SET username = excluded.username, skin_hash = excluded.skin_hash, \
           skin_variant = excluded.skin_variant, cape_hash = excluded.cape_hash, \
           last_used = excluded.last_used, is_active = 1, needs_reauth = 0",
    )
    .bind(&p.id)
    .bind(&p.name)
    .bind(&p.skin_hash)
    .bind(p.skin_variant.map(SkinVariant::as_str))
    .bind(&p.cape_hash)
    .bind(now)
    .execute(&mut *tx)
    .await?;
    tx.commit().await?;
    get(db, &p.id)
        .await?
        .ok_or_else(|| AuthError::AccountNotFound.into())
}

/// Refresh profile details after a token refresh (the player may have renamed or changed
/// skin). Keeps the active flag; clears `needs_reauth`.
pub async fn update_profile(db: &Db, p: &Profile) -> Result<()> {
    sqlx::query(
        "UPDATE accounts SET username = ?2, skin_hash = ?3, skin_variant = ?4, cape_hash = ?5, needs_reauth = 0 \
         WHERE id = ?1",
    )
    .bind(&p.id)
    .bind(&p.name)
    .bind(&p.skin_hash)
    .bind(p.skin_variant.map(SkinVariant::as_str))
    .bind(&p.cape_hash)
    .execute(db)
    .await?;
    Ok(())
}

pub async fn mark_needs_reauth(db: &Db, id: &str) -> Result<()> {
    sqlx::query("UPDATE accounts SET needs_reauth = 1 WHERE id = ?1")
        .bind(id)
        .execute(db)
        .await?;
    Ok(())
}

pub async fn set_active(db: &Db, id: &str, now: i64) -> Result<Account> {
    let mut tx = db.begin().await?;
    let exists: Option<(i64,)> = sqlx::query_as("SELECT 1 FROM accounts WHERE id = ?1")
        .bind(id)
        .fetch_optional(&mut *tx)
        .await?;
    if exists.is_none() {
        return Err(AuthError::AccountNotFound.into());
    }
    sqlx::query("UPDATE accounts SET is_active = 0 WHERE is_active = 1")
        .execute(&mut *tx)
        .await?;
    sqlx::query("UPDATE accounts SET is_active = 1, last_used = ?2 WHERE id = ?1")
        .bind(id)
        .bind(now)
        .execute(&mut *tx)
        .await?;
    tx.commit().await?;
    get(db, id)
        .await?
        .ok_or_else(|| AuthError::AccountNotFound.into())
}

/// Delete an account row. If it was the active one, the most recently used remaining
/// account becomes active.
pub async fn remove(db: &Db, id: &str) -> Result<()> {
    let mut tx = db.begin().await?;
    let was_active: Option<(i64,)> = sqlx::query_as("SELECT is_active FROM accounts WHERE id = ?1")
        .bind(id)
        .fetch_optional(&mut *tx)
        .await?;
    let Some((was_active,)) = was_active else {
        return Err(AuthError::AccountNotFound.into());
    };
    sqlx::query("DELETE FROM accounts WHERE id = ?1")
        .bind(id)
        .execute(&mut *tx)
        .await?;
    if was_active != 0 {
        sqlx::query(
            "UPDATE accounts SET is_active = 1 WHERE id = \
             (SELECT id FROM accounts ORDER BY last_used DESC, username COLLATE NOCASE LIMIT 1)",
        )
        .execute(&mut *tx)
        .await?;
    }
    tx.commit().await?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::db;

    pub fn profile(id_char: char, name: &str) -> Profile {
        Profile {
            id: id_char.to_string().repeat(32),
            name: name.into(),
            skin_hash: Some("0123456789abcdef".repeat(4)),
            skin_variant: Some(SkinVariant::Slim),
            cape_hash: None,
        }
    }

    #[test]
    fn account_id_validation() {
        assert!(is_valid_account_id(&"a".repeat(32)));
        assert!(is_valid_account_id("069a79f44e9d4e9cb12bd4a2bb7d6fd4"));
        for bad in [
            "",
            "abc",
            &"A".repeat(32),
            &"g".repeat(32),
            &"a".repeat(33),
            "../../etc/passwd",
        ] {
            assert!(!is_valid_account_id(bad), "accepted {bad:?}");
        }
    }

    #[tokio::test]
    async fn newest_sign_in_becomes_the_only_active_account() {
        let db = db::open_in_memory().await.unwrap();
        upsert_signed_in(&db, &profile('a', "Alex"), 100)
            .await
            .unwrap();
        let b = upsert_signed_in(&db, &profile('b', "Bea"), 200)
            .await
            .unwrap();
        assert!(b.is_active);

        let all = list(&db).await.unwrap();
        assert_eq!(all.iter().filter(|a| a.is_active).count(), 1);
        assert_eq!(all[0].username, "Bea", "active account sorts first");
        assert!(b.skin_url.unwrap().starts_with(TEXTURE_BASE));
        assert_eq!(b.skin_variant, Some(SkinVariant::Slim));
    }

    #[tokio::test]
    async fn signing_in_again_updates_in_place_and_clears_reauth() {
        let db = db::open_in_memory().await.unwrap();
        upsert_signed_in(&db, &profile('a', "Alex"), 100)
            .await
            .unwrap();
        mark_needs_reauth(&db, &"a".repeat(32)).await.unwrap();
        assert!(list(&db).await.unwrap()[0].needs_reauth);

        let again = upsert_signed_in(&db, &profile('a', "AlexRenamed"), 300)
            .await
            .unwrap();
        assert_eq!(list(&db).await.unwrap().len(), 1);
        assert_eq!(again.username, "AlexRenamed");
        assert!(!again.needs_reauth);
    }

    #[tokio::test]
    async fn set_active_switches_and_rejects_unknown() {
        let db = db::open_in_memory().await.unwrap();
        upsert_signed_in(&db, &profile('a', "Alex"), 100)
            .await
            .unwrap();
        upsert_signed_in(&db, &profile('b', "Bea"), 200)
            .await
            .unwrap();

        let a = set_active(&db, &"a".repeat(32), 300).await.unwrap();
        assert!(a.is_active);
        assert_eq!(
            list(&db)
                .await
                .unwrap()
                .iter()
                .filter(|x| x.is_active)
                .count(),
            1
        );

        let err = set_active(&db, &"c".repeat(32), 400).await.unwrap_err();
        assert!(matches!(
            err,
            crate::Error::Auth(AuthError::AccountNotFound)
        ));
        // The failed switch must not have deactivated anything.
        assert!(list(&db).await.unwrap().iter().any(|x| x.is_active));
    }

    #[tokio::test]
    async fn removing_the_active_account_promotes_the_most_recent_other() {
        let db = db::open_in_memory().await.unwrap();
        upsert_signed_in(&db, &profile('a', "Alex"), 100)
            .await
            .unwrap();
        upsert_signed_in(&db, &profile('b', "Bea"), 200)
            .await
            .unwrap();
        upsert_signed_in(&db, &profile('c', "Cy"), 300)
            .await
            .unwrap();

        remove(&db, &"c".repeat(32)).await.unwrap();
        let all = list(&db).await.unwrap();
        assert_eq!(all.len(), 2);
        let active: Vec<_> = all.iter().filter(|a| a.is_active).collect();
        assert_eq!(active.len(), 1);
        assert_eq!(active[0].username, "Bea");

        remove(&db, &"a".repeat(32)).await.unwrap();
        remove(&db, &"b".repeat(32)).await.unwrap();
        assert!(list(&db).await.unwrap().is_empty());
        assert!(matches!(
            remove(&db, &"b".repeat(32)).await.unwrap_err(),
            crate::Error::Auth(AuthError::AccountNotFound)
        ));
    }

    #[tokio::test]
    async fn update_profile_keeps_active_flag() {
        let db = db::open_in_memory().await.unwrap();
        upsert_signed_in(&db, &profile('a', "Alex"), 100)
            .await
            .unwrap();
        update_profile(&db, &profile('a', "NewName")).await.unwrap();
        let a = &list(&db).await.unwrap()[0];
        assert_eq!(a.username, "NewName");
        assert!(a.is_active);
    }
}
