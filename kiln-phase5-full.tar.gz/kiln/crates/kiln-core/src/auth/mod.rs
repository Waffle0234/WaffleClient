//! Microsoft → Xbox Live → XSTS → Minecraft sign-in.
//!
//! Security properties:
//! - refresh tokens are written only to the OS keychain ([`keystore`]);
//! - access tokens live in memory only, in a [`SecretString`] that hides itself from
//!   `Debug` and is wiped on drop;
//! - no token ever crosses the IPC boundary: the UI sees [`Account`] and
//!   [`DeviceCodeInfo`], and only the launch pipeline can obtain a [`LaunchSession`];
//! - nothing in this module logs a token, a response body, or a username.

mod accounts;
mod endpoints;
mod error;
mod keystore;
mod minecraft;
mod ms;
mod secret;
mod service;
mod xbox;

pub use accounts::{is_valid_account_id, texture_url, Account, SkinVariant};
pub use endpoints::{host_policy, Endpoints};
pub use error::AuthError;
pub use keystore::{KeyringStore, SecretStore};
pub use secret::SecretString;
pub use service::{client_id_from_env, AuthService, DeviceCodeInfo, LaunchSession, Timing};
