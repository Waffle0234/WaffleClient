//! Microsoft identity platform, device-code flow.
//! <https://learn.microsoft.com/entra/identity-platform/v2-oauth2-device-code>

use std::time::Duration;

use reqwest::{Method, Url};
use serde::Deserialize;

use super::endpoints::Endpoints;
use super::error::{unexpected, AuthError};
use super::secret::SecretString;
use crate::net::{Body, HttpClient};
use crate::Result;

const SCOPE: &str = "XboxLive.signin offline_access";
const DEVICE_GRANT: &str = "urn:ietf:params:oauth:grant-type:device_code";
/// Where the server may send the user to enter the code. Checked because the UI offers
/// to open this address in the browser.
const VERIFICATION_HOSTS: &[&str] = &[
    "www.microsoft.com",
    "microsoft.com",
    "login.microsoftonline.com",
    "login.live.com",
    "aka.ms",
];

pub struct DeviceCode {
    pub device_code: SecretString,
    pub user_code: String,
    pub verification_uri: String,
    pub expires_in: Duration,
    pub interval: Duration,
}

pub struct MsTokens {
    pub access_token: SecretString,
    pub refresh_token: Option<SecretString>,
}

pub enum PollOutcome {
    Tokens(MsTokens),
    Pending,
    SlowDown,
}

#[derive(Deserialize)]
struct DeviceCodeResponse {
    device_code: String,
    user_code: String,
    verification_uri: String,
    expires_in: u64,
    interval: Option<u64>,
}

#[derive(Deserialize)]
struct TokenResponse {
    access_token: Option<String>,
    refresh_token: Option<String>,
    error: Option<String>,
}

fn short(code: &str) -> String {
    code.chars().take(64).collect()
}

fn valid_user_code(code: &str) -> bool {
    (1..=32).contains(&code.len()) && code.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'-')
}

fn valid_verification_uri(uri: &str) -> bool {
    Url::parse(uri).is_ok_and(|u| {
        u.scheme() == "https"
            && u.username().is_empty()
            && u.host_str()
                .is_some_and(|h| VERIFICATION_HOSTS.contains(&h))
    })
}

pub async fn request_device_code(
    http: &HttpClient,
    ep: &Endpoints,
    client_id: &str,
) -> Result<DeviceCode> {
    let resp = http
        .execute(
            Method::POST,
            &ep.device_code,
            Body::Form(&[("client_id", client_id), ("scope", SCOPE)]),
            None,
        )
        .await?;
    if !resp.is_success() {
        return Err(unexpected(
            "Microsoft",
            format!("HTTP {} requesting a sign-in code", resp.status),
        ));
    }
    let body: DeviceCodeResponse = resp.json()?;
    if !valid_user_code(&body.user_code) || !valid_verification_uri(&body.verification_uri) {
        return Err(unexpected(
            "Microsoft",
            "sign-in code or address failed validation",
        ));
    }
    Ok(DeviceCode {
        device_code: SecretString::new(body.device_code),
        user_code: body.user_code,
        verification_uri: body.verification_uri,
        expires_in: Duration::from_secs(body.expires_in.clamp(60, 1800)),
        interval: Duration::from_secs(body.interval.unwrap_or(5).clamp(1, 30)),
    })
}

pub async fn poll_token(
    http: &HttpClient,
    ep: &Endpoints,
    client_id: &str,
    device_code: &SecretString,
) -> Result<PollOutcome> {
    let resp = http
        .execute(
            Method::POST,
            &ep.token,
            Body::Form(&[
                ("grant_type", DEVICE_GRANT),
                ("client_id", client_id),
                ("device_code", device_code.expose()),
            ]),
            None,
        )
        .await?;
    let status = resp.status;
    let body: TokenResponse = resp.json().map_err(|_| {
        unexpected(
            "Microsoft",
            format!("HTTP {status} from the token endpoint"),
        )
    })?;

    if let Some(access) = body.access_token {
        return Ok(PollOutcome::Tokens(MsTokens {
            access_token: SecretString::new(access),
            refresh_token: body.refresh_token.map(SecretString::new),
        }));
    }
    match body.error.as_deref() {
        Some("authorization_pending") => Ok(PollOutcome::Pending),
        Some("slow_down") => Ok(PollOutcome::SlowDown),
        Some("authorization_declined") => Err(AuthError::FlowDeclined.into()),
        Some("expired_token" | "bad_verification_code") => Err(AuthError::FlowExpired.into()),
        other => Err(unexpected(
            "Microsoft",
            format!("error {}", short(other.unwrap_or("none"))),
        )),
    }
}

pub async fn refresh(
    http: &HttpClient,
    ep: &Endpoints,
    client_id: &str,
    refresh_token: &SecretString,
) -> Result<MsTokens> {
    let resp = http
        .execute(
            Method::POST,
            &ep.token,
            Body::Form(&[
                ("grant_type", "refresh_token"),
                ("client_id", client_id),
                ("refresh_token", refresh_token.expose()),
                ("scope", SCOPE),
            ]),
            None,
        )
        .await?;
    let status = resp.status;
    let body: TokenResponse = resp
        .json()
        .map_err(|_| unexpected("Microsoft", format!("HTTP {status} refreshing the sign-in")))?;

    if let Some(access) = body.access_token {
        return Ok(MsTokens {
            access_token: SecretString::new(access),
            refresh_token: body.refresh_token.map(SecretString::new),
        });
    }
    match body.error.as_deref() {
        Some("invalid_grant" | "interaction_required" | "consent_required") => {
            Err(AuthError::ReauthRequired.into())
        }
        other => Err(unexpected(
            "Microsoft",
            format!("error {}", short(other.unwrap_or("none"))),
        )),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn verification_address_validation() {
        assert!(valid_verification_uri("https://www.microsoft.com/link"));
        assert!(valid_verification_uri(
            "https://login.microsoftonline.com/common/oauth2/deviceauth"
        ));
        for bad in [
            "http://www.microsoft.com/link",
            "https://evil.example/link",
            "https://www.microsoft.com.evil.net/link",
            "https://user@www.microsoft.com/link",
            "javascript:alert(1)",
            "not a url",
        ] {
            assert!(!valid_verification_uri(bad), "accepted {bad}");
        }
    }

    #[test]
    fn user_code_validation() {
        assert!(valid_user_code("ABCD1234"));
        assert!(valid_user_code("AB-CD"));
        assert!(!valid_user_code(""));
        assert!(!valid_user_code("<script>"));
        assert!(!valid_user_code(&"A".repeat(33)));
    }
}
