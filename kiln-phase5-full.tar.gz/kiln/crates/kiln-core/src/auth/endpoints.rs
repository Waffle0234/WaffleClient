use crate::net::HostPolicy;

/// Every URL the sign-in chain talks to. Overridable so tests can point at a mock server.
#[derive(Debug, Clone)]
pub struct Endpoints {
    pub device_code: String,
    pub token: String,
    pub xbox_user_auth: String,
    pub xsts: String,
    pub minecraft_login: String,
    pub minecraft_profile: String,
}

impl Default for Endpoints {
    fn default() -> Self {
        Self {
            device_code: "https://login.microsoftonline.com/consumers/oauth2/v2.0/devicecode"
                .into(),
            token: "https://login.microsoftonline.com/consumers/oauth2/v2.0/token".into(),
            xbox_user_auth: "https://user.auth.xboxlive.com/user/authenticate".into(),
            xsts: "https://xsts.auth.xboxlive.com/xsts/authorize".into(),
            minecraft_login: "https://api.minecraftservices.com/authentication/login_with_xbox"
                .into(),
            minecraft_profile: "https://api.minecraftservices.com/minecraft/profile".into(),
        }
    }
}

impl Endpoints {
    #[cfg(test)]
    pub fn with_base(base: &str) -> Self {
        Self {
            device_code: format!("{base}/devicecode"),
            token: format!("{base}/token"),
            xbox_user_auth: format!("{base}/xbl"),
            xsts: format!("{base}/xsts"),
            minecraft_login: format!("{base}/mclogin"),
            minecraft_profile: format!("{base}/profile"),
        }
    }
}

/// The only hosts the sign-in client may contact.
pub fn host_policy() -> HostPolicy {
    HostPolicy::new(&[
        "login.microsoftonline.com",
        "user.auth.xboxlive.com",
        "xsts.auth.xboxlive.com",
        "api.minecraftservices.com",
    ])
}
