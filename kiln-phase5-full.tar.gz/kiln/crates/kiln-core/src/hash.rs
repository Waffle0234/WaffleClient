//! Streaming SHA-1/SHA-256/SHA-512 hashing and verification.
//! Mojang manifests use SHA-1, Modrinth uses SHA-1 and SHA-512, Adoptium uses SHA-256.

use std::io::Read;
use std::path::Path;

use serde::{Deserialize, Serialize};
use sha1::Sha1;
use sha2::{Digest, Sha256, Sha512};

use crate::{Error, Result};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum HashAlgo {
    Sha1,
    Sha256,
    Sha512,
}

impl HashAlgo {
    pub const fn hex_len(self) -> usize {
        match self {
            Self::Sha1 => 40,
            Self::Sha256 => 64,
            Self::Sha512 => 128,
        }
    }
}

/// A validated, lowercase hex digest together with its algorithm.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ExpectedHash {
    algo: HashAlgo,
    hex: String,
}

impl ExpectedHash {
    pub fn new(algo: HashAlgo, hex: &str) -> Result<Self> {
        let hex = hex.trim();
        if hex.len() != algo.hex_len() || !hex.bytes().all(|b| b.is_ascii_hexdigit()) {
            return Err(Error::InvalidHash(format!(
                "expected {} hex characters for {algo:?}",
                algo.hex_len()
            )));
        }
        Ok(Self {
            algo,
            hex: hex.to_ascii_lowercase(),
        })
    }

    pub fn algo(&self) -> HashAlgo {
        self.algo
    }

    pub fn hex(&self) -> &str {
        &self.hex
    }
}

enum Inner {
    Sha1(Sha1),
    Sha256(Sha256),
    Sha512(Sha512),
}

/// Incremental hasher, so the downloader can hash while it writes.
pub struct StreamHasher(Inner);

impl std::fmt::Debug for StreamHasher {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("StreamHasher(..)")
    }
}

impl StreamHasher {
    pub fn new(algo: HashAlgo) -> Self {
        Self(match algo {
            HashAlgo::Sha1 => Inner::Sha1(Sha1::new()),
            HashAlgo::Sha256 => Inner::Sha256(Sha256::new()),
            HashAlgo::Sha512 => Inner::Sha512(Sha512::new()),
        })
    }

    pub fn update(&mut self, data: &[u8]) {
        match &mut self.0 {
            Inner::Sha1(h) => Digest::update(h, data),
            Inner::Sha256(h) => Digest::update(h, data),
            Inner::Sha512(h) => Digest::update(h, data),
        }
    }

    /// Lowercase hex digest.
    pub fn finalize_hex(self) -> String {
        match self.0 {
            Inner::Sha1(h) => hex::encode(h.finalize()),
            Inner::Sha256(h) => hex::encode(h.finalize()),
            Inner::Sha512(h) => hex::encode(h.finalize()),
        }
    }
}

pub fn hash_bytes(algo: HashAlgo, data: &[u8]) -> String {
    let mut h = StreamHasher::new(algo);
    h.update(data);
    h.finalize_hex()
}

pub fn hash_reader(algo: HashAlgo, mut reader: impl Read) -> Result<String> {
    let mut hasher = StreamHasher::new(algo);
    let mut buf = vec![0u8; 64 * 1024];
    loop {
        let n = reader.read(&mut buf)?;
        if n == 0 {
            break;
        }
        hasher.update(&buf[..n]);
    }
    Ok(hasher.finalize_hex())
}

/// Hash a file on the blocking pool so the async runtime stays responsive.
pub async fn hash_file(algo: HashAlgo, path: &Path) -> Result<String> {
    let path = path.to_path_buf();
    tokio::task::spawn_blocking(move || hash_reader(algo, std::fs::File::open(path)?))
        .await
        .map_err(|e| Error::Io(std::io::Error::other(e)))?
}

/// Verify a file against an expected digest; a mismatch is an error.
pub async fn verify_file(path: &Path, expected: &ExpectedHash) -> Result<()> {
    let actual = hash_file(expected.algo, path).await?;
    if actual == expected.hex {
        Ok(())
    } else {
        Err(Error::HashMismatch {
            expected: expected.hex.clone(),
            actual,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const SHA1_ABC: &str = "a9993e364706816aba3e25717850c26c9cd0d89d";
    const SHA256_ABC: &str = "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad";
    const SHA512_ABC: &str = "ddaf35a193617abacc417349ae20413112e6fa4e89a97ea20a9eeee64b55d39a\
2192992a274fc1a836ba3c23a3feebbd454d4423643ce80e2a9ac94fa54ca49f";
    const SHA256_EMPTY: &str = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";

    #[test]
    fn known_vectors() {
        assert_eq!(hash_bytes(HashAlgo::Sha1, b"abc"), SHA1_ABC);
        assert_eq!(hash_bytes(HashAlgo::Sha256, b"abc"), SHA256_ABC);
        assert_eq!(hash_bytes(HashAlgo::Sha512, b"abc"), SHA512_ABC);
        assert_eq!(hash_bytes(HashAlgo::Sha256, b""), SHA256_EMPTY);
    }

    #[test]
    fn streaming_matches_one_shot() {
        let mut h = StreamHasher::new(HashAlgo::Sha256);
        h.update(b"a");
        h.update(b"bc");
        assert_eq!(h.finalize_hex(), SHA256_ABC);
    }

    #[test]
    fn reader_spanning_multiple_buffers() {
        let data = vec![7u8; 200_000];
        let via_reader = hash_reader(HashAlgo::Sha1, &data[..]).unwrap();
        assert_eq!(via_reader, hash_bytes(HashAlgo::Sha1, &data));
    }

    #[test]
    fn expected_hash_validates_and_normalizes() {
        let h = ExpectedHash::new(HashAlgo::Sha1, &SHA1_ABC.to_uppercase()).unwrap();
        assert_eq!(h.hex(), SHA1_ABC);
        assert!(ExpectedHash::new(HashAlgo::Sha1, "abc").is_err());
        assert!(ExpectedHash::new(HashAlgo::Sha1, &"z".repeat(40)).is_err());
        // Right characters, wrong algorithm length.
        assert!(ExpectedHash::new(HashAlgo::Sha256, SHA1_ABC).is_err());
    }

    #[tokio::test]
    async fn verify_file_accepts_match_and_rejects_mismatch() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("f.bin");
        std::fs::write(&path, b"abc").unwrap();

        let good = ExpectedHash::new(HashAlgo::Sha256, SHA256_ABC).unwrap();
        verify_file(&path, &good).await.unwrap();

        let bad = ExpectedHash::new(HashAlgo::Sha256, SHA256_EMPTY).unwrap();
        let err = verify_file(&path, &bad).await.unwrap_err();
        assert!(matches!(err, Error::HashMismatch { .. }));
    }

    #[tokio::test]
    async fn verify_missing_file_is_io_error() {
        let dir = tempfile::tempdir().unwrap();
        let h = ExpectedHash::new(HashAlgo::Sha1, SHA1_ABC).unwrap();
        let err = verify_file(&dir.path().join("nope"), &h).await.unwrap_err();
        assert!(matches!(err, Error::Io(_)));
    }
}
