//! Mojang's per-version JSON: libraries, natives, arguments, assets and the client jar.

use std::collections::HashMap;

use serde::Deserialize;

use super::rules::{rules_allow, Environment, Rule};
use crate::launch::LaunchError;
use crate::Result;

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct VersionJson {
    pub id: String,
    #[serde(rename = "type")]
    pub kind: String,
    pub main_class: String,
    #[serde(default)]
    pub arguments: Option<Arguments>,
    /// Versions before 1.13 use one string instead of `arguments`.
    #[serde(default)]
    pub minecraft_arguments: Option<String>,
    /// Absent in loader profiles, which inherit it from the vanilla version.
    #[serde(default)]
    pub asset_index: Option<AssetIndexRef>,
    #[serde(default)]
    pub downloads: Option<VersionDownloads>,
    #[serde(default)]
    pub libraries: Vec<Library>,
    #[serde(default)]
    pub java_version: Option<JavaVersion>,
    /// Loader profiles (Fabric, Forge) build on a vanilla version. Phase 4.
    #[serde(default)]
    pub inherits_from: Option<String>,
}

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct JavaVersion {
    pub major_version: u32,
}

#[derive(Debug, Clone, Deserialize)]
pub struct AssetIndexRef {
    pub id: String,
    pub sha1: String,
    pub size: u64,
    pub url: String,
}

#[derive(Debug, Clone, Deserialize)]
pub struct VersionDownloads {
    pub client: FileRef,
}

/// A downloadable file as Mojang describes it.
#[derive(Debug, Clone, Deserialize)]
pub struct FileRef {
    #[serde(default)]
    pub path: Option<String>,
    pub sha1: String,
    /// Loader-generated entries may not know their size.
    #[serde(default)]
    pub size: Option<u64>,
    pub url: String,
}

#[derive(Debug, Clone, Deserialize)]
pub struct Arguments {
    #[serde(default)]
    pub game: Vec<Argument>,
    #[serde(default)]
    pub jvm: Vec<Argument>,
}

#[derive(Debug, Clone, Deserialize)]
#[serde(untagged)]
pub enum Argument {
    Plain(String),
    Conditional { rules: Vec<Rule>, value: OneOrMany },
}

#[derive(Debug, Clone, Deserialize)]
#[serde(untagged)]
pub enum OneOrMany {
    One(String),
    Many(Vec<String>),
}

impl Argument {
    /// The argument strings this entry contributes in `env` (none if its rules say no).
    pub fn values(&self, env: &Environment) -> Vec<&str> {
        match self {
            Self::Plain(s) => vec![s.as_str()],
            Self::Conditional { rules, value } if rules_allow(rules, env) => match value {
                OneOrMany::One(s) => vec![s.as_str()],
                OneOrMany::Many(v) => v.iter().map(String::as_str).collect(),
            },
            Self::Conditional { .. } => Vec::new(),
        }
    }
}

#[derive(Debug, Clone, Deserialize)]
pub struct Library {
    pub name: String,
    #[serde(default)]
    pub downloads: Option<LibraryDownloads>,
    #[serde(default)]
    pub rules: Vec<Rule>,
    /// Old-style natives: OS name to classifier, e.g. `linux` to `natives-linux`.
    #[serde(default)]
    pub natives: Option<HashMap<String, String>>,
    #[serde(default)]
    pub extract: Option<Extract>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct LibraryDownloads {
    pub artifact: Option<FileRef>,
    #[serde(default)]
    pub classifiers: Option<HashMap<String, FileRef>>,
}

#[derive(Debug, Clone, Default, Deserialize)]
pub struct Extract {
    #[serde(default)]
    pub exclude: Vec<String>,
}

/// A library file with a guaranteed relative path.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct LibraryFile {
    /// Relative to the libraries cache. Untrusted: build paths with `SafePath` only.
    pub path: String,
    pub url: String,
    pub sha1: String,
    pub size: Option<u64>,
}

/// The libraries that apply here, split by how they are used.
#[derive(Debug, Clone, Default)]
pub struct ResolvedLibraries {
    pub classpath: Vec<LibraryFile>,
    /// Jars to unpack into the natives folder, with the entry-name prefixes to skip.
    pub natives: Vec<(LibraryFile, Vec<String>)>,
}

fn to_file(name: &str, f: &FileRef) -> Result<LibraryFile> {
    let path = f
        .path
        .clone()
        .ok_or_else(|| LaunchError::UnsupportedLibrary(name.to_owned()))?;
    Ok(LibraryFile {
        path,
        url: f.url.clone(),
        sha1: f.sha1.clone(),
        size: f.size,
    })
}

impl VersionJson {
    pub fn asset_index_ref(&self) -> Result<&AssetIndexRef> {
        self.asset_index.as_ref().ok_or_else(|| {
            LaunchError::UnsupportedLibrary(format!("{} (no asset index)", self.id)).into()
        })
    }

    /// Combine a loader profile (`self`, which names its parent in `inheritsFrom`) with the
    /// vanilla version it builds on. The loader's main class wins, argument lists are
    /// concatenated parent first, and the loader's libraries come first on the classpath
    /// (replacing any parent library with the same `group:artifact`).
    pub fn merged_onto(&self, parent: &VersionJson) -> VersionJson {
        let ga = |name: &str| name.splitn(3, ':').take(2).collect::<Vec<_>>().join(":");
        let child_keys: std::collections::HashSet<String> =
            self.libraries.iter().map(|l| ga(&l.name)).collect();
        let mut libraries = self.libraries.clone();
        libraries.extend(
            parent
                .libraries
                .iter()
                .filter(|l| !child_keys.contains(&ga(&l.name)))
                .cloned(),
        );
        let arguments = match (&parent.arguments, &self.arguments) {
            (Some(p), Some(c)) => Some(Arguments {
                jvm: p.jvm.iter().chain(&c.jvm).cloned().collect(),
                game: p.game.iter().chain(&c.game).cloned().collect(),
            }),
            (Some(p), None) => Some(p.clone()),
            (None, Some(c)) => Some(c.clone()),
            (None, None) => None,
        };
        VersionJson {
            id: self.id.clone(),
            kind: self.kind.clone(),
            main_class: self.main_class.clone(),
            minecraft_arguments: if arguments.is_some() {
                None
            } else {
                self.minecraft_arguments
                    .clone()
                    .or_else(|| parent.minecraft_arguments.clone())
            },
            arguments,
            asset_index: self
                .asset_index
                .clone()
                .or_else(|| parent.asset_index.clone()),
            downloads: self.downloads.clone().or_else(|| parent.downloads.clone()),
            libraries,
            java_version: self
                .java_version
                .clone()
                .or_else(|| parent.java_version.clone()),
            inherits_from: None,
        }
    }

    /// Java major version the game needs. Versions without the field predate it: Java 8.
    pub fn java_major(&self) -> u32 {
        self.java_version.as_ref().map_or(8, |j| j.major_version)
    }

    pub fn resolve_libraries(&self, env: &Environment) -> Result<ResolvedLibraries> {
        let mut out = ResolvedLibraries::default();
        for lib in &self.libraries {
            if !rules_allow(&lib.rules, env) {
                continue;
            }
            let downloads = lib.downloads.as_ref();
            let classifier = lib.natives.as_ref().and_then(|n| {
                n.get(env.os.mojang_name())
                    .map(|c| c.replace("${arch}", env.bits()))
            });
            if let Some(classifier) = &classifier {
                // A natives library for another platform just doesn't apply here.
                if let Some(file) = downloads
                    .and_then(|d| d.classifiers.as_ref())
                    .and_then(|c| c.get(classifier))
                {
                    let exclude = lib.extract.clone().unwrap_or_default().exclude;
                    out.natives.push((to_file(&lib.name, file)?, exclude));
                }
            }
            match downloads.and_then(|d| d.artifact.as_ref()) {
                Some(artifact) => {
                    let file = to_file(&lib.name, artifact)?;
                    if !out.classpath.iter().any(|f| f.path == file.path) {
                        out.classpath.push(file);
                    }
                }
                // A library with natives only has no jar of its own for the classpath.
                None if lib.natives.is_some() => {}
                None => return Err(LaunchError::UnsupportedLibrary(lib.name.clone()).into()),
            }
        }
        Ok(out)
    }
}

/// `group:artifact:version[:classifier][@ext]` to its Maven repository path.
pub fn maven_path(name: &str) -> Option<String> {
    let (coords, ext) = name.split_once('@').unwrap_or((name, "jar"));
    let parts: Vec<&str> = coords.split(':').collect();
    if !(3..=4).contains(&parts.len()) || parts.iter().any(|p| p.is_empty()) || ext.is_empty() {
        return None;
    }
    let (group, artifact, version) = (parts[0].replace('.', "/"), parts[1], parts[2]);
    let file = match parts.get(3) {
        Some(classifier) => format!("{artifact}-{version}-{classifier}.{ext}"),
        None => format!("{artifact}-{version}.{ext}"),
    };
    Some(format!("{group}/{artifact}/{version}/{file}"))
}

/// Asset index: asset name to content hash.
#[derive(Debug, Clone, Deserialize)]
pub struct AssetIndex {
    pub objects: HashMap<String, AssetObject>,
    /// Pre-1.7 layouts need files copied to readable names. Not supported yet.
    #[serde(default, rename = "virtual")]
    pub is_virtual: bool,
    #[serde(default)]
    pub map_to_resources: bool,
}

#[derive(Debug, Clone, Deserialize)]
pub struct AssetObject {
    pub hash: String,
    pub size: u64,
}

#[cfg(test)]
mod tests {
    use serde_json::json;

    use super::*;
    use crate::mojang::rules::Os;

    fn env(os: Os) -> Environment {
        Environment {
            os,
            arch: "x86_64".into(),
            os_version: None,
            features: Default::default(),
        }
    }

    fn lib(v: serde_json::Value) -> serde_json::Value {
        v
    }

    fn version(libs: Vec<serde_json::Value>) -> VersionJson {
        serde_json::from_value(json!({
            "id": "1.21.1", "type": "release", "mainClass": "net.minecraft.client.main.Main",
            "assetIndex": {"id": "17", "sha1": "a".repeat(40), "size": 1, "url": "https://x/i.json"},
            "libraries": libs,
        }))
        .unwrap()
    }

    fn art(path: &str) -> serde_json::Value {
        json!({"path": path, "sha1": "b".repeat(40), "size": 10, "url": format!("https://libraries.minecraft.net/{path}")})
    }

    #[test]
    fn plain_and_rule_gated_libraries() {
        let v = version(vec![
            lib(
                json!({"name": "a:plain:1", "downloads": {"artifact": art("a/plain/1/plain-1.jar")}}),
            ),
            lib(
                json!({"name": "a:mac:1", "downloads": {"artifact": art("a/mac/1/mac-1.jar")},
                "rules": [{"action": "allow", "os": {"name": "osx"}}]}),
            ),
            lib(
                json!({"name": "a:notmac:1", "downloads": {"artifact": art("a/notmac/1/notmac-1.jar")},
                "rules": [{"action": "allow"}, {"action": "disallow", "os": {"name": "osx"}}]}),
            ),
        ]);
        let linux = v.resolve_libraries(&env(Os::Linux)).unwrap();
        let names: Vec<_> = linux.classpath.iter().map(|f| f.path.as_str()).collect();
        assert_eq!(names, ["a/plain/1/plain-1.jar", "a/notmac/1/notmac-1.jar"]);
        let mac = v.resolve_libraries(&env(Os::MacOs)).unwrap();
        let names: Vec<_> = mac.classpath.iter().map(|f| f.path.as_str()).collect();
        assert_eq!(names, ["a/plain/1/plain-1.jar", "a/mac/1/mac-1.jar"]);
    }

    #[test]
    fn old_style_natives_pick_the_platform_classifier() {
        let v = version(vec![lib(json!({
            "name": "org.lwjgl:lwjgl-platform:2.9.4",
            "natives": {"linux": "natives-linux", "windows": "natives-windows-${arch}"},
            "extract": {"exclude": ["META-INF/"]},
            "downloads": {
                "artifact": art("org/lwjgl/lwjgl-platform/2.9.4/lwjgl-platform-2.9.4.jar"),
                "classifiers": {
                    "natives-linux": art("org/lwjgl/lwjgl-platform/2.9.4/lwjgl-platform-2.9.4-natives-linux.jar"),
                    "natives-windows-64": art("org/lwjgl/lwjgl-platform/2.9.4/lwjgl-platform-2.9.4-natives-windows-64.jar")
                }
            }
        }))]);
        let r = v.resolve_libraries(&env(Os::Linux)).unwrap();
        assert_eq!(r.classpath.len(), 1);
        assert_eq!(r.natives.len(), 1);
        assert!(r.natives[0].0.path.ends_with("natives-linux.jar"));
        assert_eq!(r.natives[0].1, ["META-INF/"]);
        let r = v.resolve_libraries(&env(Os::Windows)).unwrap();
        assert!(r.natives[0].0.path.ends_with("natives-windows-64.jar"));
        // macOS has no entry in the natives map: nothing to extract, jar still on classpath.
        let r = v.resolve_libraries(&env(Os::MacOs)).unwrap();
        assert!(r.natives.is_empty());
    }

    #[test]
    fn natives_only_libraries_have_no_classpath_entry() {
        let v = version(vec![lib(json!({
            "name": "x:y:1", "natives": {"linux": "natives-linux"},
            "downloads": {"classifiers": {"natives-linux": art("x/y/1/y-1-natives-linux.jar")}}
        }))]);
        let r = v.resolve_libraries(&env(Os::Linux)).unwrap();
        assert!(r.classpath.is_empty());
        assert_eq!(r.natives.len(), 1);
    }

    #[test]
    fn libraries_without_download_info_are_reported_not_skipped() {
        let v = version(vec![lib(
            json!({"name": "net.fabricmc:fabric-loader:0.15", "url": "https://maven.fabricmc.net/"}),
        )]);
        let err = v.resolve_libraries(&env(Os::Linux)).unwrap_err();
        assert!(
            matches!(
                err,
                crate::Error::Launch(LaunchError::UnsupportedLibrary(_))
            ),
            "{err:?}"
        );
    }

    #[test]
    fn duplicate_classpath_entries_are_dropped() {
        let one = lib(json!({"name": "a:b:1", "downloads": {"artifact": art("a/b/1/b-1.jar")}}));
        let v = version(vec![one.clone(), one]);
        assert_eq!(
            v.resolve_libraries(&env(Os::Linux))
                .unwrap()
                .classpath
                .len(),
            1
        );
    }

    #[test]
    fn modern_arguments_parse_plain_conditional_and_list_values() {
        let v: VersionJson = serde_json::from_value(json!({
            "id": "1.21.1", "type": "release", "mainClass": "M",
            "assetIndex": {"id": "17", "sha1": "a".repeat(40), "size": 1, "url": "https://x/i.json"},
            "javaVersion": {"component": "java-runtime-delta", "majorVersion": 21},
            "arguments": {
                "game": ["--username", "${auth_player_name}",
                    {"rules": [{"action": "allow", "features": {"has_custom_resolution": true}}],
                     "value": ["--width", "${resolution_width}"]}],
                "jvm": [{"rules": [{"action": "allow", "os": {"name": "osx"}}], "value": "-XstartOnFirstThread"},
                        "-cp", "${classpath}"]
            }
        }))
        .unwrap();
        assert_eq!(v.java_major(), 21);
        let args = v.arguments.unwrap();
        let linux = env(Os::Linux);
        let game: Vec<_> = args.game.iter().flat_map(|a| a.values(&linux)).collect();
        assert_eq!(game, ["--username", "${auth_player_name}"]);
        let jvm: Vec<_> = args.jvm.iter().flat_map(|a| a.values(&linux)).collect();
        assert_eq!(jvm, ["-cp", "${classpath}"]);
        let mac: Vec<_> = args
            .jvm
            .iter()
            .flat_map(|a| a.values(&env(Os::MacOs)))
            .collect();
        assert_eq!(mac[0], "-XstartOnFirstThread");
    }

    #[test]
    fn missing_java_version_means_java_8() {
        assert_eq!(version(vec![]).java_major(), 8);
    }

    #[test]
    fn asset_index_parses_flags() {
        let idx: AssetIndex = serde_json::from_value(json!({
            "objects": {"icons/a.png": {"hash": "a".repeat(40), "size": 5}}, "virtual": true
        }))
        .unwrap();
        assert!(idx.is_virtual && !idx.map_to_resources);
    }

    #[test]
    fn maven_coordinates_become_repository_paths() {
        assert_eq!(
            maven_path("net.fabricmc:fabric-loader:0.16.5").as_deref(),
            Some("net/fabricmc/fabric-loader/0.16.5/fabric-loader-0.16.5.jar")
        );
        assert_eq!(
            maven_path("a.b:c:1:natives-linux").as_deref(),
            Some("a/b/c/1/c-1-natives-linux.jar")
        );
        assert_eq!(
            maven_path("net.minecraft:client:1.20.1:mappings@txt").as_deref(),
            Some("net/minecraft/client/1.20.1/client-1.20.1-mappings.txt")
        );
        for bad in ["", "a:b", "a:b:", "a:b:c:d:e", "a:b:c@"] {
            assert_eq!(maven_path(bad), None, "{bad}");
        }
    }

    #[test]
    fn a_loader_profile_merges_onto_its_parent() {
        let parent = version(vec![
            lib(
                json!({"name": "org.ow2.asm:asm:9.3", "downloads": {"artifact": art("org/ow2/asm/asm/9.3/asm-9.3.jar")}}),
            ),
            lib(
                json!({"name": "a:other:1", "downloads": {"artifact": art("a/other/1/other-1.jar")}}),
            ),
        ]);
        let parent: VersionJson = {
            let mut p = parent;
            p.arguments = Some(Arguments {
                jvm: vec![Argument::Plain("-Pjvm".into())],
                game: vec![Argument::Plain("--pgame".into())],
            });
            p
        };
        let child: VersionJson = serde_json::from_value(json!({
            "id": "fabric-loader-0.16.5-1.21.1", "type": "release", "inheritsFrom": "1.21.1",
            "mainClass": "net.fabricmc.loader.impl.launch.knot.KnotClient",
            "arguments": {"jvm": ["-Cjvm"], "game": []},
            "libraries": [{"name": "org.ow2.asm:asm:9.7", "downloads": {"artifact": art("org/ow2/asm/asm/9.7/asm-9.7.jar")}},
                          {"name": "net.fabricmc:fabric-loader:0.16.5", "downloads": {"artifact": art("net/fabricmc/fabric-loader/0.16.5/fabric-loader-0.16.5.jar")}}]
        })).unwrap();
        let m = child.merged_onto(&parent);
        assert_eq!(m.id, "fabric-loader-0.16.5-1.21.1");
        assert_eq!(
            m.main_class,
            "net.fabricmc.loader.impl.launch.knot.KnotClient"
        );
        assert!(m.inherits_from.is_none());
        assert_eq!(
            m.asset_index.as_ref().unwrap().id,
            "17",
            "inherited from the parent"
        );
        let names: Vec<_> = m.libraries.iter().map(|l| l.name.as_str()).collect();
        assert_eq!(
            names,
            [
                "org.ow2.asm:asm:9.7",
                "net.fabricmc:fabric-loader:0.16.5",
                "a:other:1"
            ],
            "child first, same group:artifact replaced"
        );
        let a = m.arguments.unwrap();
        let env = env(Os::Linux);
        assert_eq!(
            a.jvm
                .iter()
                .flat_map(|x| x.values(&env))
                .collect::<Vec<_>>(),
            ["-Pjvm", "-Cjvm"]
        );
        assert_eq!(
            a.game
                .iter()
                .flat_map(|x| x.values(&env))
                .collect::<Vec<_>>(),
            ["--pgame"]
        );
    }
}
