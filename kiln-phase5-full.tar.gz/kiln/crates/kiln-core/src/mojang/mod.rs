//! Mojang's launcher metadata: the version manifest, per-version JSON, asset indexes, and
//! the download tasks for the client jar, libraries and assets.
//!
//! Everything fetched here is verified against the SHA-1 Mojang publishes and cached under
//! `cache/{meta,versions,libraries,assets,jars}`.

pub mod rules;
pub mod version;

use std::path::{Path, PathBuf};

use reqwest::Method;
use serde::{Deserialize, Serialize};

use crate::download::{DownloadTask, Downloader};
use crate::hash::{ExpectedHash, HashAlgo};
use crate::launch::LaunchError;
use crate::net::{Body, HostPolicy, HttpClient};
use crate::paths::SafePath;
use crate::{Error, Result, APP_NAME, APP_VERSION};

pub use version::{AssetIndex, LibraryFile, ResolvedLibraries, VersionJson};

pub const MANIFEST_URL: &str = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json";
pub const ASSET_BASE: &str = "https://resources.download.minecraft.net/";
/// Refuse version JSON files larger than this (real ones are well under 1 MiB).
const MAX_JSON_BYTES: u64 = 8 * 1024 * 1024;

/// The only hosts the Mojang clients may contact.
pub fn host_policy() -> HostPolicy {
    HostPolicy::new(&[
        "piston-meta.mojang.com",
        "piston-data.mojang.com",
        "launchermeta.mojang.com",
        "launcher.mojang.com",
        "libraries.minecraft.net",
        "resources.download.minecraft.net",
    ])
}

/// Version ids become folder and file names, so keep them boring.
pub fn is_valid_version_id(id: &str) -> bool {
    (1..=64).contains(&id.len())
        && !id.starts_with('.')
        && id
            .bytes()
            .all(|b| b.is_ascii_alphanumeric() || matches!(b, b'.' | b'_' | b'-' | b'+'))
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Latest {
    pub release: String,
    pub snapshot: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VersionEntry {
    pub id: String,
    #[serde(rename = "type")]
    pub kind: String,
    pub url: String,
    pub sha1: String,
    #[serde(rename = "releaseTime")]
    pub release_time: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VersionManifest {
    pub latest: Latest,
    pub versions: Vec<VersionEntry>,
}

/// What the UI is told about a version. No URLs or hashes cross IPC.
#[derive(Debug, Clone, Serialize, PartialEq, Eq)]
pub struct VersionSummary {
    pub id: String,
    pub kind: String,
    pub release_time: String,
}

impl VersionManifest {
    pub fn summaries(&self) -> Vec<VersionSummary> {
        self.versions
            .iter()
            .filter(|v| is_valid_version_id(&v.id))
            .map(|v| VersionSummary {
                id: v.id.clone(),
                kind: v.kind.clone(),
                release_time: v.release_time.clone(),
            })
            .collect()
    }
}

#[derive(Debug, Clone)]
pub struct MojangClient {
    api: HttpClient,
    downloader: Downloader,
    cache: PathBuf,
    manifest_url: String,
    asset_base: String,
}

fn sha1_of(hex: &str) -> Result<ExpectedHash> {
    ExpectedHash::new(HashAlgo::Sha1, hex)
}

impl MojangClient {
    pub fn new(cache: &Path, max_concurrent: u8) -> Result<Self> {
        let ua = format!("{APP_NAME}/{APP_VERSION}");
        Ok(Self::with_clients(
            HttpClient::new(&ua, host_policy())?,
            Downloader::new(
                HttpClient::new_for_downloads(&ua, host_policy())?,
                max_concurrent,
            ),
            cache,
            MANIFEST_URL.into(),
            ASSET_BASE.into(),
        ))
    }

    pub(crate) fn with_clients(
        api: HttpClient,
        downloader: Downloader,
        cache: &Path,
        manifest_url: String,
        asset_base: String,
    ) -> Self {
        Self {
            api,
            downloader,
            cache: cache.to_path_buf(),
            manifest_url,
            asset_base,
        }
    }

    pub fn downloader(&self) -> &Downloader {
        &self.downloader
    }

    /// A folder under the cache, created on demand (`SafePath` needs its root to exist).
    pub fn cache_dir(&self, name: &str) -> Result<PathBuf> {
        let dir = self.cache.join(name);
        std::fs::create_dir_all(&dir)?;
        Ok(dir)
    }

    fn task(
        &self,
        folder: &str,
        rel: &str,
        url: &str,
        sha1: &str,
        size: Option<u64>,
    ) -> Result<DownloadTask> {
        Ok(DownloadTask {
            url: url.to_owned(),
            dest: SafePath::new(&self.cache_dir(folder)?, rel)?,
            hash: Some(sha1_of(sha1)?),
            size,
        })
    }

    /// The version list. Falls back to the copy saved by the last successful fetch when
    /// Mojang can't be reached, so installed versions still launch offline.
    pub async fn manifest(&self) -> Result<VersionManifest> {
        let saved = self.cache_dir("meta")?.join("version_manifest_v2.json");
        let fetched = match self
            .api
            .execute(Method::GET, &self.manifest_url, Body::Empty, None)
            .await
        {
            Ok(resp) if resp.is_success() => resp.json::<VersionManifest>(),
            Ok(resp) => Err(Error::Http(format!("Mojang answered HTTP {}", resp.status))),
            Err(e) => Err(e),
        };
        match fetched {
            Ok(manifest) => {
                let tmp = saved.with_extension("json.tmp");
                std::fs::write(&tmp, serde_json::to_vec(&manifest)?)?;
                std::fs::rename(&tmp, &saved)?;
                Ok(manifest)
            }
            Err(e) => match std::fs::read(&saved) {
                Ok(bytes) => {
                    tracing::warn!("using the saved version list: Mojang could not be reached");
                    Ok(serde_json::from_slice(&bytes)?)
                }
                Err(_) => Err(e),
            },
        }
    }

    pub async fn version_json(&self, id: &str) -> Result<VersionJson> {
        if !is_valid_version_id(id) {
            return Err(LaunchError::InvalidVersionId.into());
        }
        let dest = SafePath::new(&self.cache_dir("versions")?, &format!("{id}/{id}.json"))?;
        match self.manifest().await {
            Ok(manifest) => {
                let entry = manifest
                    .versions
                    .iter()
                    .find(|v| v.id == id)
                    .ok_or_else(|| LaunchError::UnknownVersion(id.to_owned()))?;
                let task = DownloadTask {
                    url: entry.url.clone(),
                    dest: dest.clone(),
                    hash: Some(sha1_of(&entry.sha1)?),
                    size: None,
                };
                self.downloader.download(task).await?;
            }
            // Offline: a previously verified copy is still good.
            Err(e) if !dest.as_path().is_file() => return Err(e),
            Err(_) => {}
        }
        read_json(dest.as_path())
    }

    pub async fn asset_index(&self, version: &VersionJson) -> Result<AssetIndex> {
        let r = version.asset_index_ref()?;
        if !is_valid_version_id(&r.id) {
            return Err(LaunchError::InvalidVersionId.into());
        }
        let task = self.task(
            "assets",
            &format!("indexes/{}.json", r.id),
            &r.url,
            &r.sha1,
            Some(r.size),
        )?;
        let dest = task.dest.clone();
        self.downloader.download(task).await?;
        let index: AssetIndex = read_json(dest.as_path())?;
        if index.is_virtual || index.map_to_resources {
            return Err(LaunchError::LegacyAssets(version.id.clone()).into());
        }
        Ok(index)
    }

    pub fn asset_tasks(&self, index: &AssetIndex) -> Result<Vec<DownloadTask>> {
        index
            .objects
            .values()
            .map(|o| {
                let hash = sha1_of(&o.hash)?;
                let prefix = &hash.hex()[..2];
                Ok(DownloadTask {
                    url: format!("{}{prefix}/{}", self.asset_base, hash.hex()),
                    dest: SafePath::new(
                        &self.cache_dir("assets")?,
                        &format!("objects/{prefix}/{}", hash.hex()),
                    )?,
                    size: Some(o.size),
                    hash: Some(hash),
                })
            })
            .collect()
    }

    /// Where a library lives (or will live) in the shared libraries cache.
    pub fn library_path(&self, lib: &LibraryFile) -> Result<SafePath> {
        SafePath::new(&self.cache_dir("libraries")?, &lib.path)
    }

    pub fn library_task(&self, lib: &LibraryFile) -> Result<DownloadTask> {
        self.task("libraries", &lib.path, &lib.url, &lib.sha1, lib.size)
    }

    /// Where the client jar lives once downloaded, and the task to fetch it.
    pub fn client_jar_task(&self, version: &VersionJson) -> Result<DownloadTask> {
        let client = &version
            .downloads
            .as_ref()
            .ok_or_else(|| LaunchError::UnsupportedLibrary(format!("{} client jar", version.id)))?
            .client;
        self.task(
            "jars",
            &format!("{0}/{0}.jar", version.id),
            &client.url,
            &client.sha1,
            client.size,
        )
    }

    pub fn assets_root(&self) -> Result<PathBuf> {
        self.cache_dir("assets")
    }
}

fn read_json<T: serde::de::DeserializeOwned>(path: &Path) -> Result<T> {
    if std::fs::metadata(path)?.len() > MAX_JSON_BYTES {
        return Err(Error::Json(
            <serde_json::Error as serde::de::Error>::custom("metadata file is too large"),
        ));
    }
    Ok(serde_json::from_slice(&std::fs::read(path)?)?)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn version_ids_are_safe_file_names() {
        for ok in [
            "1.21.1",
            "24w14a",
            "1.20.1-forge-47.2.0",
            "1.7.10_pre4",
            "a+b",
        ] {
            assert!(is_valid_version_id(ok), "{ok}");
        }
        for bad in [
            "",
            ".",
            "..",
            ".hidden",
            "a/b",
            "a\\b",
            "a b",
            "../x",
            &"a".repeat(65),
            "x:y",
            "naïve",
        ] {
            assert!(!is_valid_version_id(bad), "{bad:?}");
        }
    }

    #[test]
    fn summaries_hide_urls_and_drop_unsafe_ids() {
        let entry = |id: &str| VersionEntry {
            id: id.into(),
            kind: "release".into(),
            url: "https://piston-meta.mojang.com/x".into(),
            sha1: "a".repeat(40),
            release_time: "2024-01-01T00:00:00+00:00".into(),
        };
        let m = VersionManifest {
            latest: Latest {
                release: "1.21.1".into(),
                snapshot: "1.21.1".into(),
            },
            versions: vec![entry("1.21.1"), entry("../evil")],
        };
        let s = m.summaries();
        assert_eq!(s.len(), 1);
        assert!(!serde_json::to_string(&s).unwrap().contains("piston"));
    }
}
