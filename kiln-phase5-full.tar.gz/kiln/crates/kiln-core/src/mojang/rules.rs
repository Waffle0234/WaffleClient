//! Mojang's `rules` mechanism: which libraries and arguments apply to this computer.
//!
//! A list with no rules always applies. Otherwise it starts as "not allowed" and each rule
//! that matches this environment sets the outcome to its action, so the last match wins.

use std::collections::{HashMap, HashSet};

use regex::RegexBuilder;
use serde::Deserialize;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Os {
    Windows,
    MacOs,
    Linux,
}

impl Os {
    pub fn current() -> Self {
        if cfg!(target_os = "windows") {
            Self::Windows
        } else if cfg!(target_os = "macos") {
            Self::MacOs
        } else {
            Self::Linux
        }
    }

    /// The name Mojang's manifests use.
    pub fn mojang_name(self) -> &'static str {
        match self {
            Self::Windows => "windows",
            Self::MacOs => "osx",
            Self::Linux => "linux",
        }
    }
}

/// What the rules are evaluated against.
#[derive(Debug, Clone)]
pub struct Environment {
    pub os: Os,
    /// `x86` (32-bit), `x86_64` or `arm64`: the spellings Mojang's manifests use.
    pub arch: String,
    /// Matched by the `os.version` regex. Windows reports `10.0` for both 10 and 11; other
    /// systems are left unset, so version-restricted rules don't match there.
    pub os_version: Option<String>,
    /// Launcher features switched on (`has_custom_resolution`, `is_demo_user`, ...).
    pub features: HashSet<String>,
}

impl Environment {
    pub fn current() -> Self {
        let os = Os::current();
        let arch = match std::env::consts::ARCH {
            "aarch64" => "arm64",
            "x86" => "x86",
            _ => "x86_64",
        };
        Self {
            os,
            arch: arch.into(),
            os_version: (os == Os::Windows).then(|| "10.0".into()),
            features: HashSet::new(),
        }
    }

    /// Value substituted for `${arch}` in old-style native classifiers.
    pub fn bits(&self) -> &'static str {
        if self.arch == "x86" {
            "32"
        } else {
            "64"
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum Action {
    Allow,
    Disallow,
}

#[derive(Debug, Clone, Default, Deserialize)]
pub struct OsRule {
    pub name: Option<String>,
    pub arch: Option<String>,
    pub version: Option<String>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct Rule {
    pub action: Action,
    #[serde(default)]
    pub os: Option<OsRule>,
    #[serde(default)]
    pub features: Option<HashMap<String, bool>>,
}

impl OsRule {
    fn matches(&self, env: &Environment) -> bool {
        if self
            .name
            .as_deref()
            .is_some_and(|n| n != env.os.mojang_name())
        {
            return false;
        }
        if self.arch.as_deref().is_some_and(|a| a != env.arch) {
            return false;
        }
        match (&self.version, &env.os_version) {
            (None, _) => true,
            (Some(_), None) => false,
            // The pattern comes from a downloaded file: cap its compiled size.
            (Some(pattern), Some(version)) => RegexBuilder::new(pattern)
                .size_limit(100_000)
                .build()
                .is_ok_and(|re| re.is_match(version)),
        }
    }
}

impl Rule {
    fn matches(&self, env: &Environment) -> bool {
        self.os.as_ref().is_none_or(|os| os.matches(env))
            && self
                .features
                .as_ref()
                .is_none_or(|f| f.iter().all(|(k, v)| env.features.contains(k) == *v))
    }
}

pub fn rules_allow(rules: &[Rule], env: &Environment) -> bool {
    if rules.is_empty() {
        return true;
    }
    let mut allowed = false;
    for rule in rules.iter().filter(|r| r.matches(env)) {
        allowed = rule.action == Action::Allow;
    }
    allowed
}

#[cfg(test)]
mod tests {
    use serde_json::json;

    use super::*;

    fn env(os: Os, arch: &str) -> Environment {
        Environment {
            os,
            arch: arch.into(),
            os_version: (os == Os::Windows).then(|| "10.0".into()),
            features: HashSet::new(),
        }
    }

    fn rules(v: serde_json::Value) -> Vec<Rule> {
        serde_json::from_value(v).unwrap()
    }

    #[test]
    fn no_rules_means_allowed() {
        assert!(rules_allow(&[], &env(Os::Linux, "x86_64")));
    }

    #[test]
    fn os_rules_select_the_platform() {
        let r = rules(json!([{"action": "allow", "os": {"name": "osx"}}]));
        assert!(rules_allow(&r, &env(Os::MacOs, "arm64")));
        assert!(!rules_allow(&r, &env(Os::Linux, "x86_64")));
    }

    #[test]
    fn disallow_after_allow_wins_and_order_matters() {
        let r = rules(json!([
            {"action": "allow"},
            {"action": "disallow", "os": {"name": "osx"}}
        ]));
        assert!(rules_allow(&r, &env(Os::Linux, "x86_64")));
        assert!(!rules_allow(&r, &env(Os::MacOs, "x86_64")));
        // Reversed: the final unconditional allow overrides.
        let r = rules(json!([
            {"action": "disallow", "os": {"name": "osx"}},
            {"action": "allow"}
        ]));
        assert!(rules_allow(&r, &env(Os::MacOs, "x86_64")));
    }

    #[test]
    fn arch_rules_distinguish_32_bit_and_arm() {
        let r = rules(json!([{"action": "allow", "os": {"name": "windows", "arch": "x86"}}]));
        assert!(rules_allow(&r, &env(Os::Windows, "x86")));
        assert!(!rules_allow(&r, &env(Os::Windows, "x86_64")));
        let r = rules(json!([{"action": "allow", "os": {"name": "osx", "arch": "arm64"}}]));
        assert!(rules_allow(&r, &env(Os::MacOs, "arm64")));
        assert!(!rules_allow(&r, &env(Os::MacOs, "x86_64")));
    }

    #[test]
    fn version_regex_needs_a_known_version() {
        let r = rules(json!([{"action": "allow", "os": {"name": "windows", "version": "^10\\."}}]));
        assert!(rules_allow(&r, &env(Os::Windows, "x86_64")));
        let mut old = env(Os::Windows, "x86_64");
        old.os_version = Some("6.1".into());
        assert!(!rules_allow(&r, &old));
        assert!(!rules_allow(&r, &env(Os::Linux, "x86_64")));
    }

    #[test]
    fn a_hostile_regex_cannot_hang_or_panic() {
        let r = rules(json!([{"action": "allow", "os": {"version": "(((((((((("}}]));
        let mut e = env(Os::Windows, "x86_64");
        e.os_version = Some("10.0".into());
        assert!(!rules_allow(&r, &e));
        let huge = "a{1000}{1000}{1000}".to_string();
        let r = rules(json!([{"action": "allow", "os": {"version": huge}}]));
        assert!(!rules_allow(&r, &e));
    }

    #[test]
    fn feature_rules_follow_enabled_features() {
        let r = rules(json!([{"action": "allow", "features": {"has_custom_resolution": true}}]));
        let mut e = env(Os::Linux, "x86_64");
        assert!(!rules_allow(&r, &e));
        e.features.insert("has_custom_resolution".into());
        assert!(rules_allow(&r, &e));
        let demo_off = rules(json!([{"action": "allow", "features": {"is_demo_user": false}}]));
        assert!(rules_allow(&demo_off, &e));
        e.features.insert("is_demo_user".into());
        assert!(!rules_allow(&demo_off, &e));
    }
}
