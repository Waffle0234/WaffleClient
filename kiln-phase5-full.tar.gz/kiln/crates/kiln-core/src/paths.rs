//! Data directory layout, portable mode, and [`SafePath`], the only way file operations
//! on untrusted relative paths (archive entries, modpack files, IPC input) are allowed.

use std::path::{Path, PathBuf};

use crate::{Error, Result};

/// If a file or folder with this name sits next to the executable, Kiln runs in portable
/// mode and keeps all data beside the app.
pub const PORTABLE_MARKER: &str = "kiln-portable";
const PORTABLE_DATA_DIR: &str = "kiln-data";

#[derive(Debug, Clone)]
pub struct DataDirs {
    pub root: PathBuf,
    pub db_file: PathBuf,
    pub logs: PathBuf,
    pub cache: PathBuf,
    pub instances: PathBuf,
    pub java: PathBuf,
    pub backups: PathBuf,
    /// Where exported instances are written.
    pub exports: PathBuf,
    /// Where the user drops packs to import. IPC never carries a file path: the UI names a
    /// file in this folder.
    pub imports: PathBuf,
    pub portable: bool,
}

impl DataDirs {
    pub fn from_root(root: impl Into<PathBuf>, portable: bool) -> Self {
        let root = root.into();
        Self {
            db_file: root.join("kiln.sqlite"),
            logs: root.join("logs"),
            cache: root.join("cache"),
            instances: root.join("instances"),
            java: root.join("java"),
            backups: root.join("backups"),
            exports: root.join("exports"),
            imports: root.join("imports"),
            root,
            portable,
        }
    }

    /// Portable if the marker exists next to the executable, otherwise the platform data dir.
    pub fn resolve(exe_dir: Option<&Path>) -> Result<Self> {
        if let Some(dir) = exe_dir {
            if dir.join(PORTABLE_MARKER).exists() {
                return Ok(Self::from_root(dir.join(PORTABLE_DATA_DIR), true));
            }
        }
        let base = dirs::data_dir().ok_or_else(|| {
            Error::Io(std::io::Error::new(
                std::io::ErrorKind::NotFound,
                "no platform data directory",
            ))
        })?;
        Ok(Self::from_root(base.join("Kiln"), false))
    }

    /// Create every directory. On Unix the root is made private to the current user.
    pub fn ensure_created(&self) -> Result<()> {
        for dir in [
            &self.root,
            &self.logs,
            &self.cache,
            &self.instances,
            &self.java,
            &self.backups,
            &self.exports,
            &self.imports,
        ] {
            std::fs::create_dir_all(dir)?;
        }
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            std::fs::set_permissions(&self.root, std::fs::Permissions::from_mode(0o700))?;
        }
        Ok(())
    }
}

const RESERVED_NAMES: &[&str] = &[
    "CON", "PRN", "AUX", "NUL", "CONIN$", "CONOUT$", "COM1", "COM2", "COM3", "COM4", "COM5",
    "COM6", "COM7", "COM8", "COM9", "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8",
    "LPT9",
];

fn reject(rel: &str, why: &str) -> Error {
    Error::InvalidPath(format!("{why}: {rel:?}"))
}

fn is_reserved(component: &str) -> bool {
    let stem = component.split('.').next().unwrap_or(component).trim_end();
    RESERVED_NAMES.iter().any(|r| r.eq_ignore_ascii_case(stem))
}

fn validate_component(rel: &str, c: &str) -> Result<()> {
    if c == ".." {
        return Err(reject(rel, "parent directory reference"));
    }
    if c.len() > 255 {
        return Err(reject(rel, "name too long"));
    }
    // `:` also blocks Windows drive prefixes and NTFS alternate data streams.
    if c.chars()
        .any(|ch| ch.is_control() || matches!(ch, '<' | '>' | ':' | '"' | '|' | '?' | '*'))
    {
        return Err(reject(rel, "illegal character"));
    }
    if c.ends_with('.') || c.ends_with(' ') {
        return Err(reject(rel, "trailing dot or space"));
    }
    if is_reserved(c) {
        return Err(reject(rel, "reserved device name"));
    }
    Ok(())
}

/// Lexically validate a relative path. Both `/` and `\` separate components, so an archive
/// built on Windows can't smuggle `..\` past a Unix check (or vice versa). The rules are
/// the strictest of all platforms so instances stay portable between them.
pub fn validate_relative(rel: &str) -> Result<Vec<&str>> {
    if rel.starts_with('/') || rel.starts_with('\\') {
        return Err(reject(rel, "absolute path"));
    }
    let parts: Vec<&str> = rel
        .split(['/', '\\'])
        .filter(|c| !c.is_empty() && *c != ".")
        .collect();
    if parts.is_empty() {
        return Err(reject(rel, "empty path"));
    }
    for c in &parts {
        validate_component(rel, c)?;
    }
    Ok(parts)
}

/// A path proven to stay inside a root directory, including after resolving symlinks in
/// any part of it that already exists.
///
/// Note: this is a check at construction time. A hostile process that can already write
/// inside the root could still race it, which is outside Kiln's threat model (it would
/// already be running as the user).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SafePath {
    root: PathBuf,
    full: PathBuf,
}

impl SafePath {
    pub fn new(root: &Path, rel: &str) -> Result<Self> {
        let parts = validate_relative(rel)?;
        let root = root.canonicalize()?;
        let mut full = root.clone();
        full.extend(parts);
        ensure_inside(&root, &full, rel)?;
        Ok(Self { root, full })
    }

    pub fn as_path(&self) -> &Path {
        &self.full
    }

    pub fn root(&self) -> &Path {
        &self.root
    }

    /// Path relative to the root.
    pub fn relative(&self) -> &Path {
        self.full.strip_prefix(&self.root).unwrap_or(&self.full)
    }
}

impl AsRef<Path> for SafePath {
    fn as_ref(&self) -> &Path {
        &self.full
    }
}

fn ensure_inside(root: &Path, full: &Path, rel: &str) -> Result<()> {
    // Resolve the deepest part that exists; anything below it can't be a symlink yet.
    let mut probe = full;
    while probe.symlink_metadata().is_err() {
        match probe.parent() {
            Some(parent) if parent.starts_with(root) => probe = parent,
            _ => return Err(reject(rel, "escapes the root directory")),
        }
    }
    let resolved = probe
        .canonicalize()
        .map_err(|_| reject(rel, "could not be resolved"))?;
    if resolved.starts_with(root) {
        Ok(())
    } else {
        Err(reject(rel, "escapes the root directory"))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn root() -> tempfile::TempDir {
        tempfile::tempdir().unwrap()
    }

    #[test]
    fn accepts_plain_and_nested_paths_that_do_not_exist_yet() {
        let dir = root();
        let p = SafePath::new(dir.path(), "mods/sodium-0.6.jar").unwrap();
        assert!(p.as_path().starts_with(p.root()));
        assert_eq!(p.relative(), Path::new("mods").join("sodium-0.6.jar"));
    }

    #[test]
    fn normalizes_separators_and_dots() {
        let dir = root();
        let a = SafePath::new(dir.path(), "a\\.\\b//c").unwrap();
        let b = SafePath::new(dir.path(), "a/b/c").unwrap();
        assert_eq!(a, b);
    }

    #[test]
    fn rejects_traversal_and_absolute_paths() {
        let dir = root();
        for bad in [
            "../x",
            "a/../../x",
            "a/..",
            "..\\x",
            "a\\..\\..\\x",
            "/etc/passwd",
            "\\\\server\\share",
            "C:\\Windows\\x",
            "C:/x",
            "",
            ".",
            "./",
        ] {
            assert!(SafePath::new(dir.path(), bad).is_err(), "accepted {bad:?}");
        }
    }

    #[test]
    fn parent_references_are_rejected_by_the_explicit_rule() {
        // `..` is also caught by the trailing-dot rule; assert the reason so each layer
        // stays independently covered.
        for bad in ["..", "a/../b", "a\\..\\b"] {
            let err = validate_relative(bad).unwrap_err().to_string();
            assert!(err.contains("parent directory"), "{bad:?}: {err}");
        }
    }

    #[test]
    fn rejects_windows_hazards() {
        let dir = root();
        let long = "a".repeat(256);
        for bad in [
            "a/CON",
            "aux.txt",
            "nul",
            "Com1.log",
            "LPT9",
            "a/b.",
            "a/b ",
            "evil|name",
            "what?",
            "file.txt:stream",
            "a\0b",
            "tab\tname",
            long.as_str(),
        ] {
            assert!(SafePath::new(dir.path(), bad).is_err(), "accepted {bad:?}");
        }
        // Names that merely contain a reserved word are fine.
        assert!(SafePath::new(dir.path(), "console.txt").is_ok());
    }

    #[test]
    fn missing_root_is_an_error() {
        let dir = root();
        assert!(SafePath::new(&dir.path().join("missing"), "a").is_err());
    }

    #[cfg(unix)]
    #[test]
    fn rejects_symlink_escape_but_allows_internal_symlinks() {
        use std::os::unix::fs::symlink;
        let dir = root();
        let outside = root();
        symlink(outside.path(), dir.path().join("escape")).unwrap();
        std::fs::create_dir(dir.path().join("real")).unwrap();
        symlink(dir.path().join("real"), dir.path().join("inside")).unwrap();

        assert!(SafePath::new(dir.path(), "escape").is_err());
        assert!(SafePath::new(dir.path(), "escape/new/file").is_err());
        assert!(SafePath::new(dir.path(), "inside/file").is_ok());
    }

    #[cfg(unix)]
    #[test]
    fn rejects_dangling_symlink() {
        use std::os::unix::fs::symlink;
        let dir = root();
        symlink("/nonexistent-target", dir.path().join("dangling")).unwrap();
        assert!(SafePath::new(dir.path(), "dangling").is_err());
    }

    #[test]
    fn portable_marker_switches_layout() {
        let exe = root();
        let normal = DataDirs::resolve(Some(exe.path())).unwrap();
        assert!(!normal.portable);

        std::fs::write(exe.path().join(PORTABLE_MARKER), b"").unwrap();
        let portable = DataDirs::resolve(Some(exe.path())).unwrap();
        assert!(portable.portable);
        assert_eq!(portable.root, exe.path().join(PORTABLE_DATA_DIR));
    }

    #[test]
    fn ensure_created_makes_the_tree() {
        let base = root();
        let dirs = DataDirs::from_root(base.path().join("data"), false);
        dirs.ensure_created().unwrap();
        for d in [
            &dirs.logs,
            &dirs.cache,
            &dirs.instances,
            &dirs.java,
            &dirs.backups,
        ] {
            assert!(d.is_dir());
        }
        assert_eq!(dirs.db_file, dirs.root.join("kiln.sqlite"));
    }
}
