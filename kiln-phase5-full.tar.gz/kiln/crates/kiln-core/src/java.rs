//! Java runtimes: find ones already installed, or download Eclipse Temurin into `java/`.
//!
//! Downloads come from the Adoptium API, which publishes a SHA-256 for each package; the
//! package is verified by the downloader before it is unpacked. The download host
//! allowlist (GitHub) is only ever used by this module's own client.

use std::path::{Path, PathBuf};
use std::time::Duration;

use reqwest::Method;
use serde::Deserialize;
use tokio::sync::watch;

use crate::archive::{extract_tar_gz, extract_zip, ExtractOptions};
use crate::db::Db;
use crate::download::{DownloadTask, Downloader, Progress};
use crate::hash::{hash_bytes, ExpectedHash, HashAlgo};
use crate::launch::LaunchError;
use crate::net::{Body, HostPolicy, HttpClient};
use crate::paths::SafePath;
use crate::{Error, Result, APP_NAME, APP_VERSION};

pub const ADOPTIUM_API: &str = "https://api.adoptium.net";

pub fn api_policy() -> HostPolicy {
    HostPolicy::new(&["api.adoptium.net"])
}

/// Temurin package links redirect from github.com to GitHub's release CDN. The package's
/// SHA-256 is checked, so these hosts can't substitute a different file.
pub fn download_policy() -> HostPolicy {
    HostPolicy::new(&[
        "github.com",
        "objects.githubusercontent.com",
        "release-assets.githubusercontent.com",
    ])
}

/// Extract the major version from the output of `java -version`.
pub fn parse_java_major(output: &str) -> Option<u32> {
    let start = output.find("version \"")? + "version \"".len();
    let rest = &output[start..];
    let version = &rest[..rest.find('"')?];
    let mut parts = version.split(['.', '-', '_', '+']);
    let first: u32 = parts.next()?.parse().ok()?;
    // Java 8 and earlier call themselves "1.8.0_x".
    if first == 1 {
        parts.next()?.parse().ok()
    } else {
        Some(first)
    }
}

/// The `java` executable inside a JDK/JRE home folder, if there is one.
pub fn java_executable_in(home: &Path) -> Option<PathBuf> {
    let exe = if cfg!(windows) { "java.exe" } else { "java" };
    [
        home.join("bin").join(exe),
        home.join("Contents").join("Home").join("bin").join(exe),
    ]
    .into_iter()
    .find(|p| p.is_file())
}

/// Run `java -version` and report the major version. Fails if it doesn't run in 10 s.
pub async fn probe(java: &Path) -> Result<u32> {
    let mut cmd = tokio::process::Command::new(java);
    cmd.arg("-version").kill_on_drop(true);
    crate::launch::hide_console_window(&mut cmd);
    let output = tokio::time::timeout(Duration::from_secs(10), cmd.output())
        .await
        .map_err(|_| LaunchError::BadJava("it did not answer".into()))?
        .map_err(|e| LaunchError::BadJava(e.kind().to_string()))?;
    let text = format!(
        "{}{}",
        String::from_utf8_lossy(&output.stderr),
        String::from_utf8_lossy(&output.stdout)
    );
    parse_java_major(&text)
        .ok_or_else(|| LaunchError::BadJava("unrecognised version output".into()).into())
}

/// Places a JDK is commonly installed.
fn candidate_executables() -> Vec<PathBuf> {
    let mut homes: Vec<PathBuf> = Vec::new();
    if let Some(home) = std::env::var_os("JAVA_HOME") {
        homes.push(PathBuf::from(home));
    }
    let mut add_children = |dir: &str, suffix: &[&str]| {
        if let Ok(entries) = std::fs::read_dir(dir) {
            for e in entries.flatten() {
                let mut p = e.path();
                p.extend(suffix);
                homes.push(p);
            }
        }
    };
    add_children("/usr/lib/jvm", &[]);
    add_children("/Library/Java/JavaVirtualMachines", &["Contents", "Home"]);
    for base in [
        "C:\\Program Files\\Eclipse Adoptium",
        "C:\\Program Files\\Java",
        "C:\\Program Files\\Microsoft",
        "C:\\Program Files\\Zulu",
    ] {
        add_children(base, &[]);
    }
    let mut found: Vec<PathBuf> = homes.iter().filter_map(|h| java_executable_in(h)).collect();
    if let Some(path) = std::env::var_os("PATH") {
        let exe = if cfg!(windows) { "java.exe" } else { "java" };
        found.extend(
            std::env::split_paths(&path)
                .map(|d| d.join(exe))
                .filter(|p| p.is_file()),
        );
    }
    // The same JDK is often reachable by several routes.
    let mut seen = std::collections::HashSet::new();
    found.retain(|p| seen.insert(p.canonicalize().unwrap_or_else(|_| p.clone())));
    found
}

#[derive(Deserialize)]
struct Asset {
    binary: Binary,
}

#[derive(Deserialize)]
struct Binary {
    package: Package,
}

#[derive(Deserialize)]
struct Package {
    link: String,
    name: String,
    checksum: String,
    size: u64,
}

/// Adoptium's names for this computer, or `None` if it publishes no build for it.
fn adoptium_platform() -> Option<(&'static str, &'static str)> {
    let os = match std::env::consts::OS {
        "linux" => "linux",
        "macos" => "mac",
        "windows" => "windows",
        _ => return None,
    };
    let arch = match std::env::consts::ARCH {
        "x86_64" => "x64",
        "aarch64" => "aarch64",
        _ => return None,
    };
    Some((os, arch))
}

#[derive(Debug, Clone)]
pub struct JavaManager {
    db: Db,
    java_dir: PathBuf,
    api: HttpClient,
    downloader: Downloader,
    api_base: String,
}

impl JavaManager {
    pub fn new(db: Db, java_dir: &Path, max_concurrent: u8) -> Result<Self> {
        let ua = format!("{APP_NAME}/{APP_VERSION}");
        Ok(Self::with_clients(
            db,
            java_dir,
            HttpClient::new(&ua, api_policy())?,
            Downloader::new(
                HttpClient::new_for_downloads(&ua, download_policy())?,
                max_concurrent,
            ),
            ADOPTIUM_API.into(),
        ))
    }

    pub(crate) fn with_clients(
        db: Db,
        java_dir: &Path,
        api: HttpClient,
        downloader: Downloader,
        api_base: String,
    ) -> Self {
        Self {
            db,
            java_dir: java_dir.to_path_buf(),
            api,
            downloader,
            api_base,
        }
    }

    /// A `java` executable of exactly this major version: one Kiln already knows about, one
    /// installed on the system, or a fresh Temurin download, in that order.
    pub async fn ensure(
        &self,
        major: u32,
        progress: Option<watch::Sender<Progress>>,
    ) -> Result<PathBuf> {
        if let Some(path) = self.known(major).await? {
            return Ok(path);
        }
        for candidate in candidate_executables() {
            if probe(&candidate).await.is_ok_and(|m| m == major) {
                self.record(&candidate, "System", major, false).await?;
                return Ok(candidate);
            }
        }
        self.install_temurin(major, progress).await
    }

    /// The executable of a recorded runtime, if it is known and still on disk.
    pub async fn runtime_path(&self, id: &str) -> Result<Option<PathBuf>> {
        let row: Option<(String,)> = sqlx::query_as("SELECT path FROM java_runtimes WHERE id = ?1")
            .bind(id)
            .fetch_optional(&self.db)
            .await?;
        Ok(row.map(|(p,)| PathBuf::from(p)).filter(|p| p.is_file()))
    }

    /// A recorded runtime whose file still exists (the user may have uninstalled it).
    async fn known(&self, major: u32) -> Result<Option<PathBuf>> {
        let rows: Vec<(String,)> =
            sqlx::query_as("SELECT path FROM java_runtimes WHERE major = ?1 ORDER BY managed DESC")
                .bind(i64::from(major))
                .fetch_all(&self.db)
                .await?;
        Ok(rows
            .into_iter()
            .map(|(p,)| PathBuf::from(p))
            .find(|p| p.is_file()))
    }

    async fn record(&self, exe: &Path, vendor: &str, major: u32, managed: bool) -> Result<()> {
        let path = exe.to_string_lossy().into_owned();
        let id = hash_bytes(HashAlgo::Sha1, path.as_bytes());
        sqlx::query(
            "INSERT INTO java_runtimes (id, vendor, major, path, managed) VALUES (?1, ?2, ?3, ?4, ?5) \
             ON CONFLICT (path) DO UPDATE SET vendor = excluded.vendor, major = excluded.major, \
             managed = excluded.managed",
        )
        .bind(id)
        .bind(vendor)
        .bind(i64::from(major))
        .bind(path)
        .bind(i64::from(managed))
        .execute(&self.db)
        .await?;
        Ok(())
    }

    async fn find_package(&self, major: u32) -> Result<Package> {
        let (os, arch) = adoptium_platform().ok_or(LaunchError::NoJavaBuild(major))?;
        let url = format!(
            "{}/v3/assets/latest/{major}/hotspot?architecture={arch}&image_type=jre&os={os}&vendor=eclipse",
            self.api_base
        );
        let resp = self
            .api
            .execute(Method::GET, &url, Body::Empty, None)
            .await?;
        if !resp.is_success() {
            return Err(Error::Http(format!(
                "Adoptium answered HTTP {}",
                resp.status
            )));
        }
        let assets: Vec<Asset> = resp.json()?;
        assets
            .into_iter()
            .next()
            .map(|a| a.binary.package)
            .ok_or_else(|| LaunchError::NoJavaBuild(major).into())
    }

    async fn install_temurin(
        &self,
        major: u32,
        progress: Option<watch::Sender<Progress>>,
    ) -> Result<PathBuf> {
        let package = self.find_package(major).await?;
        if package.name.contains(['/', '\\']) {
            return Err(Error::InvalidPath("package name".into()));
        }
        let archive = SafePath::new(&self.java_dir, &format!("downloads/{}", package.name))?;
        self.downloader
            .download_all(
                vec![DownloadTask {
                    url: package.link,
                    dest: archive.clone(),
                    hash: Some(ExpectedHash::new(HashAlgo::Sha256, &package.checksum)?),
                    size: Some(package.size),
                }],
                progress,
            )
            .await?;

        let staging = self.java_dir.join(format!("{major}.tmp"));
        let target = self.java_dir.join(major.to_string());
        let (archive_path, staging_path) = (archive.as_path().to_path_buf(), staging.clone());
        let name = package.name.clone();
        tokio::task::spawn_blocking(move || -> Result<()> {
            let _ = std::fs::remove_dir_all(&staging_path);
            let opts = ExtractOptions {
                strip_components: 1,
                ..Default::default()
            };
            if name.ends_with(".zip") {
                extract_zip(&archive_path, &staging_path, &opts)?;
            } else if name.ends_with(".tar.gz") || name.ends_with(".tgz") {
                extract_tar_gz(&archive_path, &staging_path, &opts)?;
            } else {
                return Err(Error::Archive("unknown package format".into()));
            }
            Ok(())
        })
        .await
        .map_err(|e| Error::Io(std::io::Error::other(e)))??;

        // Check the unpacked runtime before it replaces anything.
        let staged_exe = java_executable_in(&staging)
            .ok_or_else(|| LaunchError::BadJava("the package has no java executable".into()))?;
        let actual = probe(&staged_exe).await?;
        if actual != major {
            let _ = std::fs::remove_dir_all(&staging);
            return Err(
                LaunchError::BadJava(format!("expected Java {major}, got {actual}")).into(),
            );
        }
        let _ = std::fs::remove_dir_all(&target);
        std::fs::rename(&staging, &target)?;
        let _ = std::fs::remove_file(archive.as_path());

        let exe = java_executable_in(&target)
            .ok_or_else(|| LaunchError::BadJava("the java executable went missing".into()))?;
        self.record(&exe, "Eclipse Temurin", major, true).await?;
        tracing::info!(major, "installed a Java runtime");
        Ok(exe)
    }
}

#[cfg(test)]
mod tests {
    use std::io::Write;

    use serde_json::json;
    use wiremock::matchers::{method, path, query_param};
    use wiremock::{Mock, MockServer, ResponseTemplate};

    use super::*;
    use crate::db;
    use crate::download::RetryPolicy;

    #[test]
    fn version_output_parsing() {
        assert_eq!(
            parse_java_major("openjdk version \"17.0.9\" 2023-10-17"),
            Some(17)
        );
        assert_eq!(parse_java_major("java version \"1.8.0_392\""), Some(8));
        assert_eq!(
            parse_java_major("openjdk version \"21\" 2023-09-19"),
            Some(21)
        );
        assert_eq!(parse_java_major("openjdk version \"22-ea\" 2024"), Some(22));
        assert_eq!(parse_java_major("openjdk version \"1.8.0+5\""), Some(8));
        assert_eq!(parse_java_major("bash: java: not found"), None);
        assert_eq!(parse_java_major("version \"abc\""), None);
    }

    fn fake_jre_tar_gz(major: u32) -> Vec<u8> {
        let script = format!("#!/bin/sh\necho 'openjdk version \"{major}.0.1\" 2024-01-01' >&2\n");
        let gz = flate2::write::GzEncoder::new(Vec::new(), flate2::Compression::fast());
        let mut b = tar::Builder::new(gz);
        let mut h = tar::Header::new_gnu();
        h.set_size(script.len() as u64);
        h.set_mode(0o755);
        h.set_cksum();
        b.append_data(
            &mut h,
            format!("jdk-{major}-jre/bin/java"),
            script.as_bytes(),
        )
        .unwrap();
        b.into_inner().unwrap().finish().unwrap()
    }

    async fn manager(server: &MockServer) -> (JavaManager, tempfile::TempDir, Db) {
        let dir = tempfile::tempdir().unwrap();
        let db = db::open_in_memory().await.unwrap();
        let policy = || HostPolicy::new(&[]).with_loopback_http();
        let mgr = JavaManager::with_clients(
            db.clone(),
            dir.path(),
            HttpClient::new("t/0", policy()).unwrap(),
            Downloader::new(HttpClient::new_for_downloads("t/0", policy()).unwrap(), 2).with_retry(
                RetryPolicy {
                    attempts: 2,
                    base_delay: Duration::from_millis(1),
                },
            ),
            server.uri(),
        );
        (mgr, dir, db)
    }

    async fn mount_package(server: &MockServer, major: u32, tarball: &[u8], checksum: &str) {
        Mock::given(method("GET"))
            .and(path(format!("/v3/assets/latest/{major}/hotspot")))
            .and(query_param("image_type", "jre"))
            .respond_with(ResponseTemplate::new(200).set_body_json(json!([{
                "binary": {"package": {
                    "link": format!("{}/pkg/jre.tar.gz", server.uri()),
                    "name": "jre.tar.gz", "checksum": checksum, "size": tarball.len(),
                }}
            }])))
            .mount(server)
            .await;
        Mock::given(path("/pkg/jre.tar.gz"))
            .respond_with(ResponseTemplate::new(200).set_body_bytes(tarball.to_vec()))
            .mount(server)
            .await;
    }

    #[cfg(unix)]
    #[tokio::test]
    async fn installs_a_verified_runtime_records_it_and_reuses_it() {
        // Only meaningful where this computer is a platform Adoptium publishes for.
        if adoptium_platform().is_none() {
            return;
        }
        let server = MockServer::start().await;
        let tarball = fake_jre_tar_gz(97);
        mount_package(
            &server,
            97,
            &tarball,
            &hash_bytes(HashAlgo::Sha256, &tarball),
        )
        .await;
        let (mgr, dir, db) = manager(&server).await;

        let exe = mgr.ensure(97, None).await.unwrap();
        assert_eq!(exe, dir.path().join("97/bin/java"));
        assert_eq!(probe(&exe).await.unwrap(), 97);
        assert!(
            !dir.path().join("downloads/jre.tar.gz").exists(),
            "archive is cleaned up"
        );
        assert!(!dir.path().join("97.tmp").exists());
        let (managed,): (i64,) =
            sqlx::query_as("SELECT managed FROM java_runtimes WHERE major = 97")
                .fetch_one(&db)
                .await
                .unwrap();
        assert_eq!(managed, 1);

        // A second call is served from the database: no more network traffic.
        let before = server.received_requests().await.unwrap().len();
        assert_eq!(mgr.ensure(97, None).await.unwrap(), exe);
        assert_eq!(server.received_requests().await.unwrap().len(), before);
    }

    #[cfg(unix)]
    #[tokio::test]
    async fn a_package_with_the_wrong_checksum_is_never_unpacked() {
        if adoptium_platform().is_none() {
            return;
        }
        let server = MockServer::start().await;
        let tarball = fake_jre_tar_gz(96);
        mount_package(&server, 96, &tarball, &"0".repeat(64)).await;
        let (mgr, dir, _db) = manager(&server).await;

        let err = mgr.ensure(96, None).await.unwrap_err();
        assert!(matches!(err, Error::HashMismatch { .. }), "{err:?}");
        assert!(!dir.path().join("96").exists() && !dir.path().join("96.tmp").exists());
    }

    #[cfg(unix)]
    #[tokio::test]
    async fn a_runtime_of_the_wrong_version_is_rejected() {
        if adoptium_platform().is_none() {
            return;
        }
        let server = MockServer::start().await;
        let tarball = fake_jre_tar_gz(11); // claims to be Java 11
        mount_package(
            &server,
            95,
            &tarball,
            &hash_bytes(HashAlgo::Sha256, &tarball),
        )
        .await;
        let (mgr, dir, _db) = manager(&server).await;

        let err = mgr.ensure(95, None).await.unwrap_err();
        assert!(
            matches!(err, Error::Launch(LaunchError::BadJava(_))),
            "{err:?}"
        );
        assert!(!dir.path().join("95").exists());
    }

    #[tokio::test]
    async fn no_published_build_gives_a_clear_error() {
        let server = MockServer::start().await;
        Mock::given(path("/v3/assets/latest/94/hotspot"))
            .respond_with(ResponseTemplate::new(200).set_body_json(json!([])))
            .mount(&server)
            .await;
        let (mgr, _dir, _db) = manager(&server).await;
        let err = mgr.find_package(94).await;
        if adoptium_platform().is_some() {
            assert!(matches!(
                err,
                Err(Error::Launch(LaunchError::NoJavaBuild(94)))
            ));
        }
    }

    #[test]
    fn executable_lookup_checks_the_macos_layout() {
        let dir = tempfile::tempdir().unwrap();
        let exe = if cfg!(windows) { "java.exe" } else { "java" };
        assert!(java_executable_in(dir.path()).is_none());
        let bin = dir.path().join("Contents/Home/bin");
        std::fs::create_dir_all(&bin).unwrap();
        std::fs::File::create(bin.join(exe))
            .unwrap()
            .write_all(b"x")
            .unwrap();
        assert!(java_executable_in(dir.path()).is_some());
    }
}
