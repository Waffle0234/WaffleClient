//! SQLite access: WAL mode, foreign keys on, migrations applied at open.
//! Queries use sqlx's runtime API (no compile-time database needed); migrations are
//! embedded at compile time.

use std::path::Path;
use std::str::FromStr;
use std::time::Duration;

use sqlx::migrate::Migrator;
use sqlx::sqlite::{
    SqliteConnectOptions, SqliteJournalMode, SqlitePool, SqlitePoolOptions, SqliteSynchronous,
};

use crate::Result;

pub type Db = SqlitePool;

static MIGRATOR: Migrator = sqlx::migrate!("./migrations");

/// Open (creating if needed) the database at `path` and apply pending migrations.
pub async fn open(path: &Path) -> Result<Db> {
    let options = SqliteConnectOptions::new()
        .filename(path)
        .create_if_missing(true)
        .journal_mode(SqliteJournalMode::Wal)
        .synchronous(SqliteSynchronous::Normal)
        .foreign_keys(true)
        .busy_timeout(Duration::from_secs(5));
    let pool = SqlitePoolOptions::new()
        .max_connections(4)
        .acquire_timeout(Duration::from_secs(5))
        .connect_with(options)
        .await?;
    MIGRATOR.run(&pool).await?;
    tracing::debug!("database ready");
    Ok(pool)
}

/// In-memory database for tests. A single never-expiring connection, because every new
/// connection to `:memory:` would otherwise be its own empty database.
pub async fn open_in_memory() -> Result<Db> {
    let options = SqliteConnectOptions::from_str("sqlite::memory:")?.foreign_keys(true);
    let pool = SqlitePoolOptions::new()
        .max_connections(1)
        .idle_timeout(None)
        .max_lifetime(None)
        .connect_with(options)
        .await?;
    MIGRATOR.run(&pool).await?;
    Ok(pool)
}

#[cfg(test)]
mod tests {
    use super::*;

    async fn insert_instance(db: &Db, id: &str) {
        sqlx::query(
            "INSERT INTO instances (id, name, mc_version, created_at, dir) VALUES (?1, ?1, '1.21.1', 0, ?1)",
        )
        .bind(id)
        .execute(db)
        .await
        .unwrap();
    }

    #[tokio::test]
    async fn migrations_create_every_table() {
        let db = open_in_memory().await.unwrap();
        let names: Vec<(String,)> = sqlx::query_as(
            "SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE '\\_%' ESCAPE '\\' AND name NOT LIKE 'sqlite_%' ORDER BY name",
        )
        .fetch_all(&db)
        .await
        .unwrap();
        let names: Vec<&str> = names.iter().map(|(n,)| n.as_str()).collect();
        for expected in [
            "accounts",
            "backups",
            "http_cache",
            "instances",
            "java_runtimes",
            "mod_backups",
            "mods",
            "option_profiles",
            "servers",
            "settings",
        ] {
            assert!(names.contains(&expected), "missing {expected}: {names:?}");
        }
    }

    #[tokio::test]
    async fn file_database_uses_wal_and_reopens_cleanly() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("k.sqlite");
        let db = open(&path).await.unwrap();
        let (mode,): (String,) = sqlx::query_as("PRAGMA journal_mode")
            .fetch_one(&db)
            .await
            .unwrap();
        assert_eq!(mode, "wal");
        insert_instance(&db, "a").await;
        db.close().await;

        // Re-opening re-runs the migrator: must be a no-op and keep data.
        let db = open(&path).await.unwrap();
        let (n,): (i64,) = sqlx::query_as("SELECT COUNT(*) FROM instances")
            .fetch_one(&db)
            .await
            .unwrap();
        assert_eq!(n, 1);
    }

    #[tokio::test]
    async fn deleting_an_instance_cascades() {
        let db = open_in_memory().await.unwrap();
        insert_instance(&db, "a").await;
        sqlx::query("INSERT INTO mods (instance_id, file_name, sha1) VALUES ('a', 'x.jar', 'h')")
            .execute(&db)
            .await
            .unwrap();
        sqlx::query("DELETE FROM instances WHERE id = 'a'")
            .execute(&db)
            .await
            .unwrap();
        let (n,): (i64,) = sqlx::query_as("SELECT COUNT(*) FROM mods")
            .fetch_one(&db)
            .await
            .unwrap();
        assert_eq!(n, 0);
    }

    #[tokio::test]
    async fn only_one_account_can_be_active() {
        let db = open_in_memory().await.unwrap();
        let insert = |id: &'static str, active: i64| {
            let db = db.clone();
            async move {
                sqlx::query("INSERT INTO accounts (id, username, is_active) VALUES (?1, ?1, ?2)")
                    .bind(id)
                    .bind(active)
                    .execute(&db)
                    .await
            }
        };
        insert("a", 1).await.unwrap();
        insert("b", 0).await.unwrap();
        assert!(insert("c", 1).await.is_err());
    }

    #[tokio::test]
    async fn constraints_reject_bad_data() {
        let db = open_in_memory().await.unwrap();
        // Unknown loader.
        let bad_loader = sqlx::query(
            "INSERT INTO instances (id, name, mc_version, loader, created_at, dir) VALUES ('x','x','1.21','optifine',0,'x')",
        )
        .execute(&db)
        .await;
        assert!(bad_loader.is_err());
        // Invalid JSON in settings.
        let bad_json = sqlx::query("INSERT INTO settings (key, value) VALUES ('k', '{not json')")
            .execute(&db)
            .await;
        assert!(bad_json.is_err());
        // Foreign key to a missing instance.
        let orphan =
            sqlx::query("INSERT INTO mods (instance_id, file_name, sha1) VALUES ('nope','x','h')")
                .execute(&db)
                .await;
        assert!(orphan.is_err());
    }
}
