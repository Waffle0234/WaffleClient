//! Scrubs secrets and personal data from text before it reaches a log or crash report:
//! bearer/JWT tokens, token-like key/value pairs, Minecraft launch credentials, e-mail
//! addresses, OS account names inside paths, and any value registered at runtime
//! (for example the active Minecraft username).

use std::borrow::Cow;
use std::sync::{LazyLock, RwLock};

use regex::Regex;

pub const MASK: &str = "[REDACTED]";
/// Registered values at least this long are matched without word boundaries.
const LONG_SECRET: usize = 12;
/// Upper bound on dynamically registered secrets.
const MAX_SECRETS: usize = 64;

pub struct Redactor {
    rules: Vec<(Regex, &'static str)>,
    secrets: RwLock<Vec<Regex>>,
}

impl std::fmt::Debug for Redactor {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("Redactor(..)")
    }
}

#[allow(clippy::expect_used)] // Static, test-covered patterns: failing here is a programmer error.
fn rule(pattern: &str, replacement: &'static str) -> (Regex, &'static str) {
    (
        Regex::new(pattern).expect("built-in redaction pattern must compile"),
        replacement,
    )
}

impl Default for Redactor {
    fn default() -> Self {
        Self::new()
    }
}

impl Redactor {
    pub fn new() -> Self {
        let rules = vec![
            // `Authorization: Bearer abc.def`
            rule(r"(?i)\b(bearer)\s+[A-Za-z0-9\-._~+/]+=*", "$1 [REDACTED]"),
            // Bare JWTs (Microsoft and Minecraft tokens).
            rule(
                r"\beyJ[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]*",
                MASK,
            ),
            // Game launch arguments that carry credentials or identity.
            rule(
                r"(?i)(--(?:username|uuid|accessToken|xuid|clientId|session|userProperties)(?:\s+|=))\S+",
                "${1}[REDACTED]",
            ),
            // `refresh_token=...`, `"access_token": "..."`, `password: ...`
            rule(
                r#"(?i)(["']?\b(?:access_token|refresh_token|id_token|client_secret|device_code|user_code|password|token|xsts_token|xbl_token|mc_token|uhs|userhash)\b["']?\s*[:=]\s*["']?)([^"'&\s,}]+)"#,
                "${1}[REDACTED]",
            ),
            // E-mail addresses (Microsoft account names).
            rule(
                r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}",
                "[REDACTED-EMAIL]",
            ),
            // OS account names inside home-directory paths (also JSON-escaped `\\`).
            rule(
                r#"(?i)(/home/|/Users/|[A-Z]:\\{1,2}Users\\{1,2})[^/\\\s"']+"#,
                "${1}<user>",
            ),
        ];
        Self {
            rules,
            secrets: RwLock::new(Vec::new()),
        }
    }

    /// Register a literal value to be masked everywhere from now on.
    ///
    /// Short values (usernames) are matched case-insensitively as whole words; long values
    /// (tokens, at least [`LONG_SECRET`] characters) are matched anywhere, because tokens
    /// contain punctuation that breaks word boundaries. Values shorter than three
    /// characters are ignored to avoid mangling ordinary text. Only the newest
    /// [`MAX_SECRETS`] are kept so a long session can't grow this without bound.
    pub fn register_secret(&self, value: &str) {
        let value = value.trim();
        if value.chars().count() < 3 {
            return;
        }
        let pattern = if value.chars().count() >= LONG_SECRET {
            regex::escape(value)
        } else {
            format!(r"(?i)\b{}\b", regex::escape(value))
        };
        if let Ok(re) = Regex::new(&pattern) {
            let mut secrets = self.secrets.write().unwrap_or_else(|e| e.into_inner());
            if secrets.len() >= MAX_SECRETS {
                secrets.remove(0);
            }
            secrets.push(re);
        }
    }

    pub fn redact<'a>(&self, input: &'a str) -> Cow<'a, str> {
        let mut out = Cow::Borrowed(input);
        for re in self
            .secrets
            .read()
            .unwrap_or_else(|e| e.into_inner())
            .iter()
        {
            if re.is_match(&out) {
                out = Cow::Owned(re.replace_all(&out, MASK).into_owned());
            }
        }
        for (re, replacement) in &self.rules {
            if re.is_match(&out) {
                out = Cow::Owned(re.replace_all(&out, *replacement).into_owned());
            }
        }
        out
    }
}

/// Process-wide redactor used by the logging layer.
pub fn global() -> &'static Redactor {
    static GLOBAL: LazyLock<Redactor> = LazyLock::new(Redactor::new);
    &GLOBAL
}

#[cfg(test)]
mod tests {
    use super::*;

    fn r(s: &str) -> String {
        Redactor::new().redact(s).into_owned()
    }

    #[test]
    fn bearer_and_jwt() {
        assert_eq!(
            r("Authorization: Bearer abc.DEF-123_x=="),
            "Authorization: Bearer [REDACTED]"
        );
        let jwt = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0In0.c2lnbmF0dXJl";
        let out = r(&format!("token was {jwt} ok"));
        assert!(!out.contains("eyJ"), "{out}");
    }

    #[test]
    fn launch_arguments() {
        let out = r(
            "java -cp x Main --username Steve --uuid 069a79f4 --accessToken abc.def --version 1.21",
        );
        assert!(!out.contains("Steve") && !out.contains("069a79f4") && !out.contains("abc.def"));
        assert!(out.contains("--version 1.21"));
    }

    #[test]
    fn key_value_forms() {
        let out = r(r#"{"refresh_token":"M.R3_BAY.secret","expires_in":3600}"#);
        assert!(!out.contains("M.R3_BAY"), "{out}");
        assert!(out.contains("expires_in"));
        let out = r("https://x/cb?access_token=SECRET&state=ok");
        assert!(!out.contains("SECRET") && out.contains("state=ok"), "{out}");
    }

    #[test]
    fn emails_and_paths() {
        assert!(!r("signed in as alex@example.com").contains("alex"));
        assert_eq!(
            r("/home/alex/.local/share/Kiln"),
            "/home/<user>/.local/share/Kiln"
        );
        assert_eq!(r("C:\\Users\\Alex Smith\\x").matches("<user>").count(), 1);
        assert!(!r(r"C:\\Users\\alex\\AppData").contains("alex"));
        assert!(!r("/Users/alex/Library").contains("alex"));
    }

    #[test]
    fn registered_secrets_are_masked_as_whole_words() {
        let red = Redactor::new();
        red.register_secret("Notch");
        red.register_secret("ab"); // too short, ignored
        assert_eq!(red.redact("hello notch!"), "hello [REDACTED]!");
        assert_eq!(red.redact("Notchless"), "Notchless");
        assert_eq!(red.redact("cab"), "cab");
    }

    #[test]
    fn long_secrets_match_even_with_punctuation_at_the_edges() {
        let red = Redactor::new();
        let token = "M.C507_BAY.2.-CjSecret$value.";
        red.register_secret(token);
        assert_eq!(red.redact(&format!("x{token}y")), "x[REDACTED]y");
    }

    #[test]
    fn registered_secrets_are_bounded() {
        let red = Redactor::new();
        for i in 0..(MAX_SECRETS + 10) {
            red.register_secret(&format!("secret-value-number-{i:04}"));
        }
        assert_eq!(red.secrets.read().unwrap().len(), MAX_SECRETS);
        // The oldest were evicted, the newest are still masked.
        assert_eq!(
            red.redact("secret-value-number-0000"),
            "secret-value-number-0000"
        );
        assert_eq!(red.redact("secret-value-number-0073"), "[REDACTED]");
    }

    #[test]
    fn plain_text_is_untouched_and_not_copied() {
        let red = Redactor::new();
        let s = "Loaded 142 mods in 3.2s (exit code 0)";
        assert!(matches!(red.redact(s), Cow::Borrowed(_)));
    }

    #[test]
    fn idempotent() {
        let once = r("Bearer abc --username Steve /home/alex/x");
        assert_eq!(r(&once), once);
    }
}
