//! Typed application settings persisted as one JSON row per key.
//!
//! Loading merges stored rows over the defaults and ignores anything unknown or invalid
//! (so a downgrade or a hand-edited row can't brick the launcher). Writing validates the
//! complete resulting settings before anything is stored.

use serde::{Deserialize, Serialize};
use serde_json::{Map, Value};

use crate::db::Db;
use crate::logging::LOG_LEVELS;
use crate::{Error, Result};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum Theme {
    System,
    Dark,
    Light,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(default)]
pub struct Settings {
    pub theme: Theme,
    /// `#rrggbb`
    pub accent_color: String,
    pub animated_background: bool,
    pub reduce_motion: bool,
    pub max_concurrent_downloads: u8,
    /// `None` means "choose automatically".
    pub default_ram_mb: Option<u32>,
    pub check_updates_on_start: bool,
    pub log_level: String,
}

impl Default for Settings {
    fn default() -> Self {
        Self {
            theme: Theme::System,
            accent_color: "#5fb99a".into(),
            animated_background: false,
            reduce_motion: false,
            max_concurrent_downloads: 8,
            default_ram_mb: None,
            check_updates_on_start: true,
            log_level: "info".into(),
        }
    }
}

fn invalid(key: &str, reason: &str) -> Error {
    Error::InvalidSetting {
        key: key.into(),
        reason: reason.into(),
    }
}

impl Settings {
    pub fn validate(&self) -> Result<()> {
        let c = self.accent_color.as_bytes();
        if c.len() != 7 || c[0] != b'#' || !c[1..].iter().all(u8::is_ascii_hexdigit) {
            return Err(invalid("accent_color", "use a color like #5fb99a"));
        }
        if !(1..=16).contains(&self.max_concurrent_downloads) {
            return Err(invalid(
                "max_concurrent_downloads",
                "choose a number from 1 to 16",
            ));
        }
        if let Some(mb) = self.default_ram_mb {
            if !(512..=262_144).contains(&mb) {
                return Err(invalid(
                    "default_ram_mb",
                    "choose between 512 MB and 256 GB",
                ));
            }
        }
        if !LOG_LEVELS.contains(&self.log_level.as_str()) {
            return Err(invalid(
                "log_level",
                "choose error, warn, info, debug or trace",
            ));
        }
        Ok(())
    }

    fn to_map(&self) -> Result<Map<String, Value>> {
        match serde_json::to_value(self)? {
            Value::Object(map) => Ok(map),
            _ => Err(<serde_json::Error as serde::ser::Error>::custom(
                "settings must serialize to an object",
            )
            .into()),
        }
    }

    fn from_map(map: &Map<String, Value>) -> Option<Self> {
        let settings: Self = serde_json::from_value(Value::Object(map.clone())).ok()?;
        settings.validate().ok()?;
        Some(settings)
    }
}

#[derive(Debug, Clone)]
pub struct SettingsStore {
    db: Db,
}

impl SettingsStore {
    pub fn new(db: Db) -> Self {
        Self { db }
    }

    pub async fn load(&self) -> Result<Settings> {
        let rows: Vec<(String, String)> = sqlx::query_as("SELECT key, value FROM settings")
            .fetch_all(&self.db)
            .await?;
        let mut map = Settings::default().to_map()?;
        for (key, raw) in rows {
            let Ok(value) = serde_json::from_str::<Value>(&raw) else {
                tracing::warn!(key, "ignoring unreadable stored setting");
                continue;
            };
            let Some(previous) = map.insert(key.clone(), value) else {
                // Unknown key (for example from a newer version): drop it again.
                map.remove(&key);
                continue;
            };
            if Settings::from_map(&map).is_none() {
                tracing::warn!(key, "ignoring invalid stored setting");
                map.insert(key, previous);
            }
        }
        Ok(Settings::from_map(&map).unwrap_or_default())
    }

    /// Set one key. Returns the full updated settings.
    pub async fn set(&self, key: &str, value: Value) -> Result<Settings> {
        if key.len() > 64 || value.to_string().len() > 4096 {
            return Err(invalid(key, "the value is too large"));
        }
        let mut map = self.load().await?.to_map()?;
        if !map.contains_key(key) {
            return Err(Error::UnknownSetting(key.into()));
        }
        map.insert(key.into(), value);
        let mut updated: Settings = serde_json::from_value(Value::Object(map)).map_err(|e| {
            tracing::debug!(error = %e, key, "setting rejected");
            invalid(key, "the value is not valid for this setting")
        })?;
        updated.accent_color.make_ascii_lowercase();
        updated.validate()?;

        // Store the canonical form of the value, not the raw input.
        let canonical = updated.to_map()?.remove(key).unwrap_or(Value::Null);
        sqlx::query(
            "INSERT INTO settings (key, value) VALUES (?1, ?2) \
             ON CONFLICT (key) DO UPDATE SET value = excluded.value",
        )
        .bind(key)
        .bind(canonical.to_string())
        .execute(&self.db)
        .await?;
        Ok(updated)
    }
}

#[cfg(test)]
mod tests {
    use serde_json::json;

    use super::*;
    use crate::db;

    async fn store() -> SettingsStore {
        SettingsStore::new(db::open_in_memory().await.unwrap())
    }

    #[test]
    fn defaults_are_valid() {
        Settings::default().validate().unwrap();
    }

    #[tokio::test]
    async fn empty_database_yields_defaults() {
        assert_eq!(store().await.load().await.unwrap(), Settings::default());
    }

    #[tokio::test]
    async fn set_persists_and_round_trips() {
        let s = store().await;
        let updated = s.set("theme", json!("dark")).await.unwrap();
        assert_eq!(updated.theme, Theme::Dark);
        s.set("default_ram_mb", json!(4096)).await.unwrap();
        s.set("default_ram_mb", Value::Null).await.unwrap();
        s.set("max_concurrent_downloads", json!(4)).await.unwrap();

        let loaded = s.load().await.unwrap();
        assert_eq!(loaded.theme, Theme::Dark);
        assert_eq!(loaded.default_ram_mb, None);
        assert_eq!(loaded.max_concurrent_downloads, 4);
    }

    #[tokio::test]
    async fn accent_color_is_normalized() {
        let s = store().await;
        let updated = s.set("accent_color", json!("#ABCDEF")).await.unwrap();
        assert_eq!(updated.accent_color, "#abcdef");
        assert_eq!(s.load().await.unwrap().accent_color, "#abcdef");
    }

    #[tokio::test]
    async fn rejects_unknown_keys_wrong_types_and_out_of_range() {
        let s = store().await;
        assert!(matches!(
            s.set("nope", json!(1)).await,
            Err(Error::UnknownSetting(_))
        ));
        for (key, value) in [
            ("theme", json!("purple")),
            ("theme", json!(3)),
            ("accent_color", json!("red")),
            ("accent_color", json!("#12345")),
            ("accent_color", json!("#12345g")),
            ("max_concurrent_downloads", json!(0)),
            ("max_concurrent_downloads", json!(17)),
            ("max_concurrent_downloads", json!(300)),
            ("max_concurrent_downloads", json!("8")),
            ("default_ram_mb", json!(64)),
            ("log_level", json!("verbose")),
            ("animated_background", json!("yes")),
        ] {
            assert!(
                matches!(
                    s.set(key, value.clone()).await,
                    Err(Error::InvalidSetting { .. })
                ),
                "accepted {key}={value}"
            );
        }
        // Nothing invalid was stored.
        assert_eq!(s.load().await.unwrap(), Settings::default());
    }

    #[tokio::test]
    async fn rejects_oversized_input() {
        let s = store().await;
        let huge = json!("x".repeat(5000));
        assert!(s.set("accent_color", huge).await.is_err());
        assert!(s.set(&"k".repeat(65), json!(1)).await.is_err());
    }

    #[tokio::test]
    async fn load_ignores_corrupt_unknown_and_invalid_rows() {
        let s = store().await;
        s.set("theme", json!("light")).await.unwrap();
        for (k, v) in [
            ("log_level", "\"loud\""),          // fails validation
            ("max_concurrent_downloads", "99"), // out of range
            ("from_the_future", "true"),        // unknown key
            ("animated_background", "null"),    // wrong type
        ] {
            sqlx::query("INSERT INTO settings (key, value) VALUES (?1, ?2)")
                .bind(k)
                .bind(v)
                .execute(&s.db)
                .await
                .unwrap();
        }
        let loaded = s.load().await.unwrap();
        assert_eq!(loaded.theme, Theme::Light, "valid rows still apply");
        assert_eq!(loaded.log_level, "info");
        assert_eq!(loaded.max_concurrent_downloads, 8);
        assert!(!loaded.animated_background);
    }
}
