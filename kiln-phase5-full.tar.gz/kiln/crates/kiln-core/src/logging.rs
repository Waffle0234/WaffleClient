//! `tracing` setup: rolling daily log files, optional stderr, and a writer that passes
//! every formatted event through the redactor before it is written anywhere.

use std::io::{self, Write};
use std::path::Path;

use tracing::Metadata;
use tracing_appender::non_blocking::WorkerGuard;
use tracing_appender::rolling::{RollingFileAppender, Rotation};
use tracing_subscriber::fmt::MakeWriter;
use tracing_subscriber::layer::SubscriberExt;
use tracing_subscriber::util::SubscriberInitExt;
use tracing_subscriber::{fmt, reload, EnvFilter, Registry};

use crate::{redact, Error, Result};

pub const LOG_LEVELS: &[&str] = &["error", "warn", "info", "debug", "trace"];
const KEEP_LOG_FILES: usize = 7;

/// Buffers one event and writes it, redacted, on flush or drop, so a secret can't be
/// split across two `write` calls and slip past the patterns.
pub struct RedactingWriter<W: Write> {
    inner: W,
    buf: Vec<u8>,
}

impl<W: Write> RedactingWriter<W> {
    pub fn new(inner: W) -> Self {
        Self {
            inner,
            buf: Vec::new(),
        }
    }

    fn flush_buf(&mut self) -> io::Result<()> {
        if self.buf.is_empty() {
            return Ok(());
        }
        let text = String::from_utf8_lossy(&self.buf);
        let redacted = redact::global().redact(&text);
        let result = self.inner.write_all(redacted.as_bytes());
        self.buf.clear();
        result
    }
}

impl<W: Write> Write for RedactingWriter<W> {
    fn write(&mut self, data: &[u8]) -> io::Result<usize> {
        self.buf.extend_from_slice(data);
        Ok(data.len())
    }

    fn flush(&mut self) -> io::Result<()> {
        self.flush_buf()?;
        self.inner.flush()
    }
}

impl<W: Write> Drop for RedactingWriter<W> {
    fn drop(&mut self) {
        // Nowhere to report a failed log write from a destructor.
        let _ = self.flush_buf();
    }
}

pub struct RedactingMakeWriter<M>(pub M);

impl<'a, M: MakeWriter<'a>> MakeWriter<'a> for RedactingMakeWriter<M> {
    type Writer = RedactingWriter<M::Writer>;

    fn make_writer(&'a self) -> Self::Writer {
        RedactingWriter::new(self.0.make_writer())
    }

    fn make_writer_for(&'a self, meta: &Metadata<'_>) -> Self::Writer {
        RedactingWriter::new(self.0.make_writer_for(meta))
    }
}

/// Keep alive for the life of the app: dropping it flushes pending log lines.
pub struct LogGuard {
    _worker: WorkerGuard,
    level: reload::Handle<EnvFilter, Registry>,
    env_override: bool,
}

impl std::fmt::Debug for LogGuard {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("LogGuard(..)")
    }
}

fn parse_filter(level: &str) -> Result<EnvFilter> {
    if !LOG_LEVELS.contains(&level) {
        return Err(Error::Logging(format!("unknown log level {level:?}")));
    }
    // sqlx logs every statement at info; keep it quiet unless the user asks for more.
    EnvFilter::try_new(format!("{level},sqlx=warn")).map_err(|e| Error::Logging(e.to_string()))
}

impl LogGuard {
    /// Change the log level at runtime. Ignored when `KILN_LOG` is set, so a developer's
    /// explicit filter always wins.
    pub fn set_level(&self, level: &str) -> Result<()> {
        if self.env_override {
            return Ok(());
        }
        let filter = parse_filter(level)?;
        self.level
            .reload(filter)
            .map_err(|e| Error::Logging(e.to_string()))
    }
}

/// Install the global subscriber. Can only succeed once per process.
pub fn init(log_dir: &Path, level: &str, also_stderr: bool) -> Result<LogGuard> {
    let appender = RollingFileAppender::builder()
        .rotation(Rotation::DAILY)
        .filename_prefix("kiln")
        .filename_suffix("log")
        .max_log_files(KEEP_LOG_FILES)
        .build(log_dir)
        .map_err(|e| Error::Logging(e.to_string()))?;
    let (non_blocking, worker) = tracing_appender::non_blocking(appender);

    let (filter, env_override) = match std::env::var("KILN_LOG") {
        Ok(spec) => (
            EnvFilter::try_new(spec).map_err(|e| Error::Logging(e.to_string()))?,
            true,
        ),
        Err(_) => (parse_filter(level)?, false),
    };
    let (filter_layer, level_handle) = reload::Layer::new(filter);

    let file_layer = fmt::layer()
        .with_ansi(false)
        .with_writer(RedactingMakeWriter(non_blocking));
    let stderr_layer =
        also_stderr.then(|| fmt::layer().with_writer(RedactingMakeWriter(io::stderr)));

    tracing_subscriber::registry()
        .with(filter_layer)
        .with(file_layer)
        .with(stderr_layer)
        .try_init()
        .map_err(|e| Error::Logging(e.to_string()))?;

    Ok(LogGuard {
        _worker: worker,
        level: level_handle,
        env_override,
    })
}

#[cfg(test)]
mod tests {
    use std::sync::{Arc, Mutex};

    use super::*;

    #[derive(Clone, Default)]
    struct Shared(Arc<Mutex<Vec<u8>>>);

    impl Write for Shared {
        fn write(&mut self, data: &[u8]) -> io::Result<usize> {
            self.0.lock().unwrap().extend_from_slice(data);
            Ok(data.len())
        }
        fn flush(&mut self) -> io::Result<()> {
            Ok(())
        }
    }

    impl<'a> MakeWriter<'a> for Shared {
        type Writer = Shared;
        fn make_writer(&'a self) -> Shared {
            self.clone()
        }
    }

    #[test]
    fn events_are_redacted_before_they_are_written() {
        let sink = Shared::default();
        let subscriber = tracing_subscriber::fmt()
            .with_ansi(false)
            .with_writer(RedactingMakeWriter(sink.clone()))
            .finish();

        tracing::subscriber::with_default(subscriber, || {
            tracing::info!(
                "refresh_token=M.R3_BAY.SECRETVALUE and --accessToken tok123 for /home/alex/x"
            );
        });

        let out = String::from_utf8(sink.0.lock().unwrap().clone()).unwrap();
        assert!(out.contains("[REDACTED]"), "{out}");
        for leaked in ["SECRETVALUE", "tok123", "alex"] {
            assert!(!out.contains(leaked), "leaked {leaked}: {out}");
        }
    }

    #[test]
    fn rejects_unknown_levels() {
        assert!(parse_filter("info").is_ok());
        assert!(parse_filter("verbose").is_err());
        assert!(parse_filter("info,secret=trace").is_err());
    }
}
