//! Forge and NeoForge: download the official installer, verify it, unpack its libraries and
//! run its processors headlessly, exactly as `--installClient` would.
//!
//! Trust note: processors are Java programs from the installer, run with the user's
//! privileges. The installer is checked against the SHA-1 its Maven repository publishes,
//! which protects against corruption and a bad mirror but not a compromised repository.
//! Each processor's outputs are verified against the hashes the installer declares.

use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::time::Duration;

use serde::Deserialize;

use super::{write_atomic, InstallContext, LoaderClient, LoaderKind};
use crate::archive::{extract_zip, read_zip_entry, ExtractOptions};
use crate::download::DownloadTask;
use crate::hash::{hash_file, ExpectedHash, HashAlgo};
use crate::launch::LaunchError;
use crate::mojang::version::{maven_path, Library};
use crate::mojang::{LibraryFile, VersionJson};
use crate::paths::SafePath;
use crate::{redact, Error, Result};

const MAX_PROFILE_BYTES: u64 = 16 * 1024 * 1024;
const MAX_DATA_BYTES: u64 = 512 * 1024 * 1024;
const PROCESSOR_TIMEOUT: Duration = Duration::from_secs(30 * 60);

#[derive(Deserialize)]
struct InstallProfile {
    #[serde(default)]
    data: HashMap<String, DataEntry>,
    #[serde(default)]
    processors: Vec<Processor>,
    #[serde(default)]
    libraries: Vec<Library>,
    json: String,
}

#[derive(Deserialize)]
struct DataEntry {
    client: String,
}

#[derive(Deserialize)]
struct Processor {
    #[serde(default)]
    sides: Option<Vec<String>>,
    jar: String,
    #[serde(default)]
    classpath: Vec<String>,
    #[serde(default)]
    args: Vec<String>,
    #[serde(default)]
    outputs: HashMap<String, String>,
}

fn fail(msg: impl Into<String>) -> Error {
    LaunchError::LoaderInstall(msg.into()).into()
}

/// `[group:artifact:version@ext]` to its path inside the libraries folder.
fn coord_path(libs: &Path, coord: &str) -> Result<String> {
    let rel = maven_path(coord).ok_or_else(|| fail(format!("bad library coordinate {coord}")))?;
    Ok(SafePath::new(libs, &rel)?
        .as_path()
        .to_string_lossy()
        .into_owned())
}

fn bracketed(s: &str) -> Option<&str> {
    s.strip_prefix('[')?.strip_suffix(']')
}

/// Replace `{KEY}` placeholders and `[coordinate]` tokens in a processor argument.
fn substitute(arg: &str, vars: &HashMap<String, String>, libs: &Path) -> Result<String> {
    if let Some(coord) = bracketed(arg) {
        return coord_path(libs, coord);
    }
    let mut out = String::new();
    let mut rest = arg;
    while let Some(start) = rest.find('{') {
        out.push_str(&rest[..start]);
        let after = &rest[start + 1..];
        let end = after
            .find('}')
            .ok_or_else(|| fail(format!("unterminated placeholder in {arg}")))?;
        let value = vars
            .get(&after[..end])
            .ok_or_else(|| fail(format!("unknown placeholder {}", &after[..end])))?;
        out.push_str(value);
        rest = &after[end + 1..];
    }
    out.push_str(rest);
    Ok(out)
}

/// `'abc'` to `abc`.
fn unquote(s: &str) -> &str {
    s.strip_prefix('\'')
        .and_then(|s| s.strip_suffix('\''))
        .unwrap_or(s)
}

fn manifest_main_class(jar: &Path) -> Result<String> {
    let manifest = read_zip_entry(jar, "META-INF/MANIFEST.MF", 1024 * 1024)?;
    String::from_utf8_lossy(&manifest)
        .lines()
        .find_map(|l| l.strip_prefix("Main-Class:").map(|v| v.trim().to_owned()))
        .ok_or_else(|| fail("a processor jar has no Main-Class"))
}

async fn outputs_valid(outputs: &[(PathBuf, ExpectedHash)]) -> bool {
    for (path, expected) in outputs {
        match hash_file(expected.algo(), path).await {
            Ok(actual) if actual == expected.hex() => {}
            _ => return false,
        }
    }
    true
}

pub(super) async fn install(
    c: &LoaderClient,
    kind: LoaderKind,
    mc: &str,
    lv: &str,
    key: &str,
    dest: &SafePath,
    ctx: &InstallContext<'_>,
) -> Result<VersionJson> {
    let (installer_url, installer_name) = match kind {
        LoaderKind::Neoforge => (
            format!(
                "{0}/net/neoforged/neoforge/{lv}/neoforge-{lv}-installer.jar",
                c.ep.neoforge_maven
            ),
            "neoforge",
        ),
        _ => {
            let full = format!("{mc}-{lv}");
            (
                format!(
                    "{0}/net/minecraftforge/forge/{full}/forge-{full}-installer.jar",
                    c.ep.forge_maven
                ),
                "forge",
            )
        }
    };
    let loaders = c.cache_dir("loaders")?;
    let libs = c.cache_dir("libraries")?;
    let installer = SafePath::new(&loaders, &format!("{key}-installer.jar"))?;
    c.downloader
        .download(DownloadTask {
            hash: Some(c.fetch_sha1(&installer_url).await?),
            url: installer_url,
            dest: installer.clone(),
            size: None,
        })
        .await?;

    // Read the profile, unpack the installer's bundled libraries.
    let (installer_path, libs_root) = (installer.as_path().to_path_buf(), libs.clone());
    let (profile, version_bytes) =
        tokio::task::spawn_blocking(move || -> Result<(InstallProfile, Vec<u8>)> {
            let profile: InstallProfile = serde_json::from_slice(&read_zip_entry(
                &installer_path,
                "install_profile.json",
                MAX_PROFILE_BYTES,
            )?)?;
            let version = read_zip_entry(
                &installer_path,
                profile.json.trim_start_matches('/'),
                MAX_PROFILE_BYTES,
            )?;
            let keep = |n: &str| n.starts_with("maven/");
            extract_zip(
                &installer_path,
                &libs_root,
                &ExtractOptions {
                    strip_components: 1,
                    filter: Some(&keep),
                    ..Default::default()
                },
            )?;
            Ok((profile, version))
        })
        .await
        .map_err(|e| Error::Io(std::io::Error::other(e)))??;

    // Libraries the processors themselves need. Entries without a URL ship inside the
    // installer and were just unpacked.
    let mut tasks = Vec::new();
    for lib in &profile.libraries {
        let Some(a) = lib.downloads.as_ref().and_then(|d| d.artifact.as_ref()) else {
            continue;
        };
        if a.url.is_empty() {
            continue;
        }
        let file = LibraryFile {
            path: a
                .path
                .clone()
                .ok_or_else(|| fail(format!("{} has no path", lib.name)))?,
            url: a.url.clone(),
            sha1: a.sha1.clone(),
            size: a.size,
        };
        tasks.push(c.mojang.library_task(&file)?);
    }
    c.downloader.download_all(tasks, None).await?;

    // Variables for processor arguments.
    let work = SafePath::new(&loaders, &format!("{key}-work"))?;
    let _ = std::fs::remove_dir_all(work.as_path());
    std::fs::create_dir_all(work.as_path())?;
    let mut vars: HashMap<String, String> = HashMap::new();
    let path_str = |p: &Path| p.to_string_lossy().into_owned();
    for (name, value) in [
        ("SIDE", "client".to_owned()),
        ("MINECRAFT_VERSION", mc.to_owned()),
        ("MINECRAFT_JAR", path_str(ctx.client_jar)),
        (
            "ROOT",
            path_str(
                &loaders
                    .parent()
                    .map(Path::to_path_buf)
                    .unwrap_or_else(|| loaders.clone()),
            ),
        ),
        ("INSTALLER", path_str(installer.as_path())),
        ("LIBRARY_DIR", path_str(&libs)),
    ] {
        vars.insert(name.into(), value);
    }
    for (name, entry) in &profile.data {
        let value = &entry.client;
        let resolved = if let Some(coord) = bracketed(value) {
            coord_path(&libs, coord)?
        } else if let Some(file) = value.strip_prefix('/') {
            let leaf = file.rsplit('/').next().unwrap_or(file);
            let bytes = read_zip_entry(installer.as_path(), file, MAX_DATA_BYTES)?;
            let target = SafePath::new(work.as_path(), leaf)?;
            std::fs::write(target.as_path(), bytes)?;
            path_str(target.as_path())
        } else {
            unquote(value).to_owned()
        };
        vars.insert(name.clone(), resolved);
    }

    for processor in profile.processors.iter().filter(|p| {
        p.sides
            .as_ref()
            .is_none_or(|s| s.iter().any(|x| x == "client"))
    }) {
        let mut outputs = Vec::new();
        for (path, hash) in &processor.outputs {
            let path = substitute(path, &vars, &libs)?;
            let hash =
                ExpectedHash::new(HashAlgo::Sha1, unquote(&substitute(hash, &vars, &libs)?))?;
            outputs.push((PathBuf::from(path), hash));
        }
        if !outputs.is_empty() && outputs_valid(&outputs).await {
            continue; // already produced by an earlier install
        }
        let jar = coord_path(&libs, &processor.jar)?;
        let main = manifest_main_class(Path::new(&jar))?;
        let mut classpath = vec![jar];
        for dep in &processor.classpath {
            classpath.push(coord_path(&libs, dep)?);
        }
        let args = processor
            .args
            .iter()
            .map(|a| substitute(a, &vars, &libs))
            .collect::<Result<Vec<_>>>()?;

        let mut cmd = tokio::process::Command::new(ctx.java);
        cmd.arg("-cp")
            .arg(classpath.join(if cfg!(windows) { ";" } else { ":" }))
            .arg(&main)
            .args(&args)
            .current_dir(work.as_path())
            .stdin(std::process::Stdio::null())
            .kill_on_drop(true);
        crate::launch::hide_console_window(&mut cmd);
        let output = tokio::time::timeout(PROCESSOR_TIMEOUT, cmd.output())
            .await
            .map_err(|_| fail("a loader installer step timed out"))?
            .map_err(|e| fail(format!("couldn't run Java: {}", e.kind())))?;
        if !output.status.success() {
            let text = format!(
                "{}{}",
                String::from_utf8_lossy(&output.stdout),
                String::from_utf8_lossy(&output.stderr)
            );
            let tail: String = text
                .chars()
                .rev()
                .take(600)
                .collect::<Vec<_>>()
                .into_iter()
                .rev()
                .collect();
            return Err(fail(format!(
                "an installer step failed: {}",
                redact::global().redact(&tail)
            )));
        }
        if !outputs.is_empty() && !outputs_valid(&outputs).await {
            return Err(fail(
                "an installer step produced a file that doesn't match its expected checksum",
            ));
        }
    }

    let parsed: VersionJson = serde_json::from_slice(&version_bytes)?;
    if parsed.inherits_from.as_deref() != Some(mc) {
        return Err(fail(
            "the installer's profile is for a different Minecraft version",
        ));
    }
    write_atomic(dest.as_path(), &version_bytes)?;
    let _ = std::fs::remove_dir_all(work.as_path());
    let _ = std::fs::remove_file(installer.as_path());
    tracing::info!(loader = installer_name, "installed a mod loader");
    Ok(parsed)
}

#[cfg(test)]
#[cfg(unix)]
mod tests {
    use std::io::Write;
    use std::os::unix::fs::PermissionsExt;

    use serde_json::json;
    use wiremock::matchers::path;
    use wiremock::{Mock, MockServer, ResponseTemplate};

    use super::super::tests::test_client;
    use super::*;
    use crate::hash::hash_bytes;

    fn jar_with_main(main: &str) -> Vec<u8> {
        let mut w = zip::ZipWriter::new(std::io::Cursor::new(Vec::new()));
        w.start_file(
            "META-INF/MANIFEST.MF",
            zip::write::SimpleFileOptions::default(),
        )
        .unwrap();
        write!(w, "Manifest-Version: 1.0\r\nMain-Class: {main}\r\n").unwrap();
        w.finish().unwrap().into_inner()
    }

    /// An installer whose single processor, run by a fake `java`, writes `OUT` to its
    /// `--output` argument. `declared_sha1` is what the profile claims the output hashes to.
    fn installer(declared_sha1: &str) -> Vec<u8> {
        let profile = json!({
            "spec": 1, "json": "/version.json", "minecraft": "1.20.1",
            "data": {
                "OUT": {"client": "[x:out:1@txt]", "server": "[x:srv:1@txt]"},
                "BLOB": {"client": "/data/client.lzma", "server": "/data/server.lzma"},
                "LITERAL": {"client": "'lit'", "server": "'lit'"}
            },
            "processors": [
                {"sides": ["server"], "jar": "x:proc:1", "args": ["--never-run-on-client"]},
                {"jar": "x:proc:1", "classpath": [], "args": ["--output", "{OUT}", "--blob", "{BLOB}", "--mc", "{MINECRAFT_VERSION}", "--lit", "{LITERAL}", "--lib", "[x:proc:1]"],
                 "outputs": {"{OUT}": format!("'{declared_sha1}'")}}
            ],
            "libraries": []
        });
        let version = json!({"id": "1.20.1-forge-47.2.0", "inheritsFrom": "1.20.1", "type": "release", "mainClass": "cpw.mods.bootstraplauncher.BootstrapLauncher", "libraries": []});
        let mut w = zip::ZipWriter::new(std::io::Cursor::new(Vec::new()));
        let o = zip::write::SimpleFileOptions::default();
        for (name, data) in [
            ("install_profile.json", profile.to_string().into_bytes()),
            ("version.json", version.to_string().into_bytes()),
            ("data/client.lzma", b"BLOBDATA".to_vec()),
            ("maven/x/proc/1/proc-1.jar", jar_with_main("p.Main")),
        ] {
            w.start_file(name, o).unwrap();
            w.write_all(&data).unwrap();
        }
        w.finish().unwrap().into_inner()
    }

    /// Stand-in for `java`: records each call and writes `OUT` to the `--output` argument.
    fn fake_java(dir: &Path) -> PathBuf {
        let p = dir.join("fake-java.sh");
        std::fs::write(&p, format!(
            "#!/bin/sh\necho call >> {calls}\nwhile [ $# -gt 0 ]; do\n  case \"$1\" in --output) mkdir -p \"$(dirname \"$2\")\"; printf OUT > \"$2\";; --blob) cp \"$2\" {blob};; --lit) echo \"$2\" > {lit};; esac\n  shift\ndone\n",
            calls = dir.join("calls").display(), blob = dir.join("blob-seen").display(), lit = dir.join("lit-seen").display()
        )).unwrap();
        std::fs::set_permissions(&p, std::fs::Permissions::from_mode(0o755)).unwrap();
        p
    }

    async fn serve(server: &MockServer, installer: &[u8]) {
        let p = "/forge/net/minecraftforge/forge/1.20.1-47.2.0/forge-1.20.1-47.2.0-installer.jar";
        Mock::given(path(p))
            .respond_with(ResponseTemplate::new(200).set_body_bytes(installer.to_vec()))
            .mount(server)
            .await;
        Mock::given(path(format!("{p}.sha1")))
            .respond_with(
                ResponseTemplate::new(200).set_body_string(hash_bytes(HashAlgo::Sha1, installer)),
            )
            .mount(server)
            .await;
    }

    #[tokio::test]
    async fn runs_the_client_processors_verifies_outputs_and_saves_the_profile() {
        let server = MockServer::start().await;
        let inst = installer(&hash_bytes(HashAlgo::Sha1, b"OUT"));
        serve(&server, &inst).await;
        let dir = tempfile::tempdir().unwrap();
        let cache = dir.path().join("cache");
        std::fs::create_dir_all(&cache).unwrap();
        let c = test_client(&server.uri(), &cache);
        let java = fake_java(dir.path());
        let ctx = InstallContext {
            java: &java,
            client_jar: Path::new("/fake/client.jar"),
        };

        let p = c
            .ensure_installed(LoaderKind::Forge, "1.20.1", "47.2.0", &ctx)
            .await
            .unwrap();
        assert_eq!(p.id, "1.20.1-forge-47.2.0");
        let calls = std::fs::read_to_string(dir.path().join("calls")).unwrap();
        assert_eq!(
            calls.lines().count(),
            1,
            "the server-only processor must not run"
        );
        assert_eq!(
            std::fs::read_to_string(cache.join("libraries/x/out/1/out-1.txt")).unwrap(),
            "OUT"
        );
        assert_eq!(
            std::fs::read(dir.path().join("blob-seen")).unwrap(),
            b"BLOBDATA",
            "installer data files are extracted for processors"
        );
        assert_eq!(
            std::fs::read_to_string(dir.path().join("lit-seen"))
                .unwrap()
                .trim(),
            "lit"
        );
        assert!(cache.join("loaders/forge-1.20.1-47.2.0.json").is_file());
        assert!(
            !cache.join("loaders/forge-1.20.1-47.2.0-work").exists(),
            "scratch files are cleaned up"
        );

        // Saved profile: no more installer runs or network.
        server.reset().await;
        c.ensure_installed(LoaderKind::Forge, "1.20.1", "47.2.0", &ctx)
            .await
            .unwrap();
        assert_eq!(
            std::fs::read_to_string(dir.path().join("calls"))
                .unwrap()
                .lines()
                .count(),
            1
        );
    }

    #[tokio::test]
    async fn a_processor_output_with_the_wrong_checksum_fails_the_install() {
        let server = MockServer::start().await;
        serve(&server, &installer(&"0".repeat(40))).await;
        let dir = tempfile::tempdir().unwrap();
        let cache = dir.path().join("cache");
        std::fs::create_dir_all(&cache).unwrap();
        let c = test_client(&server.uri(), &cache);
        let java = fake_java(dir.path());
        let ctx = InstallContext {
            java: &java,
            client_jar: Path::new("/fake/client.jar"),
        };

        let err = c
            .ensure_installed(LoaderKind::Forge, "1.20.1", "47.2.0", &ctx)
            .await
            .unwrap_err();
        assert!(
            matches!(&err, Error::Launch(LaunchError::LoaderInstall(m)) if m.contains("checksum")),
            "{err:?}"
        );
        assert!(
            !cache.join("loaders/forge-1.20.1-47.2.0.json").exists(),
            "a failed install must not be saved"
        );
    }

    #[tokio::test]
    async fn a_tampered_installer_is_rejected_before_anything_in_it_runs() {
        let server = MockServer::start().await;
        let inst = installer(&hash_bytes(HashAlgo::Sha1, b"OUT"));
        let p = "/forge/net/minecraftforge/forge/1.20.1-47.2.0/forge-1.20.1-47.2.0-installer.jar";
        Mock::given(path(p))
            .respond_with(ResponseTemplate::new(200).set_body_bytes(inst))
            .mount(&server)
            .await;
        Mock::given(path(format!("{p}.sha1")))
            .respond_with(ResponseTemplate::new(200).set_body_string("1".repeat(40)))
            .mount(&server)
            .await;
        let dir = tempfile::tempdir().unwrap();
        let cache = dir.path().join("cache");
        std::fs::create_dir_all(&cache).unwrap();
        let c = test_client(&server.uri(), &cache);
        let java = fake_java(dir.path());
        let ctx = InstallContext {
            java: &java,
            client_jar: Path::new("/fake/client.jar"),
        };

        let err = c
            .ensure_installed(LoaderKind::Forge, "1.20.1", "47.2.0", &ctx)
            .await
            .unwrap_err();
        assert!(matches!(err, Error::HashMismatch { .. }), "{err:?}");
        assert!(
            !dir.path().join("calls").exists(),
            "Java must never have been started"
        );
    }

    #[test]
    fn placeholder_substitution() {
        let vars: HashMap<String, String> = [("A".to_string(), "1".to_string())].into();
        let libs = tempfile::tempdir().unwrap();
        assert_eq!(substitute("x{A}y{A}", &vars, libs.path()).unwrap(), "x1y1");
        assert!(substitute("{NOPE}", &vars, libs.path()).is_err());
        assert!(substitute("{A", &vars, libs.path()).is_err());
        assert!(substitute("[a:b:1]", &vars, libs.path())
            .unwrap()
            .ends_with("a/b/1/b-1.jar"));
        assert!(
            substitute("[../../x:b:1]", &vars, libs.path()).is_err(),
            "coordinates cannot escape the libraries folder"
        );
        assert_eq!(unquote("'abc'"), "abc");
        assert_eq!(unquote("abc"), "abc");
    }
}
