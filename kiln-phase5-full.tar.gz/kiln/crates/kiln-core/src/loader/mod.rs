//! Mod loaders: Fabric and Quilt (profile JSON from their meta APIs) and Forge and NeoForge
//! (their official installers, run headlessly by [`forge`]).
//!
//! A loader install produces a *profile*: a version JSON that names the vanilla version it
//! builds on (`inheritsFrom`). It is saved under `cache/loaders/` and merged with the vanilla
//! version at launch time. Every library is hash-checked before use.

mod forge;

use std::path::{Path, PathBuf};

use reqwest::Method;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};

use crate::download::Downloader;
use crate::hash::{ExpectedHash, HashAlgo};
use crate::launch::LaunchError;
use crate::mojang::version::maven_path;
use crate::mojang::{is_valid_version_id, MojangClient, VersionJson};
use crate::net::{Body, HostPolicy, HttpClient};
use crate::paths::SafePath;
use crate::{Error, Result, APP_NAME, APP_VERSION};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum LoaderKind {
    Vanilla,
    Fabric,
    Quilt,
    Neoforge,
    Forge,
}

impl LoaderKind {
    /// The string stored in the `instances.loader` column.
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Vanilla => "vanilla",
            Self::Fabric => "fabric",
            Self::Quilt => "quilt",
            Self::Neoforge => "neoforge",
            Self::Forge => "forge",
        }
    }

    pub fn parse(s: &str) -> Option<Self> {
        Some(match s {
            "vanilla" => Self::Vanilla,
            "fabric" => Self::Fabric,
            "quilt" => Self::Quilt,
            "neoforge" => Self::Neoforge,
            "forge" => Self::Forge,
            _ => return None,
        })
    }

    pub fn display_name(self) -> &'static str {
        match self {
            Self::Vanilla => "Vanilla",
            Self::Fabric => "Fabric",
            Self::Quilt => "Quilt",
            Self::Neoforge => "NeoForge",
            Self::Forge => "Forge",
        }
    }
}

#[derive(Debug, Clone, Serialize, PartialEq, Eq)]
pub struct LoaderVersion {
    pub version: String,
    pub stable: bool,
}

/// Hosts the loader clients may contact. Library URLs inside loader profiles must be on one
/// of these, or the download is refused.
pub fn host_policy() -> HostPolicy {
    HostPolicy::new(&[
        "meta.fabricmc.net",
        "maven.fabricmc.net",
        "meta.quiltmc.org",
        "maven.quiltmc.org",
        "maven.neoforged.net",
        "maven.minecraftforge.net",
        "libraries.minecraft.net",
    ])
}

#[derive(Debug, Clone)]
pub struct Endpoints {
    pub fabric_meta: String,
    pub quilt_meta: String,
    pub neoforge_maven: String,
    pub forge_maven: String,
}

impl Default for Endpoints {
    fn default() -> Self {
        Self {
            fabric_meta: "https://meta.fabricmc.net".into(),
            quilt_meta: "https://meta.quiltmc.org".into(),
            neoforge_maven: "https://maven.neoforged.net/releases".into(),
            forge_maven: "https://maven.minecraftforge.net".into(),
        }
    }
}

/// What installers need from the rest of the launch pipeline.
pub struct InstallContext<'a> {
    pub java: &'a Path,
    pub client_jar: &'a Path,
}

#[derive(Debug, Clone)]
pub struct LoaderClient {
    api: HttpClient,
    downloader: Downloader,
    mojang: MojangClient,
    ep: Endpoints,
}

#[derive(Deserialize)]
struct GameEntry {
    version: String,
}

#[derive(Deserialize)]
struct LoaderEntry {
    loader: LoaderInner,
}

#[derive(Deserialize)]
struct LoaderInner {
    version: String,
    #[serde(default)]
    stable: Option<bool>,
}

/// Versions listed in a Maven `maven-metadata.xml`, oldest first.
fn xml_versions(xml: &str) -> Vec<String> {
    let mut out = Vec::new();
    let mut rest = xml;
    while let Some(start) = rest.find("<version>") {
        let after = &rest[start + "<version>".len()..];
        let Some(end) = after.find("</version>") else {
            break;
        };
        out.push(after[..end].trim().to_owned());
        rest = &after[end..];
    }
    out
}

/// NeoForge `21.1.77` is for Minecraft `1.21.1`; `21.0.x` is `1.21`. Numbering beyond the
/// 1.x scheme isn't mapped (returns `None`).
fn neoforge_mc_version(version: &str) -> Option<String> {
    let mut parts = version.split('.');
    let major: u32 = parts.next()?.parse().ok()?;
    let minor: u32 = parts
        .next()?
        .chars()
        .take_while(char::is_ascii_digit)
        .collect::<String>()
        .parse()
        .ok()?;
    if !(20..=25).contains(&major) {
        return None;
    }
    Some(if minor == 0 {
        format!("1.{major}")
    } else {
        format!("1.{major}.{minor}")
    })
}

/// `1.20.1` -> 20. `None` for anything that isn't a plain `1.N[.M]` release id.
fn mc_minor(mc: &str) -> Option<u32> {
    let mut parts = mc.split('.');
    (parts.next()? == "1").then_some(())?;
    let minor = parts.next()?.parse().ok()?;
    parts.all(|p| p.parse::<u32>().is_ok()).then_some(minor)
}

/// Forge's processor-based installers are supported from 1.17.
const FORGE_MIN_MINOR: u32 = 17;

pub(crate) fn write_atomic(path: &Path, bytes: &[u8]) -> Result<()> {
    let tmp = path.with_extension("tmp");
    std::fs::write(&tmp, bytes)?;
    std::fs::rename(&tmp, path)?;
    Ok(())
}

impl LoaderClient {
    pub fn new(mojang: MojangClient, max_concurrent: u8) -> Result<Self> {
        let ua = format!("{APP_NAME}/{APP_VERSION}");
        Ok(Self::with_clients(
            HttpClient::new(&ua, host_policy())?,
            Downloader::new(
                HttpClient::new_for_downloads(&ua, host_policy())?,
                max_concurrent,
            ),
            mojang,
            Endpoints::default(),
        ))
    }

    pub(crate) fn with_clients(
        api: HttpClient,
        downloader: Downloader,
        mojang: MojangClient,
        ep: Endpoints,
    ) -> Self {
        Self {
            api,
            downloader,
            mojang,
            ep,
        }
    }

    /// The downloader whose allowlist covers loader libraries (maven hosts).
    pub fn downloader(&self) -> &Downloader {
        &self.downloader
    }

    pub(crate) fn cache_dir(&self, name: &str) -> Result<PathBuf> {
        self.mojang.cache_dir(name)
    }

    async fn get(&self, url: &str) -> Result<crate::net::HttpResponse> {
        let resp = self
            .api
            .execute(Method::GET, url, Body::Empty, None)
            .await?;
        if resp.is_success() {
            Ok(resp)
        } else {
            Err(Error::Http(format!(
                "the server answered HTTP {}",
                resp.status
            )))
        }
    }

    /// Maven publishes `<file>.sha1` next to every artifact.
    pub(crate) async fn fetch_sha1(&self, file_url: &str) -> Result<ExpectedHash> {
        let resp = self.get(&format!("{file_url}.sha1")).await?;
        let text = String::from_utf8_lossy(resp.bytes());
        let token = text.split_whitespace().next().unwrap_or("");
        ExpectedHash::new(HashAlgo::Sha1, token)
    }

    fn meta(&self, kind: LoaderKind) -> Option<(&str, &'static str)> {
        match kind {
            LoaderKind::Fabric => Some((&self.ep.fabric_meta, "v2")),
            LoaderKind::Quilt => Some((&self.ep.quilt_meta, "v3")),
            _ => None,
        }
    }

    /// Minecraft versions this loader supports, newest first. For vanilla, use the Mojang
    /// manifest instead.
    pub async fn game_versions(&self, kind: LoaderKind) -> Result<Vec<String>> {
        if let Some((base, v)) = self.meta(kind) {
            let list: Vec<GameEntry> = self
                .get(&format!("{base}/{v}/versions/game"))
                .await?
                .json()?;
            return Ok(list
                .into_iter()
                .map(|g| g.version)
                .filter(|v| is_valid_version_id(v))
                .collect());
        }
        let mut seen = Vec::new();
        for v in self.maven_versions(kind).await? {
            if !seen.contains(&v.0) {
                seen.push(v.0);
            }
        }
        Ok(seen)
    }

    /// Loader versions that work with `mc`, newest first.
    pub async fn loader_versions(&self, kind: LoaderKind, mc: &str) -> Result<Vec<LoaderVersion>> {
        if !is_valid_version_id(mc) {
            return Err(LaunchError::InvalidVersionId.into());
        }
        if let Some((base, v)) = self.meta(kind) {
            let list: Vec<LoaderEntry> = self
                .get(&format!("{base}/{v}/versions/loader/{mc}"))
                .await?
                .json()?;
            return Ok(list
                .into_iter()
                .map(|e| LoaderVersion {
                    stable: e.loader.stable.unwrap_or(!e.loader.version.contains('-')),
                    version: e.loader.version,
                })
                .collect());
        }
        Ok(self
            .maven_versions(kind)
            .await?
            .into_iter()
            .filter(|(m, _, _)| m == mc)
            .map(|(_, version, stable)| LoaderVersion { version, stable })
            .collect())
    }

    /// `(minecraft version, loader version, stable)` for Forge and NeoForge, newest first.
    async fn maven_versions(&self, kind: LoaderKind) -> Result<Vec<(String, String, bool)>> {
        let url = match kind {
            LoaderKind::Neoforge => format!(
                "{}/net/neoforged/neoforge/maven-metadata.xml",
                self.ep.neoforge_maven
            ),
            LoaderKind::Forge => format!(
                "{}/net/minecraftforge/forge/maven-metadata.xml",
                self.ep.forge_maven
            ),
            _ => return Ok(Vec::new()),
        };
        let xml = self.get(&url).await?;
        let xml = String::from_utf8_lossy(xml.bytes());
        let mut out: Vec<_> = xml_versions(&xml)
            .into_iter()
            .filter_map(|v| match kind {
                LoaderKind::Neoforge => {
                    let stable = !v.contains('-');
                    neoforge_mc_version(&v).map(|mc| (mc, v, stable))
                }
                _ => {
                    let (mc, loader) = v.split_once('-')?;
                    (mc_minor(mc)? >= FORGE_MIN_MINOR && is_valid_version_id(loader))
                        .then(|| (mc.to_owned(), loader.to_owned(), true))
                }
            })
            .collect();
        out.reverse();
        Ok(out)
    }

    /// Install (or find the saved copy of) the loader profile for `mc`, and return it.
    /// Forge and NeoForge run their installer, which needs Java and the vanilla client jar.
    pub async fn ensure_installed(
        &self,
        kind: LoaderKind,
        mc: &str,
        loader_version: &str,
        ctx: &InstallContext<'_>,
    ) -> Result<VersionJson> {
        let key = format!("{}-{mc}-{loader_version}", kind.as_str());
        if kind == LoaderKind::Vanilla
            || !is_valid_version_id(&key)
            || !is_valid_version_id(mc)
            || !is_valid_version_id(loader_version)
        {
            return Err(LaunchError::InvalidVersionId.into());
        }
        let dest = SafePath::new(&self.cache_dir("loaders")?, &format!("{key}.json"))?;
        if dest.as_path().is_file() {
            return read_profile(dest.as_path(), mc);
        }
        let incompatible =
            || LaunchError::IncompatibleLoader(kind.display_name().into(), mc.into());
        match kind {
            LoaderKind::Fabric | LoaderKind::Quilt => {
                self.install_meta_profile(kind, mc, loader_version, &dest)
                    .await
            }
            LoaderKind::Neoforge if neoforge_mc_version(loader_version).as_deref() != Some(mc) => {
                Err(incompatible().into())
            }
            LoaderKind::Forge if mc_minor(mc).is_none_or(|m| m < FORGE_MIN_MINOR) => {
                Err(incompatible().into())
            }
            _ => forge::install(self, kind, mc, loader_version, &key, &dest, ctx).await,
        }
    }

    async fn install_meta_profile(
        &self,
        kind: LoaderKind,
        mc: &str,
        lv: &str,
        dest: &SafePath,
    ) -> Result<VersionJson> {
        let (base, v) = self.meta(kind).ok_or(LaunchError::InvalidVersionId)?;
        let url = format!("{base}/{v}/versions/loader/{mc}/{lv}/profile/json");
        let resp = self
            .api
            .execute(Method::GET, &url, Body::Empty, None)
            .await?;
        match resp.status {
            400 | 404 => {
                return Err(
                    LaunchError::IncompatibleLoader(kind.display_name().into(), mc.into()).into(),
                )
            }
            s if !(200..300).contains(&s) => {
                return Err(Error::Http(format!("the server answered HTTP {s}")))
            }
            _ => {}
        }
        let mut profile: Value = resp.json()?;
        self.fill_library_downloads(&mut profile).await?;
        let parsed: VersionJson = serde_json::from_value(profile.clone())?;
        if parsed.inherits_from.as_deref() != Some(mc) {
            return Err(LaunchError::LoaderInstall(
                "the loader profile is for a different Minecraft version".into(),
            )
            .into());
        }
        write_atomic(dest.as_path(), &serde_json::to_vec(&profile)?)?;
        Ok(parsed)
    }

    /// Loader profiles list libraries as `name` + repository `url`. Turn each into a full
    /// download entry with the SHA-1 the repository publishes for it.
    async fn fill_library_downloads(&self, profile: &mut Value) -> Result<()> {
        let Some(libs) = profile.get_mut("libraries").and_then(Value::as_array_mut) else {
            return Ok(());
        };
        for lib in libs {
            if lib.get("downloads").is_some() {
                continue;
            }
            let name = lib
                .get("name")
                .and_then(Value::as_str)
                .unwrap_or_default()
                .to_owned();
            let path =
                maven_path(&name).ok_or_else(|| LaunchError::UnsupportedLibrary(name.clone()))?;
            let mut base = lib
                .get("url")
                .and_then(Value::as_str)
                .unwrap_or("https://libraries.minecraft.net/")
                .to_owned();
            if !base.ends_with('/') {
                base.push('/');
            }
            let url = format!("{base}{path}");
            let sha1 = match lib.get("sha1").and_then(Value::as_str) {
                Some(s) => ExpectedHash::new(HashAlgo::Sha1, s)?,
                None => self.fetch_sha1(&url).await?,
            };
            lib["downloads"] = json!({"artifact": {"path": path, "url": url, "sha1": sha1.hex()}});
        }
        Ok(())
    }
}

fn read_profile(path: &Path, mc: &str) -> Result<VersionJson> {
    let profile: VersionJson = serde_json::from_slice(&std::fs::read(path)?)?;
    if profile.inherits_from.as_deref() != Some(mc) {
        return Err(
            LaunchError::LoaderInstall("the saved loader profile doesn't match".into()).into(),
        );
    }
    Ok(profile)
}

#[cfg(test)]
mod tests {
    use serde_json::json;
    use wiremock::matchers::path;
    use wiremock::{Mock, MockServer, ResponseTemplate};

    use super::*;
    use crate::download::RetryPolicy;
    use std::time::Duration;

    pub(crate) fn test_client(server_uri: &str, cache: &Path) -> LoaderClient {
        let policy = || HostPolicy::new(&[]).with_loopback_http();
        let dl = || {
            Downloader::new(HttpClient::new_for_downloads("t/0", policy()).unwrap(), 2).with_retry(
                RetryPolicy {
                    attempts: 2,
                    base_delay: Duration::from_millis(1),
                },
            )
        };
        let mojang = MojangClient::with_clients(
            HttpClient::new("t/0", policy()).unwrap(),
            dl(),
            cache,
            format!("{server_uri}/manifest.json"),
            format!("{server_uri}/assets/"),
        );
        LoaderClient::with_clients(
            HttpClient::new("t/0", policy()).unwrap(),
            dl(),
            mojang,
            Endpoints {
                fabric_meta: server_uri.into(),
                quilt_meta: format!("{server_uri}/quilt"),
                neoforge_maven: format!("{server_uri}/neo"),
                forge_maven: format!("{server_uri}/forge"),
            },
        )
    }

    async fn json_at(server: &MockServer, p: &str, v: serde_json::Value) {
        Mock::given(path(p.to_owned()))
            .respond_with(ResponseTemplate::new(200).set_body_json(v))
            .mount(server)
            .await;
    }

    #[test]
    fn kinds_round_trip_the_database_strings() {
        for k in [
            LoaderKind::Vanilla,
            LoaderKind::Fabric,
            LoaderKind::Quilt,
            LoaderKind::Neoforge,
            LoaderKind::Forge,
        ] {
            assert_eq!(LoaderKind::parse(k.as_str()), Some(k));
        }
        assert_eq!(LoaderKind::parse("optifine"), None);
    }

    #[test]
    fn version_mapping_helpers() {
        assert_eq!(neoforge_mc_version("21.1.77").as_deref(), Some("1.21.1"));
        assert_eq!(neoforge_mc_version("21.0.5-beta").as_deref(), Some("1.21"));
        assert_eq!(neoforge_mc_version("20.4.237").as_deref(), Some("1.20.4"));
        assert_eq!(
            neoforge_mc_version("47.1.0"),
            None,
            "legacy Forge numbering"
        );
        assert_eq!(
            neoforge_mc_version("26.1.0.0"),
            None,
            "beyond the 1.x scheme"
        );
        assert_eq!(mc_minor("1.20.1"), Some(20));
        assert_eq!(mc_minor("1.21"), Some(21));
        assert_eq!(mc_minor("24w14a"), None);
        assert_eq!(mc_minor("1.7.10_pre4"), None);
        assert_eq!(
            xml_versions("<versions><version>1.0</version>\n<version> 2.0 </version></versions>"),
            ["1.0", "2.0"]
        );
    }

    #[tokio::test]
    async fn fabric_lists_versions_for_the_picker() {
        let server = MockServer::start().await;
        json_at(
            &server,
            "/v2/versions/game",
            json!([{"version": "1.21.1", "stable": true}, {"version": "../evil"}]),
        )
        .await;
        json_at(&server, "/v2/versions/loader/1.21.1", json!([
            {"loader": {"version": "0.16.5", "stable": true}}, {"loader": {"version": "0.17.0-beta.1", "stable": false}}
        ])).await;
        json_at(
            &server,
            "/quilt/v3/versions/loader/1.21.1",
            json!([{"loader": {"version": "0.26.4"}}, {"loader": {"version": "0.27.0-beta.1"}}]),
        )
        .await;
        let dir = tempfile::tempdir().unwrap();
        let c = test_client(&server.uri(), dir.path());

        assert_eq!(
            c.game_versions(LoaderKind::Fabric).await.unwrap(),
            ["1.21.1"],
            "unsafe ids are dropped"
        );
        let v = c
            .loader_versions(LoaderKind::Fabric, "1.21.1")
            .await
            .unwrap();
        assert_eq!(
            v,
            [
                LoaderVersion {
                    version: "0.16.5".into(),
                    stable: true
                },
                LoaderVersion {
                    version: "0.17.0-beta.1".into(),
                    stable: false
                }
            ]
        );
        let q = c
            .loader_versions(LoaderKind::Quilt, "1.21.1")
            .await
            .unwrap();
        assert_eq!(
            (q[0].stable, q[1].stable),
            (true, false),
            "Quilt has no stable flag: betas are inferred"
        );
        assert!(c.loader_versions(LoaderKind::Fabric, "../x").await.is_err());
    }

    #[tokio::test]
    async fn forge_and_neoforge_list_only_compatible_combinations() {
        let server = MockServer::start().await;
        Mock::given(path("/forge/net/minecraftforge/forge/maven-metadata.xml")).respond_with(ResponseTemplate::new(200).set_body_string(
            "<metadata><versioning><versions><version>1.12.2-14.23.5.2860</version><version>1.20.1-47.2.0</version><version>1.20.1-47.3.0</version><version>1.21-51.0.1</version></versions></versioning></metadata>")).mount(&server).await;
        Mock::given(path("/neo/net/neoforged/neoforge/maven-metadata.xml")).respond_with(ResponseTemplate::new(200).set_body_string(
            "<metadata><versioning><versions><version>20.4.1</version><version>21.1.77</version><version>21.1.78-beta</version><version>26.1.0.0</version></versions></versioning></metadata>")).mount(&server).await;
        let dir = tempfile::tempdir().unwrap();
        let c = test_client(&server.uri(), dir.path());

        assert_eq!(
            c.game_versions(LoaderKind::Forge).await.unwrap(),
            ["1.21", "1.20.1"],
            "1.12.2 is hidden"
        );
        let v = c
            .loader_versions(LoaderKind::Forge, "1.20.1")
            .await
            .unwrap();
        assert_eq!(
            v.iter().map(|x| x.version.as_str()).collect::<Vec<_>>(),
            ["47.3.0", "47.2.0"],
            "newest first"
        );
        assert!(c
            .loader_versions(LoaderKind::Forge, "1.12.2")
            .await
            .unwrap()
            .is_empty());
        let n = c
            .loader_versions(LoaderKind::Neoforge, "1.21.1")
            .await
            .unwrap();
        assert_eq!(
            (n[0].version.as_str(), n[0].stable, n[1].stable),
            ("21.1.78-beta", false, true)
        );
        assert!(c
            .loader_versions(LoaderKind::Neoforge, "1.19.2")
            .await
            .unwrap()
            .is_empty());
    }

    #[tokio::test]
    async fn fabric_profiles_get_verified_download_entries_and_are_saved() {
        let server = MockServer::start().await;
        let s = server.uri();
        json_at(&server, "/v2/versions/loader/1.21.1/0.16.5/profile/json", json!({
            "id": "fabric-loader-0.16.5-1.21.1", "inheritsFrom": "1.21.1", "type": "release",
            "mainClass": "net.fabricmc.loader.impl.launch.knot.KnotClient",
            "arguments": {"game": [], "jvm": ["-DFabricMcEmu= net.minecraft.client.main.Main "]},
            "libraries": [
                {"name": "net.fabricmc:fabric-loader:0.16.5", "url": format!("{s}/maven/")},
                {"name": "net.fabricmc:with-hash:1", "url": format!("{s}/maven"), "sha1": "c".repeat(40)}
            ]
        })).await;
        Mock::given(path(
            "/maven/net/fabricmc/fabric-loader/0.16.5/fabric-loader-0.16.5.jar.sha1",
        ))
        .respond_with(
            ResponseTemplate::new(200)
                .set_body_string(format!("{}  fabric-loader-0.16.5.jar\n", "a".repeat(40))),
        )
        .mount(&server)
        .await;
        let dir = tempfile::tempdir().unwrap();
        let c = test_client(&s, dir.path());
        let ctx = InstallContext {
            java: Path::new("/nonexistent"),
            client_jar: Path::new("/nonexistent"),
        };

        let p = c
            .ensure_installed(LoaderKind::Fabric, "1.21.1", "0.16.5", &ctx)
            .await
            .unwrap();
        assert_eq!(
            p.main_class,
            "net.fabricmc.loader.impl.launch.knot.KnotClient"
        );
        let libs = p
            .resolve_libraries(&crate::mojang::rules::Environment::current())
            .unwrap()
            .classpath;
        assert_eq!(
            libs[0].path,
            "net/fabricmc/fabric-loader/0.16.5/fabric-loader-0.16.5.jar"
        );
        assert_eq!(
            libs[0].sha1,
            "a".repeat(40),
            "taken from the repository's .sha1 file"
        );
        assert_eq!(libs[1].sha1, "c".repeat(40));
        assert_eq!(
            libs[1].url,
            format!("{s}/maven/net/fabricmc/with-hash/1/with-hash-1.jar")
        );

        // Saved: a second call needs no network at all.
        server.reset().await;
        let again = c
            .ensure_installed(LoaderKind::Fabric, "1.21.1", "0.16.5", &ctx)
            .await
            .unwrap();
        assert_eq!(again.id, p.id);
    }

    #[tokio::test]
    async fn an_unknown_loader_version_is_reported_as_incompatible() {
        let server = MockServer::start().await;
        Mock::given(path("/v2/versions/loader/1.21.1/9.9.9/profile/json"))
            .respond_with(ResponseTemplate::new(400))
            .mount(&server)
            .await;
        let dir = tempfile::tempdir().unwrap();
        let c = test_client(&server.uri(), dir.path());
        let ctx = InstallContext {
            java: Path::new("/x"),
            client_jar: Path::new("/x"),
        };
        let err = c
            .ensure_installed(LoaderKind::Fabric, "1.21.1", "9.9.9", &ctx)
            .await
            .unwrap_err();
        assert!(
            matches!(err, Error::Launch(LaunchError::IncompatibleLoader(..))),
            "{err:?}"
        );
        for (kind, mc, lv) in [
            (LoaderKind::Forge, "1.12.2", "14.23.5.2860"),
            (LoaderKind::Neoforge, "1.21.1", "20.4.1"),
            (LoaderKind::Vanilla, "1.21.1", "1"),
        ] {
            assert!(
                c.ensure_installed(kind, mc, lv, &ctx).await.is_err(),
                "{kind:?}"
            );
        }
    }

    #[tokio::test]
    async fn a_profile_for_the_wrong_minecraft_version_is_rejected_and_not_saved() {
        let server = MockServer::start().await;
        json_at(&server, "/v2/versions/loader/1.21.1/0.16.5/profile/json", json!({
            "id": "x", "inheritsFrom": "1.20.4", "type": "release", "mainClass": "M", "libraries": []
        })).await;
        let dir = tempfile::tempdir().unwrap();
        let c = test_client(&server.uri(), dir.path());
        let ctx = InstallContext {
            java: Path::new("/x"),
            client_jar: Path::new("/x"),
        };
        assert!(c
            .ensure_installed(LoaderKind::Fabric, "1.21.1", "0.16.5", &ctx)
            .await
            .is_err());
        assert!(!dir
            .path()
            .join("loaders/fabric-1.21.1-0.16.5.json")
            .exists());
    }
}
