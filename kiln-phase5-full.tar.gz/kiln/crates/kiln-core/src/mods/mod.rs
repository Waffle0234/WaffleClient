//! Mod catalogues (Modrinth today), installing and updating mods, dependency resolution,
//! update backups with automatic rollback, and Modrinth modpacks.

pub mod cache;
pub mod error;
pub mod modrinth;
pub mod service;
pub mod source;
pub mod store;
#[cfg(test)]
mod testkit;

pub use error::ModsError;

/// Sent to Modrinth in the User-Agent so they can reach the maintainers. Change this to the
/// project's real contact page before a release.
pub const CONTACT: &str = "https://github.com/Waffle0234/WaffleClient";
