//! ETag cache for API responses, backed by the `http_cache` table. Bodies live in files
//! under `cache/http/`. The table's `url` column holds a SHA-256 of the request URL, not the
//! URL itself, so what someone searched for isn't readable in the database.

use std::path::{Path, PathBuf};

use crate::db::Db;
use crate::hash::{hash_bytes, HashAlgo};
use crate::paths::SafePath;
use crate::Result;

#[derive(Debug, Clone)]
pub struct CachedEntry {
    pub etag: Option<String>,
    pub body: Vec<u8>,
    pub fetched_at: i64,
}

#[derive(Debug, Clone)]
pub struct HttpCache {
    db: Db,
    dir: PathBuf,
}

fn now() -> i64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map_or(0, |d| i64::try_from(d.as_secs()).unwrap_or(0))
}

/// Entries older than this are deleted when the cache opens.
const MAX_AGE_SECS: i64 = 7 * 24 * 3600;

impl HttpCache {
    pub async fn open(db: Db, dir: &Path) -> Result<Self> {
        std::fs::create_dir_all(dir)?;
        let cache = Self {
            db,
            dir: dir.to_path_buf(),
        };
        cache.prune(MAX_AGE_SECS).await?;
        Ok(cache)
    }

    pub fn key(url: &str) -> String {
        hash_bytes(HashAlgo::Sha256, url.as_bytes())
    }

    fn body_name(key: &str) -> String {
        format!("{key}.json")
    }

    pub async fn get(&self, url: &str) -> Result<Option<CachedEntry>> {
        let key = Self::key(url);
        let row: Option<(Option<String>, String, i64)> =
            sqlx::query_as("SELECT etag, body_path, fetched_at FROM http_cache WHERE url = ?1")
                .bind(&key)
                .fetch_optional(&self.db)
                .await?;
        let Some((etag, body_path, fetched_at)) = row else {
            return Ok(None);
        };
        // The stored name must be the one we would have written; anything else is ignored.
        if body_path != Self::body_name(&key) {
            return Ok(None);
        }
        let path = SafePath::new(&self.dir, &body_path)?;
        match std::fs::read(path.as_path()) {
            Ok(body) => Ok(Some(CachedEntry {
                etag,
                body,
                fetched_at,
            })),
            Err(_) => Ok(None),
        }
    }

    pub async fn put(&self, url: &str, etag: Option<&str>, body: &[u8]) -> Result<()> {
        let key = Self::key(url);
        let name = Self::body_name(&key);
        let path = SafePath::new(&self.dir, &name)?;
        let tmp = SafePath::new(&self.dir, &format!("{key}.tmp"))?;
        std::fs::write(tmp.as_path(), body)?;
        std::fs::rename(tmp.as_path(), path.as_path())?;
        sqlx::query(
            "INSERT INTO http_cache (url, etag, body_path, fetched_at) VALUES (?1, ?2, ?3, ?4)
             ON CONFLICT(url) DO UPDATE SET etag = ?2, body_path = ?3, fetched_at = ?4",
        )
        .bind(&key)
        .bind(etag)
        .bind(&name)
        .bind(now())
        .execute(&self.db)
        .await?;
        Ok(())
    }

    /// The server said the cached copy is still current.
    pub async fn touch(&self, url: &str) -> Result<()> {
        sqlx::query("UPDATE http_cache SET fetched_at = ?2 WHERE url = ?1")
            .bind(Self::key(url))
            .bind(now())
            .execute(&self.db)
            .await?;
        Ok(())
    }

    async fn prune(&self, max_age_secs: i64) -> Result<()> {
        let old: Vec<(String, String)> =
            sqlx::query_as("SELECT url, body_path FROM http_cache WHERE fetched_at < ?1")
                .bind(now() - max_age_secs)
                .fetch_all(&self.db)
                .await?;
        for (key, body) in old {
            if body == Self::body_name(&key) {
                if let Ok(p) = SafePath::new(&self.dir, &body) {
                    let _ = std::fs::remove_file(p.as_path());
                }
            }
            sqlx::query("DELETE FROM http_cache WHERE url = ?1")
                .bind(&key)
                .execute(&self.db)
                .await?;
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::db;

    #[tokio::test]
    async fn stores_and_returns_bodies_without_the_url_in_the_database() {
        let dir = tempfile::tempdir().unwrap();
        let db = db::open_in_memory().await.unwrap();
        let cache = HttpCache::open(db.clone(), dir.path()).await.unwrap();
        let url = "https://api.modrinth.com/v2/search?query=secret-term";
        assert!(cache.get(url).await.unwrap().is_none());
        cache.put(url, Some("\"abc\""), b"{\"x\":1}").await.unwrap();
        let hit = cache.get(url).await.unwrap().unwrap();
        assert_eq!(hit.body, b"{\"x\":1}");
        assert_eq!(hit.etag.as_deref(), Some("\"abc\""));

        let (stored,): (String,) = sqlx::query_as("SELECT url FROM http_cache")
            .fetch_one(&db)
            .await
            .unwrap();
        assert!(!stored.contains("secret-term") && !stored.contains("modrinth"));
    }

    #[tokio::test]
    async fn old_entries_are_pruned_with_their_files() {
        let dir = tempfile::tempdir().unwrap();
        let db = db::open_in_memory().await.unwrap();
        let cache = HttpCache::open(db.clone(), dir.path()).await.unwrap();
        cache.put("https://a.example/x", None, b"1").await.unwrap();
        sqlx::query("UPDATE http_cache SET fetched_at = 1")
            .execute(&db)
            .await
            .unwrap();
        let reopened = HttpCache::open(db.clone(), dir.path()).await.unwrap();
        assert!(reopened.get("https://a.example/x").await.unwrap().is_none());
        assert_eq!(std::fs::read_dir(dir.path()).unwrap().count(), 0);
    }

    #[tokio::test]
    async fn a_tampered_body_path_is_not_followed() {
        let dir = tempfile::tempdir().unwrap();
        let db = db::open_in_memory().await.unwrap();
        let cache = HttpCache::open(db.clone(), dir.path()).await.unwrap();
        cache.put("https://a.example/x", None, b"1").await.unwrap();
        sqlx::query("UPDATE http_cache SET body_path = '../../etc/passwd'")
            .execute(&db)
            .await
            .unwrap();
        assert!(cache.get("https://a.example/x").await.unwrap().is_none());
    }
}
