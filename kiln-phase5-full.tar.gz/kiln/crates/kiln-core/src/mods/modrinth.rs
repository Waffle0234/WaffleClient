//! Modrinth API v2 as a [`ModSource`].
//!
//! Requests go through the allowlisted [`HttpClient`] (host `api.modrinth.com` only).
//! GET responses are cached by URL with their ETag; a cached copy younger than the TTL is
//! used without a request at all, which keeps Kiln well inside Modrinth's rate limit.
//! Rate-limit headers are honoured: when the quota is spent or the server answers 429,
//! calls wait briefly or fail with a "try again in N seconds" message instead of hammering.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

use reqwest::{Method, Url};
use serde::Deserialize;
use tokio::sync::Semaphore;

use super::cache::HttpCache;
use super::source::*;
use super::{ModsError, CONTACT};
use crate::net::{Body, HostPolicy, HttpClient, HttpResponse};
use crate::{Error, Result, APP_NAME, APP_VERSION};

const API_BASE: &str = "https://api.modrinth.com/v2";
/// Longest a call will sleep for the rate limit before giving up with an error instead.
const MAX_WAIT: Duration = Duration::from_secs(15);
/// Cached GET responses younger than this are served without asking Modrinth.
const DEFAULT_TTL: Duration = Duration::from_secs(300);
/// Hashes per lookup call. Responses include changelogs, so batches are kept small enough
/// to stay under the client's response size cap.
const HASH_BATCH: usize = 25;
const ID_BATCH: usize = 25;

/// Modrinth asks API clients to say who they are and how to reach them.
pub fn user_agent() -> String {
    format!("{APP_NAME}/{APP_VERSION} ({CONTACT})")
}

pub fn api_policy() -> HostPolicy {
    HostPolicy::new(&["api.modrinth.com"])
}

/// Where Modrinth serves files from.
pub fn download_policy() -> HostPolicy {
    HostPolicy::new(&["cdn.modrinth.com"])
}

#[derive(Debug, Default)]
struct LimitState {
    blocked_until: Option<Instant>,
}

#[derive(Debug)]
struct Limiter {
    state: Mutex<LimitState>,
    permits: Semaphore,
}

impl Limiter {
    fn new() -> Self {
        Self {
            state: Mutex::new(LimitState::default()),
            permits: Semaphore::new(4),
        }
    }

    fn blocked_for(&self) -> Option<Duration> {
        let s = self.state.lock().unwrap_or_else(|e| e.into_inner());
        s.blocked_until
            .and_then(|t| t.checked_duration_since(Instant::now()))
            .filter(|d| !d.is_zero())
    }

    /// Wait out a short block, or fail if it is long.
    async fn wait_turn(&self) -> Result<()> {
        if let Some(wait) = self.blocked_for() {
            if wait > MAX_WAIT {
                return Err(ModsError::RateLimited {
                    retry_secs: wait.as_secs() + 1,
                }
                .into());
            }
            tokio::time::sleep(wait).await;
        }
        Ok(())
    }

    fn record(&self, resp: &HttpResponse) {
        let reset = resp
            .header("x-ratelimit-reset")
            .or_else(|| resp.header("retry-after"))
            .and_then(|v| v.trim().parse::<u64>().ok());
        let remaining = resp
            .header("x-ratelimit-remaining")
            .and_then(|v| v.trim().parse::<u64>().ok());
        let block = if resp.status == 429 {
            Some(reset.unwrap_or(60).clamp(1, 300))
        } else if remaining == Some(0) {
            Some(reset.unwrap_or(10).clamp(1, 300))
        } else {
            None
        };
        if let Some(secs) = block {
            let mut s = self.state.lock().unwrap_or_else(|e| e.into_inner());
            s.blocked_until = Some(Instant::now() + Duration::from_secs(secs));
        }
    }
}

#[derive(Clone)]
pub struct Modrinth {
    http: HttpClient,
    base: String,
    cache: Option<HttpCache>,
    limiter: Arc<Limiter>,
    ttl: Duration,
    downloads: HostPolicy,
}

impl std::fmt::Debug for Modrinth {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("Modrinth { .. }")
    }
}

impl Modrinth {
    pub fn new(cache: Option<HttpCache>) -> Result<Self> {
        Ok(Self::with_client(
            HttpClient::new(&user_agent(), api_policy())?,
            API_BASE,
            cache,
        ))
    }

    pub(crate) fn with_client(http: HttpClient, base: &str, cache: Option<HttpCache>) -> Self {
        Self {
            http,
            base: base.trim_end_matches('/').to_owned(),
            cache,
            limiter: Arc::new(Limiter::new()),
            ttl: DEFAULT_TTL,
            downloads: download_policy(),
        }
    }

    /// Test-only: let files be fetched from a loopback mock server.
    #[cfg(test)]
    pub(crate) fn with_download_policy(mut self, policy: HostPolicy) -> Self {
        self.downloads = policy;
        self
    }

    #[cfg(test)]
    pub(crate) fn with_ttl(mut self, ttl: Duration) -> Self {
        self.ttl = ttl;
        self
    }

    fn url(&self, path: &str, params: &[(&str, String)]) -> Result<String> {
        let full = format!("{}{path}", self.base);
        let url = if params.is_empty() {
            Url::parse(&full)
        } else {
            Url::parse_with_params(&full, params.iter().map(|(k, v)| (*k, v.as_str())))
        }
        .map_err(|_| Error::Http("could not build a request".into()))?;
        Ok(url.into())
    }

    fn status_error(resp: &HttpResponse) -> Error {
        match resp.status {
            404 => ModsError::NotFound.into(),
            429 => ModsError::RateLimited {
                retry_secs: resp
                    .header("x-ratelimit-reset")
                    .or_else(|| resp.header("retry-after"))
                    .and_then(|v| v.trim().parse().ok())
                    .unwrap_or(60),
            }
            .into(),
            other => Error::Http(format!("Modrinth answered with status {other}")),
        }
    }

    /// GET with caching. Returns the body bytes.
    async fn get(&self, url: &str) -> Result<Vec<u8>> {
        let cached = match &self.cache {
            Some(c) => c.get(url).await.unwrap_or(None),
            None => None,
        };
        if let Some(c) = &cached {
            let age = std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .map_or(i64::MAX, |d| i64::try_from(d.as_secs()).unwrap_or(i64::MAX));
            if age.saturating_sub(c.fetched_at) < i64::try_from(self.ttl.as_secs()).unwrap_or(0) {
                return Ok(c.body.clone());
            }
        }
        self.limiter.wait_turn().await?;
        let _permit = self
            .limiter
            .permits
            .acquire()
            .await
            .map_err(|_| Error::Http("the request queue was closed".into()))?;
        let etag = cached.as_ref().and_then(|c| c.etag.clone());
        let extra: Vec<(&str, &str)> = etag
            .as_deref()
            .map(|e| vec![("If-None-Match", e)])
            .unwrap_or_default();
        let resp = self
            .http
            .execute_with(Method::GET, url, Body::Empty, None, &extra)
            .await?;
        self.limiter.record(&resp);
        if resp.status == 304 {
            if let (Some(c), Some(cache)) = (cached, &self.cache) {
                let _ = cache.touch(url).await;
                return Ok(c.body);
            }
        }
        if !resp.is_success() {
            return Err(Self::status_error(&resp));
        }
        if let Some(cache) = &self.cache {
            if let Err(e) = cache.put(url, resp.header("etag"), resp.bytes()).await {
                tracing::warn!(error = %e, "could not cache a Modrinth response");
            }
        }
        Ok(resp.bytes().to_vec())
    }

    async fn get_json<T: serde::de::DeserializeOwned>(&self, url: &str) -> Result<T> {
        let bytes = self.get(url).await?;
        serde_json::from_slice(&bytes)
            .map_err(|_| ModsError::BadResponse("unreadable JSON".into()).into())
    }

    async fn post_json<T: serde::de::DeserializeOwned>(
        &self,
        path: &str,
        body: &serde_json::Value,
    ) -> Result<T> {
        let url = self.url(path, &[])?;
        self.limiter.wait_turn().await?;
        let _permit = self
            .limiter
            .permits
            .acquire()
            .await
            .map_err(|_| Error::Http("the request queue was closed".into()))?;
        let resp = self
            .http
            .execute_with(Method::POST, &url, Body::Json(body), None, &[])
            .await?;
        self.limiter.record(&resp);
        if !resp.is_success() {
            return Err(Self::status_error(&resp));
        }
        resp.json()
    }
}

// ---- wire formats -------------------------------------------------------------------

#[derive(Deserialize)]
struct WireSearch {
    #[serde(default)]
    hits: Vec<WireHit>,
    #[serde(default)]
    offset: u32,
    #[serde(default)]
    total_hits: u64,
}

#[derive(Deserialize)]
struct WireHit {
    project_id: String,
    #[serde(default)]
    slug: String,
    #[serde(default)]
    title: String,
    #[serde(default)]
    description: String,
    #[serde(default)]
    author: String,
    #[serde(default)]
    project_type: String,
    #[serde(default)]
    downloads: u64,
    #[serde(default)]
    follows: u64,
    #[serde(default)]
    icon_url: Option<String>,
    #[serde(default)]
    display_categories: Vec<String>,
    #[serde(default)]
    client_side: String,
    #[serde(default)]
    server_side: String,
    #[serde(default)]
    license: Option<String>,
}

#[derive(Deserialize)]
struct WireLicense {
    #[serde(default)]
    id: String,
    #[serde(default)]
    name: String,
    #[serde(default)]
    url: Option<String>,
}

#[derive(Deserialize)]
struct WireProject {
    id: String,
    #[serde(default)]
    slug: String,
    #[serde(default)]
    title: String,
    #[serde(default)]
    description: String,
    #[serde(default)]
    body: String,
    #[serde(default)]
    project_type: String,
    #[serde(default)]
    team: String,
    #[serde(default)]
    downloads: u64,
    #[serde(default)]
    followers: u64,
    #[serde(default)]
    icon_url: Option<String>,
    #[serde(default)]
    license: Option<WireLicense>,
    #[serde(default)]
    categories: Vec<String>,
    #[serde(default)]
    loaders: Vec<String>,
    #[serde(default)]
    game_versions: Vec<String>,
    #[serde(default)]
    client_side: String,
    #[serde(default)]
    server_side: String,
}

#[derive(Deserialize)]
struct WireMember {
    #[serde(default)]
    role: String,
    user: WireUser,
}

#[derive(Deserialize)]
struct WireUser {
    #[serde(default)]
    username: String,
}

#[derive(Deserialize)]
struct WireDependency {
    #[serde(default)]
    version_id: Option<String>,
    #[serde(default)]
    project_id: Option<String>,
    #[serde(default)]
    dependency_type: String,
}

#[derive(Deserialize, Default)]
struct WireHashes {
    #[serde(default)]
    sha1: Option<String>,
    #[serde(default)]
    sha512: Option<String>,
}

#[derive(Deserialize)]
struct WireFile {
    #[serde(default)]
    hashes: WireHashes,
    #[serde(default)]
    url: String,
    #[serde(default)]
    filename: String,
    #[serde(default)]
    primary: bool,
    #[serde(default)]
    size: u64,
}

#[derive(Deserialize)]
struct WireVersion {
    id: String,
    project_id: String,
    #[serde(default)]
    name: String,
    #[serde(default)]
    version_number: String,
    #[serde(default)]
    changelog: Option<String>,
    #[serde(default)]
    version_type: String,
    #[serde(default)]
    game_versions: Vec<String>,
    #[serde(default)]
    loaders: Vec<String>,
    #[serde(default)]
    date_published: String,
    #[serde(default)]
    dependencies: Vec<WireDependency>,
    #[serde(default)]
    files: Vec<WireFile>,
}

fn hex_of(value: Option<String>, len: usize) -> Option<String> {
    value
        .map(|h| h.to_ascii_lowercase())
        .filter(|h| h.len() == len && h.chars().all(|c| c.is_ascii_hexdigit()))
}

impl From<WireVersion> for ModVersion {
    fn from(v: WireVersion) -> Self {
        Self {
            id: v.id,
            project_id: v.project_id,
            name: v.name,
            version_number: v.version_number,
            changelog: v.changelog.filter(|c| !c.trim().is_empty()),
            channel: Channel::parse(&v.version_type),
            game_versions: v.game_versions,
            loaders: v.loaders,
            date_published: v.date_published,
            dependencies: v
                .dependencies
                .into_iter()
                .filter_map(|d| {
                    let kind = match d.dependency_type.as_str() {
                        "required" => DependencyKind::Required,
                        "optional" => DependencyKind::Optional,
                        "incompatible" => DependencyKind::Incompatible,
                        "embedded" => DependencyKind::Embedded,
                        _ => return None,
                    };
                    Some(Dependency {
                        project_id: d.project_id.filter(|p| is_valid_id(p)),
                        version_id: d.version_id.filter(|p| is_valid_id(p)),
                        kind,
                    })
                })
                .collect(),
            files: v
                .files
                .into_iter()
                .map(|f| VersionFile {
                    url: f.url,
                    filename: f.filename,
                    size: f.size,
                    primary: f.primary,
                    hashes: FileHashes {
                        sha1: hex_of(f.hashes.sha1, 40),
                        sha512: hex_of(f.hashes.sha512, 128),
                    },
                })
                .collect(),
        }
    }
}

fn json_list(items: &[String]) -> String {
    serde_json::to_string(items).unwrap_or_else(|_| "[]".into())
}

impl ModSource for Modrinth {
    fn name(&self) -> &'static str {
        "modrinth"
    }

    fn download_policy(&self) -> HostPolicy {
        self.downloads.clone()
    }

    async fn search(&self, q: &SearchQuery) -> Result<SearchPage> {
        let q = q.clone().validated()?;
        let mut facets: Vec<Vec<String>> = vec![vec![format!("project_type:{}", q.kind.as_str())]];
        if let Some(v) = &q.mc_version {
            facets.push(vec![format!("versions:{v}")]);
        }
        if q.kind == ProjectKind::Mod {
            if let Some(loader) = q.loader {
                let names = VersionFilter::for_instance(loader, "").loaders;
                if !names.is_empty() {
                    facets.push(
                        names
                            .into_iter()
                            .map(|n| format!("categories:{n}"))
                            .collect(),
                    );
                }
            }
        }
        for c in &q.categories {
            facets.push(vec![format!("categories:{c}")]);
        }
        let params = [
            ("query", q.query.clone()),
            (
                "facets",
                serde_json::to_string(&facets)
                    .map_err(|_| Error::Http("could not build a request".into()))?,
            ),
            ("index", q.sort.as_str().to_owned()),
            ("offset", q.offset.to_string()),
            ("limit", q.limit.to_string()),
        ];
        let url = self.url("/search", &params)?;
        let wire: WireSearch = self.get_json(&url).await?;
        Ok(SearchPage {
            offset: wire.offset,
            total: wire.total_hits,
            hits: wire
                .hits
                .into_iter()
                .map(|h| SearchHit {
                    id: h.project_id,
                    slug: h.slug,
                    title: h.title,
                    description: h.description,
                    author: h.author,
                    kind: ProjectKind::parse(&h.project_type).unwrap_or(q.kind),
                    downloads: h.downloads,
                    follows: h.follows,
                    icon_url: h
                        .icon_url
                        .filter(|u| u.starts_with("https://cdn.modrinth.com/")),
                    categories: h.display_categories,
                    client_side: h.client_side,
                    server_side: h.server_side,
                    license: h.license.filter(|l| !l.is_empty()),
                })
                .collect(),
        })
    }

    async fn project(&self, id: &str) -> Result<Project> {
        check_id(id)?;
        self.projects(&[id.to_owned()])
            .await?
            .into_iter()
            .next()
            .ok_or_else(|| ModsError::NotFound.into())
    }

    async fn projects(&self, ids: &[String]) -> Result<Vec<Project>> {
        let mut out = Vec::new();
        for chunk in ids.chunks(ID_BATCH) {
            for id in chunk {
                check_id(id)?;
            }
            let url = self.url("/projects", &[("ids", json_list(chunk))])?;
            let wire: Vec<WireProject> = self.get_json(&url).await?;
            let teams: Vec<String> = wire
                .iter()
                .map(|p| p.team.clone())
                .filter(|t| is_valid_id(t))
                .collect();
            let mut owners: HashMap<String, String> = HashMap::new();
            if !teams.is_empty() {
                let url = self.url("/teams", &[("ids", json_list(&teams))])?;
                // The author is a nicety: a failure here must not hide the project.
                if let Ok(lists) = self.get_json::<Vec<Vec<WireMember>>>(&url).await {
                    for (team, members) in teams.iter().zip(lists) {
                        let owner = members
                            .iter()
                            .find(|m| m.role.eq_ignore_ascii_case("owner"))
                            .or_else(|| members.first());
                        if let Some(m) = owner {
                            owners.insert(team.clone(), m.user.username.clone());
                        }
                    }
                }
            }
            for p in wire {
                out.push(Project {
                    author: owners.get(&p.team).cloned(),
                    kind: ProjectKind::parse(&p.project_type).unwrap_or(ProjectKind::Mod),
                    id: p.id,
                    slug: p.slug,
                    title: p.title,
                    description: p.description,
                    body: p.body,
                    downloads: p.downloads,
                    follows: p.followers,
                    icon_url: p
                        .icon_url
                        .filter(|u| u.starts_with("https://cdn.modrinth.com/")),
                    license: p.license.map(|l| License {
                        id: l.id,
                        name: l.name,
                        url: l.url.filter(|u| u.starts_with("https://")),
                    }),
                    categories: p.categories,
                    loaders: p.loaders,
                    game_versions: p.game_versions,
                    client_side: p.client_side,
                    server_side: p.server_side,
                });
            }
        }
        Ok(out)
    }

    async fn versions(&self, project: &str, filter: &VersionFilter) -> Result<Vec<ModVersion>> {
        check_id(project)?;
        let mut params = Vec::new();
        if !filter.loaders.is_empty() {
            params.push(("loaders", json_list(&filter.loaders)));
        }
        if !filter.game_versions.is_empty() {
            params.push(("game_versions", json_list(&filter.game_versions)));
        }
        let url = self.url(&format!("/project/{project}/version"), &params)?;
        let wire: Vec<WireVersion> = self.get_json(&url).await?;
        Ok(wire.into_iter().map(Into::into).collect())
    }

    async fn version(&self, id: &str) -> Result<ModVersion> {
        check_id(id)?;
        let url = self.url(&format!("/version/{id}"), &[])?;
        let wire: WireVersion = self.get_json(&url).await?;
        Ok(wire.into())
    }

    async fn versions_by_ids(&self, ids: &[String]) -> Result<Vec<ModVersion>> {
        let mut out = Vec::new();
        for chunk in ids.chunks(ID_BATCH) {
            for id in chunk {
                check_id(id)?;
            }
            let url = self.url("/versions", &[("ids", json_list(chunk))])?;
            let wire: Vec<WireVersion> = self.get_json(&url).await?;
            out.extend(wire.into_iter().map(ModVersion::from));
        }
        Ok(out)
    }

    async fn identify(&self, sha1s: &[String]) -> Result<HashMap<String, ModVersion>> {
        let mut out = HashMap::new();
        for chunk in sha1s.chunks(HASH_BATCH) {
            let body = serde_json::json!({ "hashes": chunk, "algorithm": "sha1" });
            let found: HashMap<String, WireVersion> =
                self.post_json("/version_files", &body).await?;
            out.extend(
                found
                    .into_iter()
                    .map(|(h, v)| (h.to_ascii_lowercase(), v.into())),
            );
        }
        Ok(out)
    }

    async fn latest_for(
        &self,
        sha1s: &[String],
        filter: &VersionFilter,
    ) -> Result<HashMap<String, ModVersion>> {
        let mut out = HashMap::new();
        for chunk in sha1s.chunks(HASH_BATCH) {
            let body = serde_json::json!({
                "hashes": chunk,
                "algorithm": "sha1",
                "loaders": filter.loaders,
                "game_versions": filter.game_versions,
            });
            let found: HashMap<String, WireVersion> =
                self.post_json("/version_files/update", &body).await?;
            out.extend(
                found
                    .into_iter()
                    .map(|(h, v)| (h.to_ascii_lowercase(), v.into())),
            );
        }
        Ok(out)
    }
}

#[cfg(test)]
mod tests {
    use std::time::Instant;

    use serde_json::json;
    use wiremock::matchers::{header_regex, method, path, path_regex};
    use wiremock::{Mock, MockServer, ResponseTemplate};

    use super::*;
    use crate::db;
    use crate::loader::LoaderKind;

    fn client(server: &MockServer) -> Modrinth {
        Modrinth::with_client(
            HttpClient::new(&user_agent(), HostPolicy::new(&[]).with_loopback_http()).unwrap(),
            &format!("{}/v2", server.uri()),
            None,
        )
    }

    fn sha(c: char, n: usize) -> String {
        std::iter::repeat_n(c, n).collect()
    }

    #[test]
    fn the_user_agent_names_the_app_its_version_and_a_contact() {
        let ua = user_agent();
        assert!(
            ua.starts_with(&format!("{APP_NAME}/{APP_VERSION} (")),
            "{ua}"
        );
        assert!(ua.contains(CONTACT) && CONTACT.starts_with("https://"));
    }

    #[tokio::test]
    async fn search_sends_the_user_agent_and_the_expected_filters() {
        let server = MockServer::start().await;
        Mock::given(method("GET"))
            .and(path("/v2/search"))
            .and(header_regex("user-agent", &regex::escape(CONTACT)))
            .respond_with(ResponseTemplate::new(200).set_body_json(json!({
                "hits": [{
                    "project_id": "AAAA", "slug": "sodium", "title": "Sodium", "description": "fast",
                    "author": "jelly", "project_type": "mod", "downloads": 10, "follows": 2,
                    "icon_url": "https://cdn.modrinth.com/i.png", "display_categories": ["optimization"],
                    "client_side": "required", "server_side": "unsupported", "license": "LGPL-3.0-only",
                }, {
                    "project_id": "BBBB", "slug": "x", "title": "X", "icon_url": "https://evil.example/i.png",
                }],
                "offset": 0, "total_hits": 2,
            })))
            .expect(1)
            .mount(&server)
            .await;
        let page = client(&server)
            .search(&SearchQuery {
                query: "sodium".into(),
                kind: ProjectKind::Mod,
                mc_version: Some("1.20.1".into()),
                loader: Some(LoaderKind::Quilt),
                categories: vec!["optimization".into()],
                sort: SortOrder::Downloads,
                offset: 0,
                limit: 0,
            })
            .await
            .unwrap();
        assert_eq!(page.total, 2);
        assert_eq!(page.hits[0].title, "Sodium");
        assert_eq!(page.hits[0].license.as_deref(), Some("LGPL-3.0-only"));
        assert_eq!(
            page.hits[1].icon_url, None,
            "icons must come from Modrinth's CDN"
        );

        let req = &server.received_requests().await.unwrap()[0];
        let q: std::collections::HashMap<_, _> = req.url.query_pairs().into_owned().collect();
        let facets: Vec<Vec<String>> = serde_json::from_str(&q["facets"]).unwrap();
        assert_eq!(
            facets,
            vec![
                vec!["project_type:mod"],
                vec!["versions:1.20.1"],
                vec!["categories:quilt", "categories:fabric"],
                vec!["categories:optimization"],
            ]
        );
        assert_eq!(
            (
                q["index"].as_str(),
                q["limit"].as_str(),
                q["query"].as_str()
            ),
            ("downloads", "20", "sodium")
        );
    }

    #[tokio::test]
    async fn bad_filters_and_ids_never_reach_the_network() {
        let server = MockServer::start().await;
        let c = client(&server);
        let base = SearchQuery {
            query: String::new(),
            kind: ProjectKind::Mod,
            mc_version: None,
            loader: None,
            categories: vec![],
            sort: SortOrder::Relevance,
            offset: 0,
            limit: 0,
        };
        for bad in [
            SearchQuery {
                mc_version: Some("1.20\"]".into()),
                ..base.clone()
            },
            SearchQuery {
                categories: vec!["a b".into()],
                ..base.clone()
            },
            SearchQuery {
                categories: vec!["x".into(); 9],
                ..base.clone()
            },
        ] {
            assert!(matches!(
                c.search(&bad).await,
                Err(Error::Mods(ModsError::InvalidFilter))
            ));
        }
        assert!(matches!(
            c.project("../admin").await,
            Err(Error::Mods(ModsError::InvalidId))
        ));
        assert!(c.versions("a/b", &VersionFilter::default()).await.is_err());
        assert!(c.version("a?x=1").await.is_err());
        assert!(c.projects(&["ok".into(), "no way".into()]).await.is_err());
        assert!(server.received_requests().await.unwrap().is_empty());
    }

    #[tokio::test]
    async fn paging_is_clamped() {
        let q = SearchQuery {
            query: "a\nb".into(),
            kind: ProjectKind::Mod,
            mc_version: None,
            loader: None,
            categories: vec![],
            sort: SortOrder::Relevance,
            offset: 999_999,
            limit: 5000,
        }
        .validated()
        .unwrap();
        assert_eq!((q.limit, q.offset, q.query.as_str()), (50, 10_000, "ab"));
    }

    #[tokio::test]
    async fn cached_responses_are_reused_then_revalidated_with_their_etag() {
        let server = MockServer::start().await;
        Mock::given(method("GET"))
            .and(path("/v2/project/AAAA/version"))
            .and(wiremock::matchers::header("if-none-match", "\"v1\""))
            .respond_with(ResponseTemplate::new(304))
            .expect(1)
            .mount(&server)
            .await;
        Mock::given(method("GET"))
            .and(path("/v2/project/AAAA/version"))
            .respond_with(
                ResponseTemplate::new(200)
                    .insert_header("etag", "\"v1\"")
                    .set_body_json(json!([{
                        "id": "vv", "project_id": "AAAA", "version_number": "1", "version_type": "release",
                    }])),
            )
            .expect(1)
            .mount(&server)
            .await;
        let dir = tempfile::tempdir().unwrap();
        let cache = HttpCache::open(db::open_in_memory().await.unwrap(), dir.path())
            .await
            .unwrap();
        let stale = Modrinth::with_client(
            HttpClient::new(&user_agent(), HostPolicy::new(&[]).with_loopback_http()).unwrap(),
            &format!("{}/v2", server.uri()),
            Some(cache.clone()),
        )
        .with_ttl(Duration::ZERO);
        let first = stale
            .versions("AAAA", &VersionFilter::default())
            .await
            .unwrap();
        // Past the TTL: asks again, gets 304, serves the cached body.
        let second = stale
            .versions("AAAA", &VersionFilter::default())
            .await
            .unwrap();
        assert_eq!(first, second);
        assert_eq!(server.received_requests().await.unwrap().len(), 2);

        // Within the TTL: no request at all.
        let fresh = Modrinth::with_client(
            HttpClient::new(&user_agent(), HostPolicy::new(&[]).with_loopback_http()).unwrap(),
            &format!("{}/v2", server.uri()),
            Some(cache),
        );
        assert_eq!(
            fresh
                .versions("AAAA", &VersionFilter::default())
                .await
                .unwrap(),
            first
        );
        assert_eq!(server.received_requests().await.unwrap().len(), 2);
    }

    #[tokio::test]
    async fn a_429_stops_further_requests_until_the_reset() {
        let server = MockServer::start().await;
        Mock::given(path_regex("/v2/.*"))
            .respond_with(ResponseTemplate::new(429).insert_header("x-ratelimit-reset", "30"))
            .expect(1)
            .mount(&server)
            .await;
        let c = client(&server);
        let first = c.project("AAAA").await.unwrap_err();
        assert!(
            matches!(
                first,
                Error::Mods(ModsError::RateLimited { retry_secs: 30 })
            ),
            "{first:?}"
        );
        let second = c.version("vvvv").await.unwrap_err();
        match second {
            Error::Mods(ModsError::RateLimited { retry_secs }) => {
                assert!((28..=31).contains(&retry_secs))
            }
            other => panic!("{other:?}"),
        }
        // `expect(1)` is checked when the server drops: the second call sent nothing.
    }

    #[tokio::test]
    async fn an_exhausted_quota_makes_the_next_call_wait_for_the_reset() {
        let server = MockServer::start().await;
        Mock::given(path("/v2/projects"))
            .respond_with(
                ResponseTemplate::new(200)
                    .insert_header("x-ratelimit-remaining", "0")
                    .insert_header("x-ratelimit-reset", "1")
                    .set_body_json(json!([])),
            )
            .mount(&server)
            .await;
        let c = client(&server);
        c.projects(&["AAAA".into()]).await.unwrap();
        let started = Instant::now();
        c.projects(&["BBBB".into()]).await.unwrap();
        assert!(
            started.elapsed() >= Duration::from_millis(900),
            "{:?}",
            started.elapsed()
        );
    }

    #[tokio::test]
    async fn status_codes_become_plain_errors() {
        let server = MockServer::start().await;
        Mock::given(path("/v2/version/gone"))
            .respond_with(ResponseTemplate::new(404))
            .mount(&server)
            .await;
        Mock::given(path("/v2/version/boom"))
            .respond_with(ResponseTemplate::new(500))
            .mount(&server)
            .await;
        Mock::given(path("/v2/version/junk"))
            .respond_with(ResponseTemplate::new(200).set_body_string("<html>"))
            .mount(&server)
            .await;
        let c = client(&server);
        assert!(matches!(
            c.version("gone").await,
            Err(Error::Mods(ModsError::NotFound))
        ));
        assert!(matches!(c.version("boom").await, Err(Error::Http(_))));
        assert!(matches!(
            c.version("junk").await,
            Err(Error::Mods(ModsError::BadResponse(_)))
        ));
    }

    #[tokio::test]
    async fn hash_lookups_are_sent_in_batches() {
        let server = MockServer::start().await;
        Mock::given(method("POST"))
            .and(path("/v2/version_files"))
            .respond_with(ResponseTemplate::new(200).set_body_json(json!({})))
            .expect(3)
            .mount(&server)
            .await;
        let hashes: Vec<String> = (0..60).map(|i| format!("{i:040x}")).collect();
        assert!(client(&server).identify(&hashes).await.unwrap().is_empty());
        for r in server.received_requests().await.unwrap() {
            let body: serde_json::Value = serde_json::from_slice(&r.body).unwrap();
            assert!(body["hashes"].as_array().unwrap().len() <= 25);
            assert_eq!(body["algorithm"], "sha1");
        }
    }

    #[tokio::test]
    async fn versions_are_parsed_defensively() {
        let server = MockServer::start().await;
        Mock::given(path("/v2/project/AAAA/version"))
            .respond_with(ResponseTemplate::new(200).set_body_json(json!([{
                "id": "v1", "project_id": "AAAA", "version_number": "1.0", "version_type": "beta",
                "changelog": "   ",
                "game_versions": ["1.20.1"], "loaders": ["fabric"],
                "dependencies": [
                    {"project_id": "BBBB", "dependency_type": "required"},
                    {"project_id": "../x", "dependency_type": "required"},
                    {"project_id": "CCCC", "dependency_type": "mystery"},
                    {"version_id": "vv22", "dependency_type": "embedded"},
                ],
                "files": [{
                    "hashes": {"sha1": sha('A', 40), "sha512": "short"},
                    "url": "https://cdn.modrinth.com/x.jar", "filename": "x.jar", "primary": true, "size": 3,
                }],
            }])))
            .mount(&server)
            .await;
        let v = &client(&server)
            .versions("AAAA", &VersionFilter::default())
            .await
            .unwrap()[0];
        assert_eq!(v.channel, Channel::Beta);
        assert_eq!(v.changelog, None);
        assert_eq!(v.dependencies.len(), 3);
        assert_eq!(
            v.dependencies[1].project_id, None,
            "an id that isn't an id is dropped"
        );
        assert_eq!(
            v.files[0].hashes.sha1.as_deref(),
            Some(sha('a', 40).as_str())
        );
        assert_eq!(v.files[0].hashes.sha512, None);
    }
}
