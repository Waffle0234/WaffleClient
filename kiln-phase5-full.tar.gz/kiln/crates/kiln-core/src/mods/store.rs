//! Mods on disk and in the `mods` table: scanning an instance's mods folder, tracking which
//! jars came from Modrinth, pinning, enabling, and the backups that make an update
//! reversible. No network access lives here, so the launch manager can use it to roll back
//! a bad update without depending on any mod source.

use std::collections::{HashMap, HashSet};
use std::io::Read;
use std::path::Path;
use std::time::Duration;

use serde::{Deserialize, Serialize};
use sqlx::FromRow;

use super::source::check_jar_name;
use super::ModsError;
use crate::db::Db;
use crate::hash::{HashAlgo, StreamHasher};
use crate::instance::InstanceStore;
use crate::paths::SafePath;
use crate::{Error, Result};

/// A game that exits abnormally this soon after it started counts as "failed to start".
pub const STARTUP_WINDOW: Duration = Duration::from_secs(120);
/// Confirmed update backups kept per instance; older ones are deleted with their files.
const KEEP_CONFIRMED: i64 = 20;

fn now() -> i64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map_or(0, |d| i64::try_from(d.as_secs()).unwrap_or(0))
}

const COLUMNS: &str = "id, file_name, sha1, sha512, source, project_id, version_id, pinned, \
    enabled, size, mtime, title, author, license, downloads, icon_url, version_number, channel, \
    lookup_at, installed_as";

/// One tracked jar. `file_name` is the name without any `.disabled` suffix.
#[derive(Debug, Clone, FromRow, Serialize, Deserialize, PartialEq)]
pub struct ModEntry {
    pub id: i64,
    pub file_name: String,
    pub sha1: String,
    pub sha512: Option<String>,
    /// `modrinth` or `unverified`.
    pub source: String,
    pub project_id: Option<String>,
    pub version_id: Option<String>,
    pub pinned: bool,
    pub enabled: bool,
    pub size: Option<i64>,
    pub mtime: Option<i64>,
    pub title: Option<String>,
    pub author: Option<String>,
    pub license: Option<String>,
    pub downloads: Option<i64>,
    pub icon_url: Option<String>,
    pub version_number: Option<String>,
    pub channel: Option<String>,
    #[serde(skip)]
    pub lookup_at: Option<i64>,
    pub installed_as: String,
}

impl ModEntry {
    pub fn is_modrinth(&self) -> bool {
        self.source == "modrinth"
    }
}

/// What the catalogue knows about a jar.
#[derive(Debug, Clone, Default)]
pub struct SourceInfo {
    pub project_id: String,
    pub version_id: String,
    pub version_number: String,
    pub channel: String,
    pub title: Option<String>,
    pub author: Option<String>,
    pub license: Option<String>,
    pub downloads: Option<i64>,
    pub icon_url: Option<String>,
}

/// A jar Kiln has just written, to be recorded.
#[derive(Debug, Clone, Copy)]
pub struct InstallRecord<'a> {
    pub file_name: &'a str,
    pub info: &'a SourceInfo,
    pub sha1: &'a str,
    pub sha512: Option<&'a str>,
    pub installed_as: &'a str,
    pub pinned: bool,
}

#[derive(Debug, Clone, Default, Serialize, PartialEq, Eq)]
pub struct RollbackReport {
    pub instance_id: String,
    /// File names put back to the version they were before the update.
    pub restored: Vec<String>,
    /// File names of mods that an update had added, now removed again.
    pub removed: Vec<String>,
    /// Things that could not be undone.
    pub failed: Vec<String>,
}

impl RollbackReport {
    pub fn is_empty(&self) -> bool {
        self.restored.is_empty() && self.removed.is_empty() && self.failed.is_empty()
    }
}

pub fn disk_name(file_name: &str, enabled: bool) -> String {
    if enabled {
        file_name.to_owned()
    } else {
        format!("{file_name}.disabled")
    }
}

#[derive(Debug, Clone)]
pub struct ModStore {
    db: Db,
    instances: InstanceStore,
    backups_dir: std::path::PathBuf,
    window: Duration,
}

struct Scanned {
    base: String,
    enabled: bool,
    size: i64,
    mtime: i64,
    /// `None` when size and mtime match what is already recorded.
    hashes: Option<(String, String)>,
}

pub(crate) fn hash_file(path: &Path) -> Result<(String, String)> {
    let mut file = std::fs::File::open(path)?;
    let mut sha1 = StreamHasher::new(HashAlgo::Sha1);
    let mut sha512 = StreamHasher::new(HashAlgo::Sha512);
    let mut buf = vec![0u8; 64 * 1024];
    loop {
        let n = file.read(&mut buf)?;
        if n == 0 {
            break;
        }
        sha1.update(&buf[..n]);
        sha512.update(&buf[..n]);
    }
    Ok((sha1.finalize_hex(), sha512.finalize_hex()))
}

fn mtime_of(meta: &std::fs::Metadata) -> i64 {
    meta.modified()
        .ok()
        .and_then(|t| t.duration_since(std::time::UNIX_EPOCH).ok())
        .map_or(0, |d| i64::try_from(d.as_secs()).unwrap_or(0))
}

/// Copy `src` to `dest` through a `.part` file so `dest` is never half-written.
fn copy_atomic(src: &Path, dest: &SafePath) -> Result<()> {
    let mut part = dest.as_path().as_os_str().to_owned();
    part.push(".part");
    let part = std::path::PathBuf::from(part);
    if let Some(parent) = dest.as_path().parent() {
        std::fs::create_dir_all(parent)?;
    }
    std::fs::copy(src, &part)?;
    std::fs::rename(&part, dest.as_path())?;
    Ok(())
}

impl ModStore {
    pub fn new(db: Db, instances: InstanceStore, backups_dir: &Path) -> Self {
        Self {
            db,
            instances,
            backups_dir: backups_dir.to_path_buf(),
            window: STARTUP_WINDOW,
        }
    }

    pub fn with_startup_window(mut self, window: Duration) -> Self {
        self.window = window;
        self
    }

    pub fn startup_window(&self) -> Duration {
        self.window
    }

    pub fn instances(&self) -> &InstanceStore {
        &self.instances
    }

    pub async fn mods_dir(&self, instance_id: &str) -> Result<SafePath> {
        let game = self.instances.game_dir(instance_id).await?;
        SafePath::new(game.as_path(), "mods")
    }

    async fn file_path(
        &self,
        instance_id: &str,
        file_name: &str,
        enabled: bool,
    ) -> Result<SafePath> {
        check_jar_name(file_name)?;
        let dir = self.mods_dir(instance_id).await?;
        SafePath::new(dir.as_path(), &disk_name(file_name, enabled))
    }

    // ---- queries --------------------------------------------------------------------

    pub async fn list(&self, instance_id: &str) -> Result<Vec<ModEntry>> {
        Ok(sqlx::query_as(&format!(
            "SELECT {COLUMNS} FROM mods WHERE instance_id = ?1
             ORDER BY COALESCE(title, file_name) COLLATE NOCASE"
        ))
        .bind(instance_id)
        .fetch_all(&self.db)
        .await?)
    }

    pub async fn get(&self, instance_id: &str, mod_id: i64) -> Result<ModEntry> {
        let row: Option<ModEntry> = sqlx::query_as(&format!(
            "SELECT {COLUMNS} FROM mods WHERE instance_id = ?1 AND id = ?2"
        ))
        .bind(instance_id)
        .bind(mod_id)
        .fetch_optional(&self.db)
        .await?;
        row.ok_or_else(|| ModsError::UnknownMod.into())
    }

    pub async fn find_by_file(
        &self,
        instance_id: &str,
        file_name: &str,
    ) -> Result<Option<ModEntry>> {
        Ok(sqlx::query_as(&format!(
            "SELECT {COLUMNS} FROM mods WHERE instance_id = ?1 AND file_name = ?2"
        ))
        .bind(instance_id)
        .bind(file_name)
        .fetch_optional(&self.db)
        .await?)
    }

    pub async fn set_installed_as(&self, mod_id: i64, installed_as: &str) -> Result<()> {
        sqlx::query("UPDATE mods SET installed_as = ?2 WHERE id = ?1")
            .bind(mod_id)
            .bind(installed_as)
            .execute(&self.db)
            .await?;
        Ok(())
    }

    pub async fn find_by_project(
        &self,
        instance_id: &str,
        project_id: &str,
    ) -> Result<Option<ModEntry>> {
        Ok(sqlx::query_as(&format!(
            "SELECT {COLUMNS} FROM mods WHERE instance_id = ?1 AND project_id = ?2"
        ))
        .bind(instance_id)
        .bind(project_id)
        .fetch_optional(&self.db)
        .await?)
    }

    // ---- scanning -------------------------------------------------------------------

    /// Bring the table in line with the jars in the instance's mods folder. Jars whose size
    /// and modification time are unchanged are not hashed again.
    pub async fn sync(&self, instance_id: &str) -> Result<()> {
        let dir = self.mods_dir(instance_id).await?;
        let known: HashMap<String, (i64, i64)> = self
            .list(instance_id)
            .await?
            .into_iter()
            .map(|m| (m.file_name, (m.size.unwrap_or(-1), m.mtime.unwrap_or(-1))))
            .collect();
        let path = dir.as_path().to_path_buf();
        let scanned = tokio::task::spawn_blocking(move || -> Result<Vec<Scanned>> {
            let mut out = Vec::new();
            let entries = match std::fs::read_dir(&path) {
                Ok(e) => e,
                Err(e) if e.kind() == std::io::ErrorKind::NotFound => return Ok(out),
                Err(e) => return Err(e.into()),
            };
            for entry in entries {
                let entry = entry?;
                // A symlinked jar could point anywhere: only plain files are tracked.
                if !entry.file_type()?.is_file() {
                    continue;
                }
                let name = entry.file_name().to_string_lossy().into_owned();
                let lower = name.to_ascii_lowercase();
                let (base, enabled) = if lower.ends_with(".jar") {
                    (name.clone(), true)
                } else if lower.ends_with(".jar.disabled") {
                    (name[..name.len() - ".disabled".len()].to_owned(), false)
                } else {
                    continue;
                };
                if check_jar_name(&base).is_err() {
                    continue;
                }
                let meta = entry.metadata()?;
                let (size, mtime) = (
                    i64::try_from(meta.len()).unwrap_or(i64::MAX),
                    mtime_of(&meta),
                );
                let hashes = if known.get(&base) == Some(&(size, mtime)) {
                    None
                } else {
                    Some(hash_file(&entry.path())?)
                };
                out.push(Scanned {
                    base,
                    enabled,
                    size,
                    mtime,
                    hashes,
                });
            }
            Ok(out)
        })
        .await
        .map_err(|e| Error::Io(std::io::Error::other(e)))??;

        let present: HashSet<&str> = scanned.iter().map(|s| s.base.as_str()).collect();
        let mut tx = self.db.begin().await?;
        for s in &scanned {
            match &s.hashes {
                None => {
                    sqlx::query(
                        "UPDATE mods SET enabled = ?3 WHERE instance_id = ?1 AND file_name = ?2",
                    )
                    .bind(instance_id)
                    .bind(&s.base)
                    .bind(s.enabled)
                    .execute(&mut *tx)
                    .await?;
                }
                Some((sha1, sha512)) => {
                    // New file, or the jar was replaced: forget what we knew about the old one.
                    sqlx::query(
                        "INSERT INTO mods (instance_id, file_name, sha1, sha512, enabled, size, mtime)
                         VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7)
                         ON CONFLICT(instance_id, file_name) DO UPDATE SET
                            enabled = ?5, size = ?6, mtime = ?7,
                            sha512 = ?4,
                            source = CASE WHEN mods.sha1 = ?3 THEN mods.source ELSE 'unverified' END,
                            project_id = CASE WHEN mods.sha1 = ?3 THEN mods.project_id END,
                            version_id = CASE WHEN mods.sha1 = ?3 THEN mods.version_id END,
                            version_number = CASE WHEN mods.sha1 = ?3 THEN mods.version_number END,
                            channel = CASE WHEN mods.sha1 = ?3 THEN mods.channel END,
                            title = CASE WHEN mods.sha1 = ?3 THEN mods.title END,
                            author = CASE WHEN mods.sha1 = ?3 THEN mods.author END,
                            license = CASE WHEN mods.sha1 = ?3 THEN mods.license END,
                            downloads = CASE WHEN mods.sha1 = ?3 THEN mods.downloads END,
                            icon_url = CASE WHEN mods.sha1 = ?3 THEN mods.icon_url END,
                            lookup_at = CASE WHEN mods.sha1 = ?3 THEN mods.lookup_at END,
                            sha1 = ?3",
                    )
                    .bind(instance_id)
                    .bind(&s.base)
                    .bind(sha1)
                    .bind(sha512)
                    .bind(s.enabled)
                    .bind(s.size)
                    .bind(s.mtime)
                    .execute(&mut *tx)
                    .await?;
                }
            }
        }
        let rows: Vec<(i64, String)> =
            sqlx::query_as("SELECT id, file_name FROM mods WHERE instance_id = ?1")
                .bind(instance_id)
                .fetch_all(&mut *tx)
                .await?;
        for (id, name) in rows {
            if !present.contains(name.as_str()) {
                sqlx::query("DELETE FROM mods WHERE id = ?1")
                    .bind(id)
                    .execute(&mut *tx)
                    .await?;
            }
        }
        tx.commit().await?;
        Ok(())
    }

    /// Jars Modrinth hasn't been asked about in the last day: `(row id, sha1)`.
    pub async fn unidentified(&self, instance_id: &str) -> Result<Vec<(i64, String)>> {
        Ok(sqlx::query_as(
            "SELECT id, sha1 FROM mods
             WHERE instance_id = ?1 AND source = 'unverified'
               AND (lookup_at IS NULL OR lookup_at < ?2)",
        )
        .bind(instance_id)
        .bind(now() - 24 * 3600)
        .fetch_all(&self.db)
        .await?)
    }

    pub async fn mark_looked_up(&self, ids: &[i64]) -> Result<()> {
        for id in ids {
            sqlx::query("UPDATE mods SET lookup_at = ?2 WHERE id = ?1")
                .bind(id)
                .bind(now())
                .execute(&self.db)
                .await?;
        }
        Ok(())
    }

    pub async fn set_identified(&self, mod_id: i64, info: &SourceInfo) -> Result<()> {
        sqlx::query(
            "UPDATE mods SET source = 'modrinth', project_id = ?2, version_id = ?3,
                version_number = ?4, channel = ?5, title = ?6, author = ?7, license = ?8,
                downloads = ?9, icon_url = ?10, lookup_at = ?11
             WHERE id = ?1",
        )
        .bind(mod_id)
        .bind(&info.project_id)
        .bind(&info.version_id)
        .bind(&info.version_number)
        .bind(&info.channel)
        .bind(&info.title)
        .bind(&info.author)
        .bind(&info.license)
        .bind(info.downloads)
        .bind(&info.icon_url)
        .bind(now())
        .execute(&self.db)
        .await?;
        Ok(())
    }

    /// Insert or replace the row for a jar that Kiln has just written.
    pub async fn record_install(&self, instance_id: &str, rec: &InstallRecord<'_>) -> Result<()> {
        let InstallRecord {
            file_name,
            info,
            sha1,
            sha512,
            installed_as,
            pinned,
        } = *rec;
        check_jar_name(file_name)?;
        let path = self.file_path(instance_id, file_name, true).await?;
        let meta = std::fs::metadata(path.as_path())?;
        sqlx::query(
            "INSERT INTO mods (instance_id, file_name, sha1, sha512, source, project_id, version_id,
                pinned, enabled, size, mtime, title, author, license, downloads, icon_url,
                version_number, channel, lookup_at, installed_as)
             VALUES (?1, ?2, ?3, ?4, 'modrinth', ?5, ?6, ?7, 1, ?8, ?9, ?10, ?11, ?12, ?13, ?14,
                ?15, ?16, ?17, ?18)
             ON CONFLICT(instance_id, file_name) DO UPDATE SET
                sha1 = ?3, sha512 = ?4, source = 'modrinth', project_id = ?5, version_id = ?6,
                pinned = ?7, enabled = 1, size = ?8, mtime = ?9, title = ?10, author = ?11,
                license = ?12, downloads = ?13, icon_url = ?14, version_number = ?15,
                channel = ?16, lookup_at = ?17, installed_as = ?18",
        )
        .bind(instance_id)
        .bind(file_name)
        .bind(sha1)
        .bind(sha512)
        .bind(&info.project_id)
        .bind(&info.version_id)
        .bind(pinned)
        .bind(i64::try_from(meta.len()).unwrap_or(i64::MAX))
        .bind(mtime_of(&meta))
        .bind(&info.title)
        .bind(&info.author)
        .bind(&info.license)
        .bind(info.downloads)
        .bind(&info.icon_url)
        .bind(&info.version_number)
        .bind(&info.channel)
        .bind(now())
        .bind(installed_as)
        .execute(&self.db)
        .await?;
        Ok(())
    }

    // ---- user actions ---------------------------------------------------------------

    pub async fn set_pinned(&self, instance_id: &str, mod_id: i64, pinned: bool) -> Result<()> {
        let done = sqlx::query("UPDATE mods SET pinned = ?3 WHERE instance_id = ?1 AND id = ?2")
            .bind(instance_id)
            .bind(mod_id)
            .bind(pinned)
            .execute(&self.db)
            .await?;
        if done.rows_affected() == 0 {
            return Err(ModsError::UnknownMod.into());
        }
        Ok(())
    }

    /// Rename the jar to or from `.jar.disabled`, which every loader ignores.
    pub async fn set_enabled(&self, instance_id: &str, mod_id: i64, enabled: bool) -> Result<()> {
        let entry = self.get(instance_id, mod_id).await?;
        if entry.enabled == enabled {
            return Ok(());
        }
        let from = self
            .file_path(instance_id, &entry.file_name, entry.enabled)
            .await?;
        let to = self
            .file_path(instance_id, &entry.file_name, enabled)
            .await?;
        std::fs::rename(from.as_path(), to.as_path())?;
        sqlx::query("UPDATE mods SET enabled = ?2 WHERE id = ?1")
            .bind(mod_id)
            .bind(enabled)
            .execute(&self.db)
            .await?;
        Ok(())
    }

    pub async fn remove(&self, instance_id: &str, mod_id: i64) -> Result<()> {
        let entry = self.get(instance_id, mod_id).await?;
        let path = self
            .file_path(instance_id, &entry.file_name, entry.enabled)
            .await?;
        match std::fs::remove_file(path.as_path()) {
            Ok(()) => {}
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => {}
            Err(e) => return Err(e.into()),
        }
        sqlx::query("DELETE FROM mods WHERE id = ?1")
            .bind(mod_id)
            .execute(&self.db)
            .await?;
        Ok(())
    }

    // ---- update backups and rollback ------------------------------------------------

    /// Copy the jar an update is about to replace into the backups folder and record it.
    /// Call before the new jar is written.
    pub async fn backup_for_update(
        &self,
        instance_id: &str,
        old: &ModEntry,
        new_file_name: &str,
    ) -> Result<i64> {
        check_jar_name(new_file_name)?;
        let src = self
            .file_path(instance_id, &old.file_name, old.enabled)
            .await?;
        let rel = format!("mods/{instance_id}/{}-{}-{}", now(), old.id, old.file_name);
        let dest = SafePath::new(&self.backups_dir, &rel)?;
        let (s, d) = (src.as_path().to_path_buf(), dest);
        tokio::task::spawn_blocking(move || copy_atomic(&s, &d))
            .await
            .map_err(|e| Error::Io(std::io::Error::other(e)))??;
        let done = sqlx::query(
            "INSERT INTO mod_backups (instance_id, mod_id, file_path, replaced_at, reason,
                file_name, new_file_name, prev, state)
             VALUES (?1, ?2, ?3, ?4, 'update', ?5, ?6, ?7, 'pending')",
        )
        .bind(instance_id)
        .bind(old.id)
        .bind(&rel)
        .bind(now())
        .bind(&old.file_name)
        .bind(new_file_name)
        .bind(serde_json::to_string(old)?)
        .execute(&self.db)
        .await?;
        Ok(done.last_insert_rowid())
    }

    /// Drop a backup record (and its copy) for an update that never happened.
    pub async fn discard_backup(&self, backup_id: i64) -> Result<()> {
        let row: Option<(String,)> =
            sqlx::query_as("SELECT file_path FROM mod_backups WHERE id = ?1")
                .bind(backup_id)
                .fetch_optional(&self.db)
                .await?;
        if let Some((rel,)) = row {
            if !rel.is_empty() {
                if let Ok(p) = SafePath::new(&self.backups_dir, &rel) {
                    let _ = std::fs::remove_file(p.as_path());
                }
            }
            sqlx::query("DELETE FROM mod_backups WHERE id = ?1")
                .bind(backup_id)
                .execute(&self.db)
                .await?;
        }
        Ok(())
    }

    /// An update failed part-way: put the old jar back (a new file may have reused its
    /// name), then forget the backup.
    pub async fn abort_update(&self, instance_id: &str, backup_id: i64) -> Result<()> {
        let row: Option<(String, Option<String>, Option<String>)> =
            sqlx::query_as("SELECT file_path, new_file_name, prev FROM mod_backups WHERE id = ?1")
                .bind(backup_id)
                .fetch_optional(&self.db)
                .await?;
        if let Some((rel, new_name, prev)) = row {
            if let Err(e) = self
                .undo_update(instance_id, &rel, new_name.as_deref(), prev.as_deref())
                .await
            {
                tracing::warn!(error = %e, "could not restore a mod after a failed update");
            }
        }
        self.discard_backup(backup_id).await
    }

    /// Note that an update added a new jar (a dependency), so rolling back removes it again.
    pub async fn record_added_by_update(&self, instance_id: &str, file_name: &str) -> Result<()> {
        sqlx::query(
            "INSERT INTO mod_backups (instance_id, mod_id, file_path, replaced_at, reason,
                file_name, state)
             VALUES (?1, NULL, '', ?2, 'added', ?3, 'pending')",
        )
        .bind(instance_id)
        .bind(now())
        .bind(file_name)
        .execute(&self.db)
        .await?;
        Ok(())
    }

    pub async fn pending_updates(&self, instance_id: &str) -> Result<i64> {
        let (n,): (i64,) = sqlx::query_as(
            "SELECT COUNT(*) FROM mod_backups WHERE instance_id = ?1 AND state = 'pending'",
        )
        .bind(instance_id)
        .fetch_one(&self.db)
        .await?;
        Ok(n)
    }

    /// The game ran fine: keep the updated mods and forget the "pending" status.
    pub async fn confirm_pending(&self, instance_id: &str) -> Result<()> {
        sqlx::query(
            "UPDATE mod_backups SET state = 'confirmed' WHERE instance_id = ?1 AND state = 'pending'",
        )
        .bind(instance_id)
        .execute(&self.db)
        .await?;
        self.prune_confirmed(instance_id).await
    }

    async fn prune_confirmed(&self, instance_id: &str) -> Result<()> {
        let old: Vec<(i64, String)> = sqlx::query_as(
            "SELECT id, file_path FROM mod_backups
             WHERE instance_id = ?1 AND state IN ('confirmed', 'restored')
             ORDER BY id DESC LIMIT -1 OFFSET ?2",
        )
        .bind(instance_id)
        .bind(KEEP_CONFIRMED)
        .fetch_all(&self.db)
        .await?;
        for (id, rel) in old {
            if !rel.is_empty() {
                if let Ok(p) = SafePath::new(&self.backups_dir, &rel) {
                    let _ = std::fs::remove_file(p.as_path());
                }
            }
            sqlx::query("DELETE FROM mod_backups WHERE id = ?1")
                .bind(id)
                .execute(&self.db)
                .await?;
        }
        Ok(())
    }

    /// Undo every update that hasn't been confirmed yet: put the previous jars back (after
    /// checking each against the hash recorded before the update), remove jars the update
    /// added, and restore the table rows. Returns what was done.
    pub async fn rollback_pending(&self, instance_id: &str) -> Result<RollbackReport> {
        #[derive(FromRow)]
        struct Pending {
            id: i64,
            file_path: String,
            reason: String,
            file_name: Option<String>,
            new_file_name: Option<String>,
            prev: Option<String>,
        }
        let pending: Vec<Pending> = sqlx::query_as(
            "SELECT id, file_path, reason, file_name, new_file_name, prev FROM mod_backups
             WHERE instance_id = ?1 AND state = 'pending' ORDER BY id DESC",
        )
        .bind(instance_id)
        .fetch_all(&self.db)
        .await?;
        let mut report = RollbackReport {
            instance_id: instance_id.to_owned(),
            ..Default::default()
        };
        for p in pending {
            let label = p.file_name.clone().unwrap_or_else(|| "a mod".into());
            let result = match p.reason.as_str() {
                "added" => self.undo_added(instance_id, p.file_name.as_deref()).await,
                _ => {
                    self.undo_update(
                        instance_id,
                        &p.file_path,
                        p.new_file_name.as_deref(),
                        p.prev.as_deref(),
                    )
                    .await
                }
            };
            match result {
                Ok(()) => {
                    sqlx::query("UPDATE mod_backups SET state = 'restored' WHERE id = ?1")
                        .bind(p.id)
                        .execute(&self.db)
                        .await?;
                    if p.reason == "added" {
                        report.removed.push(label);
                    } else {
                        report.restored.push(label);
                    }
                }
                Err(e) => {
                    tracing::warn!(error = %e, "could not undo a mod update");
                    report.failed.push(label);
                }
            }
        }
        self.prune_confirmed(instance_id).await?;
        Ok(report)
    }

    async fn undo_added(&self, instance_id: &str, file_name: Option<&str>) -> Result<()> {
        let name = file_name.ok_or_else(|| Error::InvalidPath("backup record".into()))?;
        let row: Option<(i64, bool)> = sqlx::query_as(
            "SELECT id, enabled FROM mods WHERE instance_id = ?1 AND file_name = ?2",
        )
        .bind(instance_id)
        .bind(name)
        .fetch_optional(&self.db)
        .await?;
        let enabled = row.is_none_or(|(_, e)| e);
        let path = self.file_path(instance_id, name, enabled).await?;
        match std::fs::remove_file(path.as_path()) {
            Ok(()) => {}
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => {}
            Err(e) => return Err(e.into()),
        }
        if let Some((id, _)) = row {
            sqlx::query("DELETE FROM mods WHERE id = ?1")
                .bind(id)
                .execute(&self.db)
                .await?;
        }
        Ok(())
    }

    async fn undo_update(
        &self,
        instance_id: &str,
        backup_rel: &str,
        new_file_name: Option<&str>,
        prev: Option<&str>,
    ) -> Result<()> {
        let prev: ModEntry =
            serde_json::from_str(prev.ok_or_else(|| Error::InvalidPath("backup record".into()))?)?;
        check_jar_name(&prev.file_name)?;
        let backup = SafePath::new(&self.backups_dir, backup_rel)?;
        // The backup must still be the jar it was when the update began.
        let p = backup.as_path().to_path_buf();
        let (sha1, _) = tokio::task::spawn_blocking(move || hash_file(&p))
            .await
            .map_err(|e| Error::Io(std::io::Error::other(e)))??;
        if sha1 != prev.sha1 {
            return Err(Error::HashMismatch {
                expected: prev.sha1.clone(),
                actual: sha1,
            });
        }
        // Put the old jar back first, so a failure later never leaves the mod missing.
        let dest = self
            .file_path(instance_id, &prev.file_name, prev.enabled)
            .await?;
        let (b, d) = (backup.as_path().to_path_buf(), dest);
        tokio::task::spawn_blocking(move || copy_atomic(&b, &d))
            .await
            .map_err(|e| Error::Io(std::io::Error::other(e)))??;
        if let Some(new_name) = new_file_name.filter(|n| *n != prev.file_name) {
            let row: Option<(bool,)> = sqlx::query_as(
                "SELECT enabled FROM mods WHERE instance_id = ?1 AND file_name = ?2",
            )
            .bind(instance_id)
            .bind(new_name)
            .fetch_optional(&self.db)
            .await?;
            let new_path = self
                .file_path(instance_id, new_name, row.is_none_or(|(e,)| e))
                .await?;
            match std::fs::remove_file(new_path.as_path()) {
                Ok(()) => {}
                Err(e) if e.kind() == std::io::ErrorKind::NotFound => {}
                Err(e) => return Err(e.into()),
            }
            sqlx::query("DELETE FROM mods WHERE instance_id = ?1 AND file_name = ?2")
                .bind(instance_id)
                .bind(new_name)
                .execute(&self.db)
                .await?;
        }
        self.write_row(instance_id, &prev).await?;
        let _ = std::fs::remove_file(backup.as_path());
        Ok(())
    }

    async fn write_row(&self, instance_id: &str, e: &ModEntry) -> Result<()> {
        sqlx::query(
            "INSERT INTO mods (instance_id, file_name, sha1, sha512, source, project_id, version_id,
                pinned, enabled, size, mtime, title, author, license, downloads, icon_url,
                version_number, channel, lookup_at, installed_as)
             VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11, ?12, ?13, ?14, ?15, ?16, ?17,
                ?18, ?19, ?20)
             ON CONFLICT(instance_id, file_name) DO UPDATE SET
                sha1 = ?3, sha512 = ?4, source = ?5, project_id = ?6, version_id = ?7,
                pinned = ?8, enabled = ?9, size = ?10, mtime = ?11, title = ?12, author = ?13,
                license = ?14, downloads = ?15, icon_url = ?16, version_number = ?17,
                channel = ?18, lookup_at = ?19, installed_as = ?20",
        )
        .bind(instance_id)
        .bind(&e.file_name)
        .bind(&e.sha1)
        .bind(&e.sha512)
        .bind(&e.source)
        .bind(&e.project_id)
        .bind(&e.version_id)
        .bind(e.pinned)
        .bind(e.enabled)
        .bind(e.size)
        .bind(e.mtime)
        .bind(&e.title)
        .bind(&e.author)
        .bind(&e.license)
        .bind(e.downloads)
        .bind(&e.icon_url)
        .bind(&e.version_number)
        .bind(&e.channel)
        .bind(e.lookup_at)
        .bind(&e.installed_as)
        .execute(&self.db)
        .await?;
        Ok(())
    }
}

/// The Modrinth modpack an instance was installed from, and the files that pack put there.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PackLink {
    pub project_id: String,
    pub version_id: String,
    pub version_number: Option<String>,
    pub files: Vec<String>,
}

impl ModStore {
    pub async fn record_pack(
        &self,
        instance_id: &str,
        project_id: &str,
        version_id: &str,
        version_number: &str,
        files: &[String],
    ) -> Result<()> {
        sqlx::query(
            "INSERT INTO instance_packs (instance_id, project_id, version_id, version_number, files)
             VALUES (?1, ?2, ?3, ?4, ?5)
             ON CONFLICT(instance_id) DO UPDATE SET
                project_id = ?2, version_id = ?3, version_number = ?4, files = ?5",
        )
        .bind(instance_id)
        .bind(project_id)
        .bind(version_id)
        .bind(version_number)
        .bind(serde_json::to_string(files)?)
        .execute(&self.db)
        .await?;
        Ok(())
    }

    pub async fn pack_link(&self, instance_id: &str) -> Result<Option<PackLink>> {
        let row: Option<(String, String, Option<String>, String)> = sqlx::query_as(
            "SELECT project_id, version_id, version_number, files FROM instance_packs
             WHERE instance_id = ?1",
        )
        .bind(instance_id)
        .fetch_optional(&self.db)
        .await?;
        row.map(|(project_id, version_id, version_number, files)| {
            Ok(PackLink {
                project_id,
                version_id,
                version_number,
                files: serde_json::from_str(&files)?,
            })
        })
        .transpose()
    }
}
