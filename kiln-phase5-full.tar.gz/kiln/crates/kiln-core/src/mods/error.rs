//! Errors from browsing, installing and updating mods.

#[derive(Debug, thiserror::Error)]
pub enum ModsError {
    #[error("invalid project or version id")]
    InvalidId,
    #[error("invalid search filter")]
    InvalidFilter,
    #[error("rate limited; retry in {retry_secs}s")]
    RateLimited { retry_secs: u64 },
    #[error("not found")]
    NotFound,
    #[error("{0} has no version for this Minecraft version and loader")]
    NoCompatibleVersion(String),
    #[error("conflict: {0}")]
    Conflict(String),
    #[error("too many dependencies")]
    TooManyDependencies,
    #[error("mod is pinned")]
    Pinned,
    #[error("no such mod in this instance")]
    UnknownMod,
    #[error("no downloadable file: {0}")]
    NoFile(String),
    #[error("vanilla instances can't have mods")]
    VanillaInstance,
    #[error("nothing to roll back")]
    NothingToRollBack,
    #[error("unexpected response: {0}")]
    BadResponse(String),
    #[error("not a modpack: {0}")]
    NotAModpack(String),
}

impl ModsError {
    pub fn code(&self) -> &'static str {
        match self {
            Self::InvalidId => "invalid_id",
            Self::InvalidFilter => "invalid_filter",
            Self::RateLimited { .. } => "rate_limited",
            Self::NotFound => "mod_not_found",
            Self::NoCompatibleVersion(_) => "no_compatible_version",
            Self::Conflict(_) => "mod_conflict",
            Self::TooManyDependencies => "too_many_dependencies",
            Self::Pinned => "mod_pinned",
            Self::UnknownMod => "unknown_mod",
            Self::NoFile(_) => "no_file",
            Self::VanillaInstance => "vanilla_instance",
            Self::NothingToRollBack => "nothing_to_roll_back",
            Self::BadResponse(_) => "bad_response",
            Self::NotAModpack(_) => "not_a_modpack",
        }
    }

    pub fn user_message(&self) -> String {
        match self {
            Self::InvalidId => "That isn't a valid project or version.".into(),
            Self::InvalidFilter => "One of the search filters isn't valid.".into(),
            Self::RateLimited { retry_secs } => format!(
                "Modrinth is asking Kiln to slow down. Try again in about {retry_secs} seconds."
            ),
            Self::NotFound => "Modrinth doesn't have that project.".into(),
            Self::NoCompatibleVersion(name) => format!(
                "{name} has no release for this instance's Minecraft version and mod loader."
            ),
            Self::Conflict(why) => format!("These mods can't be installed together: {why}."),
            Self::TooManyDependencies => {
                "That mod pulls in an unreasonable number of other mods, so Kiln stopped.".into()
            }
            Self::Pinned => "That mod is pinned. Unpin it to update it.".into(),
            Self::UnknownMod => "That mod isn't in this instance any more.".into(),
            Self::NoFile(name) => {
                format!("{name} has no file Kiln can verify and download, so it wasn't installed.")
            }
            Self::VanillaInstance => {
                "Vanilla instances don't load mods. Pick a Fabric, Quilt, Forge or NeoForge \
                 instance."
                    .into()
            }
            Self::NothingToRollBack => "There's no recent update to undo.".into(),
            Self::BadResponse(_) => {
                "Modrinth sent something Kiln didn't understand. Try again later.".into()
            }
            Self::NotAModpack(why) => format!("That isn't a modpack Kiln can install: {why}."),
        }
    }
}
