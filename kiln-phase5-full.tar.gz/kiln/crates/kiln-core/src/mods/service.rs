//! Installing, updating and removing mods, resolving their dependencies, and installing
//! and updating Modrinth modpacks. Generic over [`ModSource`] so another catalogue can be
//! plugged in. All downloads go through the [`Downloader`] with the source's own host
//! allowlist; a file reaches the mods folder only after its hash has been verified.

use std::collections::{BTreeSet, HashMap, HashSet, VecDeque};
use std::path::PathBuf;

use serde::Serialize;
use tokio::sync::watch;

use super::source::*;
use super::store::{disk_name, InstallRecord, ModEntry, ModStore, RollbackReport, SourceInfo};
use super::ModsError;
use crate::download::{DownloadTask, Downloader, Progress};
use crate::hash::{ExpectedHash, HashAlgo};
use crate::instance::pack::{MrpackFile, PackService};
use crate::instance::{Instance, InstanceStore};
use crate::loader::LoaderKind;
use crate::net::HttpClient;
use crate::paths::{DataDirs, SafePath};
use crate::{Error, Result, APP_NAME, APP_VERSION};

/// Most mods one install may pull in, and how deep the dependency chain may go.
const MAX_PLAN: usize = 64;
const MAX_DEPTH: usize = 8;
const MAX_CHANGELOG_CHARS: usize = 6000;

#[derive(Debug, Clone, Serialize, PartialEq)]
pub struct PlannedMod {
    pub project_id: String,
    pub title: String,
    pub version_id: String,
    pub version_number: String,
    pub channel: Channel,
    pub file_name: String,
    pub size: u64,
    /// `requested` or `dependency`.
    pub reason: String,
    pub icon_url: Option<String>,
}

#[derive(Debug, Clone, Serialize, PartialEq, Eq)]
pub struct OptionalDep {
    pub project_id: String,
    pub title: String,
}

#[derive(Debug, Clone, Serialize, PartialEq, Eq)]
pub struct Conflict {
    pub title: String,
    pub conflicts_with: String,
}

#[derive(Debug, Clone, Default, Serialize, PartialEq)]
pub struct InstallPlan {
    pub mods: Vec<PlannedMod>,
    pub optional: Vec<OptionalDep>,
    pub conflicts: Vec<Conflict>,
    /// Titles of required mods that were already installed.
    pub already_installed: Vec<String>,
}

#[derive(Debug, Clone, Serialize, PartialEq)]
pub struct UpdateInfo {
    pub mod_id: i64,
    pub file_name: String,
    pub title: String,
    pub current_version: Option<String>,
    pub new_version: String,
    pub new_version_id: String,
    pub channel: Channel,
    pub changelog: Option<String>,
    pub pinned: bool,
}

#[derive(Debug, Clone, Default, Serialize, PartialEq, Eq)]
pub struct UpdateAllReport {
    pub updated: Vec<String>,
    pub failed: Vec<UpdateFailure>,
    pub skipped_pinned: usize,
}

#[derive(Debug, Clone, Serialize, PartialEq, Eq)]
pub struct UpdateFailure {
    pub title: String,
    pub message: String,
}

#[derive(Debug, Clone, Serialize, PartialEq, Eq)]
pub struct MrpackExport {
    pub file: String,
    /// Mods listed by Modrinth hash instead of being copied into the pack.
    pub listed: usize,
    /// Jars Modrinth doesn't know. They are bundled in the pack, so check you may share them.
    pub bundled_unverified: Vec<String>,
}

#[derive(Debug, Clone, Serialize, PartialEq, Eq)]
pub struct PackUpdateInfo {
    pub version_id: String,
    pub version_number: String,
    pub changelog: Option<String>,
}

#[derive(Debug, Clone, Serialize, PartialEq, Eq)]
#[serde(tag = "result", rename_all = "snake_case")]
pub enum PackUpdateOutcome {
    UpToDate,
    Updated { version_number: String },
}

/// A project version that has been chosen for installation and checked.
struct Resolved {
    project: Project,
    version: ModVersion,
    file: VersionFile,
    reason: &'static str,
}

enum Target {
    Project(String),
    Version(String),
    /// A version already chosen by the caller (an update): installed even though the
    /// project is already present.
    Given(Box<ModVersion>),
}

fn truncate(s: Option<String>) -> Option<String> {
    s.map(|c| c.chars().take(MAX_CHANGELOG_CHARS).collect())
}

fn expected_hash(f: &VersionFile) -> Result<ExpectedHash> {
    match (&f.hashes.sha512, &f.hashes.sha1) {
        (Some(h), _) => ExpectedHash::new(HashAlgo::Sha512, h),
        (None, Some(h)) => ExpectedHash::new(HashAlgo::Sha1, h),
        _ => Err(ModsError::NoFile(f.filename.clone()).into()),
    }
}

#[derive(Clone)]
pub struct ModService<S: ModSource> {
    source: S,
    store: ModStore,
    packs: PackService,
    downloader: Downloader,
    /// Scratch space for modpack archives (`imports/`).
    imports: PathBuf,
}

impl<S: ModSource> ModService<S> {
    pub fn new(
        source: S,
        store: ModStore,
        packs: PackService,
        dirs: &DataDirs,
        max_concurrent: u8,
    ) -> Result<Self> {
        let ua = format!("{APP_NAME}/{APP_VERSION}");
        let downloader = Downloader::new(
            HttpClient::new_for_downloads(&ua, source.download_policy())?,
            max_concurrent,
        );
        Ok(Self::with_downloader(
            source, store, packs, dirs, downloader,
        ))
    }

    pub(crate) fn with_downloader(
        source: S,
        store: ModStore,
        packs: PackService,
        dirs: &DataDirs,
        downloader: Downloader,
    ) -> Self {
        Self {
            source,
            store,
            packs,
            downloader,
            imports: dirs.imports.clone(),
        }
    }

    pub fn store(&self) -> &ModStore {
        &self.store
    }

    pub fn source(&self) -> &S {
        &self.source
    }

    fn instances(&self) -> &InstanceStore {
        self.store.instances()
    }

    async fn modded_instance(&self, id: &str) -> Result<Instance> {
        let inst = self.instances().get(id).await?;
        if inst.loader == LoaderKind::Vanilla {
            return Err(ModsError::VanillaInstance.into());
        }
        Ok(inst)
    }

    /// A file is only acceptable if its name is a plain `.jar`, its URL is on the source's
    /// host list, and it carries a hash we can verify.
    fn pick_file(&self, v: &ModVersion, title: &str) -> Result<VersionFile> {
        let file = v
            .primary_file()
            .ok_or_else(|| ModsError::NoFile(title.to_owned()))?
            .clone();
        check_jar_name(&file.filename).map_err(|_| ModsError::NoFile(title.to_owned()))?;
        expected_hash(&file).map_err(|_| ModsError::NoFile(title.to_owned()))?;
        let allowed = reqwest::Url::parse(&file.url)
            .is_ok_and(|u| self.source.download_policy().check(&u).is_ok());
        if !allowed {
            return Err(ModsError::NoFile(title.to_owned()).into());
        }
        Ok(file)
    }

    // ---- listing --------------------------------------------------------------------

    /// Tracked mods for an instance. Rescans the folder and asks the source about jars it
    /// hasn't seen; a network failure there only leaves them marked unverified.
    pub async fn list(&self, instance_id: &str) -> Result<Vec<ModEntry>> {
        self.store.sync(instance_id).await?;
        if let Err(e) = self.identify_unknown(instance_id).await {
            tracing::warn!(error = %e, "could not identify mods");
        }
        self.store.list(instance_id).await
    }

    async fn identify_unknown(&self, instance_id: &str) -> Result<()> {
        let rows = self.store.unidentified(instance_id).await?;
        if rows.is_empty() {
            return Ok(());
        }
        let sha1s: Vec<String> = rows.iter().map(|(_, h)| h.clone()).collect();
        let found = self.source.identify(&sha1s).await?;
        let ids: BTreeSet<String> = found.values().map(|v| v.project_id.clone()).collect();
        let ids: Vec<String> = ids.into_iter().collect();
        let projects: HashMap<String, Project> = self
            .source
            .projects(&ids)
            .await
            .unwrap_or_default()
            .into_iter()
            .map(|p| (p.id.clone(), p))
            .collect();
        for (row_id, sha1) in &rows {
            if let Some(v) = found.get(sha1) {
                let info = source_info(v, projects.get(&v.project_id));
                self.store.set_identified(*row_id, &info).await?;
            }
        }
        let all: Vec<i64> = rows.iter().map(|(id, _)| *id).collect();
        self.store.mark_looked_up(&all).await
    }

    // ---- dependency resolution ------------------------------------------------------

    async fn resolve(
        &self,
        instance: &Instance,
        requests: Vec<Target>,
        installed: &[ModEntry],
    ) -> Result<(Vec<Resolved>, Vec<OptionalDep>, Vec<Conflict>, Vec<String>)> {
        let filter = VersionFilter::for_instance(instance.loader, &instance.mc_version);
        let installed_ids: HashSet<&str> = installed
            .iter()
            .filter_map(|m| m.project_id.as_deref())
            .collect();
        let mut chosen: Vec<(ModVersion, &'static str)> = Vec::new();
        let mut chosen_ids: HashSet<String> = HashSet::new();
        let mut skipped: Vec<String> = Vec::new();
        let mut optional: BTreeSet<String> = BTreeSet::new();
        let mut incompatible: Vec<(String, String)> = Vec::new();
        let mut queue: VecDeque<(Target, usize, &'static str)> =
            requests.into_iter().map(|t| (t, 0, "requested")).collect();

        while let Some((target, depth, reason)) = queue.pop_front() {
            if depth > MAX_DEPTH || chosen.len() > MAX_PLAN {
                return Err(ModsError::TooManyDependencies.into());
            }
            let given = matches!(target, Target::Given(_));
            let version = match target {
                Target::Given(v) => *v,
                Target::Project(id) => {
                    check_id(&id)?;
                    if chosen_ids.contains(&id) || installed_ids.contains(id.as_str()) {
                        if installed_ids.contains(id.as_str()) {
                            skipped.push(id);
                        }
                        continue;
                    }
                    best_version(self.source.versions(&id, &filter).await?)
                        .ok_or(ModsError::NoCompatibleVersion(id))?
                }
                Target::Version(vid) => {
                    let v = self.source.version(&vid).await?;
                    if chosen_ids.contains(&v.project_id)
                        || installed_ids.contains(v.project_id.as_str())
                    {
                        if installed_ids.contains(v.project_id.as_str()) {
                            skipped.push(v.project_id);
                        }
                        continue;
                    }
                    if filter.accepts(&v) {
                        v
                    } else {
                        // The pinned version doesn't fit this instance: use the best one that does.
                        let pid = v.project_id.clone();
                        best_version(self.source.versions(&pid, &filter).await?)
                            .ok_or(ModsError::NoCompatibleVersion(pid))?
                    }
                }
            };
            if chosen_ids.contains(&version.project_id) {
                continue;
            }
            if !given && installed_ids.contains(version.project_id.as_str()) {
                skipped.push(version.project_id.clone());
                continue;
            }
            for dep in &version.dependencies {
                match (dep.kind, &dep.project_id, &dep.version_id) {
                    (DependencyKind::Required, _, Some(vid)) => {
                        queue.push_back((Target::Version(vid.clone()), depth + 1, "dependency"));
                    }
                    (DependencyKind::Required, Some(pid), None) => {
                        queue.push_back((Target::Project(pid.clone()), depth + 1, "dependency"));
                    }
                    (DependencyKind::Optional, Some(pid), _) => {
                        optional.insert(pid.clone());
                    }
                    (DependencyKind::Incompatible, Some(pid), _) => {
                        incompatible.push((version.project_id.clone(), pid.clone()));
                    }
                    _ => {}
                }
            }
            chosen_ids.insert(version.project_id.clone());
            chosen.push((version, reason));
        }

        let mut want: BTreeSet<String> = chosen_ids.iter().cloned().collect();
        want.extend(optional.iter().cloned());
        want.extend(skipped.iter().cloned());
        for (owner, bad) in &incompatible {
            if installed_ids.contains(bad.as_str()) || chosen_ids.contains(bad) {
                want.insert(owner.clone());
                want.insert(bad.clone());
            }
        }
        let want: Vec<String> = want.into_iter().collect();
        let projects: HashMap<String, Project> = self
            .source
            .projects(&want)
            .await?
            .into_iter()
            .map(|p| (p.id.clone(), p))
            .collect();
        let title_of = |id: &str| {
            projects
                .get(id)
                .map_or_else(|| id.to_owned(), |p| p.title.clone())
        };

        let mut conflicts = Vec::new();
        for (owner, bad) in &incompatible {
            if installed_ids.contains(bad.as_str()) || chosen_ids.contains(bad) {
                conflicts.push(Conflict {
                    title: title_of(owner),
                    conflicts_with: title_of(bad),
                });
            }
        }

        let mut resolved = Vec::new();
        for (version, reason) in chosen {
            let project = projects
                .get(&version.project_id)
                .cloned()
                .ok_or_else(|| ModsError::BadResponse("a project was missing".into()))?;
            let file = self.pick_file(&version, &project.title)?;
            resolved.push(Resolved {
                project,
                version,
                file,
                reason,
            });
        }
        let optional = optional
            .into_iter()
            .filter(|id| !chosen_ids.contains(id) && !installed_ids.contains(id.as_str()))
            .map(|id| OptionalDep {
                title: title_of(&id),
                project_id: id,
            })
            .collect();
        let skipped = skipped.iter().map(|id| title_of(id)).collect();
        Ok((resolved, optional, conflicts, skipped))
    }

    fn to_plan(
        resolved: &[Resolved],
        optional: Vec<OptionalDep>,
        conflicts: Vec<Conflict>,
        skipped: Vec<String>,
    ) -> InstallPlan {
        InstallPlan {
            mods: resolved
                .iter()
                .map(|r| PlannedMod {
                    project_id: r.project.id.clone(),
                    title: r.project.title.clone(),
                    version_id: r.version.id.clone(),
                    version_number: r.version.version_number.clone(),
                    channel: r.version.channel,
                    file_name: r.file.filename.clone(),
                    size: r.file.size,
                    reason: r.reason.to_owned(),
                    icon_url: r.project.icon_url.clone(),
                })
                .collect(),
            optional,
            conflicts,
            already_installed: skipped,
        }
    }

    /// What installing `project` would do, without doing it.
    pub async fn plan_install(&self, instance_id: &str, project: &str) -> Result<InstallPlan> {
        check_id(project)?;
        let instance = self.modded_instance(instance_id).await?;
        self.store.sync(instance_id).await?;
        let installed = self.store.list(instance_id).await?;
        let (resolved, optional, conflicts, skipped) = self
            .resolve(
                &instance,
                vec![Target::Project(project.to_owned())],
                &installed,
            )
            .await?;
        Ok(Self::to_plan(&resolved, optional, conflicts, skipped))
    }

    // ---- install --------------------------------------------------------------------

    /// Install `project` and its required dependencies, plus any of the plan's optional
    /// dependencies named in `optional`.
    pub async fn install(
        &self,
        instance_id: &str,
        project: &str,
        optional: &[String],
        progress: Option<watch::Sender<Progress>>,
    ) -> Result<InstallPlan> {
        check_id(project)?;
        let instance = self.modded_instance(instance_id).await?;
        self.store.sync(instance_id).await?;
        let installed = self.store.list(instance_id).await?;
        let mut requests = vec![Target::Project(project.to_owned())];
        let (mut resolved, mut offered, mut conflicts, mut skipped) =
            self.resolve(&instance, requests, &installed).await?;
        if !optional.is_empty() {
            // Only optional mods the plan itself offered may be added.
            let offered_ids: HashSet<&str> =
                offered.iter().map(|o| o.project_id.as_str()).collect();
            if optional.iter().any(|o| !offered_ids.contains(o.as_str())) {
                return Err(ModsError::InvalidId.into());
            }
            requests = vec![Target::Project(project.to_owned())];
            requests.extend(optional.iter().map(|o| Target::Project(o.clone())));
            (resolved, offered, conflicts, skipped) =
                self.resolve(&instance, requests, &installed).await?;
        }
        if let Some(c) = conflicts.first() {
            return Err(
                ModsError::Conflict(format!("{} and {}", c.title, c.conflicts_with)).into(),
            );
        }
        let plan = Self::to_plan(&resolved, offered, conflicts, skipped);
        let wanted_user: HashSet<&str> = std::iter::once(project)
            .chain(optional.iter().map(String::as_str))
            .collect();
        self.write_all(instance_id, &resolved, progress, |r| {
            if wanted_user.contains(r.project.id.as_str())
                || wanted_user.contains(r.project.slug.as_str())
            {
                "user"
            } else {
                "dependency"
            }
        })
        .await?;
        Ok(plan)
    }

    /// Download every resolved file into the mods folder and record it.
    async fn write_all(
        &self,
        instance_id: &str,
        items: &[Resolved],
        progress: Option<watch::Sender<Progress>>,
        installed_as: impl Fn(&Resolved) -> &'static str,
    ) -> Result<()> {
        let dir = self.store.mods_dir(instance_id).await?;
        std::fs::create_dir_all(dir.as_path())?;
        let mut tasks = Vec::new();
        let mut created: Vec<std::path::PathBuf> = Vec::new();
        for r in items {
            let target = SafePath::new(dir.as_path(), &r.file.filename)?;
            if !target.as_path().exists() {
                created.push(target.as_path().to_path_buf());
            }
            tasks.push(DownloadTask {
                url: r.file.url.clone(),
                dest: SafePath::new(dir.as_path(), &r.file.filename)?,
                hash: Some(expected_hash(&r.file)?),
                size: (r.file.size > 0).then_some(r.file.size),
            });
        }
        if let Err(e) = self.downloader.download_all(tasks, progress).await {
            // Downloads run side by side: some files may have landed before another failed.
            // Don't leave a mod behind without the things it needs.
            for path in created {
                let _ = std::fs::remove_file(path);
            }
            return Err(e);
        }
        for r in items {
            let path = SafePath::new(dir.as_path(), &r.file.filename)?;
            let (sha1, sha512) = hash_both(path.as_path()).await?;
            let info = source_info(&r.version, Some(&r.project));
            self.store
                .record_install(
                    instance_id,
                    &InstallRecord {
                        file_name: &r.file.filename,
                        info: &info,
                        sha1: &sha1,
                        sha512: Some(&sha512),
                        installed_as: installed_as(r),
                        pinned: false,
                    },
                )
                .await?;
        }
        Ok(())
    }

    // ---- updates --------------------------------------------------------------------

    /// Which tracked Modrinth mods have a newer version for this instance, found by hashing
    /// the installed jars (so renamed files still match).
    pub async fn check_updates(&self, instance_id: &str) -> Result<Vec<UpdateInfo>> {
        let instance = self.modded_instance(instance_id).await?;
        let entries = self.list(instance_id).await?;
        let filter = VersionFilter::for_instance(instance.loader, &instance.mc_version);
        let candidates: Vec<&ModEntry> = entries
            .iter()
            .filter(|m| m.is_modrinth() && m.enabled)
            .collect();
        if candidates.is_empty() {
            return Ok(Vec::new());
        }
        let sha1s: Vec<String> = candidates.iter().map(|m| m.sha1.clone()).collect();
        let latest = self.source.latest_for(&sha1s, &filter).await?;
        let mut out = Vec::new();
        for m in candidates {
            let Some(v) = latest.get(&m.sha1) else {
                continue;
            };
            if Some(&v.id) == m.version_id.as_ref() {
                continue;
            }
            // Don't push someone on a release onto a beta.
            if v.channel != Channel::Release && m.channel.as_deref() == Some("release") {
                continue;
            }
            if v.primary_file().and_then(|f| f.hashes.sha1.as_ref()) == Some(&m.sha1) {
                continue;
            }
            out.push(UpdateInfo {
                mod_id: m.id,
                file_name: m.file_name.clone(),
                title: m.title.clone().unwrap_or_else(|| m.file_name.clone()),
                current_version: m.version_number.clone(),
                new_version: v.version_number.clone(),
                new_version_id: v.id.clone(),
                channel: v.channel,
                changelog: truncate(v.changelog.clone()),
                pinned: m.pinned,
            });
        }
        Ok(out)
    }

    /// Update one mod. Returns false if it was already current. Pinned mods are refused.
    pub async fn update_mod(
        &self,
        instance_id: &str,
        mod_id: i64,
        progress: Option<watch::Sender<Progress>>,
    ) -> Result<bool> {
        let instance = self.modded_instance(instance_id).await?;
        let entry = self.store.get(instance_id, mod_id).await?;
        if entry.pinned {
            return Err(ModsError::Pinned.into());
        }
        if !entry.is_modrinth() {
            return Err(ModsError::UnknownMod.into());
        }
        let filter = VersionFilter::for_instance(instance.loader, &instance.mc_version);
        let latest = self
            .source
            .latest_for(std::slice::from_ref(&entry.sha1), &filter)
            .await?;
        let Some(version) = latest.get(&entry.sha1).cloned() else {
            return Ok(false);
        };
        if Some(&version.id) == entry.version_id.as_ref() {
            return Ok(false);
        }
        self.apply_update(&instance, &entry, version, progress)
            .await?;
        Ok(true)
    }

    async fn apply_update(
        &self,
        instance: &Instance,
        entry: &ModEntry,
        version: ModVersion,
        progress: Option<watch::Sender<Progress>>,
    ) -> Result<()> {
        let installed = self.store.list(&instance.id).await?;
        let (resolved, _optional, conflicts, _skipped) = self
            .resolve(instance, vec![Target::Given(Box::new(version))], &installed)
            .await?;
        if let Some(c) = conflicts.first() {
            return Err(
                ModsError::Conflict(format!("{} and {}", c.title, c.conflicts_with)).into(),
            );
        }
        let main_project = entry.project_id.clone().unwrap_or_default();
        let main = resolved
            .iter()
            .find(|r| r.project.id == main_project)
            .ok_or_else(|| ModsError::BadResponse("the update was missing".into()))?;
        // Keep the old jar before anything is written: the new file may reuse its name.
        let backup_id = self
            .store
            .backup_for_update(&instance.id, entry, &main.file.filename)
            .await?;
        let written = self
            .write_all(&instance.id, &resolved, progress, |r| {
                if r.project.id == main_project {
                    "user"
                } else {
                    "dependency"
                }
            })
            .await;
        if let Err(e) = written {
            // Put back anything the failed update touched (a new file may have reused the old
            // name), then drop the backup record.
            let _ = self.store.abort_update(&instance.id, backup_id).await;
            return Err(e);
        }
        if main.file.filename != entry.file_name {
            // Remove the old jar and its row; the backup copy is what rollback restores.
            self.store.remove(&instance.id, entry.id).await?;
        }
        // Carry over what the update must not change about the mod.
        let fresh = self
            .store
            .find_by_file(&instance.id, &main.file.filename)
            .await?
            .ok_or(ModsError::UnknownMod)?;
        if !entry.enabled {
            self.store
                .set_enabled(&instance.id, fresh.id, false)
                .await?;
        }
        if entry.installed_as != "user" {
            self.store
                .set_installed_as(fresh.id, &entry.installed_as)
                .await?;
        }
        for r in resolved.iter().filter(|r| r.project.id != main_project) {
            self.store
                .record_added_by_update(&instance.id, &r.file.filename)
                .await?;
        }
        Ok(())
    }

    /// Update every mod that has an update and isn't pinned. One failure doesn't stop the rest.
    pub async fn update_all(
        &self,
        instance_id: &str,
        progress: Option<watch::Sender<Progress>>,
    ) -> Result<UpdateAllReport> {
        let updates = self.check_updates(instance_id).await?;
        let mut report = UpdateAllReport::default();
        for u in updates {
            if u.pinned {
                report.skipped_pinned += 1;
                continue;
            }
            match self
                .update_mod(instance_id, u.mod_id, progress.clone())
                .await
            {
                Ok(true) => report.updated.push(u.title),
                Ok(false) => {}
                Err(e) => report.failed.push(UpdateFailure {
                    title: u.title,
                    message: crate::AppError::from(e).message,
                }),
            }
        }
        Ok(report)
    }

    /// Undo the updates made since the game last started successfully.
    pub async fn rollback(&self, instance_id: &str) -> Result<RollbackReport> {
        self.instances().get(instance_id).await?;
        let report = self.store.rollback_pending(instance_id).await?;
        if report.is_empty() {
            return Err(ModsError::NothingToRollBack.into());
        }
        Ok(report)
    }

    // ---- modpacks -------------------------------------------------------------------

    async fn fetch_pack_file(&self, version: &ModVersion, slug: &str) -> Result<(String, PathBuf)> {
        let file = version
            .files
            .iter()
            .find(|f| f.primary && f.filename.to_ascii_lowercase().ends_with(".mrpack"))
            .or_else(|| {
                version
                    .files
                    .iter()
                    .find(|f| f.filename.to_ascii_lowercase().ends_with(".mrpack"))
            })
            .ok_or_else(|| ModsError::NotAModpack("it has no .mrpack file".into()))?;
        let allowed = reqwest::Url::parse(&file.url)
            .is_ok_and(|u| self.source.download_policy().check(&u).is_ok());
        if !allowed {
            return Err(ModsError::NotAModpack(
                "it is hosted somewhere Kiln doesn't download from".into(),
            )
            .into());
        }
        let safe_slug: String = slug
            .chars()
            .filter(|c| c.is_ascii_alphanumeric() || *c == '-')
            .take(40)
            .collect();
        let name = format!(
            "kiln-{safe_slug}-{}.mrpack",
            &version.id.chars().take(12).collect::<String>()
        );
        let dest = SafePath::new(&self.imports, &name)?;
        let path = dest.as_path().to_path_buf();
        self.downloader
            .download(DownloadTask {
                url: file.url.clone(),
                dest,
                hash: Some(expected_hash(file)?),
                size: (file.size > 0).then_some(file.size),
            })
            .await?;
        Ok((name, path))
    }

    /// Install a Modrinth modpack as a new instance. Only the pack's listed files are
    /// downloaded and its override files unpacked; nothing in a pack is ever run.
    pub async fn install_modpack(
        &self,
        project: &str,
        progress: Option<watch::Sender<Progress>>,
    ) -> Result<Instance> {
        check_id(project)?;
        let project = self.source.project(project).await?;
        if project.kind != ProjectKind::Modpack {
            return Err(ModsError::NotAModpack("that project isn't a modpack".into()).into());
        }
        let version = best_version(
            self.source
                .versions(&project.id, &VersionFilter::default())
                .await?,
        )
        .ok_or_else(|| ModsError::NoCompatibleVersion(project.title.clone()))?;
        let (name, path) = self.fetch_pack_file(&version, &project.slug).await?;
        let imported = self.packs.import(&name, progress).await;
        let files = crate::instance::pack::mrpack_installed_paths(&path);
        let _ = std::fs::remove_file(&path);
        let instance = imported?;
        self.store
            .record_pack(
                &instance.id,
                &project.id,
                &version.id,
                &version.version_number,
                &files?,
            )
            .await?;
        Ok(instance)
    }

    pub async fn check_modpack_update(&self, instance_id: &str) -> Result<Option<PackUpdateInfo>> {
        let Some(link) = self.store.pack_link(instance_id).await? else {
            return Err(ModsError::NotAModpack(
                "this instance wasn't installed from a Modrinth pack".into(),
            )
            .into());
        };
        let latest = best_version(
            self.source
                .versions(&link.project_id, &VersionFilter::default())
                .await?,
        );
        Ok(latest
            .filter(|v| v.id != link.version_id)
            .map(|v| PackUpdateInfo {
                version_id: v.id,
                version_number: v.version_number,
                changelog: truncate(v.changelog),
            }))
    }

    /// Move the instance to the pack's newest version. Files the old pack put there and the
    /// new one doesn't are removed (kept in the backups folder); files you added yourself
    /// are never overwritten or removed.
    pub async fn update_modpack(
        &self,
        instance_id: &str,
        progress: Option<watch::Sender<Progress>>,
    ) -> Result<PackUpdateOutcome> {
        let Some(link) = self.store.pack_link(instance_id).await? else {
            return Err(ModsError::NotAModpack(
                "this instance wasn't installed from a Modrinth pack".into(),
            )
            .into());
        };
        let project = self.source.project(&link.project_id).await?;
        let version = best_version(
            self.source
                .versions(&project.id, &VersionFilter::default())
                .await?,
        )
        .ok_or_else(|| ModsError::NoCompatibleVersion(project.title.clone()))?;
        if version.id == link.version_id {
            return Ok(PackUpdateOutcome::UpToDate);
        }
        let (name, path) = self.fetch_pack_file(&version, &project.slug).await?;
        let applied = self
            .packs
            .apply_update(instance_id, &name, &link.files, progress)
            .await;
        let _ = std::fs::remove_file(&path);
        let files = applied?;
        self.store
            .record_pack(
                instance_id,
                &project.id,
                &version.id,
                &version.version_number,
                &files,
            )
            .await?;
        self.store.sync(instance_id).await?;
        Ok(PackUpdateOutcome::Updated {
            version_number: version.version_number,
        })
    }

    // ---- export ---------------------------------------------------------------------

    /// Export as `.mrpack`. Mods Modrinth knows are listed with their hashes and download
    /// URLs rather than copied in; other jars are bundled and reported.
    pub async fn export_mrpack(&self, instance_id: &str) -> Result<MrpackExport> {
        let entries = self.list(instance_id).await?;
        let known: Vec<&ModEntry> = entries
            .iter()
            .filter(|m| m.is_modrinth() && m.enabled && m.version_id.is_some())
            .collect();
        let version_ids: Vec<String> = known.iter().filter_map(|m| m.version_id.clone()).collect();
        let versions: HashMap<String, ModVersion> = self
            .source
            .versions_by_ids(&version_ids)
            .await?
            .into_iter()
            .map(|v| (v.id.clone(), v))
            .collect();
        let project_ids: Vec<String> = known.iter().filter_map(|m| m.project_id.clone()).collect();
        let projects: HashMap<String, Project> = self
            .source
            .projects(&project_ids)
            .await?
            .into_iter()
            .map(|p| (p.id.clone(), p))
            .collect();
        let mut listed = Vec::new();
        let mut listed_names = HashSet::new();
        for m in &known {
            let (Some(vid), Some(pid)) = (&m.version_id, &m.project_id) else {
                continue;
            };
            let Some(file) = versions.get(vid).and_then(|v| {
                v.files
                    .iter()
                    .find(|f| f.hashes.sha1.as_deref() == Some(m.sha1.as_str()))
            }) else {
                continue;
            };
            let (Some(sha1), Some(sha512)) = (&file.hashes.sha1, &file.hashes.sha512) else {
                continue;
            };
            let allowed = reqwest::Url::parse(&file.url)
                .is_ok_and(|u| self.source.download_policy().check(&u).is_ok());
            if !allowed {
                continue;
            }
            let p = projects.get(pid);
            listed_names.insert(format!("mods/{}", m.file_name));
            listed.push(MrpackFile {
                path: format!("mods/{}", m.file_name),
                sha1: sha1.clone(),
                sha512: sha512.clone(),
                size: file.size,
                url: file.url.clone(),
                client_env: p
                    .map_or("required", |p| env_value(&p.client_side))
                    .to_owned(),
                server_env: p
                    .map_or("required", |p| env_value(&p.server_side))
                    .to_owned(),
            });
        }
        let bundled_unverified: Vec<String> = entries
            .iter()
            .filter(|m| !listed_names.contains(&format!("mods/{}", m.file_name)))
            .map(|m| disk_name(&m.file_name, m.enabled))
            .collect();
        let count = listed.len();
        let file = self.packs.export_mrpack_with(instance_id, listed).await?;
        Ok(MrpackExport {
            file,
            listed: count,
            bundled_unverified,
        })
    }
}

fn env_value(side: &str) -> &'static str {
    match side {
        "optional" => "optional",
        "unsupported" => "unsupported",
        _ => "required",
    }
}

fn source_info(v: &ModVersion, p: Option<&Project>) -> SourceInfo {
    SourceInfo {
        project_id: v.project_id.clone(),
        version_id: v.id.clone(),
        version_number: v.version_number.clone(),
        channel: v.channel.as_str().to_owned(),
        title: p.map(|p| p.title.clone()),
        author: p.and_then(|p| p.author.clone()),
        license: p.and_then(|p| p.license.as_ref().map(|l| l.name.clone())),
        downloads: p.map(|p| i64::try_from(p.downloads).unwrap_or(i64::MAX)),
        icon_url: p.and_then(|p| p.icon_url.clone()),
    }
}

async fn hash_both(path: &std::path::Path) -> Result<(String, String)> {
    let p = path.to_path_buf();
    tokio::task::spawn_blocking(move || super::store::hash_file(&p))
        .await
        .map_err(|e| Error::Io(std::io::Error::other(e)))?
}

#[cfg(test)]
mod tests {
    use std::io::Write;

    use serde_json::json;

    use super::*;
    use crate::hash::hash_bytes;
    use crate::mods::testkit::{dep, files_in, sha1, tree, world, World};

    fn mod_project(w: &World, id: &str, slug: &str) {
        w.fake.add_project(id, slug, &slug.to_uppercase(), "mod");
    }

    fn fabric(
        w: &World,
        id: &str,
        project: &str,
        number: &str,
        file: &str,
        bytes: &[u8],
        deps: Vec<serde_json::Value>,
    ) {
        w.fake.add_version(
            id,
            project,
            number,
            file,
            bytes,
            deps,
            &["fabric"],
            &["1.20.1"],
        );
    }

    async fn sample() -> World {
        let w = world().await;
        for (id, slug) in [("AAAA", "a"), ("BBBB", "b"), ("CCCC", "c")] {
            mod_project(&w, id, slug);
        }
        fabric(&w, "vb1", "BBBB", "1.0", "b-1.0.jar", b"B-JAR", vec![]);
        fabric(&w, "vc1", "CCCC", "1.0", "c-1.0.jar", b"C-JAR", vec![]);
        fabric(
            &w,
            "va1",
            "AAAA",
            "1.0",
            "a-1.0.jar",
            b"A-JAR-1",
            vec![dep("BBBB", "required"), dep("CCCC", "optional")],
        );
        w
    }

    #[tokio::test]
    async fn install_pulls_in_required_dependencies_and_offers_optional_ones() {
        let w = sample().await;
        let plan = w.service.plan_install(w.id(), "AAAA").await.unwrap();
        let titles: Vec<&str> = plan.mods.iter().map(|m| m.title.as_str()).collect();
        assert_eq!(titles, ["A", "B"]);
        assert_eq!(
            plan.optional
                .iter()
                .map(|o| o.title.as_str())
                .collect::<Vec<_>>(),
            ["C"]
        );
        assert_eq!(w.fake.count("GET /cdn/"), 0, "planning must not download");
        assert!(files_in(&w.mods_dir()).is_empty());

        w.service.install(w.id(), "AAAA", &[], None).await.unwrap();
        assert_eq!(files_in(&w.mods_dir()), ["a-1.0.jar", "b-1.0.jar"]);
        let list = w.service.list(w.id()).await.unwrap();
        let a = list.iter().find(|m| m.file_name == "a-1.0.jar").unwrap();
        let b = list.iter().find(|m| m.file_name == "b-1.0.jar").unwrap();
        assert_eq!(
            (a.installed_as.as_str(), b.installed_as.as_str()),
            ("user", "dependency")
        );
        assert_eq!(a.source, "modrinth");
        assert_eq!(a.author.as_deref(), Some("alice"));
        assert_eq!(a.license.as_deref(), Some("MIT License"));
        assert_eq!(a.sha1, sha1(b"A-JAR-1"));

        // Installing again changes nothing.
        let again = w.service.install(w.id(), "AAAA", &[], None).await.unwrap();
        assert!(again.mods.is_empty());
        assert_eq!(again.already_installed, ["A"]);
        assert_eq!(w.fake.count("GET /cdn/"), 2);
    }

    #[tokio::test]
    async fn only_offered_optional_dependencies_can_be_added() {
        let w = sample().await;
        let err = w
            .service
            .install(w.id(), "AAAA", &["BBBB".into()], None)
            .await
            .unwrap_err();
        assert!(matches!(err, Error::Mods(ModsError::InvalidId)), "{err:?}");
        assert!(files_in(&w.mods_dir()).is_empty());

        w.service
            .install(w.id(), "AAAA", &["CCCC".into()], None)
            .await
            .unwrap();
        assert_eq!(
            files_in(&w.mods_dir()),
            ["a-1.0.jar", "b-1.0.jar", "c-1.0.jar"]
        );
    }

    #[tokio::test]
    async fn an_incompatible_installed_mod_blocks_the_install() {
        let w = sample().await;
        mod_project(&w, "DDDD", "d");
        fabric(&w, "vd1", "DDDD", "1.0", "d-1.0.jar", b"D-JAR", vec![]);
        mod_project(&w, "EEEE", "e");
        fabric(
            &w,
            "ve1",
            "EEEE",
            "1.0",
            "e-1.0.jar",
            b"E-JAR",
            vec![dep("DDDD", "incompatible")],
        );
        w.service.install(w.id(), "DDDD", &[], None).await.unwrap();

        let plan = w.service.plan_install(w.id(), "EEEE").await.unwrap();
        assert_eq!(
            plan.conflicts,
            [Conflict {
                title: "E".into(),
                conflicts_with: "D".into()
            }]
        );
        let err = w
            .service
            .install(w.id(), "EEEE", &[], None)
            .await
            .unwrap_err();
        assert!(
            matches!(err, Error::Mods(ModsError::Conflict(_))),
            "{err:?}"
        );
        assert_eq!(files_in(&w.mods_dir()), ["d-1.0.jar"]);
    }

    #[tokio::test]
    async fn a_mod_with_no_release_for_the_instance_is_refused() {
        let w = world().await;
        mod_project(&w, "FFFF", "f");
        w.fake.add_version(
            "vf1",
            "FFFF",
            "1.0",
            "f.jar",
            b"F",
            vec![],
            &["forge"],
            &["1.20.1"],
        );
        w.fake.add_version(
            "vf2",
            "FFFF",
            "1.1",
            "f2.jar",
            b"F2",
            vec![],
            &["fabric"],
            &["1.19.4"],
        );
        let err = w
            .service
            .install(w.id(), "FFFF", &[], None)
            .await
            .unwrap_err();
        assert!(
            matches!(err, Error::Mods(ModsError::NoCompatibleVersion(_))),
            "{err:?}"
        );
    }

    #[tokio::test]
    async fn vanilla_instances_and_bad_ids_are_refused_before_any_request() {
        let w = sample().await;
        let vanilla = w
            .instances
            .create(crate::instance::NewInstance {
                name: "Plain".into(),
                mc_version: "1.20.1".into(),
                loader: LoaderKind::Vanilla,
                loader_version: None,
            })
            .await
            .unwrap();
        let err = w
            .service
            .plan_install(&vanilla.id, "AAAA")
            .await
            .unwrap_err();
        assert!(
            matches!(err, Error::Mods(ModsError::VanillaInstance)),
            "{err:?}"
        );
        for bad in ["../x", "a/b", "a?b=c", "", "a b", &"x".repeat(65)] {
            let err = w.service.plan_install(w.id(), bad).await.unwrap_err();
            assert!(
                matches!(err, Error::Mods(ModsError::InvalidId)),
                "{bad:?}: {err:?}"
            );
        }
        assert_eq!(w.fake.log().len(), 0, "no request may be made for a bad id");
    }

    #[tokio::test]
    async fn hostile_version_metadata_is_not_installed() {
        for tamper in 0..5 {
            let w = sample().await;
            w.fake.edit_version("vb1", |v| match tamper {
                0 => v["files"][0]["url"] = json!("https://evil.example/b.jar"),
                1 => v["files"][0]["filename"] = json!("../b.jar"),
                2 => v["files"][0]["filename"] = json!("b.txt"),
                3 => v["files"][0]["hashes"] = json!({}),
                _ => v["files"][0]["url"] = json!("http://cdn.modrinth.com/b.jar"),
            });
            let err = w
                .service
                .install(w.id(), "AAAA", &[], None)
                .await
                .unwrap_err();
            assert!(
                matches!(err, Error::Mods(ModsError::NoFile(_))),
                "case {tamper}: {err:?}"
            );
            assert!(files_in(&w.mods_dir()).is_empty(), "case {tamper}");
            assert_eq!(w.fake.count("GET /cdn/"), 0, "case {tamper}");
        }
    }

    #[tokio::test]
    async fn a_file_that_fails_its_hash_never_reaches_the_mods_folder() {
        // Same length, different bytes: only the hash can catch it.
        let w = sample().await;
        w.fake.set_blob("b-1.0.jar", b"X-JAR");
        let err = w
            .service
            .install(w.id(), "AAAA", &[], None)
            .await
            .unwrap_err();
        assert!(matches!(err, Error::HashMismatch { .. }), "{err:?}");
        assert!(!files_in(&w.mods_dir()).iter().any(|f| f.ends_with(".jar")));
        assert!(w.store.list(w.id()).await.unwrap().is_empty());

        // More data than the listing promised is refused as well.
        let w = sample().await;
        w.fake.set_blob("b-1.0.jar", b"B-JAR-AND-A-LOT-MORE");
        assert!(w.service.install(w.id(), "AAAA", &[], None).await.is_err());
        assert!(!files_in(&w.mods_dir()).iter().any(|f| f.ends_with(".jar")));
    }

    #[tokio::test]
    async fn updates_are_found_by_hash_installed_with_new_dependencies_and_can_be_rolled_back() {
        let w = sample().await;
        w.service.install(w.id(), "AAAA", &[], None).await.unwrap();
        mod_project(&w, "EEEE", "e");
        fabric(&w, "ve1", "EEEE", "1.0", "e-1.0.jar", b"E-JAR", vec![]);
        fabric(
            &w,
            "va2",
            "AAAA",
            "2.0",
            "a-2.0.jar",
            b"A-JAR-2",
            vec![dep("BBBB", "required"), dep("EEEE", "required")],
        );

        let updates = w.service.check_updates(w.id()).await.unwrap();
        assert_eq!(updates.len(), 1);
        assert_eq!(updates[0].title, "A");
        assert_eq!(updates[0].current_version.as_deref(), Some("1.0"));
        assert_eq!(updates[0].new_version, "2.0");
        assert_eq!(updates[0].changelog.as_deref(), Some("Changes in 2.0"));

        assert!(w
            .service
            .update_mod(w.id(), updates[0].mod_id, None)
            .await
            .unwrap());
        assert_eq!(
            files_in(&w.mods_dir()),
            ["a-2.0.jar", "b-1.0.jar", "e-1.0.jar"]
        );
        assert_eq!(w.store.pending_updates(w.id()).await.unwrap(), 2);
        assert!(w.service.check_updates(w.id()).await.unwrap().is_empty());

        let report = w.service.rollback(w.id()).await.unwrap();
        assert_eq!(report.restored, ["a-1.0.jar"]);
        assert_eq!(report.removed, ["e-1.0.jar"]);
        assert!(report.failed.is_empty());
        assert_eq!(files_in(&w.mods_dir()), ["a-1.0.jar", "b-1.0.jar"]);
        assert_eq!(
            std::fs::read(w.mods_dir().join("a-1.0.jar")).unwrap(),
            b"A-JAR-1"
        );
        let list = w.store.list(w.id()).await.unwrap();
        let a = list.iter().find(|m| m.file_name == "a-1.0.jar").unwrap();
        assert_eq!(a.version_number.as_deref(), Some("1.0"));
        assert_eq!(a.source, "modrinth");
        assert_eq!(w.store.pending_updates(w.id()).await.unwrap(), 0);
        let nothing = w.service.rollback(w.id()).await.unwrap_err();
        assert!(
            matches!(nothing, Error::Mods(ModsError::NothingToRollBack)),
            "{nothing:?}"
        );
    }

    #[tokio::test]
    async fn an_update_that_reuses_the_file_name_is_still_reversible() {
        let w = sample().await;
        w.service.install(w.id(), "BBBB", &[], None).await.unwrap();
        fabric(&w, "vb2", "BBBB", "2.0", "b-1.0.jar", b"B-JAR-NEW", vec![]);
        let id = w.service.check_updates(w.id()).await.unwrap()[0].mod_id;
        w.service.update_mod(w.id(), id, None).await.unwrap();
        assert_eq!(
            std::fs::read(w.mods_dir().join("b-1.0.jar")).unwrap(),
            b"B-JAR-NEW"
        );
        w.service.rollback(w.id()).await.unwrap();
        assert_eq!(
            std::fs::read(w.mods_dir().join("b-1.0.jar")).unwrap(),
            b"B-JAR"
        );
        assert_eq!(w.store.list(w.id()).await.unwrap()[0].sha1, sha1(b"B-JAR"));
    }

    #[tokio::test]
    async fn rollback_refuses_a_backup_that_no_longer_matches() {
        let w = sample().await;
        w.service.install(w.id(), "BBBB", &[], None).await.unwrap();
        fabric(&w, "vb2", "BBBB", "2.0", "b-2.0.jar", b"B-JAR-NEW", vec![]);
        let id = w.service.check_updates(w.id()).await.unwrap()[0].mod_id;
        w.service.update_mod(w.id(), id, None).await.unwrap();
        // Someone replaces the backup copy.
        let backup = tree(&w.dirs.backups)
            .into_iter()
            .find(|p| p.starts_with("mods/"))
            .unwrap();
        std::fs::write(w.dirs.backups.join(&backup), b"EVIL").unwrap();

        let err = w.store.rollback_pending(w.id()).await.unwrap();
        assert_eq!(err.failed, ["b-1.0.jar"]);
        assert!(err.restored.is_empty());
        assert_eq!(
            files_in(&w.mods_dir()),
            ["b-2.0.jar"],
            "the tampered jar must not be restored"
        );
    }

    #[tokio::test]
    async fn a_failed_update_download_leaves_everything_as_it_was() {
        let w = sample().await;
        w.service.install(w.id(), "BBBB", &[], None).await.unwrap();
        fabric(&w, "vb2", "BBBB", "2.0", "b-2.0.jar", b"B-JAR-NEW", vec![]);
        let id = w.service.check_updates(w.id()).await.unwrap()[0].mod_id;
        let base = w.server.uri();
        w.fake.edit_version("vb2", |v| {
            v["files"][0]["url"] = json!(format!("{base}/cdn/missing.jar"))
        });
        assert!(w.service.update_mod(w.id(), id, None).await.is_err());
        assert_eq!(files_in(&w.mods_dir()), ["b-1.0.jar"]);
        assert_eq!(w.store.pending_updates(w.id()).await.unwrap(), 0);
        assert!(
            tree(&w.dirs.backups).is_empty(),
            "the unused backup copy must be removed"
        );
    }

    #[tokio::test]
    async fn an_update_that_fails_half_way_restores_the_old_jar_even_when_the_name_is_reused() {
        let w = sample().await;
        w.service.install(w.id(), "BBBB", &[], None).await.unwrap();
        mod_project(&w, "EEEE", "e");
        fabric(&w, "ve1", "EEEE", "1.0", "e-1.0.jar", b"E-JAR", vec![]);
        // The new B reuses b-1.0.jar and needs E, whose file is corrupt (same length).
        fabric(
            &w,
            "vb2",
            "BBBB",
            "2.0",
            "b-1.0.jar",
            b"B-JAR-2",
            vec![dep("EEEE", "required")],
        );
        w.fake.set_blob("e-1.0.jar", b"X-JAR");
        let id = w.service.check_updates(w.id()).await.unwrap()[0].mod_id;
        assert!(w.service.update_mod(w.id(), id, None).await.is_err());
        assert_eq!(files_in(&w.mods_dir()), ["b-1.0.jar"]);
        assert_eq!(
            std::fs::read(w.mods_dir().join("b-1.0.jar")).unwrap(),
            b"B-JAR"
        );
        assert_eq!(w.store.pending_updates(w.id()).await.unwrap(), 0);
        assert_eq!(w.store.list(w.id()).await.unwrap()[0].sha1, sha1(b"B-JAR"));
        assert!(tree(&w.dirs.backups).is_empty());
    }

    #[tokio::test]
    async fn pinned_mods_are_not_updated_and_update_all_skips_them() {
        let w = sample().await;
        w.service.install(w.id(), "AAAA", &[], None).await.unwrap();
        fabric(
            &w,
            "va2",
            "AAAA",
            "2.0",
            "a-2.0.jar",
            b"A-JAR-2",
            vec![dep("BBBB", "required")],
        );
        fabric(&w, "vb2", "BBBB", "2.0", "b-2.0.jar", b"B-JAR-2", vec![]);
        let list = w.store.list(w.id()).await.unwrap();
        let a = list.iter().find(|m| m.file_name == "a-1.0.jar").unwrap();
        w.store.set_pinned(w.id(), a.id, true).await.unwrap();

        let err = w.service.update_mod(w.id(), a.id, None).await.unwrap_err();
        assert!(matches!(err, Error::Mods(ModsError::Pinned)), "{err:?}");
        let report = w.service.update_all(w.id(), None).await.unwrap();
        assert_eq!(report.updated, ["B"]);
        assert_eq!(report.skipped_pinned, 1);
        assert!(report.failed.is_empty());
        assert_eq!(files_in(&w.mods_dir()), ["a-1.0.jar", "b-2.0.jar"]);
        // The pin survives and can be lifted.
        w.store.set_pinned(w.id(), a.id, false).await.unwrap();
        assert_eq!(
            w.service.update_all(w.id(), None).await.unwrap().updated,
            ["A"]
        );
    }

    #[tokio::test]
    async fn a_disabled_mod_stays_disabled_through_an_update() {
        let w = sample().await;
        w.service.install(w.id(), "BBBB", &[], None).await.unwrap();
        let id = w.store.list(w.id()).await.unwrap()[0].id;
        w.store.set_enabled(w.id(), id, false).await.unwrap();
        assert_eq!(files_in(&w.mods_dir()), ["b-1.0.jar.disabled"]);
        // Disabled mods aren't offered updates, but an explicit update keeps the state.
        assert!(w.service.check_updates(w.id()).await.unwrap().is_empty());
        fabric(&w, "vb2", "BBBB", "2.0", "b-2.0.jar", b"B-JAR-2", vec![]);
        assert!(w.service.update_mod(w.id(), id, None).await.unwrap());
        assert_eq!(files_in(&w.mods_dir()), ["b-2.0.jar.disabled"]);
        w.service.rollback(w.id()).await.unwrap();
        assert_eq!(files_in(&w.mods_dir()), ["b-1.0.jar.disabled"]);
    }

    #[tokio::test]
    async fn unknown_jars_are_flagged_unverified_and_known_ones_identified() {
        let w = sample().await;
        std::fs::write(w.mods_dir().join("whatever.jar"), b"B-JAR").unwrap(); // same bytes as b-1.0.jar
        std::fs::write(w.mods_dir().join("custom.jar"), b"HOMEBREW").unwrap();
        std::fs::write(w.mods_dir().join("notes.txt"), b"ignored").unwrap();
        let list = w.service.list(w.id()).await.unwrap();
        assert_eq!(list.len(), 2);
        let known = list.iter().find(|m| m.file_name == "whatever.jar").unwrap();
        assert_eq!(
            (known.source.as_str(), known.title.as_deref()),
            ("modrinth", Some("B"))
        );
        assert_eq!(known.author.as_deref(), Some("alice"));
        assert_eq!(known.downloads, Some(1234));
        let custom = list.iter().find(|m| m.file_name == "custom.jar").unwrap();
        assert_eq!(custom.source, "unverified");
        assert!(custom.project_id.is_none() && custom.title.is_none());

        // Not asked about again within a day.
        w.service.list(w.id()).await.unwrap();
        assert_eq!(w.fake.count("POST /v2/version_files"), 1);

        // Replacing a jar drops what was known about the old one.
        std::fs::write(
            w.mods_dir().join("whatever.jar"),
            b"SOMETHING ELSE ENTIRELY",
        )
        .unwrap();
        let list = w.service.list(w.id()).await.unwrap();
        let swapped = list.iter().find(|m| m.file_name == "whatever.jar").unwrap();
        assert_eq!(swapped.source, "unverified");
        assert!(swapped.project_id.is_none() && swapped.title.is_none());
        assert_eq!(swapped.sha1, sha1(b"SOMETHING ELSE ENTIRELY"));
        // Deleting a jar removes its row.
        std::fs::remove_file(w.mods_dir().join("custom.jar")).unwrap();
        assert_eq!(w.service.list(w.id()).await.unwrap().len(), 1);
    }

    #[cfg(unix)]
    #[tokio::test]
    async fn symlinked_jars_are_never_tracked() {
        let w = sample().await;
        std::os::unix::fs::symlink("/etc/passwd", w.mods_dir().join("evil.jar")).unwrap();
        assert!(w.service.list(w.id()).await.unwrap().is_empty());
    }

    #[tokio::test]
    async fn removing_and_toggling_only_touch_the_named_mod() {
        let w = sample().await;
        w.service.install(w.id(), "AAAA", &[], None).await.unwrap();
        let list = w.store.list(w.id()).await.unwrap();
        let a = list.iter().find(|m| m.file_name == "a-1.0.jar").unwrap();
        w.store.remove(w.id(), a.id).await.unwrap();
        assert_eq!(files_in(&w.mods_dir()), ["b-1.0.jar"]);
        let err = w.store.remove(w.id(), a.id).await.unwrap_err();
        assert!(matches!(err, Error::Mods(ModsError::UnknownMod)));
        // A mod id from another instance is not reachable.
        let other = w
            .instances
            .create(crate::instance::NewInstance {
                name: "Other".into(),
                mc_version: "1.20.1".into(),
                loader: LoaderKind::Fabric,
                loader_version: Some("0.15.0".into()),
            })
            .await
            .unwrap();
        let b = list.iter().find(|m| m.file_name == "b-1.0.jar").unwrap();
        assert!(w.store.remove(&other.id, b.id).await.is_err());
        assert_eq!(files_in(&w.mods_dir()), ["b-1.0.jar"]);
    }

    // ---- export and modpacks ----------------------------------------------------------

    fn zip_bytes(entries: &[(&str, Vec<u8>)]) -> Vec<u8> {
        let mut w = zip::ZipWriter::new(std::io::Cursor::new(Vec::new()));
        let o = zip::write::SimpleFileOptions::default();
        for (name, data) in entries {
            w.start_file(*name, o).unwrap();
            w.write_all(data).unwrap();
        }
        w.finish().unwrap().into_inner()
    }

    fn listed(base: &str, path: &str, name: &str, bytes: &[u8]) -> serde_json::Value {
        json!({
            "path": path,
            "hashes": {"sha1": sha1(bytes), "sha512": hash_bytes(HashAlgo::Sha512, bytes)},
            "env": {"client": "required", "server": "required"},
            "downloads": [format!("{base}/cdn/{name}")],
            "fileSize": bytes.len(),
        })
    }

    #[tokio::test]
    async fn export_lists_modrinth_mods_by_hash_and_bundles_the_rest() {
        let w = sample().await;
        w.service.install(w.id(), "AAAA", &[], None).await.unwrap();
        std::fs::write(w.mods_dir().join("custom.jar"), b"HOMEBREW").unwrap();
        std::fs::create_dir_all(w.game.join("config")).unwrap();
        std::fs::write(w.game.join("config/a.toml"), b"x=1").unwrap();
        std::fs::create_dir_all(w.game.join("saves/World")).unwrap();
        std::fs::write(w.game.join("saves/World/level.dat"), b"WORLD").unwrap();

        let out = w.service.export_mrpack(w.id()).await.unwrap();
        assert_eq!(out.listed, 2);
        assert_eq!(out.bundled_unverified, ["custom.jar"]);

        let path = w.dirs.exports.join(&out.file);
        let index: serde_json::Value = serde_json::from_slice(
            &crate::archive::read_zip_entry(&path, "modrinth.index.json", 1 << 20).unwrap(),
        )
        .unwrap();
        let files = index["files"].as_array().unwrap();
        let a = files
            .iter()
            .find(|f| f["path"] == "mods/a-1.0.jar")
            .unwrap();
        assert_eq!(a["hashes"]["sha1"], sha1(b"A-JAR-1"));
        assert_eq!(
            a["hashes"]["sha512"],
            hash_bytes(HashAlgo::Sha512, b"A-JAR-1")
        );
        assert_eq!(
            a["downloads"][0],
            format!("{}/cdn/a-1.0.jar", w.server.uri())
        );
        assert_eq!(
            (a["env"]["client"].as_str(), a["env"]["server"].as_str()),
            (Some("required"), Some("optional"))
        );
        let names: Vec<String> = zip::ZipArchive::new(std::fs::File::open(&path).unwrap())
            .unwrap()
            .file_names()
            .map(str::to_owned)
            .collect();
        assert!(names.contains(&"overrides/mods/custom.jar".to_owned()));
        assert!(names.contains(&"overrides/config/a.toml".to_owned()));
        assert!(!names.iter().any(
            |n| n.starts_with("overrides/mods/a-1.0") || n.starts_with("overrides/mods/b-1.0")
        ));
        assert!(
            !names.iter().any(|n| n.contains("saves")),
            "worlds are never exported"
        );

        // The exported pack imports again, fetching the listed mods by hash.
        std::fs::copy(&path, w.dirs.imports.join(&out.file)).unwrap();
        let copy = w.packs.import(&out.file, None).await.unwrap();
        let dir = w.instances.game_dir(&copy.id).await.unwrap();
        assert_eq!(
            files_in(&dir.as_path().join("mods")),
            ["a-1.0.jar", "b-1.0.jar", "custom.jar"]
        );
    }

    #[tokio::test]
    async fn modpacks_install_and_update_without_touching_user_files() {
        let w = world().await;
        let base = w.server.uri();
        w.fake.add_project("PPPP", "pack", "Pack", "modpack");
        let m1 = b"M1".to_vec();
        w.fake.set_blob("m1.jar", &m1);
        let pack1 = zip_bytes(&[
            (
                "modrinth.index.json",
                serde_json::to_vec(&json!({
                    "formatVersion": 1, "game": "minecraft", "versionId": "1.0", "name": "Pack",
                    "files": [listed(&base, "mods/m1.jar", "m1.jar", &m1)],
                    "dependencies": {"minecraft": "1.20.1", "fabric-loader": "0.15.0"},
                }))
                .unwrap(),
            ),
            ("overrides/config/pack.toml", b"v1".to_vec()),
        ]);
        w.fake.add_version(
            "vp1",
            "PPPP",
            "1.0",
            "pack-1.0.mrpack",
            &pack1,
            vec![],
            &["fabric"],
            &["1.20.1"],
        );

        let inst = w.service.install_modpack("PPPP", None).await.unwrap();
        let dir = w
            .instances
            .game_dir(&inst.id)
            .await
            .unwrap()
            .as_path()
            .to_path_buf();
        assert_eq!(files_in(&dir.join("mods")), ["m1.jar"]);
        assert_eq!(std::fs::read(dir.join("config/pack.toml")).unwrap(), b"v1");
        assert!(
            files_in(&w.dirs.imports).is_empty(),
            "the downloaded pack is cleaned up"
        );
        let link = w.store.pack_link(&inst.id).await.unwrap().unwrap();
        assert_eq!(link.version_id, "vp1");
        assert_eq!(link.files, ["config/pack.toml", "mods/m1.jar"]);
        assert!(w
            .service
            .check_modpack_update(&inst.id)
            .await
            .unwrap()
            .is_none());

        // The player adds their own files and edits one of the pack's.
        std::fs::write(dir.join("mods/mine.jar"), b"MINE").unwrap();
        std::fs::write(dir.join("options.txt"), b"USER-OPTIONS").unwrap();
        std::fs::write(dir.join("config/pack.toml"), b"USER-EDIT").unwrap();
        std::fs::write(dir.join("config/own.toml"), b"OWN").unwrap();

        let m2 = b"M2".to_vec();
        w.fake.set_blob("m2.jar", &m2);
        let pack2 = zip_bytes(&[
            (
                "modrinth.index.json",
                serde_json::to_vec(&json!({
                    "formatVersion": 1, "game": "minecraft", "versionId": "2.0", "name": "Pack",
                    "files": [listed(&base, "mods/m2.jar", "m2.jar", &m2)],
                    "dependencies": {"minecraft": "1.20.4", "fabric-loader": "0.15.1"},
                }))
                .unwrap(),
            ),
            ("overrides/config/pack.toml", b"v2".to_vec()),
            ("overrides/config/own.toml", b"PACK-WANTS-THIS".to_vec()),
            ("overrides/config/new.toml", b"new".to_vec()),
            ("overrides/options.txt", b"PACK-OPTIONS".to_vec()),
            ("overrides/saves/W/level.dat", b"PACK-WORLD".to_vec()),
        ]);
        w.fake.add_version(
            "vp2",
            "PPPP",
            "2.0",
            "pack-2.0.mrpack",
            &pack2,
            vec![],
            &["fabric"],
            &["1.20.4"],
        );

        let info = w
            .service
            .check_modpack_update(&inst.id)
            .await
            .unwrap()
            .unwrap();
        assert_eq!(info.version_number, "2.0");
        let outcome = w.service.update_modpack(&inst.id, None).await.unwrap();
        assert_eq!(
            outcome,
            PackUpdateOutcome::Updated {
                version_number: "2.0".into()
            }
        );

        assert_eq!(
            files_in(&dir.join("mods")),
            ["m2.jar", "mine.jar"],
            "old pack mod removed, own mod kept"
        );
        assert_eq!(std::fs::read(dir.join("config/pack.toml")).unwrap(), b"v2");
        assert_eq!(
            std::fs::read(dir.join("config/own.toml")).unwrap(),
            b"OWN",
            "not the pack's file: untouched"
        );
        assert_eq!(std::fs::read(dir.join("config/new.toml")).unwrap(), b"new");
        assert_eq!(
            std::fs::read(dir.join("options.txt")).unwrap(),
            b"USER-OPTIONS"
        );
        assert!(
            !dir.join("saves").join("W").exists(),
            "an update never writes worlds"
        );
        let backed_up = tree(&w.dirs.backups);
        assert!(
            backed_up.iter().any(|p| p.ends_with("/mods/m1.jar")),
            "{backed_up:?}"
        );
        let edited = backed_up
            .iter()
            .find(|p| p.ends_with("/config/pack.toml"))
            .unwrap();
        assert_eq!(
            std::fs::read(w.dirs.backups.join(edited)).unwrap(),
            b"USER-EDIT"
        );
        let now = w.instances.get(&inst.id).await.unwrap();
        assert_eq!(
            (now.mc_version.as_str(), now.loader_version.as_deref()),
            ("1.20.4", Some("0.15.1"))
        );
        assert_eq!(
            w.service.update_modpack(&inst.id, None).await.unwrap(),
            PackUpdateOutcome::UpToDate
        );
    }

    #[tokio::test]
    async fn only_modpacks_can_be_installed_as_modpacks() {
        let w = sample().await;
        let err = w.service.install_modpack("AAAA", None).await.unwrap_err();
        assert!(
            matches!(err, Error::Mods(ModsError::NotAModpack(_))),
            "{err:?}"
        );
        let err = w.service.update_modpack(w.id(), None).await.unwrap_err();
        assert!(
            matches!(err, Error::Mods(ModsError::NotAModpack(_))),
            "{err:?}"
        );
    }
}
