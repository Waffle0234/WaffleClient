//! A fake Modrinth for tests: one wiremock server that answers the API endpoints Kiln uses
//! from in-memory data and serves file bytes from `/cdn/`. State is shared, so a test can
//! publish a new version part-way through.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

use serde_json::{json, Value};
use wiremock::{Mock, MockServer, Request, Respond, ResponseTemplate};

use super::modrinth::Modrinth;
use super::service::ModService;
use super::store::ModStore;
use crate::db::{self, Db};
use crate::download::{Downloader, RetryPolicy};
use crate::hash::{hash_bytes, HashAlgo};
use crate::instance::pack::PackService;
use crate::instance::{Instance, InstanceStore, NewInstance};
use crate::loader::LoaderKind;
use crate::net::{HostPolicy, HttpClient};
use crate::paths::DataDirs;

#[derive(Default)]
pub struct FakeState {
    pub base: String,
    pub projects: Vec<Value>,
    pub versions: Vec<Value>,
    pub blobs: HashMap<String, Vec<u8>>,
    /// `"METHOD /path"` for every request, in order.
    pub log: Vec<String>,
}

#[derive(Clone)]
pub struct Fake {
    pub state: Arc<Mutex<FakeState>>,
}

fn query_list(req: &Request, key: &str) -> Vec<String> {
    req.url
        .query_pairs()
        .find(|(k, _)| k == key)
        .and_then(|(_, v)| serde_json::from_str(&v).ok())
        .unwrap_or_default()
}

fn str_list(v: &Value) -> Vec<String> {
    v.as_array()
        .map(|a| {
            a.iter()
                .filter_map(|x| x.as_str().map(str::to_owned))
                .collect()
        })
        .unwrap_or_default()
}

fn accepts(v: &Value, loaders: &[String], games: &[String]) -> bool {
    let vl = str_list(&v["loaders"]);
    let vg = str_list(&v["game_versions"]);
    (loaders.is_empty() || vl.iter().any(|l| loaders.contains(l)))
        && (games.is_empty() || vg.iter().any(|g| games.contains(g)))
}

fn file_sha1(v: &Value) -> Vec<String> {
    v["files"]
        .as_array()
        .map(|f| {
            f.iter()
                .filter_map(|f| f["hashes"]["sha1"].as_str().map(str::to_owned))
                .collect()
        })
        .unwrap_or_default()
}

impl Respond for Fake {
    fn respond(&self, req: &Request) -> ResponseTemplate {
        let mut st = self.state.lock().unwrap();
        let path = req.url.path().to_owned();
        st.log.push(format!("{} {path}", req.method));
        let ok = |v: Value| ResponseTemplate::new(200).set_body_json(v);
        if let Some(name) = path.strip_prefix("/cdn/") {
            return match st.blobs.get(name) {
                Some(b) => ResponseTemplate::new(200).set_body_bytes(b.clone()),
                None => ResponseTemplate::new(404),
            };
        }
        let Some(api) = path.strip_prefix("/v2") else {
            return ResponseTemplate::new(404);
        };
        let loaders = query_list(req, "loaders");
        let games = query_list(req, "game_versions");
        match (req.method.as_str(), api) {
            ("GET", "/projects") => {
                let ids = query_list(req, "ids");
                ok(Value::Array(
                    st.projects
                        .iter()
                        .filter(|p| ids.iter().any(|i| p["id"] == *i))
                        .cloned()
                        .collect(),
                ))
            }
            ("GET", "/teams") => {
                let ids = query_list(req, "ids");
                ok(Value::Array(
                    ids.iter()
                        .map(|_| json!([{"role": "Owner", "user": {"username": "alice"}}]))
                        .collect(),
                ))
            }
            ("GET", "/versions") => {
                let ids = query_list(req, "ids");
                ok(Value::Array(
                    st.versions
                        .iter()
                        .filter(|v| ids.iter().any(|i| v["id"] == *i))
                        .cloned()
                        .collect(),
                ))
            }
            ("GET", p) if p.starts_with("/version/") => {
                let id = &p["/version/".len()..];
                match st.versions.iter().find(|v| v["id"] == id) {
                    Some(v) => ok(v.clone()),
                    None => ResponseTemplate::new(404),
                }
            }
            ("GET", p) if p.starts_with("/project/") && p.ends_with("/version") => {
                let id = &p["/project/".len()..p.len() - "/version".len()];
                ok(Value::Array(
                    st.versions
                        .iter()
                        .filter(|v| v["project_id"] == id && accepts(v, &loaders, &games))
                        .cloned()
                        .collect(),
                ))
            }
            ("POST", "/version_files") | ("POST", "/version_files/update") => {
                let body: Value = serde_json::from_slice(&req.body).unwrap_or(Value::Null);
                let hashes = str_list(&body["hashes"]);
                let update = api.ends_with("update");
                let loaders = str_list(&body["loaders"]);
                let games = str_list(&body["game_versions"]);
                let mut out = serde_json::Map::new();
                for h in hashes {
                    let Some(owner) = st.versions.iter().find(|v| file_sha1(v).contains(&h)) else {
                        continue;
                    };
                    let chosen = if update {
                        st.versions.iter().find(|v| {
                            v["project_id"] == owner["project_id"] && accepts(v, &loaders, &games)
                        })
                    } else {
                        Some(owner)
                    };
                    if let Some(c) = chosen {
                        out.insert(h, c.clone());
                    }
                }
                ok(Value::Object(out))
            }
            _ => ResponseTemplate::new(404),
        }
    }
}

pub fn sha1(b: &[u8]) -> String {
    hash_bytes(HashAlgo::Sha1, b)
}

impl Fake {
    pub fn log(&self) -> Vec<String> {
        self.state.lock().unwrap().log.clone()
    }

    pub fn count(&self, prefix: &str) -> usize {
        self.log().iter().filter(|l| l.starts_with(prefix)).count()
    }

    pub fn add_project(&self, id: &str, slug: &str, title: &str, kind: &str) {
        self.state.lock().unwrap().projects.push(json!({
            "id": id, "slug": slug, "title": title, "description": "d", "body": "b",
            "project_type": kind, "team": format!("team{id}"), "downloads": 1234, "followers": 5,
            "icon_url": "https://cdn.modrinth.com/data/x/icon.png",
            "license": {"id": "MIT", "name": "MIT License", "url": "https://opensource.org/MIT"},
            "categories": ["optimization"], "loaders": ["fabric"], "game_versions": ["1.20.1"],
            "client_side": "required", "server_side": "optional",
        }));
    }

    /// Publish a version (newest first) whose file is `file_name` with contents `bytes`.
    #[allow(clippy::too_many_arguments)]
    pub fn add_version(
        &self,
        id: &str,
        project: &str,
        number: &str,
        file_name: &str,
        bytes: &[u8],
        deps: Vec<Value>,
        loaders: &[&str],
        games: &[&str],
    ) {
        let mut st = self.state.lock().unwrap();
        st.blobs.insert(file_name.to_owned(), bytes.to_vec());
        let url = format!("{}/cdn/{file_name}", st.base);
        st.versions.insert(
            0,
            json!({
                "id": id, "project_id": project, "name": number, "version_number": number,
                "changelog": format!("Changes in {number}"), "version_type": "release",
                "game_versions": games, "loaders": loaders, "date_published": "2026-01-01T00:00:00Z",
                "dependencies": deps,
                "files": [{
                    "hashes": {"sha1": sha1(bytes), "sha512": hash_bytes(HashAlgo::Sha512, bytes)},
                    "url": url, "filename": file_name, "primary": true, "size": bytes.len(),
                }],
            }),
        );
    }

    /// Edit the first (newest) version of a project, for tampering tests.
    pub fn edit_version(&self, id: &str, f: impl FnOnce(&mut Value)) {
        let mut st = self.state.lock().unwrap();
        let v = st.versions.iter_mut().find(|v| v["id"] == id).unwrap();
        f(v);
    }

    pub fn set_blob(&self, name: &str, bytes: &[u8]) {
        self.state
            .lock()
            .unwrap()
            .blobs
            .insert(name.to_owned(), bytes.to_vec());
    }
}

pub fn dep(project: &str, kind: &str) -> Value {
    json!({"project_id": project, "dependency_type": kind})
}

#[allow(dead_code)]
pub struct World {
    pub dir: tempfile::TempDir,
    pub dirs: DataDirs,
    pub db: Db,
    pub fake: Fake,
    pub server: MockServer,
    pub instances: InstanceStore,
    pub store: ModStore,
    pub packs: PackService,
    pub service: ModService<Modrinth>,
    pub instance: Instance,
    pub game: std::path::PathBuf,
}

pub fn loopback() -> HostPolicy {
    HostPolicy::new(&[]).with_loopback_http()
}

pub async fn world() -> World {
    let dir = tempfile::tempdir().unwrap();
    let dirs = DataDirs::from_root(dir.path(), false);
    dirs.ensure_created().unwrap();
    let db = db::open_in_memory().await.unwrap();
    let instances = InstanceStore::new(db.clone(), &dirs.instances);
    let instance = instances
        .create(NewInstance {
            name: "Test".into(),
            mc_version: "1.20.1".into(),
            loader: LoaderKind::Fabric,
            loader_version: Some("0.15.0".into()),
        })
        .await
        .unwrap();
    std::fs::create_dir_all(
        instances
            .game_dir(&instance.id)
            .await
            .unwrap()
            .as_path()
            .join("mods"),
    )
    .unwrap();

    let game = instances
        .game_dir(&instance.id)
        .await
        .unwrap()
        .as_path()
        .to_path_buf();
    let server = MockServer::start().await;
    let fake = Fake {
        state: Arc::new(Mutex::new(FakeState {
            base: server.uri(),
            ..Default::default()
        })),
    };
    Mock::given(wiremock::matchers::any())
        .respond_with(fake.clone())
        .mount(&server)
        .await;

    let source = Modrinth::with_client(
        HttpClient::new("kiln-test", loopback()).unwrap(),
        &format!("{}/v2", server.uri()),
        None,
    )
    .with_download_policy(loopback());
    let downloader = Downloader::new(
        HttpClient::new_for_downloads("kiln-test", loopback()).unwrap(),
        2,
    )
    .with_retry(RetryPolicy {
        attempts: 1,
        base_delay: std::time::Duration::from_millis(1),
    });
    let store = ModStore::new(db.clone(), instances.clone(), &dirs.backups);
    let packs =
        PackService::with_downloader(instances.clone(), &dirs, downloader.clone(), loopback());
    let service =
        ModService::with_downloader(source, store.clone(), packs.clone(), &dirs, downloader);
    World {
        dir,
        dirs,
        db,
        fake,
        server,
        instances,
        store,
        packs,
        service,
        instance,
        game,
    }
}

impl World {
    pub fn mods_dir(&self) -> std::path::PathBuf {
        self.game.join("mods")
    }

    pub fn id(&self) -> &str {
        &self.instance.id
    }
}

/// Sorted file names in a folder (not recursive).
pub fn files_in(dir: &std::path::Path) -> Vec<String> {
    let mut v: Vec<String> = match std::fs::read_dir(dir) {
        Ok(rd) => rd
            .filter_map(|e| e.ok())
            .filter(|e| e.path().is_file())
            .map(|e| e.file_name().to_string_lossy().into_owned())
            .collect(),
        Err(_) => Vec::new(),
    };
    v.sort();
    v
}

/// Every file under a folder, as paths relative to it.
pub fn tree(dir: &std::path::Path) -> Vec<String> {
    fn walk(base: &std::path::Path, dir: &std::path::Path, out: &mut Vec<String>) {
        if let Ok(rd) = std::fs::read_dir(dir) {
            for e in rd.flatten() {
                let p = e.path();
                if p.is_dir() {
                    walk(base, &p, out);
                } else {
                    out.push(
                        p.strip_prefix(base)
                            .unwrap()
                            .to_string_lossy()
                            .replace('\\', "/"),
                    );
                }
            }
        }
    }
    let mut out = Vec::new();
    walk(dir, dir, &mut out);
    out.sort();
    out
}
