//! What a mod catalogue must provide, in terms that don't mention any one website, so a
//! second source (CurseForge) can be added without touching the install logic.
//!
//! Everything a source returns is untrusted: identifiers are validated before they are put
//! in a URL, file names are validated before they touch the disk, and every download URL is
//! checked against the source's own host allowlist before a request is made.

use std::collections::HashMap;
use std::future::Future;

use serde::{Deserialize, Serialize};

use crate::loader::LoaderKind;
use crate::net::HostPolicy;
use crate::{Error, Result};

/// A project or version id or slug: letters, digits, `-` and `_`, 1 to 64 characters.
/// Anything else could steer a request at a different API endpoint, so it is refused.
pub fn is_valid_id(id: &str) -> bool {
    (1..=64).contains(&id.len())
        && id
            .chars()
            .all(|c| c.is_ascii_alphanumeric() || c == '-' || c == '_')
}

/// Minecraft versions, categories and similar short labels used in search filters.
pub fn is_valid_label(s: &str) -> bool {
    (1..=48).contains(&s.len())
        && s.chars()
            .all(|c| c.is_ascii_alphanumeric() || matches!(c, '-' | '_' | '.' | '+'))
}

pub fn check_id(id: &str) -> Result<&str> {
    if is_valid_id(id) {
        Ok(id)
    } else {
        Err(super::ModsError::InvalidId.into())
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum ProjectKind {
    Mod,
    Modpack,
    ResourcePack,
    Shader,
}

impl ProjectKind {
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Mod => "mod",
            Self::Modpack => "modpack",
            Self::ResourcePack => "resourcepack",
            Self::Shader => "shader",
        }
    }

    pub fn parse(s: &str) -> Option<Self> {
        Some(match s {
            "mod" => Self::Mod,
            "modpack" => Self::Modpack,
            "resourcepack" => Self::ResourcePack,
            "shader" => Self::Shader,
            _ => return None,
        })
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum SortOrder {
    #[default]
    Relevance,
    Downloads,
    Follows,
    Newest,
    Updated,
}

impl SortOrder {
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Relevance => "relevance",
            Self::Downloads => "downloads",
            Self::Follows => "follows",
            Self::Newest => "newest",
            Self::Updated => "updated",
        }
    }
}

#[derive(Debug, Clone, Deserialize)]
pub struct SearchQuery {
    #[serde(default)]
    pub query: String,
    pub kind: ProjectKind,
    #[serde(default)]
    pub mc_version: Option<String>,
    #[serde(default)]
    pub loader: Option<LoaderKind>,
    #[serde(default)]
    pub categories: Vec<String>,
    #[serde(default)]
    pub sort: SortOrder,
    #[serde(default)]
    pub offset: u32,
    #[serde(default)]
    pub limit: u32,
}

impl SearchQuery {
    /// Reject anything that doesn't look like a plain filter value, and clamp paging.
    pub fn validated(mut self) -> Result<Self> {
        self.query = self
            .query
            .chars()
            .filter(|c| !c.is_control())
            .take(100)
            .collect();
        if self
            .mc_version
            .as_deref()
            .is_some_and(|v| !is_valid_label(v))
            || self.categories.iter().any(|c| !is_valid_label(c))
            || self.categories.len() > 8
        {
            return Err(super::ModsError::InvalidFilter.into());
        }
        self.limit = if self.limit == 0 {
            20
        } else {
            self.limit.min(50)
        };
        self.offset = self.offset.min(10_000);
        Ok(self)
    }
}

#[derive(Debug, Clone, Serialize, PartialEq)]
pub struct SearchHit {
    pub id: String,
    pub slug: String,
    pub title: String,
    pub description: String,
    pub author: String,
    pub kind: ProjectKind,
    pub downloads: u64,
    pub follows: u64,
    pub icon_url: Option<String>,
    pub categories: Vec<String>,
    pub client_side: String,
    pub server_side: String,
    pub license: Option<String>,
}

#[derive(Debug, Clone, Serialize, PartialEq)]
pub struct SearchPage {
    pub hits: Vec<SearchHit>,
    pub offset: u32,
    pub total: u64,
}

#[derive(Debug, Clone, Serialize, PartialEq)]
pub struct License {
    pub id: String,
    pub name: String,
    pub url: Option<String>,
}

#[derive(Debug, Clone, Serialize, PartialEq)]
pub struct Project {
    pub id: String,
    pub slug: String,
    pub title: String,
    pub description: String,
    /// The long description (Markdown). The UI shows it as plain text.
    pub body: String,
    pub kind: ProjectKind,
    pub author: Option<String>,
    pub downloads: u64,
    pub follows: u64,
    pub icon_url: Option<String>,
    pub license: Option<License>,
    pub categories: Vec<String>,
    pub loaders: Vec<String>,
    pub game_versions: Vec<String>,
    pub client_side: String,
    pub server_side: String,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum DependencyKind {
    Required,
    Optional,
    Incompatible,
    Embedded,
}

#[derive(Debug, Clone, Serialize, PartialEq, Eq)]
pub struct Dependency {
    pub project_id: Option<String>,
    pub version_id: Option<String>,
    pub kind: DependencyKind,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum Channel {
    Release,
    Beta,
    Alpha,
}

impl Channel {
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Release => "release",
            Self::Beta => "beta",
            Self::Alpha => "alpha",
        }
    }

    pub fn parse(s: &str) -> Self {
        match s {
            "beta" => Self::Beta,
            "alpha" => Self::Alpha,
            _ => Self::Release,
        }
    }
}

#[derive(Debug, Clone, Default, Serialize, PartialEq, Eq)]
pub struct FileHashes {
    pub sha1: Option<String>,
    pub sha512: Option<String>,
}

#[derive(Debug, Clone, Serialize, PartialEq, Eq)]
pub struct VersionFile {
    pub url: String,
    pub filename: String,
    pub size: u64,
    pub primary: bool,
    pub hashes: FileHashes,
}

#[derive(Debug, Clone, Serialize, PartialEq)]
pub struct ModVersion {
    pub id: String,
    pub project_id: String,
    pub name: String,
    pub version_number: String,
    pub changelog: Option<String>,
    pub channel: Channel,
    pub game_versions: Vec<String>,
    pub loaders: Vec<String>,
    pub date_published: String,
    pub dependencies: Vec<Dependency>,
    pub files: Vec<VersionFile>,
}

impl ModVersion {
    /// The file to install: the one marked primary, else the first.
    pub fn primary_file(&self) -> Option<&VersionFile> {
        self.files
            .iter()
            .find(|f| f.primary)
            .or_else(|| self.files.first())
    }
}

/// Which versions are acceptable for an instance. Empty lists mean "any".
#[derive(Debug, Clone, Default)]
pub struct VersionFilter {
    /// Acceptable loader names, in the source's vocabulary (`["quilt", "fabric"]`).
    pub loaders: Vec<String>,
    pub game_versions: Vec<String>,
}

impl VersionFilter {
    /// The loaders whose mods run on `loader`. Quilt runs most Fabric mods.
    pub fn for_instance(loader: LoaderKind, mc_version: &str) -> Self {
        let loaders: &[&str] = match loader {
            LoaderKind::Vanilla => &[],
            LoaderKind::Fabric => &["fabric"],
            LoaderKind::Quilt => &["quilt", "fabric"],
            LoaderKind::Forge => &["forge"],
            LoaderKind::Neoforge => &["neoforge"],
        };
        Self {
            loaders: loaders.iter().map(|s| (*s).to_owned()).collect(),
            game_versions: vec![mc_version.to_owned()],
        }
    }

    pub fn accepts(&self, v: &ModVersion) -> bool {
        let loader_ok =
            self.loaders.is_empty() || v.loaders.iter().any(|l| self.loaders.contains(l));
        let game_ok = self.game_versions.is_empty()
            || v.game_versions
                .iter()
                .any(|g| self.game_versions.contains(g));
        loader_ok && game_ok
    }
}

/// A catalogue of downloadable projects.
pub trait ModSource: Clone + Send + Sync + 'static {
    /// Stable short name stored in the database (`"modrinth"`).
    fn name(&self) -> &'static str;

    /// Hosts this source's files may be downloaded from. The install code builds its
    /// downloader from this and also checks every URL against it before queueing it.
    fn download_policy(&self) -> HostPolicy;

    fn search(&self, query: &SearchQuery) -> impl Future<Output = Result<SearchPage>> + Send;
    fn project(&self, id: &str) -> impl Future<Output = Result<Project>> + Send;
    fn projects(&self, ids: &[String]) -> impl Future<Output = Result<Vec<Project>>> + Send;
    /// Newest first.
    fn versions(
        &self,
        project: &str,
        filter: &VersionFilter,
    ) -> impl Future<Output = Result<Vec<ModVersion>>> + Send;
    fn version(&self, id: &str) -> impl Future<Output = Result<ModVersion>> + Send;
    fn versions_by_ids(
        &self,
        ids: &[String],
    ) -> impl Future<Output = Result<Vec<ModVersion>>> + Send;
    /// Which version each file (by SHA-1) belongs to. Unknown files are absent.
    fn identify(
        &self,
        sha1s: &[String],
    ) -> impl Future<Output = Result<HashMap<String, ModVersion>>> + Send;
    /// The newest acceptable version for each file (by SHA-1).
    fn latest_for(
        &self,
        sha1s: &[String],
        filter: &VersionFilter,
    ) -> impl Future<Output = Result<HashMap<String, ModVersion>>> + Send;
}

/// Pick the version to install from a newest-first list: the newest release, else the
/// newest beta, else the newest alpha.
pub fn best_version(versions: Vec<ModVersion>) -> Option<ModVersion> {
    for channel in [Channel::Release, Channel::Beta, Channel::Alpha] {
        if let Some(v) = versions.iter().find(|v| v.channel == channel) {
            return Some(v.clone());
        }
    }
    None
}

/// A file name that is safe to create inside a mods folder.
pub fn check_jar_name(name: &str) -> Result<&str> {
    let ok = name.to_ascii_lowercase().ends_with(".jar")
        && !name.contains(['/', '\\'])
        && crate::paths::validate_relative(name).is_ok();
    if ok {
        Ok(name)
    } else {
        Err(Error::InvalidPath("mod file name".into()))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ids_are_plain_tokens() {
        for ok in ["AABBCCDD", "sodium", "fabric-api", "a_b", "x"] {
            assert!(is_valid_id(ok), "{ok}");
        }
        for bad in [
            "",
            "a/b",
            "a b",
            "..",
            "a?b",
            "a#b",
            "a%2fb",
            "é",
            &"x".repeat(65),
        ] {
            assert!(!is_valid_id(bad), "{bad:?}");
        }
    }

    #[test]
    fn jar_names_cannot_escape_or_be_anything_but_jars() {
        for ok in ["sodium-0.5.jar", "A.JAR", "a+b.jar"] {
            assert!(check_jar_name(ok).is_ok(), "{ok}");
        }
        for bad in [
            "../x.jar",
            "a/b.jar",
            "a\\b.jar",
            "x.txt",
            "x.jar.exe",
            "CON.jar",
            "a:b.jar",
            ".jar.",
            "x.jar ",
        ] {
            assert!(check_jar_name(bad).is_err(), "{bad:?}");
        }
    }

    #[test]
    fn the_best_version_prefers_releases_over_newer_betas() {
        let v = |id: &str, channel| ModVersion {
            id: id.into(),
            project_id: "p".into(),
            name: id.into(),
            version_number: id.into(),
            changelog: None,
            channel,
            game_versions: vec![],
            loaders: vec![],
            date_published: String::new(),
            dependencies: vec![],
            files: vec![],
        };
        let list = vec![
            v("new-beta", Channel::Beta),
            v("old-release", Channel::Release),
            v("alpha", Channel::Alpha),
        ];
        assert_eq!(best_version(list.clone()).unwrap().id, "old-release");
        assert_eq!(
            best_version(vec![v("a", Channel::Alpha), v("b", Channel::Beta)])
                .unwrap()
                .id,
            "b"
        );
        assert!(best_version(vec![]).is_none());
    }

    #[test]
    fn quilt_instances_also_accept_fabric_mods() {
        let f = VersionFilter::for_instance(LoaderKind::Quilt, "1.20.1");
        assert_eq!(f.loaders, ["quilt", "fabric"]);
        assert!(VersionFilter::for_instance(LoaderKind::Forge, "1.20.1").loaders == ["forge"]);
    }
}
