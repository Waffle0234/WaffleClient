//! Instances: isolated game folders, each with its own Minecraft version, mod loader, mods,
//! resource packs, shaders, saves, options and Java settings.
//!
//! The folder lives under `instances/<slug>-<id>` (the `dir` column holds only that relative
//! name, so portable installs stay relocatable). The display name is separate from the folder
//! name, so renaming never moves files.

pub mod pack;

use std::path::Path;

use serde::Serialize;
use sqlx::FromRow;

use crate::db::Db;
use crate::launch::LaunchError;
use crate::loader::LoaderKind;
use crate::mojang::is_valid_version_id;
use crate::paths::SafePath;
use crate::{Error, Result};

/// Created inside every new instance.
pub const SUBDIRS: &[&str] = &["mods", "resourcepacks", "shaderpacks", "saves", "config"];
/// Not copied when cloning or exporting: regenerated, or private to one machine.
pub const TRANSIENT: &[&str] = &[".kiln-natives", "logs", "crash-reports"];
const MAX_NAME_CHARS: usize = 64;
const MAX_JVM_ARGS_BYTES: usize = 2048;

#[derive(Debug, Clone, Serialize, PartialEq, Eq)]
pub struct Instance {
    pub id: String,
    pub name: String,
    pub mc_version: String,
    pub loader: LoaderKind,
    pub loader_version: Option<String>,
    pub java_id: Option<String>,
    pub jvm_args: Option<String>,
    pub ram_mb: Option<u32>,
    pub created_at: i64,
    pub last_played: Option<i64>,
    pub playtime_s: i64,
}

#[derive(Debug, Clone)]
pub struct NewInstance {
    pub name: String,
    pub mc_version: String,
    pub loader: LoaderKind,
    pub loader_version: Option<String>,
}

#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct InstanceSettings {
    pub ram_mb: Option<u32>,
    pub jvm_args: Option<String>,
    pub java_id: Option<String>,
}

#[derive(FromRow)]
struct Row {
    id: String,
    name: String,
    mc_version: String,
    loader: String,
    loader_version: Option<String>,
    java_id: Option<String>,
    jvm_args: Option<String>,
    ram_mb: Option<i64>,
    created_at: i64,
    last_played: Option<i64>,
    playtime_s: i64,
}

impl From<Row> for Instance {
    fn from(r: Row) -> Self {
        Self {
            id: r.id,
            name: r.name,
            mc_version: r.mc_version,
            loader: LoaderKind::parse(&r.loader).unwrap_or(LoaderKind::Vanilla),
            loader_version: r.loader_version,
            java_id: r.java_id,
            jvm_args: r.jvm_args,
            ram_mb: r.ram_mb.and_then(|v| u32::try_from(v).ok()),
            created_at: r.created_at,
            last_played: r.last_played,
            playtime_s: r.playtime_s,
        }
    }
}

const COLUMNS: &str = "id, name, mc_version, loader, loader_version, java_id, jvm_args, ram_mb, created_at, last_played, playtime_s";

fn now_unix() -> i64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map_or(0, |d| i64::try_from(d.as_secs()).unwrap_or(i64::MAX))
}

pub fn validate_name(name: &str) -> Result<String> {
    let name = name.trim();
    if name.is_empty()
        || name.chars().count() > MAX_NAME_CHARS
        || name.chars().any(char::is_control)
    {
        return Err(LaunchError::InvalidName.into());
    }
    Ok(name.to_owned())
}

/// A folder-name-safe version of a display name.
pub(crate) fn slug(name: &str) -> String {
    let s: String = name
        .chars()
        .map(|c| {
            if c.is_ascii_alphanumeric() {
                c.to_ascii_lowercase()
            } else {
                '-'
            }
        })
        .collect();
    let s = s
        .split('-')
        .filter(|p| !p.is_empty())
        .collect::<Vec<_>>()
        .join("-");
    let s: String = s.chars().take(32).collect();
    if s.is_empty() {
        "instance".into()
    } else {
        s
    }
}

/// Flags that load code or run commands, or override how Java finds its own libraries.
const DENIED: &[&str] = &[
    "javaagent",
    "agentlib",
    "agentpath",
    "bootclasspath",
    "-xrun",
    "xx:on",
    "xx:vmoptionsfile",
    "xx:flags",
    "xx:args",
    "xx:errorfile",
    "xx:heapdumppath",
    "java.library.path",
    "java.class.path",
    "java.system.class.loader",
    "jdk.module",
    "java.ext.dirs",
    "java.home",
    "sun.boot",
    "java.security",
];
const ALLOWED_PREFIXES: &[&str] = &[
    "-xmx", "-xms", "-xss", "-xmn", "-xx:", "-xshare:", "-xlog:", "-d",
];

/// Split and vet user-supplied JVM arguments. Not a sandbox (the game itself runs with the
/// user's privileges), but IPC must not be a way to inject agents or shell commands.
pub fn parse_jvm_args(args: &str) -> Result<Vec<String>> {
    let bad = |why: &str| -> Error { LaunchError::InvalidJvmArgs(why.into()).into() };
    if args.len() > MAX_JVM_ARGS_BYTES {
        return Err(bad("too long"));
    }
    if args
        .chars()
        .any(|c| c.is_control() && c != ' ' && c != '\t')
    {
        return Err(bad("control characters"));
    }
    let tokens: Vec<String> = args.split_whitespace().map(str::to_owned).collect();
    for t in &tokens {
        let lower = t.to_ascii_lowercase();
        if !ALLOWED_PREFIXES.iter().any(|p| lower.starts_with(p)) {
            return Err(bad(&format!("{t} isn't a recognised option")));
        }
        if DENIED.iter().any(|d| lower.contains(d)) {
            return Err(bad(&format!(
                "{t} could load code or change Java's own paths"
            )));
        }
    }
    Ok(tokens)
}

#[derive(Debug, Clone)]
pub struct InstanceStore {
    db: Db,
    root: std::path::PathBuf,
}

impl InstanceStore {
    pub fn new(db: Db, instances_dir: &Path) -> Self {
        Self {
            db,
            root: instances_dir.to_path_buf(),
        }
    }

    pub async fn list(&self) -> Result<Vec<Instance>> {
        let rows: Vec<Row> = sqlx::query_as(&format!(
            "SELECT {COLUMNS} FROM instances ORDER BY COALESCE(last_played, created_at) DESC, name COLLATE NOCASE"
        ))
        .fetch_all(&self.db)
        .await?;
        Ok(rows.into_iter().map(Instance::from).collect())
    }

    pub async fn get(&self, id: &str) -> Result<Instance> {
        let row: Option<Row> =
            sqlx::query_as(&format!("SELECT {COLUMNS} FROM instances WHERE id = ?1"))
                .bind(id)
                .fetch_optional(&self.db)
                .await?;
        row.map(Instance::from)
            .ok_or_else(|| LaunchError::InstanceNotFound.into())
    }

    /// The instance's folder, proven to be inside `instances/`.
    pub async fn game_dir(&self, id: &str) -> Result<SafePath> {
        let dir: Option<(String,)> = sqlx::query_as("SELECT dir FROM instances WHERE id = ?1")
            .bind(id)
            .fetch_optional(&self.db)
            .await?;
        let (dir,) = dir.ok_or(LaunchError::InstanceNotFound)?;
        SafePath::new(&self.root, &dir)
    }

    pub async fn create(&self, new: NewInstance) -> Result<Instance> {
        let name = validate_name(&new.name)?;
        if !is_valid_version_id(&new.mc_version) {
            return Err(LaunchError::InvalidVersionId.into());
        }
        match (new.loader, new.loader_version.as_deref()) {
            (LoaderKind::Vanilla, None) => {}
            (LoaderKind::Vanilla, Some(_)) | (_, None) => {
                return Err(LaunchError::InvalidVersionId.into())
            }
            (_, Some(v)) if is_valid_version_id(v) => {}
            _ => return Err(LaunchError::InvalidVersionId.into()),
        }
        let id = uuid::Uuid::new_v4().simple().to_string();
        let dir = format!("{}-{}", slug(&name), &id[..8]);
        let game_dir = SafePath::new(&self.root, &dir)?;
        sqlx::query(
            "INSERT INTO instances (id, name, mc_version, loader, loader_version, created_at, dir) \
             VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7)",
        )
        .bind(&id)
        .bind(&name)
        .bind(&new.mc_version)
        .bind(new.loader.as_str())
        .bind(&new.loader_version)
        .bind(now_unix())
        .bind(&dir)
        .execute(&self.db)
        .await?;
        let made: std::io::Result<()> = SUBDIRS
            .iter()
            .try_for_each(|s| std::fs::create_dir_all(game_dir.as_path().join(s)));
        if let Err(e) = made {
            let _ = sqlx::query("DELETE FROM instances WHERE id = ?1")
                .bind(&id)
                .execute(&self.db)
                .await;
            return Err(e.into());
        }
        self.get(&id).await
    }

    pub async fn rename(&self, id: &str, name: &str) -> Result<Instance> {
        let name = validate_name(name)?;
        let done = sqlx::query("UPDATE instances SET name = ?2 WHERE id = ?1")
            .bind(id)
            .bind(&name)
            .execute(&self.db)
            .await?;
        if done.rows_affected() == 0 {
            return Err(LaunchError::InstanceNotFound.into());
        }
        self.get(id).await
    }

    /// Delete the instance and everything in its folder. `running` is whether the game is
    /// currently running from it.
    pub async fn delete(&self, id: &str, running: bool) -> Result<()> {
        if running {
            return Err(LaunchError::InstanceBusy.into());
        }
        let dir = self.game_dir(id).await?;
        let path = dir.as_path().to_path_buf();
        // Folder first: if it can't be removed the instance stays listed and can be retried.
        tokio::task::spawn_blocking(move || match std::fs::remove_dir_all(path) {
            Err(e) if e.kind() != std::io::ErrorKind::NotFound => Err(e),
            _ => Ok(()),
        })
        .await
        .map_err(|e| Error::Io(std::io::Error::other(e)))??;
        sqlx::query("DELETE FROM instances WHERE id = ?1")
            .bind(id)
            .execute(&self.db)
            .await?;
        Ok(())
    }

    /// Copy an instance, its settings and its files (not logs, crash reports or natives).
    pub async fn clone_instance(&self, id: &str, new_name: &str) -> Result<Instance> {
        let source = self.get(id).await?;
        let src_dir = self.game_dir(id).await?;
        let copy = self
            .create(NewInstance {
                name: new_name.to_owned(),
                mc_version: source.mc_version.clone(),
                loader: source.loader,
                loader_version: source.loader_version.clone(),
            })
            .await?;
        let dst_dir = self.game_dir(&copy.id).await?;
        let (from, to) = (
            src_dir.as_path().to_path_buf(),
            dst_dir.as_path().to_path_buf(),
        );
        let copied = tokio::task::spawn_blocking(move || copy_tree(&from, &to, true))
            .await
            .map_err(|e| Error::Io(std::io::Error::other(e)))?;
        if let Err(e) = copied {
            let _ = self.delete(&copy.id, false).await;
            return Err(e.into());
        }
        self.update_settings(
            &copy.id,
            InstanceSettings {
                ram_mb: source.ram_mb,
                jvm_args: source.jvm_args.clone(),
                java_id: source.java_id.clone(),
            },
        )
        .await
    }

    pub async fn update_settings(&self, id: &str, s: InstanceSettings) -> Result<Instance> {
        if s.ram_mb.is_some_and(|mb| !(512..=262_144).contains(&mb)) {
            return Err(Error::InvalidSetting {
                key: "ram_mb".into(),
                reason: "choose between 512 MB and 256 GB".into(),
            });
        }
        let jvm_args = match s
            .jvm_args
            .as_deref()
            .map(str::trim)
            .filter(|a| !a.is_empty())
        {
            Some(a) => {
                parse_jvm_args(a)?;
                Some(a.to_owned())
            }
            None => None,
        };
        if let Some(java_id) = &s.java_id {
            let known: Option<(i64,)> = sqlx::query_as("SELECT 1 FROM java_runtimes WHERE id = ?1")
                .bind(java_id)
                .fetch_optional(&self.db)
                .await?;
            if known.is_none() {
                return Err(Error::InvalidSetting {
                    key: "java_id".into(),
                    reason: "that Java runtime isn't known".into(),
                });
            }
        }
        let done = sqlx::query(
            "UPDATE instances SET ram_mb = ?2, jvm_args = ?3, java_id = ?4 WHERE id = ?1",
        )
        .bind(id)
        .bind(s.ram_mb.map(i64::from))
        .bind(jvm_args)
        .bind(&s.java_id)
        .execute(&self.db)
        .await?;
        if done.rows_affected() == 0 {
            return Err(LaunchError::InstanceNotFound.into());
        }
        self.get(id).await
    }

    /// Change the Minecraft version and loader (a modpack update can ask for this). The
    /// loader itself is installed on the next launch. Callers must make sure the instance
    /// isn't running.
    pub async fn set_game(
        &self,
        id: &str,
        mc_version: &str,
        loader: LoaderKind,
        loader_version: Option<&str>,
    ) -> Result<()> {
        if !is_valid_version_id(mc_version) {
            return Err(LaunchError::InvalidVersionId.into());
        }
        let done = sqlx::query(
            "UPDATE instances SET mc_version = ?2, loader = ?3, loader_version = ?4 WHERE id = ?1",
        )
        .bind(id)
        .bind(mc_version)
        .bind(loader.as_str())
        .bind(loader_version)
        .execute(&self.db)
        .await?;
        if done.rows_affected() == 0 {
            return Err(LaunchError::InstanceNotFound.into());
        }
        Ok(())
    }

    /// Note that the game ran from `started` (unix seconds) for `seconds`.
    pub async fn record_play(&self, id: &str, started: i64, seconds: i64) -> Result<()> {
        sqlx::query(
            "UPDATE instances SET last_played = ?2, playtime_s = playtime_s + ?3 WHERE id = ?1",
        )
        .bind(id)
        .bind(started)
        .bind(seconds.max(0))
        .execute(&self.db)
        .await?;
        Ok(())
    }
}

/// Recursively copy `from` into `to`. Symlinks are skipped: they could point anywhere.
pub(crate) fn copy_tree(from: &Path, to: &Path, top_level: bool) -> std::io::Result<()> {
    std::fs::create_dir_all(to)?;
    for entry in std::fs::read_dir(from)? {
        let entry = entry?;
        let name = entry.file_name();
        if top_level && TRANSIENT.iter().any(|t| std::ffi::OsStr::new(t) == name) {
            continue;
        }
        let kind = entry.file_type()?;
        if kind.is_dir() {
            copy_tree(&entry.path(), &to.join(&name), false)?;
        } else if kind.is_file() {
            std::fs::copy(entry.path(), to.join(&name))?;
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::db;

    async fn store() -> (InstanceStore, tempfile::TempDir, Db) {
        let dir = tempfile::tempdir().unwrap();
        let db = db::open_in_memory().await.unwrap();
        (InstanceStore::new(db.clone(), dir.path()), dir, db)
    }

    fn vanilla(name: &str) -> NewInstance {
        NewInstance {
            name: name.into(),
            mc_version: "1.21.1".into(),
            loader: LoaderKind::Vanilla,
            loader_version: None,
        }
    }

    #[tokio::test]
    async fn create_makes_the_folder_layout_and_lists_newest_first() {
        let (s, dir, _db) = store().await;
        let a = s.create(vanilla("  My Survival World!  ")).await.unwrap();
        assert_eq!(a.name, "My Survival World!");
        let game = s.game_dir(&a.id).await.unwrap();
        assert!(game
            .as_path()
            .starts_with(dir.path().canonicalize().unwrap()));
        for sub in SUBDIRS {
            assert!(game.as_path().join(sub).is_dir(), "{sub}");
        }
        let folder = game
            .as_path()
            .file_name()
            .unwrap()
            .to_string_lossy()
            .into_owned();
        assert!(folder.starts_with("my-survival-world-"), "{folder}");

        let fabric = s
            .create(NewInstance {
                name: "Mods".into(),
                mc_version: "1.21.1".into(),
                loader: LoaderKind::Fabric,
                loader_version: Some("0.16.5".into()),
            })
            .await
            .unwrap();
        assert_eq!(fabric.loader, LoaderKind::Fabric);
        assert_eq!(s.list().await.unwrap().len(), 2);
    }

    #[tokio::test]
    async fn names_with_nasty_characters_cannot_escape_the_instances_folder() {
        let (s, dir, _db) = store().await;
        let i = s.create(vanilla("../../etc/passwd")).await.unwrap();
        let game = s.game_dir(&i.id).await.unwrap();
        assert!(game
            .as_path()
            .starts_with(dir.path().canonicalize().unwrap()));
        assert_eq!(
            i.name, "../../etc/passwd",
            "the display name is kept as typed"
        );
        for bad in ["", "   ", "a\nb", &"x".repeat(65), "tab\there"] {
            assert!(
                matches!(
                    s.create(vanilla(bad)).await,
                    Err(Error::Launch(LaunchError::InvalidName))
                ),
                "{bad:?}"
            );
        }
    }

    #[tokio::test]
    async fn loader_and_version_combinations_are_validated() {
        let (s, _d, _db) = store().await;
        let mk = |loader, lv: Option<&str>, mc: &str| NewInstance {
            name: "x".into(),
            mc_version: mc.into(),
            loader,
            loader_version: lv.map(Into::into),
        };
        assert!(
            s.create(mk(LoaderKind::Fabric, None, "1.21.1"))
                .await
                .is_err(),
            "loaders need a version"
        );
        assert!(s
            .create(mk(LoaderKind::Vanilla, Some("1"), "1.21.1"))
            .await
            .is_err());
        assert!(s
            .create(mk(LoaderKind::Fabric, Some("../x"), "1.21.1"))
            .await
            .is_err());
        assert!(s
            .create(mk(LoaderKind::Vanilla, None, "../x"))
            .await
            .is_err());
        assert!(
            s.list().await.unwrap().is_empty(),
            "rejected instances leave nothing behind"
        );
    }

    #[tokio::test]
    async fn rename_keeps_the_folder_and_missing_ids_are_reported() {
        let (s, _d, _db) = store().await;
        let i = s.create(vanilla("Old")).await.unwrap();
        let before = s.game_dir(&i.id).await.unwrap();
        let r = s.rename(&i.id, "New").await.unwrap();
        assert_eq!(r.name, "New");
        assert_eq!(s.game_dir(&i.id).await.unwrap(), before);
        assert!(matches!(
            s.rename("nope", "x").await,
            Err(Error::Launch(LaunchError::InstanceNotFound))
        ));
        assert!(matches!(
            s.rename(&i.id, "").await,
            Err(Error::Launch(LaunchError::InvalidName))
        ));
    }

    #[tokio::test]
    async fn delete_removes_files_and_refuses_while_running() {
        let (s, _d, _db) = store().await;
        let i = s.create(vanilla("Doomed")).await.unwrap();
        let game = s.game_dir(&i.id).await.unwrap();
        std::fs::write(game.as_path().join("saves/world.dat"), b"x").unwrap();
        assert!(matches!(
            s.delete(&i.id, true).await,
            Err(Error::Launch(LaunchError::InstanceBusy))
        ));
        assert!(game.as_path().exists());
        s.delete(&i.id, false).await.unwrap();
        assert!(!game.as_path().exists());
        assert!(s.list().await.unwrap().is_empty());
        assert!(matches!(
            s.delete(&i.id, false).await,
            Err(Error::Launch(LaunchError::InstanceNotFound))
        ));
    }

    #[tokio::test]
    async fn deleting_never_follows_a_symlink_out_of_the_instance() {
        let (s, _d, _db) = store().await;
        let i = s.create(vanilla("Linked")).await.unwrap();
        let game = s.game_dir(&i.id).await.unwrap();
        let outside = tempfile::tempdir().unwrap();
        std::fs::write(outside.path().join("precious.txt"), b"keep me").unwrap();
        #[cfg(unix)]
        std::os::unix::fs::symlink(outside.path(), game.as_path().join("saves/escape")).unwrap();
        s.delete(&i.id, false).await.unwrap();
        assert!(
            outside.path().join("precious.txt").exists(),
            "files behind a symlink must survive"
        );
    }

    #[tokio::test]
    async fn clone_copies_files_and_settings_but_not_transient_folders() {
        let (s, _d, _db) = store().await;
        let a = s.create(vanilla("Original")).await.unwrap();
        let game = s.game_dir(&a.id).await.unwrap();
        std::fs::write(game.as_path().join("options.txt"), b"fov:90").unwrap();
        std::fs::write(game.as_path().join("mods/a.jar"), b"jar").unwrap();
        std::fs::create_dir_all(game.as_path().join("logs")).unwrap();
        std::fs::write(game.as_path().join("logs/latest.log"), b"log").unwrap();
        std::fs::create_dir_all(game.as_path().join(".kiln-natives")).unwrap();
        #[cfg(unix)]
        std::os::unix::fs::symlink("/etc", game.as_path().join("saves/link")).unwrap();
        s.update_settings(
            &a.id,
            InstanceSettings {
                ram_mb: Some(4096),
                jvm_args: Some("-XX:+UseG1GC".into()),
                java_id: None,
            },
        )
        .await
        .unwrap();

        let b = s.clone_instance(&a.id, "Copy").await.unwrap();
        assert_ne!(a.id, b.id);
        assert_eq!(
            (b.ram_mb, b.jvm_args.as_deref(), b.playtime_s),
            (Some(4096), Some("-XX:+UseG1GC"), 0)
        );
        let copy = s.game_dir(&b.id).await.unwrap();
        assert_eq!(
            std::fs::read(copy.as_path().join("options.txt")).unwrap(),
            b"fov:90"
        );
        assert_eq!(
            std::fs::read(copy.as_path().join("mods/a.jar")).unwrap(),
            b"jar"
        );
        assert!(
            !copy.as_path().join("logs").exists() && !copy.as_path().join(".kiln-natives").exists()
        );
        assert!(
            !copy.as_path().join("saves/link").exists(),
            "symlinks are not copied"
        );
    }

    #[tokio::test]
    async fn settings_are_validated() {
        let (s, _d, db) = store().await;
        let i = s.create(vanilla("S")).await.unwrap();
        let set = |ram, args: Option<&str>, java: Option<&str>| InstanceSettings {
            ram_mb: ram,
            jvm_args: args.map(Into::into),
            java_id: java.map(Into::into),
        };
        assert!(s
            .update_settings(&i.id, set(Some(64), None, None))
            .await
            .is_err());
        assert!(s
            .update_settings(&i.id, set(None, Some("-javaagent:/tmp/evil.jar"), None))
            .await
            .is_err());
        assert!(s
            .update_settings(&i.id, set(None, None, Some("no-such-runtime")))
            .await
            .is_err());
        let ok = s
            .update_settings(&i.id, set(Some(2048), Some("  -Xss1M  "), None))
            .await
            .unwrap();
        assert_eq!(
            (ok.ram_mb, ok.jvm_args.as_deref()),
            (Some(2048), Some("-Xss1M"))
        );
        sqlx::query(
            "INSERT INTO java_runtimes (id, vendor, major, path) VALUES ('j1','T',21,'/x/java')",
        )
        .execute(&db)
        .await
        .unwrap();
        assert_eq!(
            s.update_settings(&i.id, set(None, Some("   "), Some("j1")))
                .await
                .unwrap()
                .jvm_args,
            None
        );
    }

    #[test]
    fn jvm_arguments_cannot_load_code_or_run_commands() {
        assert_eq!(
            parse_jvm_args("-Xmx4G -Xms1G -XX:+UseG1GC -Dfoo=bar").unwrap(),
            ["-Xmx4G", "-Xms1G", "-XX:+UseG1GC", "-Dfoo=bar"]
        );
        for bad in [
            "-javaagent:/tmp/x.jar",
            "-agentlib:jdwp=transport=dt_socket",
            "-agentpath:/x.so",
            "-Xbootclasspath/a:/x.jar",
            "-XX:OnError=rm -rf ~",
            "-XX:OnOutOfMemoryError=sh",
            "-XX:VMOptionsFile=/x",
            "-Djava.library.path=/evil",
            "-Djava.class.path=/evil",
            "-cp /evil",
            "-jar /evil.jar",
            "--add-opens=a/b=ALL-UNNAMED",
            "Main",
            "-Xrunjdwp:x",
            "-JAVAAGENT:/x",
            "-Xmx4G\n-javaagent:/x",
        ] {
            assert!(parse_jvm_args(bad).is_err(), "accepted {bad:?}");
        }
        assert!(
            parse_jvm_args(&"-Xmx1G ".repeat(400)).is_err(),
            "length cap"
        );
    }

    #[tokio::test]
    async fn play_time_accumulates() {
        let (s, _d, _db) = store().await;
        let i = s.create(vanilla("P")).await.unwrap();
        s.record_play(&i.id, 1000, 60).await.unwrap();
        s.record_play(&i.id, 2000, 30).await.unwrap();
        let g = s.get(&i.id).await.unwrap();
        assert_eq!((g.last_played, g.playtime_s), (Some(2000), 90));
    }
}
