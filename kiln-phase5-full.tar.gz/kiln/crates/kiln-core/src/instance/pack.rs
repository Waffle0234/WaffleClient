//! Exporting and importing instances: Kiln's own `.kiln.zip` and Modrinth's `.mrpack`.
//!
//! Imports treat the pack as hostile: every path goes through `SafePath`, downloads are
//! limited to the hosts the `.mrpack` format allows and verified against the hashes in the
//! pack, and nothing in a pack is ever executed: files are only written to disk.

use std::collections::{HashMap, HashSet};
use std::path::Path;

use serde::{Deserialize, Serialize};
use tokio::sync::watch;

use super::{
    validate_name, Instance, InstanceSettings, InstanceStore, NewInstance, SUBDIRS, TRANSIENT,
};
use crate::archive::{extract_zip, read_zip_entry, write_zip, write_zip_excluding, ExtractOptions};
use crate::download::{DownloadTask, Downloader, Progress};
use crate::hash::{ExpectedHash, HashAlgo};
use crate::launch::LaunchError;
use crate::loader::LoaderKind;
use crate::net::{HostPolicy, HttpClient};
use crate::paths::{DataDirs, SafePath};
use crate::{Error, Result, APP_NAME, APP_VERSION};

const NATIVE_MANIFEST: &str = "kiln-instance.json";
const MRPACK_INDEX: &str = "modrinth.index.json";
/// Unpacked size cap for packs: worlds can be large, but not unbounded.
const MAX_UNPACKED: u64 = 32 * 1024 * 1024 * 1024;
const MAX_FILES: usize = 10_000;
const MAX_MANIFEST_BYTES: u64 = 8 * 1024 * 1024;
/// Not exported to `.mrpack`: personal data and machine-generated folders.
const MRPACK_SKIP: &[&str] = &[
    "saves",
    "screenshots",
    "backups",
    "logs",
    "crash-reports",
    ".kiln-natives",
];

/// Hosts the `.mrpack` specification allows file downloads from, plus the GitHub CDN that
/// release downloads redirect to. Hashes are verified, so these can't swap a file.
pub fn mrpack_policy() -> HostPolicy {
    HostPolicy::new(&[
        "cdn.modrinth.com",
        "github.com",
        "raw.githubusercontent.com",
        "gitlab.com",
        "objects.githubusercontent.com",
        "release-assets.githubusercontent.com",
    ])
}

fn invalid(why: impl Into<String>) -> Error {
    LaunchError::InvalidPack(why.into()).into()
}

#[derive(Serialize, Deserialize)]
struct NativeManifest {
    format: u32,
    app: String,
    name: String,
    mc_version: String,
    loader: String,
    loader_version: Option<String>,
    ram_mb: Option<u32>,
}

#[derive(Deserialize)]
struct Index {
    #[serde(rename = "formatVersion")]
    format_version: u32,
    game: String,
    name: String,
    #[serde(default)]
    files: Vec<IndexFile>,
    #[serde(default)]
    dependencies: HashMap<String, String>,
}

#[derive(Deserialize)]
struct IndexFile {
    path: String,
    #[serde(default)]
    hashes: HashMap<String, String>,
    #[serde(default)]
    env: Option<IndexEnv>,
    #[serde(default)]
    downloads: Vec<String>,
    #[serde(default, rename = "fileSize")]
    file_size: Option<u64>,
}

#[derive(Deserialize)]
struct IndexEnv {
    #[serde(default)]
    client: Option<String>,
}

#[derive(Debug, Clone, Serialize, PartialEq, Eq)]
pub struct ImportFile {
    pub name: String,
    pub size: u64,
}

/// A mod listed in an exported `.mrpack` by hash and URL instead of being bundled.
#[derive(Debug, Clone)]
pub struct MrpackFile {
    /// Path inside the game folder, `/`-separated (`mods/sodium.jar`).
    pub path: String,
    pub sha1: String,
    pub sha512: String,
    pub size: u64,
    pub url: String,
    pub client_env: String,
    pub server_env: String,
}

/// User data that a modpack update never touches.
const UPDATE_PROTECTED_TOP: &[&str] = &["saves", "screenshots", "logs", "crash-reports", "backups"];
const UPDATE_PROTECTED_FILES: &[&str] = &["options.txt", "servers.dat"];

#[derive(Clone)]
pub struct PackService {
    store: InstanceStore,
    backups: std::path::PathBuf,
    exports: std::path::PathBuf,
    imports: std::path::PathBuf,
    downloader: Downloader,
    /// Must match the downloader's own policy: it decides which listed URL is used.
    policy: HostPolicy,
}

fn loader_dependency_key(kind: LoaderKind) -> Option<&'static str> {
    match kind {
        LoaderKind::Vanilla => None,
        LoaderKind::Fabric => Some("fabric-loader"),
        LoaderKind::Quilt => Some("quilt-loader"),
        LoaderKind::Forge => Some("forge"),
        LoaderKind::Neoforge => Some("neoforge"),
    }
}

/// Entry names that must never be written into an instance (Kiln's own scratch folders).
fn is_reserved(name: &str) -> bool {
    name.split(['/', '\\']).any(|c| c.starts_with(".kiln"))
}

impl PackService {
    pub fn new(store: InstanceStore, dirs: &DataDirs, max_concurrent: u8) -> Result<Self> {
        let ua = format!("{APP_NAME}/{APP_VERSION}");
        Ok(Self::with_downloader(
            store,
            dirs,
            Downloader::new(
                HttpClient::new_for_downloads(&ua, mrpack_policy())?,
                max_concurrent,
            ),
            mrpack_policy(),
        ))
    }

    pub(crate) fn with_downloader(
        store: InstanceStore,
        dirs: &DataDirs,
        downloader: Downloader,
        policy: HostPolicy,
    ) -> Self {
        Self {
            store,
            backups: dirs.backups.clone(),
            exports: dirs.exports.clone(),
            imports: dirs.imports.clone(),
            downloader,
            policy,
        }
    }

    /// A file name in `exports/` that doesn't exist yet.
    fn export_target(&self, instance: &Instance, ext: &str) -> Result<SafePath> {
        let base: String = super::slug(&instance.name);
        for n in 0..1000 {
            let name = if n == 0 {
                format!("{base}.{ext}")
            } else {
                format!("{base}-{n}.{ext}")
            };
            let target = SafePath::new(&self.exports, &name)?;
            if !target.as_path().exists() {
                return Ok(target);
            }
        }
        Err(invalid("too many exports with the same name"))
    }

    /// Everything in the instance, including worlds, as Kiln's own format. Returns the file
    /// name inside `exports/`.
    pub async fn export_native(&self, id: &str) -> Result<String> {
        let instance = self.store.get(id).await?;
        let dir = self.store.game_dir(id).await?;
        let target = self.export_target(&instance, "kiln.zip")?;
        let manifest = NativeManifest {
            format: 1,
            app: APP_NAME.into(),
            name: instance.name.clone(),
            mc_version: instance.mc_version.clone(),
            loader: instance.loader.as_str().into(),
            loader_version: instance.loader_version.clone(),
            ram_mb: instance.ram_mb,
        };
        let first = vec![(
            NATIVE_MANIFEST.to_owned(),
            serde_json::to_vec_pretty(&manifest)?,
        )];
        let (dest, src) = (target.as_path().to_path_buf(), dir.as_path().to_path_buf());
        tokio::task::spawn_blocking(move || write_zip(&dest, "instance/", &src, TRANSIENT, &first))
            .await
            .map_err(|e| Error::Io(std::io::Error::other(e)))??;
        Ok(file_name(&target))
    }

    /// A Modrinth pack without worlds, with every mod and config bundled as overrides.
    /// [`export_mrpack_with`](Self::export_mrpack_with) lists known mods by hash instead.
    pub async fn export_mrpack(&self, id: &str) -> Result<String> {
        self.export_mrpack_with(id, Vec::new()).await
    }

    /// A Modrinth pack without worlds. `listed` files are named in the index with their
    /// hashes and download URLs and left out of `overrides/`; everything else is bundled.
    pub async fn export_mrpack_with(&self, id: &str, listed: Vec<MrpackFile>) -> Result<String> {
        let instance = self.store.get(id).await?;
        let dir = self.store.game_dir(id).await?;
        let target = self.export_target(&instance, "mrpack")?;
        let mut dependencies = serde_json::Map::new();
        dependencies.insert("minecraft".into(), instance.mc_version.clone().into());
        if let (Some(key), Some(v)) = (
            loader_dependency_key(instance.loader),
            &instance.loader_version,
        ) {
            dependencies.insert(key.into(), v.clone().into());
        }
        let files: Vec<serde_json::Value> = listed
            .iter()
            .map(|f| {
                serde_json::json!({
                    "path": f.path,
                    "hashes": { "sha1": f.sha1, "sha512": f.sha512 },
                    "env": { "client": f.client_env, "server": f.server_env },
                    "downloads": [f.url],
                    "fileSize": f.size,
                })
            })
            .collect();
        let exclude: HashSet<String> = listed.iter().map(|f| f.path.clone()).collect();
        let index = serde_json::json!({
            "formatVersion": 1, "game": "minecraft", "versionId": "1.0.0",
            "name": instance.name, "files": files, "dependencies": dependencies,
        });
        let first = vec![(MRPACK_INDEX.to_owned(), serde_json::to_vec_pretty(&index)?)];
        let (dest, src) = (target.as_path().to_path_buf(), dir.as_path().to_path_buf());
        tokio::task::spawn_blocking(move || {
            write_zip_excluding(&dest, "overrides/", &src, MRPACK_SKIP, &first, &exclude)
        })
        .await
        .map_err(|e| Error::Io(std::io::Error::other(e)))??;
        Ok(file_name(&target))
    }

    /// Packs waiting in `imports/`.
    pub fn list_imports(&self) -> Result<Vec<ImportFile>> {
        let mut out = Vec::new();
        for entry in std::fs::read_dir(&self.imports)? {
            let entry = entry?;
            let name = entry.file_name().to_string_lossy().into_owned();
            let lower = name.to_ascii_lowercase();
            if entry.file_type()?.is_file()
                && (lower.ends_with(".zip") || lower.ends_with(".mrpack"))
            {
                out.push(ImportFile {
                    name,
                    size: entry.metadata()?.len(),
                });
            }
        }
        out.sort_by(|a, b| a.name.to_lowercase().cmp(&b.name.to_lowercase()));
        Ok(out)
    }

    /// Import a pack from `imports/` as a new instance.
    pub async fn import(
        &self,
        file_name: &str,
        progress: Option<watch::Sender<Progress>>,
    ) -> Result<Instance> {
        if file_name.contains(['/', '\\']) {
            return Err(Error::InvalidPath("import file name".into()));
        }
        let file = SafePath::new(&self.imports, file_name)?;
        let path = file.as_path().to_path_buf();
        if !path.is_file() {
            return Err(invalid("the file isn't in the imports folder"));
        }
        let probe = path.clone();
        let (has_mrpack, has_native) =
            tokio::task::spawn_blocking(move || -> Result<(bool, bool)> {
                let zip = zip::ZipArchive::new(std::fs::File::open(probe)?)?;
                let names: HashSet<&str> = zip.file_names().collect();
                Ok((
                    names.contains(MRPACK_INDEX),
                    names.contains(NATIVE_MANIFEST),
                ))
            })
            .await
            .map_err(|e| Error::Io(std::io::Error::other(e)))??;
        if has_mrpack {
            self.import_mrpack(&path, progress).await
        } else if has_native {
            self.import_native(&path).await
        } else {
            Err(invalid("it isn't a Kiln export or a Modrinth pack"))
        }
    }

    /// Run `fill` against a fresh instance; if it fails, remove the half-built instance.
    async fn with_new_instance<F, Fut>(&self, new: NewInstance, fill: F) -> Result<Instance>
    where
        F: FnOnce(SafePath) -> Fut,
        Fut: std::future::Future<Output = Result<()>>,
    {
        let instance = self.store.create(new).await?;
        let dir = self.store.game_dir(&instance.id).await?;
        match fill(dir).await {
            Ok(()) => {
                let dir = self.store.game_dir(&instance.id).await?;
                for sub in SUBDIRS {
                    std::fs::create_dir_all(dir.as_path().join(sub))?;
                }
                Ok(instance)
            }
            Err(e) => {
                let _ = self.store.delete(&instance.id, false).await;
                Err(e)
            }
        }
    }

    async fn import_native(&self, path: &Path) -> Result<Instance> {
        let p = path.to_path_buf();
        let manifest: NativeManifest = serde_json::from_slice(
            &tokio::task::spawn_blocking(move || {
                read_zip_entry(&p, NATIVE_MANIFEST, MAX_MANIFEST_BYTES)
            })
            .await
            .map_err(|e| Error::Io(std::io::Error::other(e)))??,
        )
        .map_err(|_| invalid("its manifest is unreadable"))?;
        if manifest.format != 1 {
            return Err(invalid("it was made by a newer version of Kiln"));
        }
        let loader =
            LoaderKind::parse(&manifest.loader).ok_or_else(|| invalid("unknown mod loader"))?;
        let name = validate_name(&manifest.name).map_err(|_| invalid("its name isn't valid"))?;
        let new = NewInstance {
            name,
            mc_version: manifest.mc_version,
            loader,
            loader_version: manifest.loader_version,
        };
        let archive = path.to_path_buf();
        let instance = self
            .with_new_instance(new, |dir| async move {
                tokio::task::spawn_blocking(move || {
                    let keep = |n: &str| n.starts_with("instance/") && !is_reserved(n);
                    extract_zip(
                        &archive,
                        dir.as_path(),
                        &ExtractOptions {
                            strip_components: 1,
                            max_total_bytes: MAX_UNPACKED,
                            filter: Some(&keep),
                        },
                    )
                })
                .await
                .map_err(|e| Error::Io(std::io::Error::other(e)))??;
                Ok(())
            })
            .await
            .map_err(|e| match e {
                Error::Launch(_) | Error::InvalidPath(_) | Error::Archive(_) => e,
                other => other,
            })?;
        // Java and JVM arguments are machine-specific and untrusted: only RAM is carried over.
        match manifest.ram_mb {
            Some(ram_mb) => self
                .store
                .update_settings(
                    &instance.id,
                    InstanceSettings {
                        ram_mb: Some(ram_mb),
                        ..Default::default()
                    },
                )
                .await
                .or(Ok(instance)),
            None => Ok(instance),
        }
    }

    async fn read_index(&self, path: &Path) -> Result<Index> {
        let p = path.to_path_buf();
        let index: Index = serde_json::from_slice(
            &tokio::task::spawn_blocking(move || {
                read_zip_entry(&p, MRPACK_INDEX, MAX_MANIFEST_BYTES)
            })
            .await
            .map_err(|e| Error::Io(std::io::Error::other(e)))??,
        )
        .map_err(|_| invalid("its index is unreadable"))?;
        if index.format_version != 1 || index.game != "minecraft" {
            return Err(invalid(
                "it isn't a Minecraft pack in a format Kiln understands",
            ));
        }
        if index.files.len() > MAX_FILES {
            return Err(invalid("it lists too many files"));
        }
        Ok(index)
    }

    async fn import_mrpack(
        &self,
        path: &Path,
        progress: Option<watch::Sender<Progress>>,
    ) -> Result<Instance> {
        let index = self.read_index(path).await?;
        let (mc, loader, loader_version) = pack_game(&index)?;
        let name: String = index
            .name
            .chars()
            .filter(|c| !c.is_control())
            .take(64)
            .collect();
        let name = if name.trim().is_empty() {
            "Imported pack".to_owned()
        } else {
            name
        };

        let policy = self.policy.clone();
        let new = NewInstance {
            name,
            mc_version: mc,
            loader,
            loader_version,
        };
        let archive = path.to_path_buf();
        let downloader = self.downloader.clone();
        self.with_new_instance(new, |dir| async move {
            let tasks = pack_tasks(&index, &dir, &policy)?;
            downloader
                .download_all(tasks.into_iter().map(|(_, t)| t).collect(), progress)
                .await?;
            for prefix in ["overrides/", "client-overrides/"] {
                let archive = archive.clone();
                let dest = dir.as_path().to_path_buf();
                tokio::task::spawn_blocking(move || {
                    let keep = |n: &str| n.starts_with(prefix) && !is_reserved(n);
                    extract_zip(
                        &archive,
                        &dest,
                        &ExtractOptions {
                            strip_components: 1,
                            max_total_bytes: MAX_UNPACKED,
                            filter: Some(&keep),
                        },
                    )
                })
                .await
                .map_err(|e| Error::Io(std::io::Error::other(e)))??;
            }
            Ok(())
        })
        .await
    }

    /// Move an existing pack instance to a newer version of its pack. `archive_name` is the
    /// new `.mrpack` in `imports/`; `old_files` are the paths the previous version put in the
    /// instance. Files that were not put there by the pack are never overwritten or removed,
    /// and everything the update replaces or removes is first copied to `backups/packs/`.
    /// Returns the paths this version of the pack owns.
    pub async fn apply_update(
        &self,
        id: &str,
        archive_name: &str,
        old_files: &[String],
        progress: Option<watch::Sender<Progress>>,
    ) -> Result<Vec<String>> {
        if archive_name.contains(['/', '\\']) {
            return Err(Error::InvalidPath("pack file name".into()));
        }
        let archive = SafePath::new(&self.imports, archive_name)?
            .as_path()
            .to_path_buf();
        let index = self.read_index(&archive).await?;
        let (mc, loader, loader_version) = pack_game(&index)?;
        self.store.get(id).await?;
        let dir = self.store.game_dir(id).await?;
        let tasks = pack_tasks(&index, &dir, &self.policy)?;

        let arch = archive.clone();
        let override_paths = tokio::task::spawn_blocking(move || override_paths(&arch))
            .await
            .map_err(|e| Error::Io(std::io::Error::other(e)))??;
        let mut owned: Vec<String> = tasks.iter().map(|(rel, _)| rel.clone()).collect();
        owned.extend(override_paths.iter().cloned());
        owned.sort();
        owned.dedup();
        let owned_set: HashSet<&str> = owned.iter().map(String::as_str).collect();
        let old: HashSet<&str> = old_files.iter().map(String::as_str).collect();

        // 1. Keep a copy of every file the old version put here that still exists.
        let stamp = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map_or(0, |d| d.as_secs());
        for rel in old_files {
            let Ok(src) = SafePath::new(dir.as_path(), rel) else {
                continue;
            };
            if !src.as_path().is_file() {
                continue;
            }
            let dest = SafePath::new(&self.backups, &format!("packs/{id}/{stamp}/{rel}"))?;
            if let Some(parent) = dest.as_path().parent() {
                std::fs::create_dir_all(parent)?;
            }
            std::fs::copy(src.as_path(), dest.as_path())?;
        }
        // 2. Download the new files (each is verified before it replaces anything).
        self.downloader
            .download_all(tasks.into_iter().map(|(_, t)| t).collect(), progress)
            .await?;
        // 3. Remove what the old version had and the new one doesn't.
        for rel in old_files.iter().filter(|r| !owned_set.contains(r.as_str())) {
            if let Ok(p) = SafePath::new(dir.as_path(), rel) {
                match std::fs::remove_file(p.as_path()) {
                    Ok(()) => {}
                    Err(e) if e.kind() == std::io::ErrorKind::NotFound => {}
                    Err(e) => return Err(e.into()),
                }
            }
        }
        // 4. Unpack the pack's own files, leaving anything the user added alone.
        for prefix in ["overrides/", "client-overrides/"] {
            let archive = archive.clone();
            let dest = dir.as_path().to_path_buf();
            let old: HashSet<String> = old.iter().map(|s| (*s).to_owned()).collect();
            tokio::task::spawn_blocking(move || {
                let keep = |n: &str| {
                    let Some(rel) = n.strip_prefix(prefix) else {
                        return false;
                    };
                    if rel.is_empty() || is_reserved(n) || is_user_data(rel) {
                        return false;
                    }
                    old.contains(rel) || !dest.join(rel).exists()
                };
                extract_zip(
                    &archive,
                    &dest,
                    &ExtractOptions {
                        strip_components: 1,
                        max_total_bytes: MAX_UNPACKED,
                        filter: Some(&keep),
                    },
                )
            })
            .await
            .map_err(|e| Error::Io(std::io::Error::other(e)))??;
        }
        // 5. The new pack version may need a different Minecraft version or loader.
        self.store
            .set_game(id, &mc, loader, loader_version.as_deref())
            .await?;
        Ok(owned)
    }
}

fn is_user_data(rel: &str) -> bool {
    let first = rel.split('/').next().unwrap_or(rel);
    UPDATE_PROTECTED_TOP.contains(&first) || UPDATE_PROTECTED_FILES.contains(&rel)
}

/// Minecraft version and loader a pack asks for.
fn pack_game(index: &Index) -> Result<(String, LoaderKind, Option<String>)> {
    let mc = index
        .dependencies
        .get("minecraft")
        .cloned()
        .ok_or_else(|| invalid("it doesn't say which Minecraft version it needs"))?;
    let mut loader = (LoaderKind::Vanilla, None);
    for kind in [
        LoaderKind::Fabric,
        LoaderKind::Quilt,
        LoaderKind::Forge,
        LoaderKind::Neoforge,
    ] {
        if let Some(v) = loader_dependency_key(kind).and_then(|k| index.dependencies.get(k)) {
            if loader.0 != LoaderKind::Vanilla {
                return Err(invalid("it asks for more than one mod loader"));
            }
            loader = (kind, Some(v.clone()));
        }
    }
    Ok((mc, loader.0, loader.1))
}

/// Download tasks for a pack's listed files, each with its path relative to the game folder.
/// Every path is validated, every URL must be on the pack host list and every file needs a
/// checksum.
fn pack_tasks(
    index: &Index,
    dir: &SafePath,
    policy: &HostPolicy,
) -> Result<Vec<(String, DownloadTask)>> {
    let mut tasks = Vec::new();
    let mut total = 0u64;
    for f in index
        .files
        .iter()
        .filter(|f| f.env.as_ref().and_then(|e| e.client.as_deref()) != Some("unsupported"))
    {
        if is_reserved(&f.path) {
            return Err(invalid("a file is placed in a folder Kiln reserves"));
        }
        let dest = SafePath::new(dir.as_path(), &f.path)
            .map_err(|_| invalid("a file has an unsafe path"))?;
        let url = f
            .downloads
            .iter()
            .find(|u| url_allowed(policy, u))
            .ok_or_else(|| invalid("a file is hosted somewhere Kiln doesn't download from"))?;
        let hash = match (f.hashes.get("sha512"), f.hashes.get("sha1")) {
            (Some(h), _) => ExpectedHash::new(HashAlgo::Sha512, h),
            (None, Some(h)) => ExpectedHash::new(HashAlgo::Sha1, h),
            _ => return Err(invalid("a file has no checksum")),
        }
        .map_err(|_| invalid("a file has an unreadable checksum"))?;
        total = total.saturating_add(f.file_size.unwrap_or(0));
        tasks.push((
            f.path.clone(),
            DownloadTask {
                url: url.clone(),
                dest,
                hash: Some(hash),
                size: f.file_size,
            },
        ));
    }
    if total > MAX_UNPACKED {
        return Err(invalid("its files are too large"));
    }
    Ok(tasks)
}

/// Files a pack's `overrides/` and `client-overrides/` folders would create.
fn override_paths(archive: &Path) -> Result<Vec<String>> {
    let zip = zip::ZipArchive::new(std::fs::File::open(archive)?)?;
    let mut out = Vec::new();
    for name in zip.file_names() {
        for prefix in ["overrides/", "client-overrides/"] {
            if let Some(rel) = name.strip_prefix(prefix) {
                if !rel.is_empty() && !rel.ends_with('/') && !is_reserved(name) {
                    out.push(rel.to_owned());
                }
            }
        }
    }
    Ok(out)
}

/// Every game-folder path an `.mrpack` install writes: listed files and override files.
pub fn mrpack_installed_paths(archive: &Path) -> Result<Vec<String>> {
    let index: Index =
        serde_json::from_slice(&read_zip_entry(archive, MRPACK_INDEX, MAX_MANIFEST_BYTES)?)
            .map_err(|_| invalid("its index is unreadable"))?;
    let mut out: Vec<String> = index
        .files
        .iter()
        .filter(|f| f.env.as_ref().and_then(|e| e.client.as_deref()) != Some("unsupported"))
        .map(|f| f.path.clone())
        .collect();
    out.extend(override_paths(archive)?);
    out.sort();
    out.dedup();
    Ok(out)
}

fn url_allowed(policy: &HostPolicy, url: &str) -> bool {
    reqwest::Url::parse(url).is_ok_and(|u| policy.check(&u).is_ok())
}

fn file_name(p: &SafePath) -> String {
    p.as_path()
        .file_name()
        .map(|n| n.to_string_lossy().into_owned())
        .unwrap_or_default()
}

#[cfg(test)]
mod tests {
    use std::io::Write;
    use std::time::Duration;

    use serde_json::json;
    use wiremock::matchers::path as url_path;
    use wiremock::{Mock, MockServer, ResponseTemplate};

    use super::*;
    use crate::db;
    use crate::download::RetryPolicy;
    use crate::hash::hash_bytes;

    struct Env {
        svc: PackService,
        store: InstanceStore,
        dirs: DataDirs,
        _tmp: tempfile::TempDir,
    }

    async fn env(loopback: bool) -> Env {
        let tmp = tempfile::tempdir().unwrap();
        let dirs = DataDirs::from_root(tmp.path().join("data"), false);
        dirs.ensure_created().unwrap();
        let store = InstanceStore::new(db::open_in_memory().await.unwrap(), &dirs.instances);
        let policy = if loopback {
            HostPolicy::new(&[]).with_loopback_http()
        } else {
            mrpack_policy()
        };
        let dl = Downloader::new(HttpClient::new_for_downloads("t/0", policy).unwrap(), 2)
            .with_retry(RetryPolicy {
                attempts: 2,
                base_delay: Duration::from_millis(1),
            });
        Env {
            svc: PackService::with_downloader(
                store.clone(),
                &dirs,
                dl,
                if loopback {
                    HostPolicy::new(&[]).with_loopback_http()
                } else {
                    mrpack_policy()
                },
            ),
            store,
            dirs,
            _tmp: tmp,
        }
    }

    fn zip_of(path: &Path, entries: &[(&str, &[u8])]) {
        let mut w = zip::ZipWriter::new(std::fs::File::create(path).unwrap());
        for (n, d) in entries {
            w.start_file(*n, zip::write::SimpleFileOptions::default())
                .unwrap();
            w.write_all(d).unwrap();
        }
        w.finish().unwrap();
    }

    async fn sample(e: &Env) -> Instance {
        let i = e
            .store
            .create(NewInstance {
                name: "Pack Source".into(),
                mc_version: "1.21.1".into(),
                loader: LoaderKind::Fabric,
                loader_version: Some("0.16.5".into()),
            })
            .await
            .unwrap();
        let dir = e.store.game_dir(&i.id).await.unwrap();
        let d = dir.as_path();
        std::fs::write(d.join("mods/a.jar"), b"jar").unwrap();
        std::fs::write(d.join("config/x.toml"), b"cfg").unwrap();
        std::fs::create_dir_all(d.join("saves/World")).unwrap();
        std::fs::write(d.join("saves/World/level.dat"), b"world").unwrap();
        std::fs::create_dir_all(d.join("logs")).unwrap();
        std::fs::write(d.join("logs/latest.log"), b"log").unwrap();
        e.store
            .update_settings(
                &i.id,
                InstanceSettings {
                    ram_mb: Some(3072),
                    jvm_args: Some("-Xss2M".into()),
                    java_id: None,
                },
            )
            .await
            .unwrap();
        i
    }

    fn move_to_imports(e: &Env, name: &str) -> String {
        std::fs::rename(e.dirs.exports.join(name), e.dirs.imports.join(name)).unwrap();
        name.to_owned()
    }

    #[tokio::test]
    async fn native_export_and_import_round_trip() {
        let e = env(true).await;
        let src = sample(&e).await;
        let name = e.svc.export_native(&src.id).await.unwrap();
        assert_eq!(name, "pack-source.kiln.zip");
        assert_eq!(
            e.svc.export_native(&src.id).await.unwrap(),
            "pack-source-1.kiln.zip",
            "never overwrites an earlier export"
        );

        let name = move_to_imports(&e, &name);
        assert_eq!(
            e.svc.list_imports().unwrap(),
            [ImportFile {
                name: name.clone(),
                size: std::fs::metadata(e.dirs.imports.join(&name)).unwrap().len()
            }]
        );
        let imported = e.svc.import(&name, None).await.unwrap();
        assert_eq!(
            (
                imported.loader,
                imported.loader_version.as_deref(),
                imported.mc_version.as_str()
            ),
            (LoaderKind::Fabric, Some("0.16.5"), "1.21.1")
        );
        assert_eq!(imported.ram_mb, Some(3072));
        assert_eq!(
            imported.jvm_args, None,
            "JVM arguments from a pack are never trusted"
        );
        let dir = e.store.game_dir(&imported.id).await.unwrap();
        assert_eq!(
            std::fs::read(dir.as_path().join("mods/a.jar")).unwrap(),
            b"jar"
        );
        assert_eq!(
            std::fs::read(dir.as_path().join("saves/World/level.dat")).unwrap(),
            b"world",
            "native export keeps worlds"
        );
        assert!(!dir.as_path().join("logs").exists());
    }

    #[tokio::test]
    async fn a_hostile_native_pack_is_rejected_and_leaves_nothing_behind() {
        let e = env(true).await;
        let manifest = json!({"format": 1, "app": "x", "name": "Evil", "mc_version": "1.21.1", "loader": "vanilla", "loader_version": null, "ram_mb": null}).to_string();
        for evil in ["instance/../../escape.txt", "instance/.kiln-natives/lib.so"] {
            let f = e.dirs.imports.join("evil.kiln.zip");
            zip_of(
                &f,
                &[
                    (NATIVE_MANIFEST, manifest.as_bytes()),
                    ("instance/mods/ok.jar", b"ok"),
                    (evil, b"pwned"),
                ],
            );
            let res = e.svc.import("evil.kiln.zip", None).await;
            if evil.contains("..") {
                assert!(res.is_err(), "{evil}");
                assert!(
                    !e.dirs.root.join("escape.txt").exists()
                        && !e.dirs.instances.join("../escape.txt").exists()
                );
                assert!(
                    e.store.list().await.unwrap().is_empty(),
                    "failed import must not leave an instance"
                );
            } else {
                // Reserved folders are skipped silently rather than written.
                let i = res.unwrap();
                assert!(!e
                    .store
                    .game_dir(&i.id)
                    .await
                    .unwrap()
                    .as_path()
                    .join(".kiln-natives")
                    .exists());
            }
        }
    }

    #[tokio::test]
    async fn import_only_accepts_plain_file_names_from_the_imports_folder() {
        let e = env(true).await;
        std::fs::write(e.dirs.root.join("outside.zip"), b"x").unwrap();
        for bad in [
            "../outside.zip",
            "a/b.zip",
            "..\\outside.zip",
            "missing.zip",
        ] {
            assert!(e.svc.import(bad, None).await.is_err(), "{bad}");
        }
        std::fs::write(e.dirs.imports.join("junk.zip"), b"not a zip").unwrap();
        assert!(e.svc.import("junk.zip", None).await.is_err());
        zip_of(
            &e.dirs.imports.join("neither.zip"),
            &[("readme.txt", b"hi")],
        );
        assert!(matches!(
            e.svc.import("neither.zip", None).await,
            Err(Error::Launch(LaunchError::InvalidPack(_)))
        ));
    }

    fn mrpack_with(path: &Path, files: serde_json::Value, extra: &[(&str, &[u8])]) {
        let index =
            json!({"formatVersion": 1, "game": "minecraft", "versionId": "1", "name": "Cool Pack",
            "files": files, "dependencies": {"minecraft": "1.20.1", "fabric-loader": "0.15.0"}})
            .to_string();
        let mut entries: Vec<(&str, &[u8])> = vec![(MRPACK_INDEX, index.as_bytes())];
        entries.extend_from_slice(extra);
        zip_of(path, &entries);
    }

    #[tokio::test]
    async fn mrpack_import_downloads_verified_files_and_applies_overrides() {
        let e = env(true).await;
        let server = MockServer::start().await;
        let jar = b"MOD-JAR-BYTES".to_vec();
        Mock::given(url_path("/data/x.jar"))
            .respond_with(ResponseTemplate::new(200).set_body_bytes(jar.clone()))
            .mount(&server)
            .await;
        let files = json!([
            {"path": "mods/x.jar", "hashes": {"sha1": hash_bytes(HashAlgo::Sha1, &jar), "sha512": hash_bytes(HashAlgo::Sha512, &jar)},
             "downloads": [format!("{}/data/x.jar", server.uri())], "fileSize": jar.len(), "env": {"client": "required", "server": "required"}},
            {"path": "mods/server-only.jar", "hashes": {"sha1": hash_bytes(HashAlgo::Sha1, b"s")},
             "downloads": [format!("{}/data/server-only.jar", server.uri())], "env": {"client": "unsupported", "server": "required"}}
        ]);
        mrpack_with(
            &e.dirs.imports.join("cool.mrpack"),
            files,
            &[
                ("overrides/config/c.toml", b"base"),
                ("overrides/options.txt", b"fov:70"),
                ("client-overrides/options.txt", b"fov:90"),
            ],
        );

        let i = e.svc.import("cool.mrpack", None).await.unwrap();
        assert_eq!(
            (
                i.name.as_str(),
                i.loader,
                i.loader_version.as_deref(),
                i.mc_version.as_str()
            ),
            ("Cool Pack", LoaderKind::Fabric, Some("0.15.0"), "1.20.1")
        );
        let dir = e.store.game_dir(&i.id).await.unwrap();
        assert_eq!(
            std::fs::read(dir.as_path().join("mods/x.jar")).unwrap(),
            jar
        );
        assert_eq!(
            std::fs::read(dir.as_path().join("config/c.toml")).unwrap(),
            b"base"
        );
        assert_eq!(
            std::fs::read(dir.as_path().join("options.txt")).unwrap(),
            b"fov:90",
            "client-overrides win"
        );
        assert!(!dir.as_path().join("mods/server-only.jar").exists());
        assert_eq!(
            server.received_requests().await.unwrap().len(),
            1,
            "server-only files are never requested"
        );
    }

    #[tokio::test]
    async fn mrpack_with_a_wrong_hash_or_unsafe_path_is_rejected_cleanly() {
        let e = env(true).await;
        let server = MockServer::start().await;
        Mock::given(url_path("/data/x.jar"))
            .respond_with(ResponseTemplate::new(200).set_body_bytes(b"ACTUAL".to_vec()))
            .mount(&server)
            .await;
        let url = format!("{}/data/x.jar", server.uri());
        let cases = [
            json!([{"path": "mods/x.jar", "hashes": {"sha1": hash_bytes(HashAlgo::Sha1, b"DIFFERENT")}, "downloads": [&url], "fileSize": 6}]),
            json!([{"path": "../../escape.jar", "hashes": {"sha1": hash_bytes(HashAlgo::Sha1, b"ACTUAL")}, "downloads": [&url]}]),
            json!([{"path": "mods/.kiln-natives/x.so", "hashes": {"sha1": hash_bytes(HashAlgo::Sha1, b"ACTUAL")}, "downloads": [&url]}]),
            json!([{"path": "mods/x.jar", "hashes": {}, "downloads": [&url]}]),
        ];
        for (n, files) in cases.into_iter().enumerate() {
            mrpack_with(&e.dirs.imports.join("bad.mrpack"), files, &[]);
            assert!(e.svc.import("bad.mrpack", None).await.is_err(), "case {n}");
            assert!(
                e.store.list().await.unwrap().is_empty(),
                "case {n} left an instance"
            );
        }
        assert!(!e.dirs.root.join("escape.jar").exists());
    }

    #[tokio::test]
    async fn mrpack_files_from_unlisted_hosts_are_refused_without_any_request() {
        let e = env(false).await; // the real allowlist
        mrpack_with(
            &e.dirs.imports.join("evil.mrpack"),
            json!([
                {"path": "mods/x.jar", "hashes": {"sha1": "a".repeat(40)}, "downloads": ["https://evil.example/x.jar", "http://cdn.modrinth.com/plain-http.jar"]}
            ]),
            &[],
        );
        let err = e.svc.import("evil.mrpack", None).await.unwrap_err();
        assert!(
            matches!(&err, Error::Launch(LaunchError::InvalidPack(m)) if m.contains("hosted")),
            "{err:?}"
        );
        assert!(e.store.list().await.unwrap().is_empty());

        let p = mrpack_policy();
        assert!(url_allowed(&p, "https://cdn.modrinth.com/data/a/b.jar"));
        assert!(url_allowed(&p, "https://raw.githubusercontent.com/a/b/c"));
        assert!(!url_allowed(&p, "https://cdn.modrinth.com.evil.net/x"));
        assert!(!url_allowed(&p, "http://cdn.modrinth.com/x"));
    }

    #[tokio::test]
    async fn mrpack_dependency_rules() {
        let e = env(true).await;
        let write = |deps: serde_json::Value, game: &str| {
            let index = json!({"formatVersion": 1, "game": game, "name": "N", "files": [], "dependencies": deps}).to_string();
            zip_of(
                &e.dirs.imports.join("d.mrpack"),
                &[(MRPACK_INDEX, index.as_bytes())],
            );
        };
        write(
            json!({"minecraft": "1.20.1", "fabric-loader": "1", "forge": "2"}),
            "minecraft",
        );
        assert!(e.svc.import("d.mrpack", None).await.is_err(), "two loaders");
        write(json!({"fabric-loader": "1"}), "minecraft");
        assert!(
            e.svc.import("d.mrpack", None).await.is_err(),
            "no Minecraft version"
        );
        write(json!({"minecraft": "1.20.1"}), "terraria");
        assert!(e.svc.import("d.mrpack", None).await.is_err(), "wrong game");
        write(json!({"minecraft": "1.20.1"}), "minecraft");
        assert_eq!(
            e.svc.import("d.mrpack", None).await.unwrap().loader,
            LoaderKind::Vanilla
        );
    }

    #[tokio::test]
    async fn mrpack_export_leaves_out_worlds_and_re_imports() {
        let e = env(true).await;
        let src = sample(&e).await;
        let name = e.svc.export_mrpack(&src.id).await.unwrap();
        assert_eq!(name, "pack-source.mrpack");
        let zip =
            zip::ZipArchive::new(std::fs::File::open(e.dirs.exports.join(&name)).unwrap()).unwrap();
        let names: Vec<&str> = zip.file_names().collect();
        assert!(
            names.contains(&MRPACK_INDEX)
                && names.contains(&"overrides/mods/a.jar")
                && names.contains(&"overrides/config/x.toml")
        );
        assert!(
            !names
                .iter()
                .any(|n| n.contains("saves") || n.contains("logs")),
            "{names:?}"
        );

        move_to_imports(&e, &name);
        let i = e.svc.import(&name, None).await.unwrap();
        assert_eq!(
            (i.loader, i.loader_version.as_deref()),
            (LoaderKind::Fabric, Some("0.16.5"))
        );
        let dir = e.store.game_dir(&i.id).await.unwrap();
        assert_eq!(
            std::fs::read(dir.as_path().join("mods/a.jar")).unwrap(),
            b"jar"
        );
        assert!(!dir.as_path().join("saves/World").exists());
    }
}
