-- Kiln schema v1.
-- Timestamps are unix seconds (UTC). Booleans are 0/1.
-- No secrets live here: refresh tokens are kept only in the OS keychain.

CREATE TABLE settings (
    key   TEXT PRIMARY KEY NOT NULL,
    value TEXT NOT NULL CHECK (json_valid(value))
) STRICT;

CREATE TABLE accounts (
    id        TEXT PRIMARY KEY NOT NULL,
    username  TEXT NOT NULL,
    skin_hash TEXT,
    last_used INTEGER,
    is_active INTEGER NOT NULL DEFAULT 0 CHECK (is_active IN (0, 1))
) STRICT;
-- At most one active account.
CREATE UNIQUE INDEX accounts_one_active ON accounts (is_active) WHERE is_active = 1;

CREATE TABLE java_runtimes (
    id      TEXT PRIMARY KEY NOT NULL,
    vendor  TEXT NOT NULL,
    major   INTEGER NOT NULL CHECK (major > 0),
    path    TEXT NOT NULL UNIQUE,
    managed INTEGER NOT NULL DEFAULT 0 CHECK (managed IN (0, 1))
) STRICT;

CREATE TABLE instances (
    id             TEXT PRIMARY KEY NOT NULL,
    name           TEXT NOT NULL,
    mc_version     TEXT NOT NULL,
    loader         TEXT NOT NULL DEFAULT 'vanilla'
                   CHECK (loader IN ('vanilla', 'fabric', 'quilt', 'neoforge', 'forge')),
    loader_version TEXT,
    java_id        TEXT REFERENCES java_runtimes (id) ON DELETE SET NULL,
    jvm_args       TEXT,
    ram_mb         INTEGER CHECK (ram_mb IS NULL OR ram_mb > 0),
    perf_preset    TEXT NOT NULL DEFAULT 'off',
    created_at     INTEGER NOT NULL,
    last_played    INTEGER,
    playtime_s     INTEGER NOT NULL DEFAULT 0 CHECK (playtime_s >= 0),
    -- Directory name relative to the instances folder (keeps portable mode relocatable).
    dir            TEXT NOT NULL UNIQUE
) STRICT;

CREATE TABLE mods (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    instance_id TEXT NOT NULL REFERENCES instances (id) ON DELETE CASCADE,
    file_name   TEXT NOT NULL,
    sha1        TEXT NOT NULL,
    sha512      TEXT,
    source      TEXT NOT NULL DEFAULT 'unverified' CHECK (source IN ('modrinth', 'unverified')),
    project_id  TEXT,
    version_id  TEXT,
    pinned      INTEGER NOT NULL DEFAULT 0 CHECK (pinned IN (0, 1)),
    enabled     INTEGER NOT NULL DEFAULT 1 CHECK (enabled IN (0, 1)),
    UNIQUE (instance_id, file_name)
) STRICT;
CREATE INDEX mods_by_sha1 ON mods (sha1);

CREATE TABLE mod_backups (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    instance_id TEXT NOT NULL REFERENCES instances (id) ON DELETE CASCADE,
    mod_id      INTEGER REFERENCES mods (id) ON DELETE SET NULL,
    file_path   TEXT NOT NULL,
    replaced_at INTEGER NOT NULL,
    reason      TEXT NOT NULL
) STRICT;
CREATE INDEX mod_backups_by_instance ON mod_backups (instance_id);

CREATE TABLE servers (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    instance_id TEXT NOT NULL REFERENCES instances (id) ON DELETE CASCADE,
    name        TEXT NOT NULL,
    address     TEXT NOT NULL,
    favorite    INTEGER NOT NULL DEFAULT 0 CHECK (favorite IN (0, 1))
) STRICT;
CREATE INDEX servers_by_instance ON servers (instance_id);

CREATE TABLE backups (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    instance_id TEXT NOT NULL REFERENCES instances (id) ON DELETE CASCADE,
    world       TEXT NOT NULL,
    path        TEXT NOT NULL,
    created_at  INTEGER NOT NULL,
    size        INTEGER NOT NULL CHECK (size >= 0)
) STRICT;
CREATE INDEX backups_by_instance ON backups (instance_id);

CREATE TABLE option_profiles (
    id   TEXT PRIMARY KEY NOT NULL,
    name TEXT NOT NULL,
    kind TEXT NOT NULL CHECK (kind IN ('keybinds', 'options')),
    data TEXT NOT NULL CHECK (json_valid(data))
) STRICT;

CREATE TABLE http_cache (
    url        TEXT PRIMARY KEY NOT NULL,
    etag       TEXT,
    body_path  TEXT NOT NULL,
    fetched_at INTEGER NOT NULL
) STRICT;
