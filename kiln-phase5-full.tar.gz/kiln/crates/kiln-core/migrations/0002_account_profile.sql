-- Account profile details shown in the UI, plus a flag for accounts whose Microsoft
-- sign-in was revoked or expired and must be redone. Still no secrets here.
ALTER TABLE accounts ADD COLUMN skin_variant TEXT CHECK (skin_variant IN ('classic', 'slim'));
ALTER TABLE accounts ADD COLUMN cape_hash TEXT;
ALTER TABLE accounts ADD COLUMN needs_reauth INTEGER NOT NULL DEFAULT 0 CHECK (needs_reauth IN (0, 1));
