-- Phase 5: mod tracking, update backups and modpack links. Still no secrets here.
ALTER TABLE mods ADD COLUMN size INTEGER;
ALTER TABLE mods ADD COLUMN mtime INTEGER;
ALTER TABLE mods ADD COLUMN title TEXT;
ALTER TABLE mods ADD COLUMN author TEXT;
ALTER TABLE mods ADD COLUMN license TEXT;
ALTER TABLE mods ADD COLUMN downloads INTEGER;
ALTER TABLE mods ADD COLUMN icon_url TEXT;
ALTER TABLE mods ADD COLUMN version_number TEXT;
ALTER TABLE mods ADD COLUMN channel TEXT;
-- Unix seconds of the last Modrinth lookup for a jar, so unknown jars aren't re-asked daily.
ALTER TABLE mods ADD COLUMN lookup_at INTEGER;
ALTER TABLE mods ADD COLUMN installed_as TEXT NOT NULL DEFAULT 'user'
    CHECK (installed_as IN ('user', 'dependency'));

-- What an update replaced. `prev` is the old mods row as JSON, `new_file_name` the jar that
-- took its place. `state` says whether the update has been proven to start the game.
ALTER TABLE mod_backups ADD COLUMN file_name TEXT;
ALTER TABLE mod_backups ADD COLUMN new_file_name TEXT;
ALTER TABLE mod_backups ADD COLUMN prev TEXT;
ALTER TABLE mod_backups ADD COLUMN state TEXT NOT NULL DEFAULT 'pending'
    CHECK (state IN ('pending', 'confirmed', 'restored'));

-- The modpack an instance was installed from, and the files that pack put there.
CREATE TABLE instance_packs (
    instance_id    TEXT PRIMARY KEY NOT NULL REFERENCES instances (id) ON DELETE CASCADE,
    project_id     TEXT NOT NULL,
    version_id     TEXT NOT NULL,
    version_number TEXT,
    files          TEXT NOT NULL CHECK (json_valid(files))
) STRICT;
