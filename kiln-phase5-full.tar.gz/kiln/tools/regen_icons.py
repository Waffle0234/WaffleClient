#!/usr/bin/env python3
"""Regenerate Kiln's app icons (original artwork, no Minecraft imagery).

Draws a 1024px kiln-mouth glyph with Pillow, then runs `tauri icon` (installed as a dev
dependency in ui/) to produce every size, and deletes the unused mobile icon sets.

    pip install pillow          # if missing
    (cd ui && npm ci)           # installs the Tauri CLI
    python3 tools/regen_icons.py [--out DIR]

`--out` defaults to src-tauri/icons. The Rust build of src-tauri needs these files to exist.
"""
import pathlib
import shutil
import subprocess
import sys

from PIL import Image, ImageDraw

ROOT = pathlib.Path(__file__).resolve().parent.parent


def draw(path: pathlib.Path) -> None:
    size = 1024
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((64, 64, size - 64, size - 64), radius=220, fill=(24, 33, 31, 255))
    d.rounded_rectangle((232, 300, 792, 800), radius=60, fill=(40, 54, 50, 255))
    d.pieslice((232, 250, 792, 610), 180, 360, fill=(40, 54, 50, 255))
    d.pieslice((372, 430, 652, 710), 180, 360, fill=(95, 185, 154, 255))
    d.rectangle((372, 570, 652, 800), fill=(95, 185, 154, 255))
    d.rectangle((372, 740, 652, 800), fill=(24, 33, 31, 255))
    img.save(path)


def main() -> int:
    out = ROOT / "src-tauri" / "icons"
    if "--out" in sys.argv:
        out = pathlib.Path(sys.argv[sys.argv.index("--out") + 1]).resolve()
    source = ROOT / "icon-source.png"
    draw(source)
    try:
        subprocess.run(
            ["npx", "tauri", "icon", str(source), "-o", str(out)],
            cwd=ROOT / "ui",
            check=True,
            stdout=subprocess.DEVNULL,
        )
    finally:
        source.unlink(missing_ok=True)
    for mobile in ("android", "ios"):
        shutil.rmtree(out / mobile, ignore_errors=True)
    print(f"icons written to {out}: {len(list(out.iterdir()))} files")
    return 0


if __name__ == "__main__":
    sys.exit(main())
