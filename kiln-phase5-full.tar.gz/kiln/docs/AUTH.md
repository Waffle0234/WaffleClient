# Microsoft sign-in

## How it works

Kiln uses Microsoft's **device-code flow**: the app shows a short code, the user enters it
on microsoft.com in any browser, and Kiln polls until they finish. There is no embedded
webview, no local redirect server, and Kiln never sees the user's password.

```
Microsoft device code -> MS access + refresh token
  -> Xbox Live user token -> XSTS token (relying party rp://api.minecraftservices.com/)
  -> Minecraft access token -> Minecraft profile (404 means the account doesn't own the game)
```

Where things live:

| Item | Storage |
|---|---|
| Refresh token | OS keychain only (Credential Manager / Keychain / Secret Service), stored as raw bytes |
| Minecraft access token | Memory only, wiped on drop, refreshed ~5 minutes before expiry |
| Device code | Memory only, never sent to the UI |
| Account name, skin hash, flags | SQLite (`accounts` table), no secrets |

No token ever crosses the IPC boundary. The UI receives `Account` and `DeviceCodeInfo`; only the
launch pipeline can ask the backend for a `LaunchSession`.

## Setup you must do before real sign-in works

1. **Azure app registration** (portal.azure.com, App registrations, New registration).
   - Supported account types: personal Microsoft accounts (consumer accounts).
   - Name: must not contain "Mojang", "Minecraft" or similar protected words.
   - Redirect URI: leave empty (device flow doesn't use one).
   - Authentication, Advanced settings: **Allow public client flows = Yes**. Without this Microsoft
     returns `AADSTS70002`.
   - No client secret. Copy the **Application (client) ID**, a GUID.
2. **Ask Mojang to approve the client ID** at <https://aka.ms/mce-reviewappid>. Until then
   `login_with_xbox` answers 403 "Invalid app registration" and Kiln shows
   "Mojang hasn't approved this build's Microsoft app registration". Reviews have been reported as
   weekly; the form is authoritative, not this document.
3. **Give the ID to Kiln**, either:
   - at runtime: `KILN_MS_CLIENT_ID=<guid> cargo tauri dev` (handy while testing), or
   - at build time: set `KILN_MS_CLIENT_ID` in the environment when building releases (it is read
     with `option_env!`). A client ID is public information, not a secret.

Anything that isn't a well-formed GUID is treated as "not configured".

These steps were checked against third-party documentation and a Microsoft Q&A thread, not
Mojang's own pages. Verify against the form before relying on them.

## Errors users can see

| Situation | Message gist |
|---|---|
| No client ID in this build | Sign-in isn't set up in this build |
| Code not used in time | The code expired, start again |
| Declined on Microsoft's page | Sign-in was cancelled |
| XSTS `2148916233` | No Xbox profile yet; sign in at xbox.com once |
| XSTS `2148916235` | Xbox unavailable in the account's region |
| XSTS `2148916236` / `2148916237` | Adult verification needed |
| XSTS `2148916238` | Child account; an adult must add it to a family group |
| Profile 404 | Account doesn't own Minecraft: Java Edition |
| Refresh rejected, or keychain entry missing | Sign in again (account stays listed, flagged) |
| Keychain unavailable | Explains how to unlock it; nothing is stored in plaintext as a fallback |

## Platform notes

- **Linux** needs a running Secret Service provider (GNOME Keyring or KWallet), unlocked.
- **Windows** Credential Manager limits a blob to 2,560 bytes. Tokens are stored as raw UTF-8 bytes
  (the string API would store UTF-16 and double the size). A real refresh token is ~1.5 KB.

## Testing

Everything except the real OS keychain is covered by unit tests against a mock server
(`cargo test`). The keychain test is ignored by default because most CI machines have no unlocked
keychain: run `cargo test -p kiln-core -- --ignored keyring` on a machine that has one.
It has been run on Linux with GNOME Keyring; macOS and Windows are untested.
