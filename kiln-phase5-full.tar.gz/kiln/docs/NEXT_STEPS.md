# Kiln: handoff prompt for the next chat

Paste everything below the line into a new chat. Give the assistant the project in **one** of two ways:

- **Bundle files** (for chat uploads with a file-count limit): attach `restore.py` and every
  `kiln-*.txt` file, then the assistant runs `python3 restore.py` to rebuild the repository.
  `kiln-8-lockfiles.txt` is optional and large: skip it if context is tight.
- **Local folder** (Claude Code on your own machine): `cd` into your checkout and start Claude Code
  there. No attachments needed.

---

You are continuing a project already in progress: **Kiln** (a codename; the display name lives in
`kiln_core::APP_NAME` and `src-tauri/tauri.conf.json`), a fast, secure, cross-platform (Windows,
macOS, Linux) **Minecraft Java Edition launcher**. Stack: Tauri 2 (Rust backend), Svelte 5 +
TypeScript + Tailwind 4 frontend, SQLite via sqlx, tokio, reqwest (rustls + ring), tracing.
Licence: GPL-3.0-only.

The project arrives either as bundle files (see "Your first steps") or as a folder on disk. A restore
from bundles starts a fresh git history with one baseline commit. Read `README.md`,
`docs/ARCHITECTURE.md` and `docs/AUTH.md` before writing anything. The architecture was **already
approved by the user**: do not re-ask for approval, and do not redo finished work.

## Status

| Phase | Scope | State |
|---|---|---|
| 1 | Scaffold, settings, SQLite, logging, CI | Done |
| 2 | Microsoft sign-in (device code), OS keychain, Accounts screen | Done, but real sign-in untested (see "User-side blockers") |
| 3 | Version manifests, Java manager, downloader, vanilla launch, Console screen | Done, but only tested against mock servers |
| 4 | Instances and loaders (Fabric, Quilt, NeoForge, Forge), `.kiln.zip` / `.mrpack` import and export, Instances screen | Done, but only tested against mock servers |
| 5 | Modrinth browser, installs, dependency resolution, updates, rollback, modpacks | Done, but only tested against a fake Modrinth |
| 6 | Performance presets, JVM flags, options optimizer, benchmark, in-game extras | **To do** |
| 7 | UI polish, crash analyzer, world backups, servers, playtime | **To do** |
| 8 | Security audit, packaging, signed auto-updater, final docs | **To do** |

## Where things are

`crates/kiln-core/src` (all logic and tests live here): `paths` (data dirs, portable mode, `SafePath`),
`hash`, `redact`, `logging`, `db` (SQLite, WAL, migrations in `crates/kiln-core/migrations`),
`settings`, `error` (`Error` / `AppError`), `net` (allowlisted HTTPS client; `execute` for small
responses, `get_stream` for downloads with per-hop redirect checks), `auth` (device-code sign-in,
keychain, accounts, `LaunchSession`), `download` (`Downloader`, `DownloadTask`, `link_or_copy`),
`archive` (`extract_zip`, `extract_tar_gz`, `read_zip_entry`, `write_zip`), `mojang` (manifest, version
JSON, `rules`, libraries, natives, asset index, `VersionJson::merged_onto`), `java` (`JavaManager`),
`loader` (`LoaderClient`; `forge.rs` runs Forge/NeoForge installers), `instance` (`InstanceStore`,
`parse_jvm_args`; `pack.rs` is `PackService`), `launch` (`args`, `LaunchManager`, `prepare`,
`spawn_and_stream`, `LaunchEvents`). The `instances`, `mods`, `mod_backups`, `servers`, `backups`,
`option_profiles` and `http_cache` tables exist (migration `0001`); `mods`, `mod_backups`, `servers`,
`backups`, `option_profiles` and `http_cache` are not used by any code yet.

`src-tauri`: `state.rs` (`AppState`), `commands/{app,auth,instances,launch}.rs`, `build.rs` (command
list), `capabilities/default.json`, `tauri.conf.json` (CSP). `ui/src`: `routes/{Accounts,Console,
Instances,Settings}.svelte`, stores in `lib/*.svelte.ts`, typed IPC in `lib/api.ts`, an in-memory
browser stand-in in `lib/mock.ts`. Home and Mods are still placeholders
(`components/Placeholder.svelte`).

Testing patterns to reuse: `wiremock` servers with `HostPolicy::new(&[]).with_loopback_http()` (a
`#[cfg(test)]`-only switch), `with_clients(...)` constructors that let tests inject clients and
endpoints, a shell script standing in for `java` (Unix-only tests), and `db::open_in_memory()`.

## What is still to build

**Phase 5**: a `ModSource` trait (so CurseForge can be added later) with a Modrinth v2
implementation: proper User-Agent identifying app and version (Modrinth wants contact info), search
with filters, project pages, version lists, dependency resolution (required, optional,
incompatible), one-click install, update scan by file hash (`version_files`), changelogs, update-all,
per-mod pinning, automatic rollback if the game fails to start after an update (previous jars kept
in a backup folder, `mod_backups` table; hook into `LaunchManager`), full `.mrpack` install, update
and export, rate-limit awareness, ETag caching (`http_cache` table), and "unverified" flagging of jars
not from Modrinth (show author, downloads, licence). Populate the `mods` table (instance folders
currently hold untracked jars). Never run anything from a modpack except installing its files.
Carry-overs for this phase: `.mrpack` export should list Modrinth-hosted files with their hashes
instead of putting everything in `overrides/`; show import progress in the UI; add the Mods screen
(the CSP already allows `cdn.modrinth.com` images); add a `ModSource`-level host allowlist.

**Phase 6**: optional "Performance" preset that installs the loader-compatible set (Sodium, Lithium,
FerriteCore, ModernFix, EntityCulling, ImmediatelyFast, Iris, Sodium extras) resolved per Minecraft
version; JVM argument presets (Aikar-style or Generational ZGC/G1) by Java version and RAM with
automatic RAM sizing (unset RAM currently means the JVM default) and an advanced override; an
"optimize" tool that writes recommended `options.txt` values; opt-in per-instance extras (HUD editor,
zoom, freelook, screenshot manager, replay recorder) by integrating existing open-source mods via
Modrinth and respecting licences; keybind and options profiles that can be saved, shared and applied
(`option_profiles` table). New JVM flags must still pass the `instance::parse_jvm_args` rules.

**Phase 7**: finish the screens (Home with news and last-played, Instance detail with
mods/packs/shaders/worlds/logs/settings, Mod browser; the Instances list and Console exist), a crash
analyzer parsing `latest.log` and crash reports to suggest the likely culprit mod and a fix,
scheduled world backups with one-click restore, server list with favorites/ping/quick-join, playtime
stats (play time is already recorded per instance), a UI for the per-instance Java runtime
(`java_id`, supported by the backend), and a plugin/extension API for custom panels.

**Phase 8**: security audit pass (including the Forge/NeoForge installer trust model); `cargo audit`
in CI (never run locally yet); packaging (MSI/NSIS, DMG, AppImage/deb); Tauri updater with signature
verification (not configured yet, no pubkey); `docs/SECURITY.md` and `docs/LICENSING.md`; the README
security-model section completed; a properly designed app icon (the current one is an acceptable
placeholder with a small notch); measure **release-build** idle RAM (a debug build under Xvfb showed
roughly 144 MB for the app plus 190 MB for WebKit processes: a baseline, not a result).

**Known gaps from earlier phases** (do them when they become blocking or in Phase 8): the Zulu fallback
for Java builds Temurin doesn't publish (Java 8 on Apple Silicon); legacy asset layouts
(`virtual` / `map_to_resources`); Forge before Minecraft 1.17 and NeoForge/Minecraft numbering beyond
`25.x`; using `download::link_or_copy` to share cached files into instances; `fsync` before the
`.part` rename; real-network validation of everything below.

## Rules the codebase already follows (keep them)

- All logic and tests live in `crates/kiln-core`; `src-tauri` only validates input, calls core and
  maps errors. Strict clippy: `unwrap_used`/`expect_used` are denied outside tests.
- Untrusted relative paths go through `paths::SafePath`/`validate_relative`. Never build file
  paths from archive entries, modpack manifests or IPC strings any other way.
- All network traffic goes through `net::HttpClient`: HTTPS only, per-client host allowlist, no
  redirect following, 2 MiB response cap, never logs URLs beyond host and path or any body.
  Redirect-following for downloads must re-check every hop against the allowlist.
- Secrets: refresh tokens only in the OS keychain; access tokens in `SecretString` (hidden from
  `Debug`, zeroized, auto-registered with the log redactor); no token crosses IPC or reaches a log.
  Never add a plaintext fallback.
- Every IPC command must be listed in `src-tauri/build.rs` `COMMANDS` **and** granted in
  `src-tauri/capabilities/default.json` (`allow-<kebab-name>`), and return `Result<T, AppError>`
  with a plain-English message. Validate inputs in the command (see `commands/auth.rs`).
- Strict CSP in `tauri.conf.json` (no inline scripts/styles, fonts self-hosted, `img-src` allows
  only Modrinth CDN and `textures.minecraft.net`). Avoid Svelte transitions (they inject `<style>`);
  use CSS transitions.
- Legal: no cracked/offline-auth features, no Minecraft logos or assets, state non-affiliation
  with Mojang/Microsoft, respect mod licences.
- No telemetry. No background polling when idle.
- Design language: "glaze" palette (celadon accent on slate-green dark; green-grey paper light),
  Bricolage Grotesque headings and Public Sans body, ruled rows instead of card grids, user-themeable
  accent. Follow the existing tokens in `ui/src/app.css`.
- Downloads: every destination is a `SafePath`; files reach their final path only after hash
  verification (`.part` then rename). Archives are extracted only through `archive::*`. Loader and
  pack downloads use their own host allowlists (`loader::host_policy`, `instance::pack::mrpack_policy`).
- The webview never supplies a file path. Imports name a file in the `imports/` folder, exports go to
  `exports/`, `open_folder` takes a fixed choice. Do not add a dialog or fs plugin.
- User-supplied JVM arguments go through `instance::parse_jvm_args`; values from packs or other
  untrusted sources are dropped, not trusted.
- The UI never receives a token, a URL with credentials, or an unredacted game log line.

## How I (the previous assistant) worked: please do the same

- Work phase by phase. A phase is done only when `cargo fmt --all --check`,
  `cargo clippy --workspace --all-targets -- -D warnings`, `cargo test --workspace`,
  `svelte-check`, `vitest`, and `npm audit --audit-level=high` pass. Commit once per phase.
- **Mutation-check security claims.** After tests pass, deliberately break the behaviour (log a
  token, drop an allowlist, reorder a write, skip a hash check) and confirm a test fails. Verify the
  mutation actually applied (rustfmt reflows lines, so a search-and-replace can silently miss: check
  the match count) and that the sources were restored. Mutation checks found real problems: an untested
  `..` rule, a silently failed mutation, and a test that passed only because a fake `java` never wrote
  its output.
- For anything UI-visible, run the real binary under Xvfb and look at a screenshot (see
  "Environment notes"). Svelte-check passing is not proof the CSP lets the page render. Seed the
  throwaway data folder (for example a saved Mojang manifest, or packs in `imports/`) inside the same
  tool call as the run, since the sandbox has no network and environment variables do not persist
  between calls. Prove a check can fail (a negative control) before trusting it.
- clippy gotcha: it only treats `#[cfg(test)]` (possibly with a second `#[cfg(unix)]` outer attribute)
  as test code for the `unwrap` allowance, not `cfg(all(test, unix))`, and it rejects mixing inner and
  outer attributes on a module.
- Finish each phase with a short, honest summary: what was verified, what was not, deviations.
- Ask clarifying questions only if truly blocking; otherwise decide, state the assumption, continue.

## Environment notes (the sandbox the project was built in; adapt if yours differs)

- No `rustup` access. Rust came from Ubuntu packages: `apt-get install rustc-1.91 cargo-1.91
  rust-1.91-clippy rustfmt-1.91`, then `export PATH=/usr/lib/rust-1.91/bin:$PATH` (this directory has
  `cargo`, `cargo-clippy`, `cargo-fmt`). Also needed: `build-essential pkg-config libssl-dev
  libdbus-1-dev libwebkit2gtk-4.1-dev libgtk-3-dev libayatana-appindicator3-dev librsvg2-dev
  libsoup-3.0-dev libjavascriptcoregtk-4.1-dev`. For UI screenshots: `xvfb scrot xdotool dbus-x11`.
  For a real-keychain test: `gnome-keyring libsecret-tools`.
- Disk can fill: clippy, test and app builds together reached ~8 GB of `target/`, and the sandbox failed
  to link with "No space left on device". `rm -rf target/debug/incremental`, `apt-get clean`, and deleting
  large test executables in `target/debug/deps` freed enough.
- Xvfb and background GUI processes do not survive between tool calls: start Xvfb, the app, the click and
  the screenshot in one call (a helper script is a good idea).
- Cheaper builds: `CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=line-tables-only` (environment only, no
  repo change) kept `target/` small after a `cargo clean` freed 8.5 GB. `/bin/sh` here is dash: use
  `. file`, not `source`.
- One CPU core: a cold workspace build takes ~6 minutes. Run long builds detached:
  `setsid nohup cargo ... > /tmp/x.log 2>&1 < /dev/null &` and poll the log. Plain `&` jobs die when
  the tool call ends, and the VM was once restored from a snapshot mid-session (processes lost, disk
  kept), so start a GUI, click and screenshot within a single call.
- `/bin/sh` is dash: **no `{a,b}` brace expansion** in `mkdir -p`. Use explicit paths or `bash -c`.
- Run the built app: `cargo build -p kiln --features tauri/custom-protocol` (embeds `ui/dist`, so run
  `npm run build` in `ui/` first), then under `Xvfb :99` with `WEBKIT_DISABLE_COMPOSITING_MODE=1
  WEBKIT_DISABLE_DMABUF_RENDERER=1 LIBGL_ALWAYS_SOFTWARE=1` and a throwaway `HOME`/`XDG_DATA_HOME`;
  drive it with `xdotool`, capture with `scrot`.
- Real-keychain test: inside `dbus-run-session`, start `gnome-keyring-daemon --unlock
  --components=secrets`, then `cargo test -p kiln-core --lib -- --ignored keyring`.
- Network egress from the sandbox is allowlisted (crates.io, npm, GitHub, Ubuntu mirrors), so real
  Mojang/Microsoft/Modrinth calls cannot be made; use wiremock.
- Newer dependency majors than you may expect resolved fine (Vite 8, TypeScript 6, vitest 5,
  reqwest 0.13, keyring 3.6). Lockfiles are committed.

## What earlier phases left open

### Phase 3

- Real Mojang, Adoptium and GitHub downloads have never run (sandbox egress is allowlisted). Everything
  is verified against wiremock. A real vanilla launch has never happened.
- The game runs in `instances/vanilla-<version>`, which is **not** a row in the `instances` table.
  Phase 4 should replace this with real instances, and use `download::link_or_copy` to share cached
  jars and libraries (it exists and is tested, but the launch pipeline still uses the cache directly).
- Not supported yet, each with a clear error: loader profiles (`inheritsFrom`), libraries without
  `downloads.artifact` (Fabric/Forge style, which Phase 4 must handle with its own hashing), legacy
  asset layouts (`virtual` / `map_to_resources`), and Java 8 on Apple Silicon (no Temurin build; the
  brief's Zulu fallback was not implemented). Java is matched by exact major version.
- The cache trusts a file whose size matches (files only reach their final path after verification).
  There is no `fsync` before the rename. RAM unset means the JVM default (Phase 6 does sizing).
- The Java download client's allowlist includes `github.com` and GitHub's release CDN; it relies on the
  Adoptium SHA-256 check. `os.version` rules only match on Windows (assumed `10.0`).
- There is no `game-exited` event: exit is a `launch-status` variant. One game runs at a time.
- Several launch and Java tests use a shell script as a fake `java` and are Unix-only.
- Mutation checks done (each applied, each caught by a test): dropping the per-hop redirect allowlist
  check, skipping hash verification, skipping the archive name validation, forwarding game output
  unredacted, a `Debug` impl that prints launch args, accepting any tar symlink target, skipping the Java
  version check. Also done: the real binary under Xvfb renders the Console under the CSP, and removing
  `core:event:allow-listen` makes the Console show its "live output unavailable" alert (restoring it
  clears the alert).

### Phase 4

- Real Fabric, Quilt, Forge, NeoForge and Modrinth-CDN traffic has never run. Loader installs, the
  Forge/NeoForge installer pipeline and `.mrpack` downloads are verified against wiremock and a fake
  `java` script only. **A real Forge or NeoForge install has never happened**; expect surprises in
  real installer profiles (library `url: ""` entries, `data` entries, processor argument forms).
- Loaders install lazily on first launch (profile saved under `cache/loaders/`, libraries shared in
  `cache/libraries`), not when the instance is created. Fabric/Quilt libraries get their SHA-1 from the
  `.sha1` file next to each artifact on the same Maven host, which protects against corruption and bad
  mirrors, not a compromised repository. The Forge/NeoForge installer is checked the same way, and its
  processors run as Java programs with the user's privileges; each processor's declared output hashes
  are verified.
- Supported ranges: Forge from Minecraft 1.17 (older installers use a different format), NeoForge
  `20.x`-`25.x` version numbers (the new year-based Minecraft numbering is not mapped). The picker hides
  everything else. Library URLs in loader profiles must be on the loader allowlist
  (`loader::host_policy`) or the download is refused.
- Packs: `.mrpack` import honours `env.client`, requires a checksum (sha512 preferred), accepts only the
  spec's hosts (plus GitHub's CDN), applies `overrides/` then `client-overrides/`, and never runs
  anything. `.mrpack` export puts mods and configs in `overrides/` (no Modrinth hash lookups until
  Phase 5) and leaves out worlds; `.kiln.zip` export includes worlds. Imported JVM arguments and Java
  choice are dropped; only RAM is kept. Import progress is not reported to the UI yet.
- The webview never supplies paths: imports name a file in `imports/`, exports land in `exports/`,
  `open_folder` accepts a fixed set. There is no native file dialog by design (no dialog plugin).
- `LaunchRequest` now carries the instance (version, loader, folder, RAM, vetted JVM flags, optional
  Java path); `launch_start` takes an instance id. Play time is recorded when a game that reached
  "running" exits. The Console no longer has a version picker. The per-instance Java runtime
  (`java_id`) is supported by the backend but has no UI yet; `mods` rows are not populated yet.
- Mutation checks done for Phase 4 (each applied, each caught): JVM deny-list, deleting a running
  instance, reserved `.kiln*` paths in `.mrpack`, `.mrpack` host filtering, `.mrpack` hash
  verification, reserved paths in native packs, library hash verification, Forge processor output
  verification, installer checksum verification, confinement of Maven coordinates to the libraries
  folder. The real binary under Xvfb: create, export, Play with no account (clean error), importing a
  valid pack, and refusing a zip-slip pack with nothing left on disk.
- The GUI check harness needs its state seeded in the same tool call as the run (environment
  variables do not persist between calls). One unexplained empty-list frame appeared in an early run
  and did not reproduce.

## Not verified yet (treat as open risks)

- The Windows and macOS builds and the GitHub Actions workflow have **never run**.
- macOS Keychain and Windows Credential Manager paths are untested (Linux Secret Service passed).
- `npm audit --audit-level=high` fails since the advisory database updated on 2026-11-17: picomatch
  (ReDoS through crafted glob patterns, GHSA-fc5q-39xc-vjpf) has no patched release (4.0.7 is the
  newest and is flagged), and it is pulled in by vite, vitest and svelte-check. It is a build-time
  tool: `npm audit --omit=dev --audit-level=high` passes and the built `ui/dist` contains no picomatch.
  npm's suggested fix is a breaking downgrade of vite, so nothing was changed. CI's audit job will
  fail until upstream ships a fix, or someone decides to audit with `--omit=dev`.
- Phase 5 was verified against a fake Modrinth only. Not built: project detail pages, UI buttons for
  checking and applying a modpack update (the commands `modpack_check_update` and `modpack_update`
  exist), shader and resource-pack installs, reading metadata out of unverified jars.
- `cargo audit` never run; `cargo tauri dev` and the `beforeDevCommand` (`npm --prefix ui run dev`)
  never run.
- Real Microsoft/Xbox/Minecraft/Adoptium calls have never been made (mock server only).

## User-side blockers (the user said they will handle these themselves)

Real sign-in needs a Microsoft Azure app registration (public client, personal accounts, "Allow
public client flows" on) **and** Mojang's approval of that client ID via https://aka.ms/mce-reviewappid.
Until then Mojang answers 403 "Invalid app registration" and Kiln shows a clear message. Details in
`docs/AUTH.md`; those steps were checked against third-party sources only, so remind the user to
verify them against Mojang's form. The client ID is supplied by `KILN_MS_CLIENT_ID` (runtime, or at
build time).

## Your first steps

1. **If you received bundle files**: run `python3 restore.py` next to them (it writes `./kiln`,
   rejects any path that would escape that folder, fetches the GPL-3.0 `LICENSE` text if the
   network allows, and makes a baseline git commit). Then, because binary files can't travel in
   text bundles, regenerate the icons (the Rust build of `src-tauri` fails without them):
   `cd kiln/ui && npm ci && cd .. && pip install pillow && python3 tools/regen_icons.py`.
   Tauri's `src-tauri/permissions/autogenerated/*.toml` also regenerate on the first build; if
   `kiln-8-lockfiles.txt` was skipped, `Cargo.lock` and `ui/package-lock.json` are recreated by the
   first `cargo build` / `npm install` (commit them, and run the baseline to confirm nothing broke).
2. Install the toolchain if needed and run the baseline: `cargo test -p kiln-core` should report 173
   passed, 1 ignored, plus 1 logging integration test; then
   `cd ui && npm ci && npx svelte-check && npx vitest run` (6 tests).
3. Start **Phase 5** immediately. Plan the module layout in a few lines (no new approval round),
   build it, and report as described above.
