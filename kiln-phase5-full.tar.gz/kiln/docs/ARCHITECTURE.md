# Architecture

Approved design for Kiln. Boundary rule: `ui -> IPC -> src-tauri -> kiln-core`; all
logic and tests live in `kiln-core`.

## Modules in `kiln-core`

Implemented: `paths` (data dirs, portable mode, `SafePath`), `hash`, `redact`, `logging`,
`db` (SQLite, WAL, migrations), `settings`, `error`, `net` (allowlisted HTTPS client, streaming
GET with per-hop redirect checks), `auth` (device-code sign-in, keychain, accounts), `download`
(parallel, resumable, hash-verified, atomic `.part` rename), `archive` (zip and tar.gz, zip-slip
safe), `mojang` (version manifest, version JSON, `rules`, libraries, natives, asset index, profile merging), `java`
(detect installed JDKs, download Temurin), `launch` (argument building, pipeline, one-game manager,
events), `loader` (Fabric and Quilt profiles from their meta APIs; Forge and NeoForge through their
official installers), `instance` (instance store, JVM-argument vetting, `.kiln.zip` and `.mrpack`
import/export).

`mods` (Phase 5):
- `source.rs`: the `ModSource` trait and catalogue-neutral types. Ids are validated (`[A-Za-z0-9_-]`,
  at most 64 chars) before they go into a URL; file names must be plain `.jar`s.
- `modrinth.rs`: the Modrinth v2 implementation. Host allowlist `api.modrinth.com` for the API and
  `cdn.modrinth.com` for files (`ModSource::download_policy`, checked again for every file URL before
  a download is queued). User-Agent is `Kiln/<version> (<contact>)` (`mods::CONTACT`). GET responses
  are cached with their ETag in `http_cache` (keyed by a hash of the URL; bodies in `cache/http/`)
  and reused without a request for five minutes. Rate-limit headers and 429s are honoured: short
  waits are slept off, long ones fail with a "try again in N seconds" message.
- `store.rs`: the `mods` table, scanning `mods/` (size and mtime skip re-hashing; symlinks are
  ignored), pin, enable (`.jar.disabled`), remove, update backups (`mod_backups`, files under
  `backups/mods/`) and rollback. No network code, so the launch manager can use it.
- `service.rs`: dependency resolution (required, optional offered, incompatible blocks), install,
  update scan by SHA-1 (`version_files/update`), update, update-all, modpack install and update,
  `.mrpack` export with Modrinth hashes.

Rollback: an update records the replaced jar (copied before anything is written) as `pending`. When
the game exits abnormally within two minutes of starting, `LaunchManager` calls
`ModStore::rollback_pending`, which checks each backup against the hash recorded before the update,
puts it back and removes jars the update added. A clean exit, or a run longer than the window,
confirms the update; stopping the game yourself decides nothing.

Planned: `perf`, `crash`, `backup`, `servers`.

## Roadmap

| Phase | Scope |
|---|---|
| 1 | Scaffold, settings, SQLite, logging, CI |
| 2 (done) | Microsoft auth and OS keychain |
| 3 (done) | Version manifests, Java manager, downloader, vanilla launch |
| 4 (done) | Instances and loaders (Fabric and Quilt, then NeoForge and Forge) |
| 5 (done) | Modrinth browser, installs, dependencies, updates, rollback, modpacks |
| 6 | Performance presets and benchmark |
| 7 | UI polish, crash analyzer, backups |
| 8 | Security audit, packaging, signed updater |

## Data model

Defined in `crates/kiln-core/migrations/` (`0001_init.sql`; `0003_mods.sql` adds mod metadata, update
backups and `instance_packs`, which links an instance to the Modrinth pack it came from). No secrets are stored in SQLite;
refresh tokens go only to the OS keychain.

## IPC commands

Implemented: `get_app_info`, `get_settings`, `set_setting`, `auth_begin_device_flow`,
`auth_poll` (waits until the user finishes; replaces repeated polling from the UI),
`auth_cancel`, `auth_open_verification_page` (takes no argument: the address comes from the
validated pending flow), `auth_list_accounts`, `auth_set_active`, `auth_remove`.
Instances and the version picker: `picker_game_versions`, `picker_loader_versions` (only versions the
chosen loader supports), `instance_list`, `instance_create`, `instance_rename`, `instance_clone`,
`instance_delete`, `instance_update_settings`, `instance_export`, `instance_list_imports`,
`instance_import`, `open_folder`. None takes a file path.
Launching: `launch_start` (takes only an instance id; the account, settings and Java come from the
backend), `launch_stop`, `launch_status`, `launch_log`. Progress and output reach the UI
as the events `launch-status` (including the final `exited`/`failed` state) and `game-log`; the
capability file grants `core:event:allow-listen` and `allow-unlisten` for them.
Mods: `mod_search`, `mod_project`, `mod_versions`, `mods_list`, `mod_install_plan`, `mod_install`,
`mods_check_updates`, `mod_update`, `mods_update_all`, `mod_set_pinned`, `mod_set_enabled`,
`mod_remove`, `mods_rollback`, `modpack_install`, `modpack_check_update`, `modpack_update`. They take
project ids, instance ids and mod row ids only. `instance_export` returns what was listed by hash and
which jars were bundled. Long operations report through the `task-progress` event (counts only); an
automatic rollback is announced with `mods-rolled-back`. One mod operation runs at a time, and none
runs on an instance whose game is starting or running (and the game won't start during one).
Skin and cape URLs are part of `Account`, so there is no separate `auth_get_skin`. Every command must be listed
in `src-tauri/build.rs` and granted in `src-tauri/capabilities/default.json`.
Errors cross the boundary as `{ code, message }` with a plain-English message.
