//! Declares every IPC command in the app manifest. With a manifest, a command is only
//! callable if a capability grants its `allow-*` permission (least privilege).

pub const COMMANDS: &[&str] = &[
    "get_app_info",
    "get_settings",
    "set_setting",
    "auth_begin_device_flow",
    "auth_poll",
    "auth_cancel",
    "auth_open_verification_page",
    "auth_list_accounts",
    "auth_set_active",
    "auth_remove",
    "launch_start",
    "launch_stop",
    "launch_status",
    "launch_log",
    "picker_game_versions",
    "picker_loader_versions",
    "instance_list",
    "instance_create",
    "instance_rename",
    "instance_clone",
    "instance_delete",
    "instance_update_settings",
    "instance_export",
    "instance_list_imports",
    "instance_import",
    "open_folder",
    "mod_search",
    "mod_project",
    "mod_versions",
    "mods_list",
    "mod_install_plan",
    "mod_install",
    "mods_check_updates",
    "mod_update",
    "mods_update_all",
    "mod_set_pinned",
    "mod_set_enabled",
    "mod_remove",
    "mods_rollback",
    "modpack_install",
    "modpack_check_update",
    "modpack_update",
];

fn main() {
    let manifest = tauri_build::AppManifest::new().commands(COMMANDS);
    let attributes = tauri_build::Attributes::new().app_manifest(manifest);
    if let Err(e) = tauri_build::try_build(attributes) {
        eprintln!("tauri-build failed: {e:#}");
        std::process::exit(1);
    }
}
