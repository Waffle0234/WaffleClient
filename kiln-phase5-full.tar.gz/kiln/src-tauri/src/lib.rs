//! Tauri shell. Rule: this crate only validates input, calls `kiln-core`, and maps
//! errors. Logic and tests live in `kiln-core`.

mod commands;
mod state;

use std::path::PathBuf;

use state::AppState;

pub fn run() {
    let result = tauri::Builder::default()
        .setup(|app| {
            use tauri::Manager;
            let exe_dir: Option<PathBuf> = std::env::current_exe()
                .ok()
                .and_then(|exe| exe.parent().map(PathBuf::from));
            let state = tauri::async_runtime::block_on(AppState::init(exe_dir.as_deref()))?;
            app.manage(state);
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            commands::app::get_app_info,
            commands::app::get_settings,
            commands::app::set_setting,
            commands::auth::auth_begin_device_flow,
            commands::auth::auth_poll,
            commands::auth::auth_cancel,
            commands::auth::auth_open_verification_page,
            commands::auth::auth_list_accounts,
            commands::auth::auth_set_active,
            commands::auth::auth_remove,
            commands::launch::launch_start,
            commands::launch::launch_stop,
            commands::launch::launch_status,
            commands::launch::launch_log,
            commands::instances::picker_game_versions,
            commands::instances::picker_loader_versions,
            commands::instances::instance_list,
            commands::instances::instance_create,
            commands::instances::instance_rename,
            commands::instances::instance_clone,
            commands::instances::instance_delete,
            commands::instances::instance_update_settings,
            commands::instances::instance_export,
            commands::instances::instance_list_imports,
            commands::instances::instance_import,
            commands::instances::open_folder,
            commands::mods::mod_search,
            commands::mods::mod_project,
            commands::mods::mod_versions,
            commands::mods::mods_list,
            commands::mods::mod_install_plan,
            commands::mods::mod_install,
            commands::mods::mods_check_updates,
            commands::mods::mod_update,
            commands::mods::mods_update_all,
            commands::mods::mod_set_pinned,
            commands::mods::mod_set_enabled,
            commands::mods::mod_remove,
            commands::mods::mods_rollback,
            commands::mods::modpack_install,
            commands::mods::modpack_check_update,
            commands::mods::modpack_update,
        ])
        .run(tauri::generate_context!());

    if let Err(e) = result {
        tracing::error!(error = %e, "Kiln failed to start");
        eprintln!("Kiln failed to start: {e}");
        std::process::exit(1);
    }
}
