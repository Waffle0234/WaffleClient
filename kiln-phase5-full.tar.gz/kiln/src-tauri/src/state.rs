use std::path::Path;
use std::sync::Arc;

use kiln_core::auth::{client_id_from_env, AuthService, KeyringStore};
use kiln_core::db::{self, Db};
use kiln_core::instance::InstanceStore;
use kiln_core::launch::LaunchManager;
use kiln_core::logging::{self, LogGuard};
use kiln_core::mods::cache::HttpCache;
use kiln_core::mods::modrinth::Modrinth;
use kiln_core::mods::store::ModStore;
use kiln_core::paths::DataDirs;
use kiln_core::settings::SettingsStore;

/// Keychain service name. Entries show up under this name in Keychain Access, Credential
/// Manager, and Seahorse/KWallet.
const KEYCHAIN_SERVICE: &str = "app.kiln.launcher";

pub struct AppState {
    pub dirs: DataDirs,
    pub db: Db,
    pub settings: SettingsStore,
    pub auth: Arc<AuthService>,
    pub launch: LaunchManager,
    pub instances: InstanceStore,
    pub mods: ModStore,
    pub modrinth: Modrinth,
    /// Held while a mod or modpack operation runs, so two never change a folder at once.
    pub mod_ops: tokio::sync::Mutex<()>,
    pub log: LogGuard,
}

impl AppState {
    pub async fn init(exe_dir: Option<&Path>) -> kiln_core::Result<Self> {
        let dirs = DataDirs::resolve(exe_dir)?;
        dirs.ensure_created()?;

        // Logging first so database problems are recorded. The saved level is applied
        // as soon as settings are loaded. No background work happens after this.
        let log = logging::init(&dirs.logs, "info", cfg!(debug_assertions))?;
        tracing::info!(
            version = kiln_core::APP_VERSION,
            portable = dirs.portable,
            "starting"
        );

        let db = db::open(&dirs.db_file).await?;
        let settings = SettingsStore::new(db.clone());
        let instances = InstanceStore::new(db.clone(), &dirs.instances);
        log.set_level(&settings.load().await?.log_level)?;
        let mods = ModStore::new(db.clone(), instances.clone(), &dirs.backups);
        let cache = HttpCache::open(db.clone(), &dirs.cache.join("http")).await?;
        let modrinth = Modrinth::new(Some(cache))?;

        let client_id = client_id_from_env();
        if client_id.is_none() {
            tracing::warn!("no Microsoft client id configured: sign-in is disabled");
        }
        let auth = Arc::new(AuthService::new(
            db.clone(),
            Arc::new(KeyringStore::new(KEYCHAIN_SERVICE)),
            client_id,
        )?);
        auth.init().await?;

        Ok(Self {
            dirs,
            db,
            settings,
            auth,
            launch: LaunchManager::new(),
            instances,
            mods,
            modrinth,
            mod_ops: tokio::sync::Mutex::new(()),
            log,
        })
    }
}
