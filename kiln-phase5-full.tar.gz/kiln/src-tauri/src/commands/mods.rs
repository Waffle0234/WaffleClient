//! Mod browsing, installing, updating and modpack commands. Everything is validated in
//! `kiln-core`; the webview only ever names a project, an instance or a mod row, never a
//! file path or a URL.

use kiln_core::instance::pack::PackService;
use kiln_core::instance::Instance;
use kiln_core::launch::LaunchError;
use kiln_core::mods::modrinth::Modrinth;
use kiln_core::mods::service::{
    InstallPlan, ModService, PackUpdateInfo, PackUpdateOutcome, UpdateAllReport, UpdateInfo,
};
use kiln_core::mods::source::{
    ModSource, ModVersion, Project, SearchPage, SearchQuery, VersionFilter,
};
use kiln_core::mods::store::{ModEntry, RollbackReport};
use kiln_core::{AppError, Error};
use tauri::{AppHandle, State};

use super::progress::progress_sender;
use crate::state::AppState;

async fn service(state: &AppState) -> Result<ModService<Modrinth>, AppError> {
    let max = state.settings.load().await?.max_concurrent_downloads;
    let packs = PackService::new(state.instances.clone(), &state.dirs, max)?;
    Ok(ModService::new(
        state.modrinth.clone(),
        state.mods.clone(),
        packs,
        &state.dirs,
        max,
    )?)
}

/// Mods can't change under a running (or starting) game.
fn ensure_idle(state: &AppState, instance_id: &str) -> Result<(), AppError> {
    if state.launch.running_instance().as_deref() == Some(instance_id) {
        return Err(Error::from(LaunchError::InstanceBusy).into());
    }
    Ok(())
}

#[tauri::command]
pub async fn mod_search(
    state: State<'_, AppState>,
    query: SearchQuery,
) -> Result<SearchPage, AppError> {
    Ok(state.modrinth.search(&query).await?)
}

#[tauri::command]
pub async fn mod_project(state: State<'_, AppState>, id: String) -> Result<Project, AppError> {
    Ok(state.modrinth.project(&id).await?)
}

/// Versions of a project. With an instance, only those that fit its Minecraft version and
/// loader.
#[tauri::command]
pub async fn mod_versions(
    state: State<'_, AppState>,
    project_id: String,
    instance_id: Option<String>,
) -> Result<Vec<ModVersion>, AppError> {
    let filter = match instance_id {
        Some(id) => {
            let i = state.instances.get(&id).await?;
            VersionFilter::for_instance(i.loader, &i.mc_version)
        }
        None => VersionFilter::default(),
    };
    Ok(state.modrinth.versions(&project_id, &filter).await?)
}

#[tauri::command]
pub async fn mods_list(
    state: State<'_, AppState>,
    instance_id: String,
) -> Result<Vec<ModEntry>, AppError> {
    let _ops = state.mod_ops.lock().await;
    Ok(service(&state).await?.list(&instance_id).await?)
}

#[tauri::command]
pub async fn mod_install_plan(
    state: State<'_, AppState>,
    instance_id: String,
    project_id: String,
) -> Result<InstallPlan, AppError> {
    let _ops = state.mod_ops.lock().await;
    Ok(service(&state)
        .await?
        .plan_install(&instance_id, &project_id)
        .await?)
}

#[tauri::command]
pub async fn mod_install(
    app: AppHandle,
    state: State<'_, AppState>,
    instance_id: String,
    project_id: String,
    optional: Vec<String>,
) -> Result<InstallPlan, AppError> {
    ensure_idle(&state, &instance_id)?;
    let _ops = state.mod_ops.lock().await;
    let progress = progress_sender(&app, "mod-install");
    Ok(service(&state)
        .await?
        .install(&instance_id, &project_id, &optional, Some(progress))
        .await?)
}

#[tauri::command]
pub async fn mods_check_updates(
    state: State<'_, AppState>,
    instance_id: String,
) -> Result<Vec<UpdateInfo>, AppError> {
    let _ops = state.mod_ops.lock().await;
    Ok(service(&state).await?.check_updates(&instance_id).await?)
}

/// Returns false if the mod was already up to date.
#[tauri::command]
pub async fn mod_update(
    app: AppHandle,
    state: State<'_, AppState>,
    instance_id: String,
    mod_id: i64,
) -> Result<bool, AppError> {
    ensure_idle(&state, &instance_id)?;
    let _ops = state.mod_ops.lock().await;
    let progress = progress_sender(&app, "mod-update");
    Ok(service(&state)
        .await?
        .update_mod(&instance_id, mod_id, Some(progress))
        .await?)
}

#[tauri::command]
pub async fn mods_update_all(
    app: AppHandle,
    state: State<'_, AppState>,
    instance_id: String,
) -> Result<UpdateAllReport, AppError> {
    ensure_idle(&state, &instance_id)?;
    let _ops = state.mod_ops.lock().await;
    let progress = progress_sender(&app, "mod-update");
    Ok(service(&state)
        .await?
        .update_all(&instance_id, Some(progress))
        .await?)
}

#[tauri::command]
pub async fn mod_set_pinned(
    state: State<'_, AppState>,
    instance_id: String,
    mod_id: i64,
    pinned: bool,
) -> Result<(), AppError> {
    Ok(state.mods.set_pinned(&instance_id, mod_id, pinned).await?)
}

#[tauri::command]
pub async fn mod_set_enabled(
    state: State<'_, AppState>,
    instance_id: String,
    mod_id: i64,
    enabled: bool,
) -> Result<(), AppError> {
    ensure_idle(&state, &instance_id)?;
    let _ops = state.mod_ops.lock().await;
    Ok(state
        .mods
        .set_enabled(&instance_id, mod_id, enabled)
        .await?)
}

#[tauri::command]
pub async fn mod_remove(
    state: State<'_, AppState>,
    instance_id: String,
    mod_id: i64,
) -> Result<(), AppError> {
    ensure_idle(&state, &instance_id)?;
    let _ops = state.mod_ops.lock().await;
    Ok(state.mods.remove(&instance_id, mod_id).await?)
}

/// Undo the mod updates made since the game last started successfully.
#[tauri::command]
pub async fn mods_rollback(
    state: State<'_, AppState>,
    instance_id: String,
) -> Result<RollbackReport, AppError> {
    ensure_idle(&state, &instance_id)?;
    let _ops = state.mod_ops.lock().await;
    Ok(service(&state).await?.rollback(&instance_id).await?)
}

#[tauri::command]
pub async fn modpack_install(
    app: AppHandle,
    state: State<'_, AppState>,
    project_id: String,
) -> Result<Instance, AppError> {
    let _ops = state.mod_ops.lock().await;
    let progress = progress_sender(&app, "modpack");
    Ok(service(&state)
        .await?
        .install_modpack(&project_id, Some(progress))
        .await?)
}

#[tauri::command]
pub async fn modpack_check_update(
    state: State<'_, AppState>,
    instance_id: String,
) -> Result<Option<PackUpdateInfo>, AppError> {
    let _ops = state.mod_ops.lock().await;
    Ok(service(&state)
        .await?
        .check_modpack_update(&instance_id)
        .await?)
}

#[tauri::command]
pub async fn modpack_update(
    app: AppHandle,
    state: State<'_, AppState>,
    instance_id: String,
) -> Result<PackUpdateOutcome, AppError> {
    ensure_idle(&state, &instance_id)?;
    let _ops = state.mod_ops.lock().await;
    let progress = progress_sender(&app, "modpack");
    Ok(service(&state)
        .await?
        .update_modpack(&instance_id, Some(progress))
        .await?)
}
