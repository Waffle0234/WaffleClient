//! Progress for long operations (imports, installs, updates) reaches the UI as a
//! `task-progress` event. It carries byte and file counts only: no paths or URLs.

use kiln_core::download::Progress;
use serde::Serialize;
use tauri::{AppHandle, Emitter};
use tokio::sync::watch;

#[derive(Debug, Clone, Serialize)]
struct TaskProgress {
    task: &'static str,
    progress: Progress,
}

/// A sender for the core to report into. A background task forwards each change to the UI
/// and ends when the sender is dropped, so nothing keeps running when idle.
pub fn progress_sender(app: &AppHandle, task: &'static str) -> watch::Sender<Progress> {
    let (tx, mut rx) = watch::channel(Progress::default());
    let app = app.clone();
    tauri::async_runtime::spawn(async move {
        while rx.changed().await.is_ok() {
            let progress = *rx.borrow_and_update();
            if let Err(e) = app.emit("task-progress", TaskProgress { task, progress }) {
                tracing::debug!(error = %e, "could not emit task-progress");
            }
        }
    });
    tx
}
