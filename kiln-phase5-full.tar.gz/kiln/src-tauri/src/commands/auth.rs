//! Sign-in commands. None of these ever returns a token: the UI only sees accounts and the
//! short code the user types on Microsoft's page.

use kiln_core::auth::{is_valid_account_id, Account, AuthError, DeviceCodeInfo};
use kiln_core::{AppError, Error};
use tauri::State;

use crate::state::AppState;

fn check_id(id: &str) -> Result<(), AppError> {
    if is_valid_account_id(id) {
        Ok(())
    } else {
        Err(Error::from(AuthError::InvalidAccountId).into())
    }
}

#[tauri::command]
pub async fn auth_begin_device_flow(
    state: State<'_, AppState>,
) -> Result<DeviceCodeInfo, AppError> {
    Ok(state.auth.begin_device_flow().await?)
}

/// Resolves when the user finishes (or abandons) the sign-in started by
/// `auth_begin_device_flow`. Can take minutes; `auth_cancel` ends it early.
#[tauri::command]
pub async fn auth_poll(state: State<'_, AppState>) -> Result<Account, AppError> {
    Ok(state.auth.poll().await?)
}

#[tauri::command]
pub fn auth_cancel(state: State<'_, AppState>) {
    state.auth.cancel_flow();
}

/// Opens the sign-in page in the default browser. Takes no arguments on purpose: the
/// address comes from the validated pending flow, never from the webview.
#[tauri::command]
pub async fn auth_open_verification_page(state: State<'_, AppState>) -> Result<(), AppError> {
    let uri = state
        .auth
        .pending_verification_uri()
        .ok_or_else(|| Error::from(AuthError::NoPendingFlow))?;
    tauri::async_runtime::spawn_blocking(move || opener::open(uri))
        .await
        .map_err(|e| Error::Io(std::io::Error::other(e)))?
        .map_err(|e| Error::Io(std::io::Error::other(e.to_string())))?;
    Ok(())
}

#[tauri::command]
pub async fn auth_list_accounts(state: State<'_, AppState>) -> Result<Vec<Account>, AppError> {
    Ok(state.auth.list_accounts().await?)
}

#[tauri::command]
pub async fn auth_set_active(state: State<'_, AppState>, id: String) -> Result<Account, AppError> {
    check_id(&id)?;
    Ok(state.auth.set_active(&id).await?)
}

#[tauri::command]
pub async fn auth_remove(state: State<'_, AppState>, id: String) -> Result<(), AppError> {
    check_id(&id)?;
    Ok(state.auth.remove_account(&id).await?)
}
