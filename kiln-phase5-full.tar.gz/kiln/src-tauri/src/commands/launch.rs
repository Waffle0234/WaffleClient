//! Game launching commands. Progress and output reach the UI as events (`launch-status`,
//! `game-log`); no command or event ever carries a token.

use std::sync::Arc;

use kiln_core::instance::parse_jvm_args;
use kiln_core::java::JavaManager;
use kiln_core::launch::{
    LaunchDeps, LaunchError, LaunchEvents, LaunchRequest, LaunchStatus, LogLine,
};
use kiln_core::loader::LoaderClient;
use kiln_core::mods::store::RollbackReport;
use kiln_core::mojang::MojangClient;
use kiln_core::{AppError, Error};
use tauri::{AppHandle, Emitter, State};

use crate::state::AppState;

struct TauriEvents(AppHandle);

impl LaunchEvents for TauriEvents {
    fn status(&self, status: &LaunchStatus) {
        if let Err(e) = self.0.emit("launch-status", status) {
            tracing::debug!(error = %e, "could not emit launch-status");
        }
    }

    fn log(&self, line: &LogLine) {
        // Lines were redacted in kiln-core before they got here.
        if let Err(e) = self.0.emit("game-log", line) {
            tracing::debug!(error = %e, "could not emit game-log");
        }
    }

    fn rolled_back(&self, report: &RollbackReport) {
        if let Err(e) = self.0.emit("mods-rolled-back", report) {
            tracing::debug!(error = %e, "could not emit mods-rolled-back");
        }
    }
}

/// Start the game from a stored instance, using the active account.
#[tauri::command]
pub async fn launch_start(
    app: AppHandle,
    state: State<'_, AppState>,
    instance_id: String,
) -> Result<(), AppError> {
    if state.launch.is_active() {
        return Err(Error::from(LaunchError::AlreadyRunning).into());
    }
    // Don't start the game while mods or a modpack are being changed.
    let _no_mod_changes = state
        .mod_ops
        .try_lock()
        .map_err(|_| Error::from(LaunchError::InstanceBusy))?;
    let instance = state.instances.get(&instance_id).await?;
    let game_dir = state.instances.game_dir(&instance_id).await?;
    let account = state
        .auth
        .list_accounts()
        .await?
        .into_iter()
        .find(|a| a.is_active)
        .ok_or_else(|| Error::from(LaunchError::NoAccount))?;
    let settings = state.settings.load().await?;
    let max = settings.max_concurrent_downloads;
    // Refreshes the Microsoft sign-in if needed; the session never leaves the backend.
    let session = state.auth.session_for_launch(&account.id).await?;

    let mojang = MojangClient::new(&state.dirs.cache, max)?;
    let java = JavaManager::new(state.db.clone(), &state.dirs.java, max)?;
    let java_path = match &instance.java_id {
        Some(id) => java.runtime_path(id).await?,
        None => None,
    };
    let jvm_args = match instance.jvm_args.as_deref() {
        Some(args) => parse_jvm_args(args)?,
        None => Vec::new(),
    };
    let deps = LaunchDeps {
        dirs: state.dirs.clone(),
        loaders: LoaderClient::new(mojang.clone(), max)?,
        mojang,
        java,
        instances: Some(state.instances.clone()),
        mods: Some(state.mods.clone()),
    };
    let request = LaunchRequest {
        mc_version: instance.mc_version,
        loader: instance.loader,
        loader_version: instance.loader_version,
        game_dir,
        instance_id: Some(instance.id),
        ram_mb: instance.ram_mb.or(settings.default_ram_mb),
        jvm_args,
        java_path,
    };
    state
        .launch
        .start(deps, request, session, Arc::new(TauriEvents(app)))?;
    Ok(())
}

#[tauri::command]
pub fn launch_stop(state: State<'_, AppState>) -> Result<(), AppError> {
    Ok(state.launch.stop()?)
}

#[tauri::command]
pub fn launch_status(state: State<'_, AppState>) -> LaunchStatus {
    state.launch.status()
}

/// The most recent game output, for a console opened after the game started.
#[tauri::command]
pub fn launch_log(state: State<'_, AppState>) -> Vec<LogLine> {
    state.launch.log_tail()
}
