//! Instance management commands. The webview never supplies a file path: imports name a
//! file inside Kiln's `imports/` folder and exports are written to `exports/`.

use kiln_core::instance::pack::{ImportFile, PackService};
use kiln_core::instance::{Instance, InstanceSettings, NewInstance};
use kiln_core::loader::{LoaderClient, LoaderKind, LoaderVersion};
use kiln_core::mods::service::ModService;
use kiln_core::mojang::{MojangClient, VersionSummary};
use kiln_core::{AppError, Error};
use serde::Deserialize;
use tauri::State;

use crate::state::AppState;

fn parse_loader(loader: &str) -> Result<LoaderKind, AppError> {
    LoaderKind::parse(loader).ok_or_else(|| {
        Error::InvalidSetting {
            key: "loader".into(),
            reason: "choose Vanilla, Fabric, Quilt, NeoForge or Forge".into(),
        }
        .into()
    })
}

async fn clients(state: &AppState) -> Result<(MojangClient, LoaderClient), AppError> {
    let max = state.settings.load().await?.max_concurrent_downloads;
    let mojang = MojangClient::new(&state.dirs.cache, max)?;
    let loaders = LoaderClient::new(mojang.clone(), max)?;
    Ok((mojang, loaders))
}

/// Minecraft versions that work with `loader`, newest first. Versions the loader supports
/// but Mojang no longer lists are left out, so every choice can actually be launched.
#[tauri::command]
pub async fn picker_game_versions(
    state: State<'_, AppState>,
    loader: String,
) -> Result<Vec<VersionSummary>, AppError> {
    let kind = parse_loader(&loader)?;
    let (mojang, loaders) = clients(&state).await?;
    let all = mojang.manifest().await?.summaries();
    if kind == LoaderKind::Vanilla {
        return Ok(all);
    }
    let supported: std::collections::HashSet<String> =
        loaders.game_versions(kind).await?.into_iter().collect();
    Ok(all
        .into_iter()
        .filter(|v| supported.contains(&v.id))
        .collect())
}

#[tauri::command]
pub async fn picker_loader_versions(
    state: State<'_, AppState>,
    loader: String,
    mc_version: String,
) -> Result<Vec<LoaderVersion>, AppError> {
    let kind = parse_loader(&loader)?;
    let (_, loaders) = clients(&state).await?;
    Ok(loaders.loader_versions(kind, &mc_version).await?)
}

#[tauri::command]
pub async fn instance_list(state: State<'_, AppState>) -> Result<Vec<Instance>, AppError> {
    Ok(state.instances.list().await?)
}

#[tauri::command]
pub async fn instance_create(
    state: State<'_, AppState>,
    name: String,
    mc_version: String,
    loader: String,
    loader_version: Option<String>,
) -> Result<Instance, AppError> {
    Ok(state
        .instances
        .create(NewInstance {
            name,
            mc_version,
            loader: parse_loader(&loader)?,
            loader_version,
        })
        .await?)
}

#[tauri::command]
pub async fn instance_rename(
    state: State<'_, AppState>,
    id: String,
    name: String,
) -> Result<Instance, AppError> {
    Ok(state.instances.rename(&id, &name).await?)
}

#[tauri::command]
pub async fn instance_clone(
    state: State<'_, AppState>,
    id: String,
    name: String,
) -> Result<Instance, AppError> {
    Ok(state.instances.clone_instance(&id, &name).await?)
}

#[tauri::command]
pub async fn instance_delete(state: State<'_, AppState>, id: String) -> Result<(), AppError> {
    let running = state.launch.running_instance().as_deref() == Some(id.as_str());
    Ok(state.instances.delete(&id, running).await?)
}

#[tauri::command]
pub async fn instance_update_settings(
    state: State<'_, AppState>,
    id: String,
    ram_mb: Option<u32>,
    jvm_args: Option<String>,
) -> Result<Instance, AppError> {
    // The Java runtime choice is kept as it was: this command only edits memory and flags.
    let current = state.instances.get(&id).await?;
    Ok(state
        .instances
        .update_settings(
            &id,
            InstanceSettings {
                ram_mb,
                jvm_args,
                java_id: current.java_id,
            },
        )
        .await?)
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum ExportFormat {
    Kiln,
    Mrpack,
}

async fn packs(state: &AppState) -> Result<PackService, AppError> {
    let max = state.settings.load().await?.max_concurrent_downloads;
    Ok(PackService::new(state.instances.clone(), &state.dirs, max)?)
}

#[derive(Debug, serde::Serialize)]
pub struct ExportResult {
    pub file: String,
    /// Mods listed by Modrinth hash instead of being copied into the pack.
    pub listed: usize,
    /// Jars Modrinth doesn't know, which the pack bundles. The person should check they may
    /// share them.
    pub bundled_unverified: Vec<String>,
}

/// Writes the pack to the exports folder and returns its file name.
#[tauri::command]
pub async fn instance_export(
    state: State<'_, AppState>,
    id: String,
    format: ExportFormat,
) -> Result<ExportResult, AppError> {
    Ok(match format {
        ExportFormat::Kiln => ExportResult {
            file: packs(&state).await?.export_native(&id).await?,
            listed: 0,
            bundled_unverified: Vec::new(),
        },
        ExportFormat::Mrpack => {
            let _ops = state.mod_ops.lock().await;
            let max = state.settings.load().await?.max_concurrent_downloads;
            let svc = ModService::new(
                state.modrinth.clone(),
                state.mods.clone(),
                packs(&state).await?,
                &state.dirs,
                max,
            )?;
            let out = svc.export_mrpack(&id).await?;
            ExportResult {
                file: out.file,
                listed: out.listed,
                bundled_unverified: out.bundled_unverified,
            }
        }
    })
}

#[tauri::command]
pub async fn instance_list_imports(
    state: State<'_, AppState>,
) -> Result<Vec<ImportFile>, AppError> {
    Ok(packs(&state).await?.list_imports()?)
}

/// Import a pack that sits in the imports folder, by file name.
#[tauri::command]
pub async fn instance_import(
    app: tauri::AppHandle,
    state: State<'_, AppState>,
    file_name: String,
) -> Result<Instance, AppError> {
    let progress = super::progress::progress_sender(&app, "import");
    Ok(packs(&state)
        .await?
        .import(&file_name, Some(progress))
        .await?)
}

/// Open one of Kiln's folders in the system file manager. Only fixed choices are accepted.
#[tauri::command]
pub async fn open_folder(
    state: State<'_, AppState>,
    which: String,
    id: Option<String>,
) -> Result<(), AppError> {
    let path = match (which.as_str(), id) {
        ("imports", _) => state.dirs.imports.clone(),
        ("exports", _) => state.dirs.exports.clone(),
        ("instance", Some(id)) => state.instances.game_dir(&id).await?.as_path().to_path_buf(),
        _ => {
            return Err(Error::InvalidSetting {
                key: "folder".into(),
                reason: "choose imports, exports or an instance".into(),
            }
            .into())
        }
    };
    tauri::async_runtime::spawn_blocking(move || opener::open(path))
        .await
        .map_err(|e| Error::Io(std::io::Error::other(e)))?
        .map_err(|e| Error::Io(std::io::Error::other(e.to_string())))?;
    Ok(())
}
