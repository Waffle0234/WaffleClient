use kiln_core::settings::Settings;
use kiln_core::AppError;
use serde::Serialize;
use tauri::State;

use crate::state::AppState;

#[derive(Debug, Serialize)]
pub struct AppInfo {
    pub name: &'static str,
    pub version: &'static str,
    pub os: &'static str,
    pub arch: &'static str,
    pub portable: bool,
    pub data_dir: String,
}

#[tauri::command]
pub fn get_app_info(state: State<'_, AppState>) -> AppInfo {
    AppInfo {
        name: kiln_core::APP_NAME,
        version: kiln_core::APP_VERSION,
        os: std::env::consts::OS,
        arch: std::env::consts::ARCH,
        portable: state.dirs.portable,
        data_dir: state.dirs.root.display().to_string(),
    }
}

#[tauri::command]
pub async fn get_settings(state: State<'_, AppState>) -> Result<Settings, AppError> {
    Ok(state.settings.load().await?)
}

#[tauri::command]
pub async fn set_setting(
    state: State<'_, AppState>,
    key: String,
    value: serde_json::Value,
) -> Result<Settings, AppError> {
    let updated = state.settings.set(&key, value).await?;
    if key == "log_level" {
        state.log.set_level(&updated.log_level)?;
    }
    Ok(updated)
}
